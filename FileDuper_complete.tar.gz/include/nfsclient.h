#ifndef NFSCLIENT_H
#define NFSCLIENT_H

#include <string>

class NfsClient {
public:
    NfsClient() {}
    ~NfsClient() {}
    
    // Stub methods - not implemented yet
    bool connectToHost(const std::string& host) { return false; }
};

#endif // NFSCLIENT_H
