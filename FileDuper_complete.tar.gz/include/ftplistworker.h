#ifndef FTPLISTWORKER_H
#define FTPLISTWORKER_H
// Stub header
#endif
