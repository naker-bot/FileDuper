#ifndef FTPDELETEWORKER_H
#define FTPDELETEWORKER_H
// Stub
#endif
