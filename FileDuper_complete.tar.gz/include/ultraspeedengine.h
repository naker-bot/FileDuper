#ifndef ULTRASPEEDENGINE_H
#define ULTRASPEEDENGINE_H
class UltraSpeedEngine {
public:
    UltraSpeedEngine() {}
    ~UltraSpeedEngine() {}
};
#endif
