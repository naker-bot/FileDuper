#ifndef NPUMANAGER_H
#define NPUMANAGER_H
// Stub
#endif
