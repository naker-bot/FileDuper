#ifndef HARDWAREBENCHMARK_H
#define HARDWAREBENCHMARK_H
class HardwareBenchmark {
public:
    HardwareBenchmark() {}
    ~HardwareBenchmark() {}
};
#endif
