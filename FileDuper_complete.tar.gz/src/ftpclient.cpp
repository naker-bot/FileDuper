#include "ftpclient.h"
#include <iostream>

// FTP functionality is fully implemented in main.cpp via libcurl
// This file exists only for linking compatibility

FtpClient::FtpClient() {
}

FtpClient::~FtpClient() {
}
