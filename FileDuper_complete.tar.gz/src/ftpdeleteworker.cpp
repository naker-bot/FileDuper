#include "ftpdeleteworker.h"
