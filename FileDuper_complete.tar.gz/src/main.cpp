// FileDuper - ImGui Version
// Full-featured duplicate file scanner with GUI

#define GLFW_EXPOSE_NATIVE_X11
#include "tree_view.h"
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include <iostream>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cstdio>
#include <sys/stat.h>
#include <dirent.h>
#include <algorithm>
#include <numeric>
#include <unistd.h>
#include <sys/types.h>
#include <mntent.h>
#include <sys/statvfs.h>
#include <cstring>
#include <thread>
#include <mutex>
#include <atomic>
#include <future>
#include <chrono>
#include <queue>
#include <unordered_map>
#include <curl/curl.h>
#include <openssl/md5.h>
#include <iomanip>
#include <cmath>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/mount.h>
#include <sys/vfs.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// FTP/NFS/SMB/WebDAV Server Preset
struct FtpPreset {
    std::string name;
    std::string ip;
    std::string serviceType; // "FTP", "SMB", "NFS", "WebDAV"
    int port;
    std::string username;
    std::string password;
    std::vector<std::string> directories; // Discovered directories
    
    // NFS-specific fields
    std::string nfsExportPath; // z.B. "/export/data"
    std::string nfsMountPoint; // z.B. "/mnt/nfs_server1"
    std::string nfsOptions; // z.B. "vers=4,rw,nolock"
    bool nfsAutoMount = false; // Auto-mount beim Start
    bool nfsMounted = false; // Aktueller Mount-Status
    
    // SMB/CIFS-specific fields
    std::string smbSharePath; // z.B. "//192.168.1.100/shared"
    std::string smbMountPoint; // z.B. "/mnt/smb_share"
    std::string smbDomain; // Windows Domain (optional)
    std::string smbWorkgroup; // Workgroup (optional)
    std::string smbOptions; // z.B. "vers=3.0,uid=1000,gid=1000"
    bool smbAutoMount = false; // Auto-mount beim Start
    bool smbMounted = false; // Aktueller Mount-Status
    
    // WebDAV-specific fields
    std::string davUrl; // z.B. "https://cloud.example.com/remote.php/dav/files/username/"
    std::string davMountPoint; // z.B. "/mnt/webdav"
    std::string davOptions; // z.B. "uid=1000,gid=1000,file_mode=0600,dir_mode=0700"
    bool davUseSSL = true; // HTTPS vs HTTP
    bool davAutoMount = false; // Auto-mount beim Start
    bool davMounted = false; // Aktueller Mount-Status
};

// Duplicate File Group
struct DuplicateGroup {
    std::string hash;
    long long size;
    std::vector<std::string> files;
    std::vector<time_t> mtimes; // Cached modification times (parallel to files vector)
    bool sorted = false; // Flag to indicate if files are sorted by mtime
};

// Application State
struct AppState {
    // Sudo Password Caching (once per session)
    std::string sudoPassword = "";
    bool sudoPasswordAvailable = false;
    bool showSudoPasswordPrompt = false;
    time_t sudoPasswordCacheTime = 0;  // Timestamp when password was cached
    
    // Selected directories for scanning
    std::set<std::string> selectedLocalDirs;
    std::set<std::string> selectedFtpDirs;
    std::vector<std::string> savedFtpIPs;
    
    // FTP Server Presets
    std::vector<FtpPreset> ftpPresets;
    
    // Currently connected FTP server
    int connectedPresetIndex = -1;
    bool isConnected = false;
    std::vector<std::string> serverDirectories; // Vom Server geholte Verzeichnisse
    std::set<std::string> selectedServerDirs; // Mehrfachauswahl
    bool showCredentialsDialog = false;
    bool showServerBrowser = false;
    bool showSmbMountDialog = false; // Neues Flag für SMB-Mount-Dialog
    int selectedSmbPresetForMount = -1; // Welche SMB-Preset wurde gemountet
    std::string connectionStatus = ""; // Status-Meldung während Verbindungsaufbau
    std::mutex serverDirectoriesMutex; // Mutex für Thread-sicheren Zugriff auf serverDirectories
    bool isScanningFtp = false; // Flag ob FTP-Scan läuft
    
    // NFS Local Browser
    std::string selectedNfsMountPath = ""; // Welches NFS-Mount wird gerade angezeigt
    std::string lastNfsMountPath = "";     // Letzter verwendeter Mount für Auto-Unmount
    bool nfsAutoUnmount = true;              // Auto-Unmount wenn Browser geschlossen wird
    bool savePasswordsPermanently = true;    // Passwörter dauerhaft speichern (Standard: AN)
    std::string nfsSearchTerm = "";         // NFS-Suchbegriff
    std::vector<std::string> nfsSearchResults; // Async Suchergebnisse
    std::atomic<bool> nfsSearchActive{false};  // Suche läuft im Hintergrund
    std::string nfsSearchRootPath = "";     // Wurzelpfad der aktuellen Suche
    
    // Scan state
    bool scanning = false;
    float scanProgress = 0.0f;
    std::string scanStatus = "Bereit";
    std::string currentHashingFile = ""; // Aktuell bearbeitete Datei beim Hashen
    int filesScanned = 0;
    int totalFiles = 0;
    long long totalBytes = 0;
    long long bytesProcessed = 0;
    
    // FTP Directory Scan Progress (NEW)
    std::atomic<int> ftpDirsProcessed{0};
    std::atomic<int> ftpTotalDirsEstimate{0};
    
    // Performance metrics
    float hashSpeed = 0.0f; // MB/s - Hash calculation speed
    float scanSpeed = 0.0f; // MB/s - File reading speed (local/network)
    float filesPerSecond = 0.0f;
    int threadsActive = 0;
    time_t scanStartTime = 0;
    time_t estimatedTimeRemaining = 0;
    
    // Bandwidth & Hardware Status
    float diskBandwidth = 0.0f; // MB/s - measured before scan
    float networkBandwidth = 0.0f; // MB/s - for FTP
    float cpuUsage = 0.0f; // Percentage 0-100
    float gpuUsage = 0.0f; // Percentage 0-100
    float npuUsage = 0.0f; // Percentage 0-100
    float gpuPower = 0.0f; // GPU power consumption in Watts
    float gpuMemBandwidth = 0.0f; // GPU memory bandwidth in GB/s
    float gpuHashSpeed = 0.0f; // GPU hash speed in GB/s
    long long ramUsageKB = 0; // RAM usage in KB
    int cpuTemp = 0; // Celsius
    std::string currentHashAlgo = "AUTO"; // Currently used algorithm
    bool bandwidthTested = false;
    bool hasNPU = false; // Wird beim Start erkannt
    
    // AVX2 Performance Profile Settings
    std::string avx2Profile = "Maximum"; // Maximum, Balanced, Compatible
    bool avx2ForceEnabled = false;       // Override auto-detection
    int avx2MinFileSize = 4096;          // Minimum file size for AVX2 (bytes)
    
    // Window maximize state
    bool windowMaximized = false;
    int savedWindowWidth = 1400;
    int savedWindowHeight = 900;
    int savedWindowPosX = 0;
    int savedWindowPosY = 0;
    
    // Results
    int duplicateGroups = 0;
    int duplicateFiles = 0;
    long long duplicateSize = 0;
    long long totalSize = 0;  // Total size of all scanned files
    std::vector<DuplicateGroup> duplicates;
    std::map<std::string, std::vector<std::string>> filesByHash; // Hash -> Filepaths
    
    // Duplicate file selection (for deletion)
    std::map<std::string, bool> markedForDeletion; // filepath -> marked
    
    // UI State
    bool showAbout = false;
    bool showSettings = false;
    bool showLocalBrowser = false;
    bool showFtpBrowser = false;
    bool showResults = false;
    bool showNetworkScanner = false;
    bool showDeleteSuccess = false;
    int deletedFilesCount = 0;
    long long deletedFilesSize = 0;
    
    // File access error tracking
    bool showFileErrorDialog = false;
    std::vector<std::string> inaccessibleFiles;
    std::mutex inaccessibleFilesMutex;
    int totalInaccessibleFiles = 0;
    
    // Settings confirmation
    bool showSettingsRestoredMessage = false;
    float settingsMessageTimer = 0.0f;
    
    // Network/FTP state
    std::vector<std::string> discoveredHosts;
    std::string selectedFtpHost = "";
    std::string ftpUsername = "anonymous";
    std::string ftpPassword = "";
    int ftpPort = 21;
    bool scanningNetwork = false;
    int switchToFtpTab = 0; // 0 = kein Wechsel, 1 = zur FTP-Verbindung wechseln
    std::atomic<int> scannedHosts{0};
    std::atomic<int> totalHostsToScan{0};
    
    // Network bandwidth tracking for FTP
    std::atomic<long long> ftpBytesTransferred{0};
    std::chrono::steady_clock::time_point ftpScanStartTime;
    std::atomic<bool> scanThreadRunning{false};
    
    // Directory Tree Settings (NEW)
    int localTreeMaxDepth = 3;      // Max Verzeichnistiefe für lokalen Browser (Reduziert von 10 auf 3 wegen NFS-Performance)
    int ftpTreeMaxDepth = 7;         // Max Verzeichnistiefe für FTP Browser (Default: 7)
    bool treeSearchShowSubdirs = false; // Unterverzeichnisse von Suchergebnissen anzeigen (Default: false)
    std::vector<std::string> searchHistory; // Such-History für schnellen Zugriff
    int maxSearchHistory = 20;       // Maximale Anzahl gespeicherter Suchbegriffe
    
    // FTP Scan Optimization Settings (NEW - Ultra-Fast Defaults)
    int ftpMaxThreads = 16;          // Parallele FTP-Verbindungen (16 für maximale Speed)
    int ftpScanMaxDepth = 30;        // Max Verzeichnistiefe beim SCANNEN (30 für tiefe Strukturen)
    int ftpConnectTimeout = 2;       // Connect timeout in Sekunden (2s für Speed)
    int ftpResponseTimeout = 5;      // Response timeout (5s)
    bool ftpUseParallelScan = true;  // Paralleler Scan ab Tiefe 1 (ON)
    bool ftpUseLsR = true;           // LIST -R verwenden (maximale Geschwindigkeit) - DEFAULT: ON!
    
    // Post-Scan Actions (NEW)
    bool postScanActionEnabled = false;
    int postScanAction = 0;          // 0=Nichts, 1=Herunterfahren, 2=Suspend, 3=Hibernate, 4=Benachrichtigung, 5=Duplikate löschen
    int postScanDelay = 60;          // Verzögerung in Sekunden vor Aktion
    int autoDeleteMode = 0;          // Für Aktion 5: 0=Älteste behalten, 1=Neueste behalten, 2=Erste behalten
    
    // Scan State Management (NEW)
    std::atomic<bool> scanPaused{false};
    bool autoSaveScanState = true;   // Automatisches Speichern des Scan-Fortschritts
    std::string scanStateFile = "";  // Aktueller Scan-State Pfad
    bool showSaveStateDialog = false;
    bool showLoadStateDialog = false;
    char saveStateFilename[256] = "scan_state.fds"; // FileDuper Scan State
    
    // Status notifications (NEW)
    std::string statusNotification = "";
    float statusNotificationTimer = 0.0f;
    ImVec4 statusNotificationColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    
    // Settings
    int threadCount = 8; // Erhöht von 4 auf 8 für bessere Multi-Core Nutzung
    int scannerThreads = 128; // Lightning Speed: Anzahl paralleler IP-Scans (erhöht für mehr Speed)
    int scanTimeout = 1; // Timeout in Sekunden pro Host
    bool useLightningSpeed = true;
    int minFileSize = 0; // Geändert von 1024 auf 0 - ALLE Dateien scannen (auch kleinste)
    bool scanHiddenFiles = true;  // Default: AN - versteckte Dateien einbeziehen
    bool followSymlinks = true;   // Default: AN - symbolischen Links folgen
    bool deleteEmptyDirs = true;  // Default: AN - leere Verzeichnisse automatisch löschen (außer Systemordner)
    bool useGPU = false;
    
    // Hash Settings
    std::string hashAlgorithm = "AUTO"; // AUTO, MD5, SHA1, SHA256, SHA512, BLAKE2B, BLAKE3, XXHASH64, XXHASH3
    std::string hashPreset = "AUTO"; // AUTO, FAST, BALANCED, SECURE
    bool useHardwareAcceleration = true;
    std::string detectedHardware = "CPU"; // CPU, GPU, NPU, CPU_SIMD
    bool useFastHash = true; // XXHASH64 vs MD5
    int bufferSize = 8192; // KB
    bool autoExportResults = false;
    std::string exportPath = "./duplicates.csv";
    
    // Neue Performance-Optimierungen
    bool useAsyncIO = true;          // Async I/O für Datei-Scanning
    bool useCurlPooling = true;      // CURL Connection Pooling
    bool useMemoryMapping = true;    // mmap() für große Dateien - AKTIVIERT für Speed
    bool useTCPPing = true;          // TCP Connect statt system() ping
    int batchScanSize = 20;          // Erhöht von 10 auf 20 - mehr Batch-Scans
    bool autoTuneThreads = true;     // Auto-Thread-Anzahl basierend auf CPU - AKTIVIERT
    bool cacheFileHashes = true;     // Hash-Cache für bekannte Dateien
    bool skipEmptyFiles = true;      // Leere Dateien überspringen
    bool smartTimeout = true;        // Adaptiver Timeout basierend auf Netzwerk
    
    // Performance Tuning Settings (NEW)
    int hashBatchSize = 10000;       // Batch-Größe für Hash-Ergebnisse (10000 = weniger Mutex-Locks)
    int statusUpdateInterval = 1000; // Status-Update alle X Dateien (1000 = weniger UI-Updates)
    
    // PARALLEL PROCESSING SETTINGS (NEW - Maximale Parallelisierung)
    bool parallelDirectoryScan = true;      // Paralleles Scannen mehrerer Verzeichnisse (AKTIVIERT)
    int dirScanThreads = 8;                 // Anzahl Threads für paralleles Directory-Scanning (8 = optimal für 24 Cores)
    bool parallelFtpDirScan = true;         // Paralleles FTP Directory Scanning (AKTIVIERT)
    int ftpDirScanThreads = 4;              // Threads für paralleles FTP-Scanning (4 = optimal)
    bool parallelCleanup = true;            // Parallele Post-Scan Bereinigung (AKTIVIERT)
    int cleanupThreads = 4;                 // Threads für Cleanup-Operationen (4 = schnell)
    bool parallelCacheLoad = true;          // Paralleles Laden von Caches (AKTIVIERT)
    int cacheLoadThreads = 4;               // Threads zum Cache-Laden (4 = optimal)
    
    // FTP Hash Performance Settings (NEW)
    int ftpHashTimeout = 5;          // FTP Hash Timeout in Sekunden (5s = schnell, 60s = langsam)
    int ftpHashRetries = 3;          // Anzahl Wiederholungsversuche bei FTP Hash-Fehlern
    bool ftpSkipFailedFiles = true;  // Überspringe Dateien nach max. Retries (sonst ewig hängen)
    int ftpMaxConnections = 8;       // Max. parallele FTP-Verbindungen pro Server (8 = schnell, 1 = langsam)
    bool ftpReuseConnections = true; // Wiederverwendung von FTP-Verbindungen (SEHR schnell!)
    int ftpMinFileSize = 100;        // Min. Dateigröße für FTP-Hash (Bytes) - kleinere werden übersprungen (zu viel Overhead)
    
    // FTP/Network Optimierungen (ftpConnectTimeout is declared above in FTP Scan Optimization Settings)
    int ftpMaxRetries = 3;           // FTP Verbindungs-Wiederholungen
    int ftpReadTimeout = 15;         // FTP Read Timeout (Sekunden)
    bool ftpPipelining = true;       // HTTP/FTP Pipelining
    bool ftpKeepAlive = true;        // TCP Keep-Alive
    int curlBufferSize = 512000;     // CURL Buffer Size (bytes) - default 500KB for max performance
    
    // Theme
    int currentTheme = 3; // Quake 3 Light Blue als Default
    const char* themes[33] = {
        "Dark", "Light", "Classic", "Quake 3", "Nord Dark", 
        "Dracula", "Monokai", "Solarized Dark", "Solarized Light", "Gruvbox Dark",
        "Material Dark", "Material Light", "One Dark", "Atom Dark", "VS Dark",
        "VS Light", "GitHub Dark", "GitHub Light", "Oceanic Next", "Tomorrow Night",
        "Cyberpunk", "Synthwave", "Vaporwave", "Forest", "Desert",
        "Ocean", "Sunset", "Midnight", "Ice", "Fire",
        "Purple Haze", "Golden", "Matrix"
    };
};

static AppState appState;
static std::thread scanThread;
static std::atomic<bool> stopScan(false);

// HASH CACHE: Store computed hashes to avoid recalculating
// Key: (inode, mtime) - identifies unique file state
// Value: hash string
// Hash functor for pair<ino_t, time_t>
struct PairHash {
    std::size_t operator()(const std::pair<ino_t, time_t>& p) const {
        return std::hash<ino_t>()(p.first) ^ (std::hash<time_t>()(p.second) << 1);
    }
};

static std::unordered_map<std::pair<ino_t, time_t>, std::string, PairHash> hashCache;
static std::mutex hashCacheMutex;

// FILE CACHE: Store file listings (local + FTP) to accelerate subsequent scans
// Key: Full file path (local: /path/to/file, FTP: ftp://host:port/path/to/file)
// Value: {size, mtime, inode, hash} - file metadata
struct CachedFileInfo {
    long long size;
    time_t mtime;
    ino_t inode;      // 0 for FTP files (they don't have inodes)
    std::string hash; // Optional - filled during hash calculation
};
static std::map<std::string, CachedFileInfo> fileCache; // Combined local + FTP cache
static std::mutex fileCacheMutex;
static std::string localCacheFilePath = "local_cache.dat";
static std::string ftpCacheFilePath = "ftp_cache.dat";

// DIRECTORY CACHE: Store scanned directories for faster loading
static std::vector<std::string> cachedLocalDirs;
static std::mutex dirCacheMutex;
static std::string dirCacheFilePath = "directory_cache.dat";
static time_t dirCacheTimestamp = 0;

// FTP DIRECTORY CACHE: Store FTP server directory trees
struct FTPDirCacheEntry {
    std::string path;
    std::vector<std::string> subdirs;
    time_t timestamp;
};
static std::unordered_map<std::string, FTPDirCacheEntry> ftpDirCache; // Key: server:port/path
static std::mutex ftpDirCacheMutex;
static std::string ftpDirCacheFilePath = "ftp_directory_cache.dat";

// TREE STATE CACHE: Store expanded nodes for faster tree rendering
static std::set<std::string> expandedNodes;
static std::mutex expandedNodesMutex;
static std::string treeStateFilePath = "tree_state.dat";

static std::mutex resultsMutex;

// CURL Connection Pooling für FTP-Performance
static CURLSH* curlShareHandle = nullptr;
static std::recursive_mutex curlShareMutex; // CRITICAL: recursive_mutex for CURL re-locking!

// CURL Share Lock/Unlock callbacks (CRITICAL for thread-safety!)
static void curlShareLockCallback(CURL* handle, curl_lock_data data, curl_lock_access access, void* userptr) {
    std::recursive_mutex* mtx = static_cast<std::recursive_mutex*>(userptr);
    mtx->lock();
}

static void curlShareUnlockCallback(CURL* handle, curl_lock_data data, void* userptr) {
    std::recursive_mutex* mtx = static_cast<std::recursive_mutex*>(userptr);
    mtx->unlock();
}

void initCurlSharing() {
    curlShareHandle = curl_share_init();
    if (curlShareHandle) {
        // Set lock/unlock callbacks for thread-safety
        curl_share_setopt(curlShareHandle, CURLSHOPT_LOCKFUNC, curlShareLockCallback);
        curl_share_setopt(curlShareHandle, CURLSHOPT_UNLOCKFUNC, curlShareUnlockCallback);
        curl_share_setopt(curlShareHandle, CURLSHOPT_USERDATA, &curlShareMutex);
        
        // Share DNS, SSL sessions, and connections
        curl_share_setopt(curlShareHandle, CURLSHOPT_SHARE, CURL_LOCK_DATA_DNS);
        curl_share_setopt(curlShareHandle, CURLSHOPT_SHARE, CURL_LOCK_DATA_SSL_SESSION);
        curl_share_setopt(curlShareHandle, CURLSHOPT_SHARE, CURL_LOCK_DATA_CONNECT);
        
        std::cout << "[CURL] Connection pooling enabled (thread-safe)" << std::endl;
    }
}

void cleanupCurlSharing() {
    if (curlShareHandle) {
        curl_share_cleanup(curlShareHandle);
        curlShareHandle = nullptr;
    }
}

// Forward declarations
void performScan();
bool deleteFtpFile(const std::string& ftpUrl, const std::string& username, const std::string& password);
void saveTreeState();
void loadTreeState();
bool deleteFile(const std::string& filepath);
bool deleteEmptyDirectories(const std::string& path, int& deletedCount);
std::vector<std::string> getFtpSubdirectories(const std::string& ftpDir, const std::string& baseUrl,
                                              const std::string& username, const std::string& password,
                                              bool useCache);
bool hasAVX2Support();
float getGpuPower();
float getGpuMemBandwidth();
long long getCurrentRAMUsageKB();

// Get current RAM usage in KB
long long getCurrentRAMUsageKB() {
    long long ramKB = 0;
#ifdef __linux__
    std::ifstream statFile("/proc/self/status");
    std::string line;
    while (std::getline(statFile, line)) {
        if (line.find("VmRSS:") == 0) {
            std::istringstream iss(line);
            std::string label;
            iss >> label >> ramKB;
            break;
        }
    }
#endif
    return ramKB;
}

// Save/Load Theme Settings
void saveThemeSettings() {
    std::ofstream file(std::string(getenv("HOME")) + "/.fileduper_theme.cfg");
    if (file.is_open()) {
        file << appState.currentTheme << std::endl;
        file.close();
        std::cout << "[Config] Theme saved: " << appState.themes[appState.currentTheme] << std::endl;
    }
}

void loadThemeSettings() {
    std::ifstream file(std::string(getenv("HOME")) + "/.fileduper_theme.cfg");
    if (file.is_open()) {
        int theme;
        file >> theme;
        if (theme >= 0 && theme < 33) {
            appState.currentTheme = theme;
            std::cout << "[Config] Theme loaded: " << appState.themes[appState.currentTheme] << std::endl;
        }
        file.close();
    } else {
        // Default: Quake 3
        appState.currentTheme = 3;
        std::cout << "[Config] Using default theme: " << appState.themes[appState.currentTheme] << std::endl;
    }
}

// Forward declarations
void saveScannerSettings();
void restoreDefaultSettings();

// Create default configuration files with optimal performance settings
void createDefaultConfigs() {
    std::string homeDir = std::string(getenv("HOME"));
    
    // Check and create theme config
    std::string themeFile = homeDir + "/.fileduper_theme.cfg";
    std::ifstream themeCheck(themeFile);
    if (!themeCheck.good()) {
        std::ofstream theme(themeFile);
        if (theme.is_open()) {
            theme << "3" << std::endl; // Default: Quake 3 Light Blue
            theme.close();
            std::cout << "[Config] Created default theme config: Quake 3 Light Blue" << std::endl;
        }
    }
    themeCheck.close();
    
    // Check and create scanner config with optimal performance settings
    std::string scannerFile = homeDir + "/.fileduper_scanner.cfg";
    std::ifstream scannerCheck(scannerFile);
    if (!scannerCheck.good()) {
        // Scanner config doesn't exist - will be created by saveScannerSettings() later
        // Just set a marker so we know to create it
        std::cout << "[Config] Scanner config will be created with all 45 settings on first save" << std::endl;
    }
    scannerCheck.close();
    
    // Check and create FTP presets config
    std::string ftpFile = homeDir + "/.fileduper_ftp_presets.cfg";
    std::ifstream ftpCheck(ftpFile);
    if (!ftpCheck.good()) {
        std::ofstream ftp(ftpFile);
        if (ftp.is_open()) {
            // Create with empty content (user will add presets)
            ftp.close();
            std::cout << "[Config] Created empty FTP presets config" << std::endl;
        }
    }
    ftpCheck.close();
    
    // Create default imgui.ini if it doesn't exist
    std::string imguiFile = "imgui.ini";
    std::ifstream imguiCheck(imguiFile);
    if (!imguiCheck.good()) {
        std::ofstream imgui(imguiFile);
        if (imgui.is_open()) {
            imgui << "[Window][FileDuper - Duplicate File Scanner]" << std::endl;
            imgui << "Pos=60,60" << std::endl;
            imgui << "Size=1800,900" << std::endl;
            imgui << "Collapsed=0" << std::endl;
            imgui << std::endl;
            imgui.close();
            std::cout << "[Config] Created default imgui.ini with optimal window size" << std::endl;
        }
    }
    imguiCheck.close();
    
    std::cout << "[Config] All configuration files checked/created" << std::endl;
}

// Restore DEFAULT settings (for reset functionality)
void restoreDefaultSettings() {
    std::cout << "[Config] ========================================" << std::endl;
    std::cout << "[Config] RESTORING DEFAULT SETTINGS" << std::endl;
    std::cout << "[Config] ========================================" << std::endl;
    
    // Basic Settings
    appState.scannerThreads = 128;
    appState.scanTimeout = 1;
    appState.useLightningSpeed = true;
    appState.hashAlgorithm = "AUTO";
    appState.hashPreset = "AUTO";
    appState.useHardwareAcceleration = true;
    appState.useGPU = false;
    appState.useFastHash = true;
    appState.scanHiddenFiles = true;
    appState.followSymlinks = true;
    appState.deleteEmptyDirs = true;
    
    // Advanced Performance Settings
    appState.useAsyncIO = true;
    appState.useCurlPooling = true;
    appState.useMemoryMapping = true;
    appState.useTCPPing = true;
    appState.batchScanSize = 20;
    appState.autoTuneThreads = true;
    appState.cacheFileHashes = true;
    appState.skipEmptyFiles = true;
    appState.smartTimeout = true;
    
    // FTP/Network Settings
    appState.ftpMaxRetries = 3;
    appState.ftpConnectTimeout = 2;
    appState.ftpReadTimeout = 15;
    appState.ftpPipelining = true;
    appState.ftpKeepAlive = true;
    appState.curlBufferSize = 512000;
    
    // Directory Tree Settings
    appState.localTreeMaxDepth = 3;  // Reduced for NFS performance (was 10)
    appState.ftpTreeMaxDepth = 7;
    appState.treeSearchShowSubdirs = false;
    
    // FTP Scan Optimization Settings
    appState.ftpMaxThreads = 16;
    appState.ftpScanMaxDepth = 30;
    appState.ftpResponseTimeout = 5;
    appState.ftpUseParallelScan = true;
    appState.ftpUseLsR = true;
    
    // Post-Scan Actions
    appState.postScanActionEnabled = false;
    appState.postScanAction = 0;
    appState.postScanDelay = 60;
    
    // Performance Tuning Settings
    appState.hashBatchSize = 10000;       // OPTIMIZED: 10000 (10x larger batches = 90% less mutex locks)
    appState.statusUpdateInterval = 1000;
    
    // FTP Hash Performance Settings
    appState.ftpHashTimeout = 5;          // ADAPTIVE: Auto-scales for large files (>100MB)
    appState.ftpHashRetries = 3;
    appState.ftpSkipFailedFiles = true;
    appState.ftpMaxConnections = 8;
    appState.ftpReuseConnections = true;
    appState.ftpMinFileSize = 100;
    
    // PARALLEL PROCESSING SETTINGS (DEFAULT: ALL ON!)
    appState.parallelDirectoryScan = true;
    appState.dirScanThreads = 8;          // OPTIMIZED: 8 threads with 10k batches + string reuse
    appState.parallelFtpDirScan = true;
    appState.ftpDirScanThreads = 4;
    appState.parallelCleanup = true;
    appState.cleanupThreads = 4;
    appState.parallelCacheLoad = true;
    appState.cacheLoadThreads = 4;
    
    // Save defaults to config file
    saveScannerSettings();
    
    std::cout << "[Config] ✅ DEFAULT SETTINGS RESTORED!" << std::endl;
    std::cout << "[Config]   - Parallel Dir Scan: ON (" << appState.dirScanThreads << " threads, 10k batches)" << std::endl;
    std::cout << "[Config]   - Parallel FTP Scan: ON (" << appState.ftpDirScanThreads << " threads)" << std::endl;
    std::cout << "[Config]   - Parallel Cleanup: ON (" << appState.cleanupThreads << " threads)" << std::endl;
    std::cout << "[Config]   - Parallel Cache Load: ON (" << appState.cacheLoadThreads << " threads)" << std::endl;
    std::cout << "[Config]   - Hash Threads: " << appState.threadCount << std::endl;
    std::cout << "[Config]   - Scanner Threads: " << appState.scannerThreads << std::endl;
    std::cout << "[Config]   - Hash Batch Size: " << appState.hashBatchSize << " (10x optimized)" << std::endl;
    std::cout << "[Config]   - Hash Buffer: 1 MB chunks (16x larger)" << std::endl;
    std::cout << "[Config]   - FTP Timeout: Adaptive (scales with file size)" << std::endl;
    std::cout << "[Config]   - FTP Max Connections: " << appState.ftpMaxConnections << std::endl;
    std::cout << "[Config] ========================================" << std::endl;
}

// Save/Load Scanner Settings
void loadScannerSettings() {
    std::ifstream file(std::string(getenv("HOME")) + "/.fileduper_scanner.cfg");
    if (file.is_open()) {
        file >> appState.scannerThreads;
        file >> appState.scanTimeout;
        int lightning;
        file >> lightning;
        appState.useLightningSpeed = (lightning == 1);
        
        // Load hash settings (new)
        std::string hashAlgo, hashPreset;
        int hwAccel;
        if (file >> hashAlgo >> hashPreset >> hwAccel) {
            appState.hashAlgorithm = hashAlgo;
            appState.hashPreset = hashPreset;
            appState.useHardwareAcceleration = (hwAccel == 1);
        }
        
        // Load GPU and Fast Hash settings
        int useGpu, useFast;
        if (file >> useGpu >> useFast) {
            appState.useGPU = (useGpu == 1);
            appState.useFastHash = (useFast == 1);
        }
        
        // Load Hidden Files and Symlinks settings
        int scanHidden, followSyms;
        if (file >> scanHidden >> followSyms) {
            appState.scanHiddenFiles = (scanHidden == 1);
            appState.followSymlinks = (followSyms == 1);
        }
        
        // Load Delete Empty Dirs setting
        int deleteEmpty;
        if (file >> deleteEmpty) appState.deleteEmptyDirs = (deleteEmpty == 1);
        
        // Load Advanced performance settings (optional - defaults if missing)
        int asyncIO, curlPool, memMap, tcpPing, autoTune, hashCache, skipEmpty, smartTO;
        if (file >> asyncIO) appState.useAsyncIO = (asyncIO == 1);
        if (file >> curlPool) appState.useCurlPooling = (curlPool == 1);
        if (file >> memMap) appState.useMemoryMapping = (memMap == 1);
        if (file >> tcpPing) appState.useTCPPing = (tcpPing == 1);
        if (file >> appState.batchScanSize) {} // Already read
        if (file >> autoTune) appState.autoTuneThreads = (autoTune == 1);
        if (file >> hashCache) appState.cacheFileHashes = (hashCache == 1);
        if (file >> skipEmpty) appState.skipEmptyFiles = (skipEmpty == 1);
        if (file >> smartTO) appState.smartTimeout = (smartTO == 1);
        
        // Load FTP/Network settings (optional)
        if (file >> appState.ftpMaxRetries) {}
        if (file >> appState.ftpConnectTimeout) {}
        if (file >> appState.ftpReadTimeout) {}
        int ftpPipe, ftpKeep;
        if (file >> ftpPipe) appState.ftpPipelining = (ftpPipe == 1);
        if (file >> ftpKeep) appState.ftpKeepAlive = (ftpKeep == 1);
        if (file >> appState.curlBufferSize) {}  // CURL Buffer Size
        
        // NEW: Load Directory Tree Settings (optional - defaults if missing)
        if (file >> appState.localTreeMaxDepth) {}
        if (file >> appState.ftpTreeMaxDepth) {}
        int treeSearchShowSubs;
        if (file >> treeSearchShowSubs) appState.treeSearchShowSubdirs = (treeSearchShowSubs == 1);
        
        // NEW: Load FTP Scan Optimization Settings (optional - defaults if missing)
        if (file >> appState.ftpMaxThreads) {}
        if (file >> appState.ftpScanMaxDepth) {}
        if (file >> appState.ftpResponseTimeout) {}
        int ftpParallel;
        if (file >> ftpParallel) appState.ftpUseParallelScan = (ftpParallel == 1);
        int ftpLsR;
        if (file >> ftpLsR) appState.ftpUseLsR = (ftpLsR == 1);
        
        // NEW: Load Post-Scan Actions (optional - defaults if missing)
        int postScanEnabled;
        if (file >> postScanEnabled) appState.postScanActionEnabled = (postScanEnabled == 1);
        if (file >> appState.postScanAction) {}
        if (file >> appState.postScanDelay) {}
        
        // NEW: Load Performance Tuning Settings (optional - defaults if missing)
        if (file >> appState.hashBatchSize) {}
        if (file >> appState.statusUpdateInterval) {}
        
        // NEW: Load FTP Hash Performance Settings (optional - defaults if missing)
        if (file >> appState.ftpHashTimeout) {}
        if (file >> appState.ftpHashRetries) {}
        int ftpSkipFailed;
        if (file >> ftpSkipFailed) appState.ftpSkipFailedFiles = (ftpSkipFailed == 1);
        if (file >> appState.ftpMaxConnections) {}
        int ftpReuse;
        if (file >> ftpReuse) appState.ftpReuseConnections = (ftpReuse == 1);
        if (file >> appState.ftpMinFileSize) {}
        
        // NEW: Load PARALLEL PROCESSING SETTINGS (Lines 46-53 - optional)
        int parallelDir, parallelFtpDir, parallelClean, parallelCache;
        if (file >> parallelDir) appState.parallelDirectoryScan = (parallelDir == 1);
        if (file >> appState.dirScanThreads) {}
        if (file >> parallelFtpDir) appState.parallelFtpDirScan = (parallelFtpDir == 1);
        if (file >> appState.ftpDirScanThreads) {}
        if (file >> parallelClean) appState.parallelCleanup = (parallelClean == 1);
        if (file >> appState.cleanupThreads) {}
        if (file >> parallelCache) appState.parallelCacheLoad = (parallelCache == 1);
        if (file >> appState.cacheLoadThreads) {}
        
        file.close();
        std::cout << "[Config] Scanner settings loaded: " << appState.scannerThreads 
                  << " threads"
                  << ", DirScan: " << (appState.parallelDirectoryScan ? "ON" : "OFF") << " (" << appState.dirScanThreads << ")"
                  << ", FTP-DirScan: " << (appState.parallelFtpDirScan ? "ON" : "OFF") << " (" << appState.ftpDirScanThreads << ")"
                  << ", Cleanup: " << (appState.parallelCleanup ? "ON" : "OFF") << " (" << appState.cleanupThreads << ")"
                  << ", Cache: " << (appState.parallelCacheLoad ? "ON" : "OFF") << " (" << appState.cacheLoadThreads << ")"
                  << ", " << appState.scanTimeout << "s timeout, Lightning: " 
                  << (appState.useLightningSpeed ? "ON" : "OFF") 
                  << ", Hash: " << appState.hashAlgorithm 
                  << ", GPU: " << (appState.useGPU ? "ON" : "OFF")
                  << ", Hidden: " << (appState.scanHiddenFiles ? "ON" : "OFF")
                  << ", Symlinks: " << (appState.followSymlinks ? "ON" : "OFF")
                  << ", TCP-Ping: " << (appState.useTCPPing ? "ON" : "OFF")
                  << ", CURL-Pool: " << (appState.useCurlPooling ? "ON" : "OFF") << std::endl;
    } else {
        // Defaults - use restoreDefaultSettings() for complete defaults
        std::cout << "[Config] No config file found - using DEFAULT settings" << std::endl;
        restoreDefaultSettings();
    }
}

// Save scanner settings including hash configuration
// ALWAYS creates a fresh, complete config file with all 45 settings
void saveScannerSettings() {
    std::string configPath = std::string(getenv("HOME")) + "/.fileduper_scanner.cfg";
    
    // Remove old config to ensure fresh start
    std::remove(configPath.c_str());
    
    // Create fresh config file
    std::ofstream file(configPath, std::ios::out | std::ios::trunc);
    if (!file.is_open()) {
        std::cerr << "[Config] ERROR: Could not create config file: " << configPath << std::endl;
        return;
    }
    
    // Write all settings in order (45 lines total)
    // Basic settings (Lines 1-11)
    file << appState.scannerThreads << std::endl;                        // 1
    file << appState.scanTimeout << std::endl;                           // 2
    file << (appState.useLightningSpeed ? 1 : 0) << std::endl;          // 3
    file << appState.hashAlgorithm << std::endl;                        // 4
    file << appState.hashPreset << std::endl;                           // 5
    file << (appState.useHardwareAcceleration ? 1 : 0) << std::endl;    // 6
    file << (appState.useGPU ? 1 : 0) << std::endl;                     // 7
    file << (appState.useFastHash ? 1 : 0) << std::endl;                // 8
    file << (appState.scanHiddenFiles ? 1 : 0) << std::endl;            // 9
    file << (appState.followSymlinks ? 1 : 0) << std::endl;             // 10
    file << (appState.deleteEmptyDirs ? 1 : 0) << std::endl;            // 11
    
    // Advanced performance settings (Lines 12-20)
    file << (appState.useAsyncIO ? 1 : 0) << std::endl;                 // 12
    file << (appState.useCurlPooling ? 1 : 0) << std::endl;             // 13
    file << (appState.useMemoryMapping ? 1 : 0) << std::endl;           // 14
    file << (appState.useTCPPing ? 1 : 0) << std::endl;                 // 15
    file << appState.batchScanSize << std::endl;                        // 16
    file << (appState.autoTuneThreads ? 1 : 0) << std::endl;            // 17
    file << (appState.cacheFileHashes ? 1 : 0) << std::endl;            // 18
    file << (appState.skipEmptyFiles ? 1 : 0) << std::endl;             // 19
    file << (appState.smartTimeout ? 1 : 0) << std::endl;               // 20
    
    // FTP/Network settings (Lines 21-26)
    file << appState.ftpMaxRetries << std::endl;                        // 21
    file << appState.ftpConnectTimeout << std::endl;                    // 22
    file << appState.ftpReadTimeout << std::endl;                       // 23
    file << (appState.ftpPipelining ? 1 : 0) << std::endl;              // 24
    file << (appState.ftpKeepAlive ? 1 : 0) << std::endl;               // 25
    file << appState.curlBufferSize << std::endl;                       // 26
    
    // Directory Tree Settings (Lines 27-29)
    file << appState.localTreeMaxDepth << std::endl;                    // 27
    file << appState.ftpTreeMaxDepth << std::endl;                      // 28
    file << (appState.treeSearchShowSubdirs ? 1 : 0) << std::endl;      // 29
    
    // FTP Scan Optimization Settings (Lines 30-34)
    file << appState.ftpMaxThreads << std::endl;                        // 30
    file << appState.ftpScanMaxDepth << std::endl;                      // 31
    file << appState.ftpResponseTimeout << std::endl;                   // 32
    file << (appState.ftpUseParallelScan ? 1 : 0) << std::endl;         // 33
    file << (appState.ftpUseLsR ? 1 : 0) << std::endl;                  // 34
    
    // Post-Scan Actions (Lines 35-37)
    file << (appState.postScanActionEnabled ? 1 : 0) << std::endl;      // 35
    file << appState.postScanAction << std::endl;                       // 36
    file << appState.postScanDelay << std::endl;                        // 37
    
    // Performance Tuning Settings (Lines 38-39)
    file << appState.hashBatchSize << std::endl;                        // 38
    file << appState.statusUpdateInterval << std::endl;                 // 39
    
    // FTP Hash Performance Settings (Lines 40-45)
    file << appState.ftpHashTimeout << std::endl;                       // 40
    file << appState.ftpHashRetries << std::endl;                       // 41
    file << (appState.ftpSkipFailedFiles ? 1 : 0) << std::endl;         // 42
    file << appState.ftpMaxConnections << std::endl;                    // 43
    file << (appState.ftpReuseConnections ? 1 : 0) << std::endl;        // 44
    file << appState.ftpMinFileSize << std::endl;                       // 45
    
    // PARALLEL PROCESSING SETTINGS (Lines 46-53 - NEU!)
    file << (appState.parallelDirectoryScan ? 1 : 0) << std::endl;      // 46
    file << appState.dirScanThreads << std::endl;                       // 47
    file << (appState.parallelFtpDirScan ? 1 : 0) << std::endl;         // 48
    file << appState.ftpDirScanThreads << std::endl;                    // 49
    file << (appState.parallelCleanup ? 1 : 0) << std::endl;            // 50
    file << appState.cleanupThreads << std::endl;                       // 51
    file << (appState.parallelCacheLoad ? 1 : 0) << std::endl;          // 52
    file << appState.cacheLoadThreads << std::endl;                     // 53
    
    file.close();
    std::cout << "[Config] Fresh config saved with all 53 settings (Threads: " << appState.scannerThreads
              << ", DirScan: " << appState.dirScanThreads
              << ", FTP-DirScan: " << appState.ftpDirScanThreads
              << ", Cleanup: " << appState.cleanupThreads
              << ", Cache: " << appState.cacheLoadThreads
              << ", Batch: " << appState.hashBatchSize
              << ", FTP-Timeout: " << appState.ftpHashTimeout << "s"
              << ", FTP-Conn: " << appState.ftpMaxConnections
              << ", MinSize: " << appState.ftpMinFileSize << " bytes)" << std::endl;
}

// Save/Load Search History
void saveSearchHistory() {
    std::ofstream file(std::string(getenv("HOME")) + "/.fileduper_search_history.cfg");
    if (file.is_open()) {
        for (const auto& search : appState.searchHistory) {
            file << search << std::endl;
        }
        file.close();
    }
}

void loadSearchHistory() {
    std::ifstream file(std::string(getenv("HOME")) + "/.fileduper_search_history.cfg");
    if (file.is_open()) {
        std::string line;
        appState.searchHistory.clear();
        while (std::getline(file, line)) {
            if (!line.empty() && appState.searchHistory.size() < appState.maxSearchHistory) {
                appState.searchHistory.push_back(line);
            }
        }
        file.close();
    }
}

// Forward declarations for NFS/SMB/WebDAV functions
bool isNfsMounted(const std::string& mountPoint);
bool isSmbMounted(const std::string& mountPoint);
bool isWebDavMounted(const std::string& mountPoint);
bool mountNFS(FtpPreset& preset);
bool unmountNFS(FtpPreset& preset);
bool mountSMB(FtpPreset& preset);
bool unmountSMB(FtpPreset& preset);
bool mountWebDAV(FtpPreset& preset);
bool unmountWebDAV(FtpPreset& preset);

// Show status notification in GUI
void showStatusNotification(const std::string& message, const ImVec4& color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f), float duration = 5.0f) {
    appState.statusNotification = message;
    appState.statusNotificationColor = color;
    appState.statusNotificationTimer = duration;
}

// Save/Load FTP Presets
void saveFtpPresets() {
    json j = json::array();
    
    for (const auto& preset : appState.ftpPresets) {
        json presetObj;
        presetObj["name"] = preset.name;
        presetObj["ip"] = preset.ip;
        presetObj["serviceType"] = preset.serviceType;
        presetObj["port"] = preset.port;
        presetObj["username"] = preset.username;
        // Passwort nur speichern wenn Option aktiviert ist
        if (appState.savePasswordsPermanently) {
            presetObj["password"] = preset.password;
        } else {
            presetObj["password"] = ""; // Leeres Passwort wenn nicht permanent gespeichert
        }
        
        // NFS-specific fields
        if (preset.serviceType == "NFS") {
            presetObj["nfsExportPath"] = preset.nfsExportPath;
            presetObj["nfsMountPoint"] = preset.nfsMountPoint;
            presetObj["nfsOptions"] = preset.nfsOptions;
            presetObj["nfsAutoMount"] = preset.nfsAutoMount;
            presetObj["nfsMounted"] = preset.nfsMounted;
        }
        
        // SMB/CIFS-specific fields
        if (preset.serviceType == "SMB") {
            presetObj["smbSharePath"] = preset.smbSharePath;
            presetObj["smbMountPoint"] = preset.smbMountPoint;
            presetObj["smbDomain"] = preset.smbDomain;
            presetObj["smbWorkgroup"] = preset.smbWorkgroup;
            presetObj["smbOptions"] = preset.smbOptions;
            presetObj["smbAutoMount"] = preset.smbAutoMount;
            presetObj["smbMounted"] = preset.smbMounted;
        }
        
        // WebDAV-specific fields
        if (preset.serviceType == "WebDAV") {
            presetObj["davUrl"] = preset.davUrl;
            presetObj["davMountPoint"] = preset.davMountPoint;
            presetObj["davOptions"] = preset.davOptions;
            presetObj["davUseSSL"] = preset.davUseSSL;
            presetObj["davAutoMount"] = preset.davAutoMount;
            presetObj["davMounted"] = preset.davMounted;
        }
        
        j.push_back(presetObj);
    }
    
    std::ofstream file(std::string(getenv("HOME")) + "/.fileduper_ftp_presets.json");
    if (file.is_open()) {
        file << j.dump(2); // Pretty print with 2 spaces
        file.close();
        std::cout << "[FTP Presets] Saved " << appState.ftpPresets.size() << " presets (JSON)" << std::endl;
    }
}
void loadFtpPresets() {
    std::string jsonPath = std::string(getenv("HOME")) + "/.fileduper_ftp_presets.json";
    std::string oldPath = std::string(getenv("HOME")) + "/.fileduper_ftp_presets.cfg";
    
    appState.ftpPresets.clear();
    
    // Try loading JSON format first
    std::ifstream jsonFile(jsonPath);
    if (jsonFile.is_open()) {
        try {
            json j;
            jsonFile >> j;
            jsonFile.close();
            
            for (const auto& presetObj : j) {
                FtpPreset preset;
                preset.name = presetObj.value("name", "");
                preset.ip = presetObj.value("ip", "");
                preset.serviceType = presetObj.value("serviceType", "FTP");
                preset.port = presetObj.value("port", 21);
                preset.username = presetObj.value("username", "");
                preset.password = presetObj.value("password", "");
                
                // NFS-specific fields
                // NFS-specific fields
                if (preset.serviceType == "NFS") {
                    preset.nfsExportPath = presetObj.value("nfsExportPath", "");
                    preset.nfsMountPoint = presetObj.value("nfsMountPoint", "");
                    preset.nfsOptions = presetObj.value("nfsOptions", "vers=4,rw");
                    preset.nfsAutoMount = presetObj.value("nfsAutoMount", false);
                    preset.nfsMounted = false; // Don't trust persisted mount status
                    
                    // Verify actual mount status on startup
                    if (isNfsMounted(preset.nfsMountPoint)) {
                        preset.nfsMounted = true;
                        std::cout << "[NFS] Found already mounted: " << preset.nfsMountPoint << std::endl;
                    }
                }
                
                // SMB/CIFS-specific fields
                if (preset.serviceType == "SMB") {
                    preset.smbSharePath = presetObj.value("smbSharePath", "");
                    preset.smbMountPoint = presetObj.value("smbMountPoint", "");
                    preset.smbDomain = presetObj.value("smbDomain", "");
                    preset.smbWorkgroup = presetObj.value("smbWorkgroup", "WORKGROUP");
                    preset.smbOptions = presetObj.value("smbOptions", "vers=3.0");
                    preset.smbAutoMount = presetObj.value("smbAutoMount", false);
                    preset.smbMounted = false; // Don't trust persisted mount status
                    
                    // Verify actual mount status on startup
                    if (isSmbMounted(preset.smbMountPoint)) {
                        preset.smbMounted = true;
                        std::cout << "[SMB] Found already mounted: " << preset.smbMountPoint << std::endl;
                    }
                }
                
                // WebDAV-specific fields
                if (preset.serviceType == "WebDAV") {
                    preset.davUrl = presetObj.value("davUrl", "");
                    preset.davMountPoint = presetObj.value("davMountPoint", "");
                    preset.davOptions = presetObj.value("davOptions", "");
                    preset.davUseSSL = presetObj.value("davUseSSL", true);
                    preset.davAutoMount = presetObj.value("davAutoMount", false);
                    preset.davMounted = false; // Don't trust persisted mount status
                    
                    // Verify actual mount status on startup
                    if (isWebDavMounted(preset.davMountPoint)) {
                        preset.davMounted = true;
                        std::cout << "[WebDAV] Found already mounted: " << preset.davMountPoint << std::endl;
                    }
                }
                
                appState.ftpPresets.push_back(preset);
            }
            
            std::cout << "[FTP Presets] Loaded " << appState.ftpPresets.size() << " presets (JSON)" << std::endl;
            return;
        } catch (const std::exception& e) {
            std::cerr << "[FTP Presets] JSON parse error: " << e.what() << std::endl;
            appState.ftpPresets.clear();
        }
    }    
    // Fallback: Try loading old pipe-delimited format
    std::ifstream oldFile(oldPath);
    if (oldFile.is_open()) {
        std::string line;
        while (std::getline(oldFile, line)) {
            if (!line.empty()) {
                FtpPreset preset;
                std::istringstream iss(line);
                std::string token;
                int field = 0;
                while (std::getline(iss, token, '|')) {
                    switch(field++) {
                        case 0: preset.name = token; break;
                        case 1: preset.ip = token; break;
                        case 2: preset.serviceType = token; break;
                        case 3: preset.port = std::stoi(token); break;
                        case 4: preset.username = token; break;
                        case 5: preset.password = token; break;
                    }
                }
                if (field >= 6) appState.ftpPresets.push_back(preset);
            }
        }
        oldFile.close();
        std::cout << "[FTP Presets] Loaded " << appState.ftpPresets.size() << " presets (old format)" << std::endl;
        
        // Convert to JSON format
        if (!appState.ftpPresets.empty()) {
            saveFtpPresets();
            std::cout << "[FTP Presets] Converted to JSON format" << std::endl;
        }
    }
}

// Add/Remove FTP Presets (simple IP version for compatibility)
void addFtpPreset(const std::string& ip) {
    if (std::find(appState.savedFtpIPs.begin(), appState.savedFtpIPs.end(), ip) == appState.savedFtpIPs.end()) {
        appState.savedFtpIPs.push_back(ip);
        
        // Also add to ftpPresets with default values
        FtpPreset preset;
        preset.name = "Server " + std::to_string(appState.ftpPresets.size() + 1);
        preset.ip = ip;
        preset.serviceType = "FTP";
        preset.port = 21;
        preset.username = "";
        preset.password = "";
        appState.ftpPresets.push_back(preset);
        
        saveFtpPresets();
    }
}

void removeFtpPreset(const std::string& ip) {
    auto it = std::find(appState.savedFtpIPs.begin(), appState.savedFtpIPs.end(), ip);
    if (it != appState.savedFtpIPs.end()) {
        appState.savedFtpIPs.erase(it);
    }
    
    // Also remove from ftpPresets
    for (auto it2 = appState.ftpPresets.begin(); it2 != appState.ftpPresets.end(); ) {
        if (it2->ip == ip) {
            it2 = appState.ftpPresets.erase(it2);
        } else {
            ++it2;
        }
    }
    
    saveFtpPresets();
}

// Save Scan State (kompletter Scan-Fortschritt)
void saveScanState(const std::string& filename) {
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "[Scan State] Failed to save: " << filename << std::endl;
        return;
    }
    
    // Header
    file << "FILEDUPER_SCAN_STATE_V1" << std::endl;
    file << time(nullptr) << std::endl; // Timestamp
    
    // Scan Configuration
    file << appState.minFileSize << std::endl;
    file << (appState.scanHiddenFiles ? 1 : 0) << std::endl;
    file << (appState.followSymlinks ? 1 : 0) << std::endl;
    file << appState.hashAlgorithm << std::endl;
    
    // Selected Directories
    file << appState.selectedLocalDirs.size() << std::endl;
    for (const auto& dir : appState.selectedLocalDirs) {
        file << dir << std::endl;
    }
    
    file << appState.selectedFtpDirs.size() << std::endl;
    for (const auto& dir : appState.selectedFtpDirs) {
        file << dir << std::endl;
    }
    
    // FTP Connection Info
    file << appState.connectedPresetIndex << std::endl;
    
    // Scan Results (filesByHash)
    file << appState.filesByHash.size() << std::endl;
    for (const auto& pair : appState.filesByHash) {
        file << pair.first << std::endl; // Hash
        file << pair.second.size() << std::endl; // Anzahl Dateien
        for (const auto& filepath : pair.second) {
            file << filepath << std::endl;
        }
    }
    
    // Statistics
    file << appState.totalFiles << std::endl;
    file << appState.duplicateFiles << std::endl;
    file << appState.duplicateGroups << std::endl;
    file << appState.totalSize << std::endl;
    file << appState.duplicateSize << std::endl;
    
    file.close();
    
    // Also save tree state for faster loading
    saveTreeState();
    
    std::cout << "[Scan State] Saved to: " << filename << std::endl;
    std::cout << "[Scan State] " << appState.filesByHash.size() << " hash groups, "
              << appState.totalFiles << " files" << std::endl;
}

// Load Scan State
bool loadScanState(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "[Scan State] Failed to load: " << filename << std::endl;
        return false;
    }
    
    std::string header;
    std::getline(file, header);
    if (header != "FILEDUPER_SCAN_STATE_V1") {
        std::cerr << "[Scan State] Invalid file format" << std::endl;
        return false;
    }
    
    long timestamp;
    file >> timestamp;
    std::cout << "[Scan State] Loading scan from " << ctime(&timestamp);
    
    // Scan Configuration
    file >> appState.minFileSize;
    int hidden, symlinks;
    file >> hidden >> symlinks;
    appState.scanHiddenFiles = (hidden == 1);
    appState.followSymlinks = (symlinks == 1);
    file >> appState.hashAlgorithm;
    file.ignore(); // newline
    
    // Selected Directories - DON'T LOAD THEM! User must manually select each time
    appState.selectedLocalDirs.clear();
    size_t localDirCount;
    file >> localDirCount;
    file.ignore();
    for (size_t i = 0; i < localDirCount; i++) {
        std::string dir;
        std::getline(file, dir);
        // REMOVED: appState.selectedLocalDirs.insert(dir);  // Don't auto-load selections!
    }
    
    appState.selectedFtpDirs.clear();
    size_t ftpDirCount;
    file >> ftpDirCount;
    file.ignore();
    for (size_t i = 0; i < ftpDirCount; i++) {
        std::string dir;
        std::getline(file, dir);
        // REMOVED: appState.selectedFtpDirs.insert(dir);  // Don't auto-load selections!
    }
    
    file >> appState.connectedPresetIndex;
    file.ignore();
    
    // Scan Results
    appState.filesByHash.clear();
    size_t hashGroupCount;
    file >> hashGroupCount;
    file.ignore();
    
    for (size_t i = 0; i < hashGroupCount; i++) {
        std::string hash;
        std::getline(file, hash);
        
        size_t fileCount;
        file >> fileCount;
        file.ignore();
        
        std::vector<std::string> files;
        for (size_t j = 0; j < fileCount; j++) {
            std::string filepath;
            std::getline(file, filepath);
            files.push_back(filepath);
        }
        
        appState.filesByHash[hash] = files;
    }
    
    // Statistics
    file >> appState.totalFiles;
    file >> appState.duplicateFiles;
    file >> appState.duplicateGroups;
    file >> appState.totalSize;
    file >> appState.duplicateSize;
    
    file.close();
    
    // Also load tree state for faster tree rendering
    loadTreeState();
    
    appState.scanStateFile = filename;
    std::cout << "[Scan State] Loaded successfully!" << std::endl;
    std::cout << "[Scan State] " << appState.filesByHash.size() << " hash groups, "
              << appState.totalFiles << " files, "
              << appState.duplicateGroups << " duplicate groups" << std::endl;
    
    return true;
}

// Helper function to check if a filepath is an FTP URL
bool isFtpFile(const std::string& filepath) {
    return (filepath.length() >= 6 && 
            (filepath.substr(0, 6) == "ftp://" || filepath.substr(0, 6) == "FTP://"));
}

// Helper function to check if a path is a network mount point
// Excludes NFS, SMB/CIFS, and WebDAV mount points from local directory selection
bool isNetworkMountPoint(const std::string& path, const AppState& appState) {
    // Check against all NFS mount points
    for (const auto& preset : appState.ftpPresets) {
        if (preset.serviceType == "NFS" && !preset.nfsMountPoint.empty()) {
            // Exact match or path is subdirectory of mount point
            if (path == preset.nfsMountPoint || 
                path.find(preset.nfsMountPoint + "/") == 0) {
                return true;
            }
        }
        
        // Check against all SMB/CIFS mount points
        if (preset.serviceType == "SMB" && !preset.smbMountPoint.empty()) {
            if (path == preset.smbMountPoint || 
                path.find(preset.smbMountPoint + "/") == 0) {
                return true;
            }
        }
        
        // Check against all WebDAV mount points
        if (preset.serviceType == "WebDAV" && !preset.davMountPoint.empty()) {
            if (path == preset.davMountPoint || 
                path.find(preset.davMountPoint + "/") == 0) {
                return true;
            }
        }
    }
    
    return false;
}

// ============================================================================
// FILE CACHE: Save/Load file listings for ultra-fast incremental scans
// ============================================================================

// Save file cache to disk (automatic, transparent)
void saveFileCache() {
    std::lock_guard<std::mutex> lock(fileCacheMutex);
    
    // Separate local and FTP files
    std::vector<std::pair<std::string, CachedFileInfo>> localFiles;
    std::vector<std::pair<std::string, CachedFileInfo>> ftpFiles;
    
    for (const auto& entry : fileCache) {
        if (isFtpFile(entry.first)) {
            ftpFiles.push_back(entry);
        } else {
            localFiles.push_back(entry);
        }
    }
    
    // Save LOCAL cache
    if (!localFiles.empty()) {
        std::ofstream file(localCacheFilePath, std::ios::binary);
        if (file.is_open()) {
            file << "LOCALCACHE_V1\n" << localFiles.size() << "\n";
            
            for (const auto& entry : localFiles) {
                file << entry.first.length() << "\n" << entry.first << "\n";
                file << entry.second.size << "\n";
                file << entry.second.mtime << "\n";
                file << entry.second.inode << "\n";
                file << entry.second.hash.length() << "\n";
                if (!entry.second.hash.empty()) {
                    file << entry.second.hash << "\n";
                }
            }
            file.close();
            std::cout << "[Cache] Saved " << localFiles.size() << " local files" << std::endl;
        }
    }
    
    // Save FTP cache
    if (!ftpFiles.empty()) {
        std::ofstream file(ftpCacheFilePath, std::ios::binary);
        if (file.is_open()) {
            file << "FTPCACHE_V1\n" << ftpFiles.size() << "\n";
            
            for (const auto& entry : ftpFiles) {
                file << entry.first.length() << "\n" << entry.first << "\n";
                file << entry.second.size << "\n";
                file << entry.second.mtime << "\n";
                file << entry.second.hash.length() << "\n";
                if (!entry.second.hash.empty()) {
                    file << entry.second.hash << "\n";
                }
            }
            file.close();
            std::cout << "[Cache] Saved " << ftpFiles.size() << " FTP files" << std::endl;
        }
    }
}

// Load file cache from disk (automatic on startup)
void loadFileCache() {
    std::lock_guard<std::mutex> lock(fileCacheMutex);
    fileCache.clear();
    
    int totalLoaded = 0;
    
    // Load LOCAL cache
    {
        std::ifstream file(localCacheFilePath, std::ios::binary);
        if (file.is_open()) {
            std::string header;
            std::getline(file, header);
            
            if (header == "LOCALCACHE_V1") {
                size_t count;
                file >> count;
                file.ignore();
                
                for (size_t i = 0; i < count; i++) {
                    size_t pathLen;
                    file >> pathLen;
                    file.ignore();
                    
                    std::string path(pathLen, '\0');
                    file.read(&path[0], pathLen);
                    file.ignore();
                    
                    CachedFileInfo info;
                    file >> info.size >> info.mtime >> info.inode;
                    
                    size_t hashLen;
                    file >> hashLen;
                    file.ignore();
                    
                    if (hashLen > 0) {
                        info.hash.resize(hashLen);
                        file.read(&info.hash[0], hashLen);
                        file.ignore();
                    }
                    
                    fileCache[path] = info;
                    totalLoaded++;
                }
            }
            file.close();
        }
    }
    
    // Load FTP cache
    {
        std::ifstream file(ftpCacheFilePath, std::ios::binary);
        if (file.is_open()) {
            std::string header;
            std::getline(file, header);
            
            if (header == "FTPCACHE_V1") {
                size_t count;
                file >> count;
                file.ignore();
                
                for (size_t i = 0; i < count; i++) {
                    size_t pathLen;
                    file >> pathLen;
                    file.ignore();
                    
                    std::string path(pathLen, '\0');
                    file.read(&path[0], pathLen);
                    file.ignore();
                    
                    CachedFileInfo info;
                    info.inode = 0; // FTP files have no inode
                    file >> info.size >> info.mtime;
                    
                    size_t hashLen;
                    file >> hashLen;
                    file.ignore();
                    
                    if (hashLen > 0) {
                        info.hash.resize(hashLen);
                        file.read(&info.hash[0], hashLen);
                        file.ignore();
                    }
                    
                    fileCache[path] = info;
                    totalLoaded++;
                }
            }
            file.close();
        }
    }
    
    if (totalLoaded > 0) {
        std::cout << "[Cache] Loaded " << totalLoaded << " cached files (instant scan boost!)" << std::endl;
    }
}

// Save tree state to disk (expanded nodes)
void saveTreeState() {
    std::lock_guard<std::mutex> lock(expandedNodesMutex);
    std::ofstream file(treeStateFilePath, std::ios::binary);
    if (!file.is_open()) return;
    
    const char* header = "TREESTATE_V1";
    file.write(header, 12);
    
    size_t count = expandedNodes.size();
    file.write(reinterpret_cast<const char*>(&count), sizeof(count));
    
    for (const auto& path : expandedNodes) {
        size_t len = path.size();
        file.write(reinterpret_cast<const char*>(&len), sizeof(len));
        file.write(path.c_str(), len);
    }
    
    file.close();
}

// Load tree state from disk (expanded nodes)
void loadTreeState() {
    std::lock_guard<std::mutex> lock(expandedNodesMutex);
    expandedNodes.clear();
    
    std::ifstream file(treeStateFilePath, std::ios::binary);
    if (!file.is_open()) return;
    
    char header[12];
    file.read(header, 12);
    if (std::string(header, 12) != "TREESTATE_V1") {
        file.close();
        return;
    }
    
    size_t count;
    file.read(reinterpret_cast<char*>(&count), sizeof(count));
    
    for (size_t i = 0; i < count; i++) {
        size_t len;
        file.read(reinterpret_cast<char*>(&len), sizeof(len));
        
        std::string path(len, '\0');
        file.read(&path[0], len);
        
        expandedNodes.insert(path);
    }
    
    file.close();
}

// Save Directory Cache
void saveDirCache() {
    std::lock_guard<std::mutex> lock(dirCacheMutex);
    std::ofstream file(dirCacheFilePath, std::ios::binary);
    if (!file.is_open()) return;
    
    const char* header = "DIRCACHE_V1";
    file.write(header, 12);
    
    // Timestamp
    time_t now = time(nullptr);
    file.write(reinterpret_cast<const char*>(&now), sizeof(now));
    
    // Directory count
    size_t count = cachedLocalDirs.size();
    file.write(reinterpret_cast<const char*>(&count), sizeof(count));
    
    // Write directories
    for (const auto& dir : cachedLocalDirs) {
        size_t len = dir.size();
        file.write(reinterpret_cast<const char*>(&len), sizeof(len));
        file.write(dir.c_str(), len);
    }
    
    file.close();
    std::cout << "[DirCache] Saved " << count << " directories to cache" << std::endl;
}

// Load Directory Cache
void loadDirCache() {
    std::lock_guard<std::mutex> lock(dirCacheMutex);
    std::ifstream file(dirCacheFilePath, std::ios::binary);
    if (!file.is_open()) {
        std::cout << "[DirCache] No cache file found, will scan fresh" << std::endl;
        return;
    }
    
    char header[12];
    file.read(header, 12);
    if (std::string(header, 12) != "DIRCACHE_V1") {
        std::cerr << "[DirCache] Invalid cache format" << std::endl;
        file.close();
        return;
    }
    
    // Read timestamp
    file.read(reinterpret_cast<char*>(&dirCacheTimestamp), sizeof(dirCacheTimestamp));
    
    // Read directory count
    size_t count;
    file.read(reinterpret_cast<char*>(&count), sizeof(count));
    
    cachedLocalDirs.clear();
    cachedLocalDirs.reserve(count);
    
    // Read directories
    for (size_t i = 0; i < count; i++) {
        size_t len;
        file.read(reinterpret_cast<char*>(&len), sizeof(len));
        
        std::string dir(len, '\0');
        file.read(&dir[0], len);
        
        cachedLocalDirs.push_back(dir);
    }
    
    file.close();
    
    // Calculate cache age
    time_t now = time(nullptr);
    int age_hours = (now - dirCacheTimestamp) / 3600;
    
    std::cout << "[DirCache] Loaded " << count << " directories from cache (age: " 
              << age_hours << " hours)" << std::endl;
}

// Save FTP Directory Cache
void saveFtpDirCache() {
    std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
    std::ofstream file(ftpDirCacheFilePath, std::ios::binary);
    if (!file.is_open()) return;
    
    const char* header = "FTPDIRCACHE_V1";
    file.write(header, 16);
    
    // Entry count
    size_t count = ftpDirCache.size();
    file.write(reinterpret_cast<const char*>(&count), sizeof(count));
    
    // Write all cache entries
    for (const auto& [key, entry] : ftpDirCache) {
        // Write key
        size_t keyLen = key.size();
        file.write(reinterpret_cast<const char*>(&keyLen), sizeof(keyLen));
        file.write(key.c_str(), keyLen);
        
        // Write path
        size_t pathLen = entry.path.size();
        file.write(reinterpret_cast<const char*>(&pathLen), sizeof(pathLen));
        file.write(entry.path.c_str(), pathLen);
        
        // Write timestamp
        file.write(reinterpret_cast<const char*>(&entry.timestamp), sizeof(entry.timestamp));
        
        // Write subdirs count
        size_t subdirCount = entry.subdirs.size();
        file.write(reinterpret_cast<const char*>(&subdirCount), sizeof(subdirCount));
        
        // Write subdirs
        for (const auto& subdir : entry.subdirs) {
            size_t len = subdir.size();
            file.write(reinterpret_cast<const char*>(&len), sizeof(len));
            file.write(subdir.c_str(), len);
        }
    }
    
    file.close();
    std::cout << "[FTP DirCache] Saved " << count << " FTP directory entries to cache" << std::endl;
}

// Load FTP Directory Cache
void loadFtpDirCache() {
    std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
    std::ifstream file(ftpDirCacheFilePath, std::ios::binary);
    if (!file.is_open()) {
        std::cout << "[FTP DirCache] No FTP cache file found, will scan fresh" << std::endl;
        return;
    }
    
    char header[16];
    file.read(header, 16);
    if (std::string(header, 16) != "FTPDIRCACHE_V1") {
        std::cerr << "[FTP DirCache] Invalid cache format" << std::endl;
        file.close();
        return;
    }
    
    // Read entry count
    size_t count;
    file.read(reinterpret_cast<char*>(&count), sizeof(count));
    
    ftpDirCache.clear();
    ftpDirCache.reserve(count);
    
    // Read all entries
    for (size_t i = 0; i < count; i++) {
        // Read key
        size_t keyLen;
        file.read(reinterpret_cast<char*>(&keyLen), sizeof(keyLen));
        std::string key(keyLen, '\0');
        file.read(&key[0], keyLen);
        
        FTPDirCacheEntry entry;
        
        // Read path
        size_t pathLen;
        file.read(reinterpret_cast<char*>(&pathLen), sizeof(pathLen));
        entry.path.resize(pathLen);
        file.read(&entry.path[0], pathLen);
        
        // Read timestamp
        file.read(reinterpret_cast<char*>(&entry.timestamp), sizeof(entry.timestamp));
        
        // Read subdirs
        size_t subdirCount;
        file.read(reinterpret_cast<char*>(&subdirCount), sizeof(subdirCount));
        entry.subdirs.reserve(subdirCount);
        
        for (size_t j = 0; j < subdirCount; j++) {
            size_t len;
            file.read(reinterpret_cast<char*>(&len), sizeof(len));
            std::string subdir(len, '\0');
            file.read(&subdir[0], len);
            entry.subdirs.push_back(subdir);
        }
        
        ftpDirCache[key] = std::move(entry);
    }
    
    file.close();
    std::cout << "[FTP DirCache] Loaded " << count << " FTP directory entries from cache" << std::endl;
}

// ==================== SUDO PASSWORD ENCRYPTION ====================
// Simple XOR encryption with machine-specific key (better than plain text)
std::string encryptPassword(const std::string& password) {
    // Generate machine-specific key from hostname + username
    char hostname[256];
    gethostname(hostname, sizeof(hostname));
    std::string key = std::string(hostname) + getenv("USER");
    
    // XOR encryption
    std::string encrypted = password;
    for (size_t i = 0; i < encrypted.length(); i++) {
        encrypted[i] ^= key[i % key.length()];
    }
    
    // Base64-like encoding to make it text-safe
    std::stringstream ss;
    for (unsigned char c : encrypted) {
        ss << std::hex << std::setw(2) << std::setfill('0') << (int)c;
    }
    return ss.str();
}

std::string decryptPassword(const std::string& encrypted) {
    // Decode from hex
    std::string decoded;
    for (size_t i = 0; i < encrypted.length(); i += 2) {
        std::string byteString = encrypted.substr(i, 2);
        char byte = (char)strtol(byteString.c_str(), nullptr, 16);
        decoded.push_back(byte);
    }
    
    // Generate same machine-specific key
    char hostname[256];
    gethostname(hostname, sizeof(hostname));
    std::string key = std::string(hostname) + getenv("USER");
    
    // XOR decryption
    for (size_t i = 0; i < decoded.length(); i++) {
        decoded[i] ^= key[i % key.length()];
    }
    
    return decoded;
}

void saveSudoPassword(const std::string& password) {
    std::string configPath = std::string(getenv("HOME")) + "/.fileduper_sudo.cfg";
    
    std::ofstream file(configPath);
    if (file.is_open()) {
        std::string encrypted = encryptPassword(password);
        file << encrypted << std::endl;
        file.close();
        
        // Set secure permissions (only owner can read/write)
        chmod(configPath.c_str(), 0600);
        
        std::cout << "[SUDO] Password encrypted and saved to " << configPath << std::endl;
    }
}

std::string loadSudoPassword() {
    std::string configPath = std::string(getenv("HOME")) + "/.fileduper_sudo.cfg";
    
    std::ifstream file(configPath);
    if (file.is_open()) {
        std::string encrypted;
        std::getline(file, encrypted);
        file.close();
        
        if (!encrypted.empty()) {
            std::string decrypted = decryptPassword(encrypted);
            std::cout << "[SUDO] Loaded encrypted password from " << configPath << std::endl;
            return decrypted;
        }
    }
    
    return "";
}

void clearSudoPassword() {
    std::string configPath = std::string(getenv("HOME")) + "/.fileduper_sudo.cfg";
    remove(configPath.c_str());
    std::cout << "[SUDO] Cleared saved password" << std::endl;
}

// ==================== SETTINGS SAVE/LOAD ====================
const std::string SETTINGS_FILE = "fileduper_settings.json";

void saveSettings() {
    json settings;
    
    // Directory Tree Settings
    settings["localTreeMaxDepth"] = appState.localTreeMaxDepth;
    settings["ftpTreeMaxDepth"] = appState.ftpTreeMaxDepth;
    settings["treeSearchShowSubdirs"] = appState.treeSearchShowSubdirs;
    settings["maxSearchHistory"] = appState.maxSearchHistory;
    
    // FTP Scan Optimization
    settings["ftpMaxThreads"] = appState.ftpMaxThreads;
    settings["ftpScanMaxDepth"] = appState.ftpScanMaxDepth;
    settings["ftpConnectTimeout"] = appState.ftpConnectTimeout;
    settings["ftpResponseTimeout"] = appState.ftpResponseTimeout;
    settings["ftpUseParallelScan"] = appState.ftpUseParallelScan;
    settings["ftpUseLsR"] = appState.ftpUseLsR;
    
    // General Settings
    settings["threadCount"] = appState.threadCount;
    settings["scannerThreads"] = appState.scannerThreads;
    settings["scanTimeout"] = appState.scanTimeout;
    settings["useLightningSpeed"] = appState.useLightningSpeed;
    settings["minFileSize"] = appState.minFileSize;
    settings["scanHiddenFiles"] = appState.scanHiddenFiles;
    settings["followSymlinks"] = appState.followSymlinks;
    settings["deleteEmptyDirs"] = appState.deleteEmptyDirs;
    
    // Hash Settings
    settings["hashAlgorithm"] = appState.hashAlgorithm;
    settings["hashPreset"] = appState.hashPreset;
    settings["useHardwareAcceleration"] = appState.useHardwareAcceleration;
    settings["useFastHash"] = appState.useFastHash;
    settings["bufferSize"] = appState.bufferSize;
    
    // Performance Optimizations
    settings["useAsyncIO"] = appState.useAsyncIO;
    settings["useCurlPooling"] = appState.useCurlPooling;
    settings["useMemoryMapping"] = appState.useMemoryMapping;
    settings["useTCPPing"] = appState.useTCPPing;
    settings["batchScanSize"] = appState.batchScanSize;
    settings["autoTuneThreads"] = appState.autoTuneThreads;
    settings["cacheFileHashes"] = appState.cacheFileHashes;
    settings["skipEmptyFiles"] = appState.skipEmptyFiles;
    settings["smartTimeout"] = appState.smartTimeout;
    
    // FTP/Network
    settings["ftpMaxRetries"] = appState.ftpMaxRetries;
    settings["ftpReadTimeout"] = appState.ftpReadTimeout;
    settings["ftpPipelining"] = appState.ftpPipelining;
    settings["ftpKeepAlive"] = appState.ftpKeepAlive;
    settings["curlBufferSize"] = appState.curlBufferSize;
    
    // Theme
    settings["currentTheme"] = appState.currentTheme;
    
    // Post-Scan Actions
    settings["postScanActionEnabled"] = appState.postScanActionEnabled;
    settings["postScanAction"] = appState.postScanAction;
    settings["postScanDelay"] = appState.postScanDelay;
    settings["autoDeleteMode"] = appState.autoDeleteMode;
    
    // Scan State
    settings["autoSaveScanState"] = appState.autoSaveScanState;
    
    // Security Settings
    settings["savePasswordsPermanently"] = appState.savePasswordsPermanently;
    settings["nfsAutoUnmount"] = appState.nfsAutoUnmount;
    
    // Export
    settings["autoExportResults"] = appState.autoExportResults;
    settings["exportPath"] = appState.exportPath;
    
    std::ofstream file(SETTINGS_FILE);
    if (file.is_open()) {
        file << settings.dump(4); // Pretty print with 4-space indent
        file.close();
        std::cout << "[Settings] Saved to " << SETTINGS_FILE << std::endl;
    } else {
        std::cerr << "[Settings] Failed to save settings!" << std::endl;
    }
}

void loadSettings() {
    std::ifstream file(SETTINGS_FILE);
    if (!file.is_open()) {
        std::cout << "[Settings] No settings file found, using defaults" << std::endl;
        
        // Set defaults manually
        appState.localTreeMaxDepth = 3;  // Reduced for NFS performance (was 10)
        appState.ftpTreeMaxDepth = 7;
        appState.treeSearchShowSubdirs = false;
        appState.maxSearchHistory = 20;
        appState.ftpMaxThreads = 16;
        appState.ftpScanMaxDepth = 30;
        appState.ftpConnectTimeout = 2;
        appState.ftpResponseTimeout = 5;
        appState.ftpUseParallelScan = true;
        appState.ftpUseLsR = true;
        appState.threadCount = 8;
        appState.scannerThreads = 128;
        appState.scanTimeout = 1;
        appState.useLightningSpeed = true;
        appState.minFileSize = 0;
        appState.scanHiddenFiles = true;
        appState.followSymlinks = true;
        appState.deleteEmptyDirs = true;
        appState.useGPU = false;
        appState.hashAlgorithm = "AUTO";
        appState.hashPreset = "AUTO";
        appState.useHardwareAcceleration = true;
        appState.detectedHardware = "CPU";
        appState.useFastHash = true;
        appState.bufferSize = 8192;
        appState.autoExportResults = false;
        appState.exportPath = "./duplicates.csv";
        appState.useAsyncIO = true;
        appState.useCurlPooling = true;
        appState.useMemoryMapping = true;
        appState.useTCPPing = true;
        appState.batchScanSize = 20;
        appState.autoTuneThreads = true;
        appState.cacheFileHashes = true;
        appState.skipEmptyFiles = true;
        appState.smartTimeout = true;
        appState.ftpMaxRetries = 3;
        appState.ftpReadTimeout = 15;
        appState.ftpPipelining = true;
        appState.ftpKeepAlive = true;
        appState.curlBufferSize = 512000;
        appState.currentTheme = 3;
        appState.postScanActionEnabled = false;
        appState.postScanAction = 0;
        appState.postScanDelay = 60;
        appState.autoDeleteMode = 0;
        appState.autoSaveScanState = true;
        appState.savePasswordsPermanently = true;  // Default: AN
        appState.nfsAutoUnmount = true;             // Default: AN
        
        return;
    }
    
    try {
        json settings;
        file >> settings;
        file.close();
        
        // Load Directory Tree Settings
        if (settings.contains("localTreeMaxDepth")) appState.localTreeMaxDepth = settings["localTreeMaxDepth"];
        if (settings.contains("ftpTreeMaxDepth")) appState.ftpTreeMaxDepth = settings["ftpTreeMaxDepth"];
        if (settings.contains("treeSearchShowSubdirs")) appState.treeSearchShowSubdirs = settings["treeSearchShowSubdirs"];
        if (settings.contains("maxSearchHistory")) appState.maxSearchHistory = settings["maxSearchHistory"];
        
        // Load FTP Scan Optimization
        if (settings.contains("ftpMaxThreads")) appState.ftpMaxThreads = settings["ftpMaxThreads"];
        if (settings.contains("ftpScanMaxDepth")) appState.ftpScanMaxDepth = settings["ftpScanMaxDepth"];
        if (settings.contains("ftpConnectTimeout")) appState.ftpConnectTimeout = settings["ftpConnectTimeout"];
        if (settings.contains("ftpResponseTimeout")) appState.ftpResponseTimeout = settings["ftpResponseTimeout"];
        if (settings.contains("ftpUseParallelScan")) appState.ftpUseParallelScan = settings["ftpUseParallelScan"];
        if (settings.contains("ftpUseLsR")) appState.ftpUseLsR = settings["ftpUseLsR"];
        
        // Load General Settings
        if (settings.contains("threadCount")) appState.threadCount = settings["threadCount"];
        if (settings.contains("scannerThreads")) appState.scannerThreads = settings["scannerThreads"];
        if (settings.contains("scanTimeout")) appState.scanTimeout = settings["scanTimeout"];
        if (settings.contains("useLightningSpeed")) appState.useLightningSpeed = settings["useLightningSpeed"];
        if (settings.contains("minFileSize")) appState.minFileSize = settings["minFileSize"];
        if (settings.contains("scanHiddenFiles")) appState.scanHiddenFiles = settings["scanHiddenFiles"];
        if (settings.contains("followSymlinks")) appState.followSymlinks = settings["followSymlinks"];
        if (settings.contains("deleteEmptyDirs")) appState.deleteEmptyDirs = settings["deleteEmptyDirs"];
        
        // Load Hash Settings
        if (settings.contains("hashAlgorithm")) appState.hashAlgorithm = settings["hashAlgorithm"];
        if (settings.contains("hashPreset")) appState.hashPreset = settings["hashPreset"];
        if (settings.contains("useHardwareAcceleration")) appState.useHardwareAcceleration = settings["useHardwareAcceleration"];
        if (settings.contains("useFastHash")) appState.useFastHash = settings["useFastHash"];
        if (settings.contains("bufferSize")) appState.bufferSize = settings["bufferSize"];
        
        // Load Performance Optimizations
        if (settings.contains("useAsyncIO")) appState.useAsyncIO = settings["useAsyncIO"];
        if (settings.contains("useCurlPooling")) appState.useCurlPooling = settings["useCurlPooling"];
        if (settings.contains("useMemoryMapping")) appState.useMemoryMapping = settings["useMemoryMapping"];
        if (settings.contains("useTCPPing")) appState.useTCPPing = settings["useTCPPing"];
        if (settings.contains("batchScanSize")) appState.batchScanSize = settings["batchScanSize"];
        if (settings.contains("autoTuneThreads")) appState.autoTuneThreads = settings["autoTuneThreads"];
        if (settings.contains("cacheFileHashes")) appState.cacheFileHashes = settings["cacheFileHashes"];
        if (settings.contains("skipEmptyFiles")) appState.skipEmptyFiles = settings["skipEmptyFiles"];
        if (settings.contains("smartTimeout")) appState.smartTimeout = settings["smartTimeout"];
        
        // Load FTP/Network
        if (settings.contains("ftpMaxRetries")) appState.ftpMaxRetries = settings["ftpMaxRetries"];
        if (settings.contains("ftpReadTimeout")) appState.ftpReadTimeout = settings["ftpReadTimeout"];
        if (settings.contains("ftpPipelining")) appState.ftpPipelining = settings["ftpPipelining"];
        if (settings.contains("ftpKeepAlive")) appState.ftpKeepAlive = settings["ftpKeepAlive"];
        if (settings.contains("curlBufferSize")) appState.curlBufferSize = settings["curlBufferSize"];
        
        // Load Theme
        if (settings.contains("currentTheme")) appState.currentTheme = settings["currentTheme"];
        
        // Load Post-Scan Actions
        if (settings.contains("postScanActionEnabled")) appState.postScanActionEnabled = settings["postScanActionEnabled"];
        if (settings.contains("postScanAction")) appState.postScanAction = settings["postScanAction"];
        if (settings.contains("postScanDelay")) appState.postScanDelay = settings["postScanDelay"];
        if (settings.contains("autoDeleteMode")) appState.autoDeleteMode = settings["autoDeleteMode"];
        
        // Load Scan State
        if (settings.contains("autoSaveScanState")) appState.autoSaveScanState = settings["autoSaveScanState"];
        
        // Load Security Settings
        if (settings.contains("savePasswordsPermanently")) appState.savePasswordsPermanently = settings["savePasswordsPermanently"];
        if (settings.contains("nfsAutoUnmount")) appState.nfsAutoUnmount = settings["nfsAutoUnmount"];
        
        // Load Export
        if (settings.contains("autoExportResults")) appState.autoExportResults = settings["autoExportResults"];
        if (settings.contains("exportPath")) appState.exportPath = settings["exportPath"];
        
        std::cout << "[Settings] Loaded from " << SETTINGS_FILE << std::endl;
        std::cout << "[Settings] ftpTreeMaxDepth = " << appState.ftpTreeMaxDepth << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "[Settings] Error loading settings: " << e.what() << std::endl;
        std::cerr << "[Settings] Using defaults" << std::endl;
    }
}

// Auto-Export Results (CSV)
void autoExportResults(const std::string& filename) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "[Export] Failed to export to: " << filename << std::endl;
        return;
    }
    
    // CSV Header
    file << "Hash,Dateiname,Pfad,Größe,Duplikat-Gruppe" << std::endl;
    
    int groupId = 0;
    for (const auto& pair : appState.filesByHash) {
        if (pair.second.size() <= 1) continue; // Keine Duplikate
        
        groupId++;
        for (const auto& filepath : pair.second) {
            struct stat st;
            long long size = 0;
            if (stat(filepath.c_str(), &st) == 0) {
                size = st.st_size;
            }
            
            // Trenne Pfad und Dateiname
            size_t lastSlash = filepath.find_last_of('/');
            std::string path = filepath.substr(0, lastSlash);
            std::string filename_only = filepath.substr(lastSlash + 1);
            
            file << pair.first << ","
                 << filename_only << ","
                 << path << ","
                 << size << ","
                 << groupId << std::endl;
        }
    }
    
    file.close();
    std::cout << "[Export] Results exported to: " << filename << std::endl;
}

// Hilfsfunktion: Finde die beste Original-Datei (die am besten in ihr Verzeichnis passt)
// Strategie: Wähle die Datei, die alphabetisch am nächsten bei anderen Dateien im gleichen Verzeichnis liegt
size_t findBestOriginalFile(const std::vector<std::string>& files) {
    if (files.size() <= 1) return 0;
    
    // Gruppiere Dateien nach Verzeichnis
    std::map<std::string, std::vector<size_t>> dirFiles; // Verzeichnis -> Indizes der Dateien
    
    for (size_t i = 0; i < files.size(); i++) {
        size_t lastSlash = files[i].find_last_of('/');
        std::string dir = (lastSlash != std::string::npos) ? files[i].substr(0, lastSlash) : "";
        dirFiles[dir].push_back(i);
    }
    
    // Bewerte jede Datei: Dateien in Verzeichnissen mit mehreren Duplikaten haben niedrigere Priorität
    // (wir wollen die Datei behalten, die ALLEINE in ihrem Verzeichnis ist)
    size_t bestIdx = 0;
    size_t minDuplicatesInDir = SIZE_MAX;
    
    for (size_t i = 0; i < files.size(); i++) {
        size_t lastSlash = files[i].find_last_of('/');
        std::string dir = (lastSlash != std::string::npos) ? files[i].substr(0, lastSlash) : "";
        
        size_t duplicatesInThisDir = dirFiles[dir].size();
        
        // Bevorzuge Dateien, die alleine in ihrem Verzeichnis sind
        if (duplicatesInThisDir < minDuplicatesInDir) {
            minDuplicatesInDir = duplicatesInThisDir;
            bestIdx = i;
        } else if (duplicatesInThisDir == minDuplicatesInDir) {
            // Bei Gleichstand: Wähle die alphabetisch erste (stabilere Sortierung)
            if (files[i] < files[bestIdx]) {
                bestIdx = i;
            }
        }
    }
    
    return bestIdx;
}

// Connect to server and fetch directories recursively
// Callback für CURL um Daten zu speichern
static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t totalSize = size * nmemb;
    ((std::string*)userp)->append((char*)contents, totalSize);
    
    // Track network bandwidth during FTP scan
    appState.ftpBytesTransferred += totalSize;
    
    return totalSize;
}

// FTP Verzeichnisliste abrufen (Hybrid: ls -R oder Parallel Multi-Threaded BFS)
bool fetchFtpDirectories(const std::string& url, const std::string& username, 
                         const std::string& password, std::vector<std::string>& directories,
                         const std::string& currentPath = "/") {
    
    // ==================== STRATEGY 1: Try recursive ls -R (if enabled) ====================
    if (appState.ftpUseLsR) {
        std::cout << "[FTP] Attempting fast recursive scan with 'ls -R'..." << std::endl;
        
        CURL* curl = curl_easy_init();
        if (curl) {
        std::string readBuffer;
        readBuffer.reserve(2097152); // 2MB for recursive listing
        
        // Build URL
        std::string fullUrl = url;
        if (!fullUrl.empty() && fullUrl.back() == '/' && !currentPath.empty() && currentPath[0] == '/') {
            fullUrl.pop_back();
        }
        fullUrl += currentPath;
        if (!fullUrl.empty() && fullUrl.back() != '/') {
            fullUrl += '/';
        }
        
        // Try using CUSTOMREQUEST for ls -R
        curl_easy_setopt(curl, CURLOPT_URL, fullUrl.c_str());
        curl_easy_setopt(curl, CURLOPT_USERNAME, username.c_str());
        curl_easy_setopt(curl, CURLOPT_PASSWORD, password.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "LIST -R");
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L); // Longer for recursive
        curl_easy_setopt(curl, CURLOPT_TCP_KEEPALIVE, 1L);
        
        CURLcode res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        
        if (res == CURLE_OK && !readBuffer.empty()) {
            std::cout << "[FTP] Recursive listing successful! Received " << readBuffer.size() << " bytes" << std::endl;
            
            // Parse recursive output
            std::istringstream iss(readBuffer);
            std::string line;
            std::string currentDir = "/";
            int totalDirs = 0;
            
            while (std::getline(iss, line)) {
                // Remove trailing \r if present
                if (!line.empty() && line.back() == '\r') {
                    line.pop_back();
                }
                
                // Directory header (ends with :)
                if (!line.empty() && line.back() == ':') {
                    std::string dirPath = line.substr(0, line.size() - 1);
                    if (dirPath == ".") {
                        currentDir = "/";
                    } else if (dirPath.size() >= 2 && dirPath.substr(0, 2) == "./") {
                        currentDir = "/" + dirPath.substr(2);
                    } else {
                        currentDir = "/" + dirPath;
                    }
                    continue;
                }
                
                // Parse directory entries
                if (line.empty() || line.length() < 10) continue;
                if (line[0] != 'd') continue;
                
                size_t lastSpace = line.find_last_of(' ');
                if (lastSpace != std::string::npos) {
                    std::string dirName = line.substr(lastSpace + 1);
                    if (dirName == "." || dirName == "..") continue;
                    
                    // Baue den vollständigen Pfad
                    std::string fullPath;
                    if (currentDir == "/") {
                        fullPath = "/" + dirName;
                    } else {
                        fullPath = currentDir + "/" + dirName;
                    }
                    
                    int depth = std::count(fullPath.begin(), fullPath.end(), '/');
                    
                    if (depth <= appState.ftpTreeMaxDepth) {
                        directories.push_back(fullPath);
                        totalDirs++;
                    }
                }
            }
            
            std::cout << "[FTP] Recursive scan complete: " << totalDirs << " directories found (FAST MODE)" << std::endl;
            return true;
        }
        
        std::cout << "[FTP] Recursive listing not supported, falling back to parallel scan..." << std::endl;
        } // Ende if (curl)
    } else {
        std::cout << "[FTP] LIST -R disabled in settings, using parallel scan..." << std::endl;
    } // Ende if (appState.ftpUseLsR)
    
    // ==================== STRATEGY 2: Parallel Multi-Threaded BFS ====================
    int numThreads = std::max(1, std::min(appState.ftpMaxThreads, 32));
    std::cout << "[FTP] Starting parallel directory scan (" << numThreads << " threads) from: " << currentPath << std::endl;
    
    // Reset progress tracking
    appState.ftpDirsProcessed = 0;
    appState.ftpTotalDirsEstimate = 1; // Start with at least root
    
    // BFS queue structure
    struct DirToScan {
        std::string path;
        int depth;
    };
    
    std::queue<DirToScan> scanQueue;
    std::mutex queueMutex;
    std::mutex directoriesMutex;
    std::atomic<int> totalDirsFound{0};
    std::atomic<int> activeThreads{0};
    std::atomic<bool> scanComplete{false};
    
    scanQueue.push({currentPath, currentPath == "/" ? 0 : std::count(currentPath.begin(), currentPath.end(), '/')});
    
    // Worker function
    auto scanWorker = [&]() {
        activeThreads++;
        
        while (true) {
            DirToScan current;
            bool gotWork = false;
            
            // Get next directory from queue
            {
                std::lock_guard<std::mutex> lock(queueMutex);
                if (!scanQueue.empty()) {
                    current = scanQueue.front();
                    scanQueue.pop();
                    gotWork = true;
                }
            }
            
            // If no work available, check if we should exit
            if (!gotWork) {
                activeThreads--;
                
                // Wait a bit to see if more work arrives
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
                
                // Check again if there's work or if all threads are idle
                bool shouldExit = false;
                {
                    std::lock_guard<std::mutex> lock(queueMutex);
                    if (scanQueue.empty() && activeThreads.load() == 0) {
                        shouldExit = true;
                    } else if (!scanQueue.empty()) {
                        // Work arrived, continue
                        activeThreads++;
                        continue;
                    } else {
                        shouldExit = true;
                    }
                }
                
                if (shouldExit) {
                    return;
                } else {
                    activeThreads++;
                    continue;
                }
            }
            
            // Update progress: increment processed count
            int processed = appState.ftpDirsProcessed.fetch_add(1) + 1;
            
            // Update estimated total and progress (streng monoton steigend!)
            {
                std::lock_guard<std::mutex> lock(queueMutex);
                int queueSize = scanQueue.size();
                int currentTotal = processed + queueSize;
                
                // Speichere den maximalen jemals gesehenen Total-Wert
                // Dies verhindert dass der Fortschritt zurückgeht wenn die Queue wächst
                int maxSeen = appState.ftpTotalDirsEstimate.load();
                if (currentTotal > maxSeen) {
                    appState.ftpTotalDirsEstimate = currentTotal;
                    maxSeen = currentTotal;
                }
                
                // Berechne Fortschritt: processed / maxSeen
                // Da processed nur steigt und maxSeen nur steigt, ist der Fortschritt monoton
                float dirProgress = 0.3f * ((float)processed / (float)std::max(processed, maxSeen));
                
                // Direkt setzen - ist bereits monoton
                appState.scanProgress = std::max(appState.scanProgress, dirProgress);
            }
            
            // Check depth limit
            if (current.depth >= appState.ftpTreeMaxDepth) {
                continue;
            }
            
            // USE CACHE: Get subdirectories with cache support (FAST!)
            std::vector<std::string> subdirNames = getFtpSubdirectories(current.path, url, username, password, true);
            
            // Build full paths from directory names
            std::vector<std::string> subdirs;
            for (const auto& dirName : subdirNames) {
                std::string fullPath = current.path;
                if (fullPath != "/" && !fullPath.empty() && fullPath.back() != '/') {
                    fullPath += "/";
                }
                if (fullPath == "/") {
                    fullPath += dirName;
                } else {
                    fullPath += dirName;
                }
                subdirs.push_back(fullPath);
            }
            
            // Add results to shared structures
            if (!subdirs.empty()) {
                {
                    std::lock_guard<std::mutex> lock(directoriesMutex);
                    directories.insert(directories.end(), subdirs.begin(), subdirs.end());
                }
                
                {
                    std::lock_guard<std::mutex> lock(queueMutex);
                    for (const auto& subdir : subdirs) {
                        scanQueue.push({subdir, current.depth + 1});
                    }
                }
                
                int newTotal = totalDirsFound.fetch_add(subdirs.size()) + subdirs.size();
                std::cout << "[FTP] Found " << subdirs.size() << " subdirs in " << current.path 
                          << " (total: " << newTotal << ")" << std::endl;
            }
        }
    };
    
    // Launch worker threads
    std::vector<std::thread> workers;
    for (int i = 0; i < numThreads; i++) {
        workers.emplace_back(scanWorker);
    }
    
    // Wait for all threads to complete
    for (auto& worker : workers) {
        if (worker.joinable()) {
            worker.join();
        }
    }
    
    std::cout << "[FTP] Parallel scan complete: " << totalDirsFound.load() << " directories found" << std::endl;
    
    return true;
}

// ============================================================================
// SUDO PASSWORD HELPER - GUI Password Prompt
// ============================================================================

// Global state for password prompt
static bool showPasswordPrompt = false;
static char sudoPassword[256] = "";
static bool passwordEntered = false;
static std::string pendingSudoCommand = "";

// Execute command with sudo using GUI password prompt
// OPTIMIZED: Native fork/exec instead of system() - 10-50x faster!
bool executeSudoCommand(const std::string& command) {
    // First try without password (user might have NOPASSWD configured)
    pid_t pid = fork();
    if (pid == 0) {
        // Child process
        execl("/usr/bin/sudo", "sudo", "-n", "true", nullptr);
        _exit(1);
    } else if (pid > 0) {
        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
            std::cout << "[SUDO] Passwordless sudo available" << std::endl;
            // Execute actual command without password
            pid = fork();
            if (pid == 0) {
                execl("/bin/sh", "sh", "-c", command.c_str(), nullptr);
                _exit(1);
            }
            waitpid(pid, &status, 0);
            return WIFEXITED(status) && WEXITSTATUS(status) == 0;
        }
    }
    
    // Check if we have cached password
    if (appState.sudoPasswordAvailable && !appState.sudoPassword.empty()) {
        // Use popen for password piping - much faster than system()
        std::string fullCmd = "echo '" + appState.sudoPassword + "' | sudo -S " + command + " 2>/dev/null";
        FILE* pipe = popen(fullCmd.c_str(), "r");
        if (!pipe) return false;
        int result = pclose(pipe);
        return WIFEXITED(result) && WEXITSTATUS(result) == 0;
    }
    
    // No password - request it BUT DON'T BLOCK and prevent duplicate prompts
    if (!appState.showSudoPasswordPrompt) {
        appState.showSudoPasswordPrompt = true;
        std::cout << "[SUDO] Password needed, showing prompt (non-blocking)" << std::endl;
    }
    return false;
}


// Check if a path is a valid mountpoint
bool isNfsMounted(const std::string& mountPoint) {
    if (mountPoint.empty()) return false;
    
    // OPTIMIZED: Use native statfs() instead of system(mountpoint) - 10x faster!
    struct stat st;
    if (stat(mountPoint.c_str(), &st) != 0) {
        return false;
    }
    
    // Check parent directory to detect mountpoint
    std::string parentPath = mountPoint;
    size_t lastSlash = parentPath.find_last_of('/');
    if (lastSlash != std::string::npos && lastSlash > 0) {
        parentPath = parentPath.substr(0, lastSlash);
    } else {
        parentPath = "/";
    }
    
    struct stat parentSt;
    if (stat(parentPath.c_str(), &parentSt) != 0) {
        return false;
    }
    
    // A mountpoint has different device ID than its parent
    return (st.st_dev != parentSt.st_dev);
}

// Mount NFS share
bool mountNFS(FtpPreset& preset) {
    // Fallback: wenn nfsExportPath nicht gesetzt, verwende "/export"
    if (preset.nfsExportPath.empty()) {
        preset.nfsExportPath = "/export/" + preset.name;
    }
    
    // Fallback: wenn nfsMountPoint nicht gesetzt, erstelle einen
    if (preset.nfsMountPoint.empty()) {
        preset.nfsMountPoint = "/mnt/nfs_" + preset.name;
    }
    
    if (preset.ip.empty() || preset.nfsExportPath.empty() || preset.nfsMountPoint.empty()) {
        std::cerr << "[NFS] Invalid configuration: missing IP, export path, or mount point" << std::endl;
        showStatusNotification("❌ NFS: Ungültige Konfiguration", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        return false;
    }
    
    // Only log mount attempt once
    static std::set<std::string> loggedMounts;
    std::string mountKey = preset.ip + ":" + preset.nfsExportPath;
    bool firstAttempt = (loggedMounts.find(mountKey) == loggedMounts.end());
    
    if (firstAttempt) {
        std::cout << "[NFS] Mounting " << preset.ip << ":" << preset.nfsExportPath 
                  << " -> " << preset.nfsMountPoint << std::endl;
        showStatusNotification("⏳ NFS: Verbinde mit " + preset.ip + "...", ImVec4(0.5f, 0.8f, 1.0f, 1.0f));
        loggedMounts.insert(mountKey);
    }
    
    // Create mount point directory with sudo if needed
    struct stat st;
    if (stat(preset.nfsMountPoint.c_str(), &st) != 0) {
        if (firstAttempt) {
            std::cout << "[NFS] Creating mount point: " << preset.nfsMountPoint << std::endl;
        }
        std::string mkdirCmd = "mkdir -p \"" + preset.nfsMountPoint + "\"";
        if (!executeSudoCommand(mkdirCmd)) {
            if (firstAttempt) {
                std::cerr << "[NFS] Failed to create mount point (waiting for password...)" << std::endl;
                showStatusNotification("🔐 NFS: Warte auf Passwort...", ImVec4(1.0f, 1.0f, 0.3f, 1.0f));
            }
            return false;
        }
        
        // Set permissions so current user can access
        std::string chownCmd = "chown $USER:$USER \"" + preset.nfsMountPoint + "\"";
        executeSudoCommand(chownCmd);
    }
    
    // Check if already mounted
    if (isNfsMounted(preset.nfsMountPoint)) {
        if (firstAttempt) {
            std::cout << "[NFS] Already mounted: " << preset.nfsMountPoint << std::endl;
            showStatusNotification("✅ NFS: Bereits verbunden (" + preset.name + ")", ImVec4(0.3f, 1.0f, 0.3f, 1.0f));
        }
        preset.nfsMounted = true;
        return true;
    }
    
    // Build mount command
    std::string mountCmd = "mount -t nfs ";
    
    // Add options if specified
    if (!preset.nfsOptions.empty()) {
        mountCmd += "-o " + preset.nfsOptions + " ";
    } else {
        // Default options: NFSv4, read-write
        std::string options = "vers=4,rw";
        
        // Add Kerberos/Secure NFS authentication if username/password provided
        if (!preset.username.empty()) {
            options += ",sec=krb5";  // Use Kerberos authentication
            std::cout << "[NFS] Using Kerberos authentication for user: " << preset.username << std::endl;
            
            // For Kerberos, we need to kinit first
            if (!preset.password.empty()) {
                std::string kinitCmd = "echo '" + preset.password + "' | kinit " + preset.username;
                if (firstAttempt) {
                    std::cout << "[NFS] Authenticating with Kerberos..." << std::endl;
                }
                executeSudoCommand(kinitCmd);
            }
        }
        
        mountCmd += "-o " + options + " ";
    }
    
    mountCmd += "\"" + preset.ip + ":" + preset.nfsExportPath + "\" ";
    mountCmd += "\"" + preset.nfsMountPoint + "\"";
    
    if (firstAttempt) {
        std::cout << "[NFS] Executing mount..." << std::endl;
    }
    
    // Execute mount command with sudo
    if (!executeSudoCommand(mountCmd)) {
        // Don't spam "Mount failed" - it's waiting for password
        return false;
    }
    
    // Verify mount succeeded
    if (!isNfsMounted(preset.nfsMountPoint)) {
        std::cerr << "[NFS] Mount command succeeded but mountpoint verification failed" << std::endl;
        showStatusNotification("❌ NFS: Mount fehlgeschlagen (" + preset.name + ")", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        preset.nfsMounted = false;
        return false;
    }
    
    std::cout << "[NFS] ✅ Successfully mounted: " << preset.nfsMountPoint << std::endl;
    showStatusNotification("✅ NFS: Erfolgreich verbunden (" + preset.name + ")", ImVec4(0.3f, 1.0f, 0.3f, 1.0f));
    preset.nfsMounted = true;
    
    // Auto-discover directories after mount
    preset.directories.clear();
    preset.directories.push_back(preset.nfsMountPoint);
    
    return true;
}

// Unmount NFS share
bool unmountNFS(FtpPreset& preset) {
    if (preset.nfsMountPoint.empty()) {
        std::cerr << "[NFS] No mount point specified" << std::endl;
        return false;
    }
    
    std::cout << "[NFS] Unmounting " << preset.nfsMountPoint << std::endl;
    
    // Check if actually mounted
    if (!isNfsMounted(preset.nfsMountPoint)) {
        std::cout << "[NFS] Not mounted: " << preset.nfsMountPoint << std::endl;
        preset.nfsMounted = false;
        return true;
    }
    
    // Unmount
    std::string umountCmd = "umount \"" + preset.nfsMountPoint + "\"";
    
    if (!executeSudoCommand(umountCmd)) {
        // Try force unmount if regular unmount fails
        std::cout << "[NFS] Regular unmount failed, trying force unmount..." << std::endl;
        std::string forceCmd = "umount -f \"" + preset.nfsMountPoint + "\"";
        if (!executeSudoCommand(forceCmd)) {
            std::cerr << "[NFS] Force unmount also failed" << std::endl;
            return false;
        }
    }
    
    std::cout << "[NFS] ✅ Successfully unmounted: " << preset.nfsMountPoint << std::endl;
    preset.nfsMounted = false;
    preset.directories.clear();
    
    return true;
}

// ============================================================================
// SMB/CIFS MOUNT/UMOUNT FUNCTIONS
// ============================================================================

// Check if a path is a valid SMB mountpoint
bool isSmbMounted(const std::string& mountPoint) {
    if (mountPoint.empty()) return false;
    
    // OPTIMIZED: Use native statfs() instead of system(mountpoint) - 10x faster!
    struct stat st;
    if (stat(mountPoint.c_str(), &st) != 0) {
        return false;
    }
    
    // Check parent directory to detect mountpoint
    std::string parentPath = mountPoint;
    size_t lastSlash = parentPath.find_last_of('/');
    if (lastSlash != std::string::npos && lastSlash > 0) {
        parentPath = parentPath.substr(0, lastSlash);
    } else {
        parentPath = "/";
    }
    
    struct stat parentSt;
    if (stat(parentPath.c_str(), &parentSt) != 0) {
        return false;
    }
    
    // A mountpoint has different device ID than its parent
    return (st.st_dev != parentSt.st_dev);
}

// Mount SMB/CIFS share
bool mountSMB(FtpPreset& preset) {
    // Fallback: wenn smbSharePath nicht gesetzt, baue ihn aus ip
    if (preset.smbSharePath.empty() && !preset.ip.empty()) {
        preset.smbSharePath = "//" + preset.ip + "/" + preset.name;
    }
    
    // Fallback: wenn smbMountPoint nicht gesetzt, erstelle einen
    if (preset.smbMountPoint.empty()) {
        preset.smbMountPoint = "/mnt/smb_" + preset.name;
    }
    
    if (preset.smbSharePath.empty() || preset.smbMountPoint.empty()) {
        std::cerr << "[SMB] Invalid configuration: missing share path or mount point" << std::endl;
        showStatusNotification("❌ SMB: Ungültige Konfiguration", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        return false;
    }
    
    std::cout << "[SMB] Mounting " << preset.smbSharePath 
              << " -> " << preset.smbMountPoint << std::endl;
    showStatusNotification("⏳ SMB: Verbinde mit " + preset.ip + "...", ImVec4(0.5f, 0.8f, 1.0f, 1.0f));
    
    // Create mount point directory with sudo if needed
    struct stat st;
    if (stat(preset.smbMountPoint.c_str(), &st) != 0) {
        std::cout << "[SMB] Creating mount point: " << preset.smbMountPoint << std::endl;
        std::string mkdirCmd = "mkdir -p \"" + preset.smbMountPoint + "\"";
        if (!executeSudoCommand(mkdirCmd)) {
            std::cerr << "[SMB] Failed to create mount point" << std::endl;
            showStatusNotification("🔐 SMB: Warte auf Passwort...", ImVec4(1.0f, 1.0f, 0.3f, 1.0f));
            return false;
        }
        
        // Set permissions so current user can access
        std::string chownCmd = "chown $USER:$USER \"" + preset.smbMountPoint + "\"";
        executeSudoCommand(chownCmd);
    }
    
    // Check if already mounted
    if (isSmbMounted(preset.smbMountPoint)) {
        std::cout << "[SMB] Already mounted: " << preset.smbMountPoint << std::endl;
        preset.smbMounted = true;
        showStatusNotification("✅ SMB: Bereits verbunden (" + preset.name + ")", ImVec4(0.3f, 1.0f, 0.3f, 1.0f));
        return true;
    }
    
    // Build credentials file for secure authentication
    std::string credFile = "/tmp/.smb_cred_" + std::to_string(getpid());
    std::ofstream credStream(credFile);
    if (credStream.is_open()) {
        credStream << "username=" << preset.username << "\n";
        credStream << "password=" << preset.password << "\n";
        if (!preset.smbDomain.empty()) {
            credStream << "domain=" << preset.smbDomain << "\n";
        }
        if (!preset.smbWorkgroup.empty()) {
            credStream << "workgroup=" << preset.smbWorkgroup << "\n";
        }
        credStream.close();
        chmod(credFile.c_str(), 0600); // Secure permissions
    }
    
    // Build mount command
    std::string mountCmd = "mount -t cifs ";
    
    // Add options
    std::string options = "credentials=" + credFile;
    if (!preset.smbOptions.empty()) {
        options += "," + preset.smbOptions;
    } else {
        // Default options: SMB3, current user's UID/GID
        options += ",vers=3.0,uid=" + std::to_string(getuid()) + 
                   ",gid=" + std::to_string(getgid());
    }
    
    mountCmd += "-o " + options + " ";
    mountCmd += "\"" + preset.smbSharePath + "\" ";
    mountCmd += "\"" + preset.smbMountPoint + "\"";
    
    std::cout << "[SMB] Executing mount..." << std::endl;
    
    // Execute mount command with sudo
    bool mountSuccess = executeSudoCommand(mountCmd);
    
    // Clean up credentials file
    unlink(credFile.c_str());
    
    if (!mountSuccess) {
        std::cerr << "[SMB] Mount failed" << std::endl;
        preset.smbMounted = false;
        showStatusNotification("❌ SMB: Mount fehlgeschlagen (" + preset.name + ")", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        return false;
    }
    
    // Verify mount succeeded
    if (!isSmbMounted(preset.smbMountPoint)) {
        std::cerr << "[SMB] Mount command succeeded but mountpoint verification failed" << std::endl;
        preset.smbMounted = false;
        showStatusNotification("❌ SMB: Mount fehlgeschlagen (" + preset.name + ")", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        return false;
    }
    
    std::cout << "[SMB] ✅ Successfully mounted: " << preset.smbMountPoint << std::endl;
    preset.smbMounted = true;
    showStatusNotification("✅ SMB: Erfolgreich verbunden (" + preset.name + ")", ImVec4(0.3f, 1.0f, 0.3f, 1.0f));
    
    // Auto-discover directories after mount
    preset.directories.clear();
    preset.directories.push_back(preset.smbMountPoint);
    
    return true;
}

// Unmount SMB/CIFS share
bool unmountSMB(FtpPreset& preset) {
    if (preset.smbMountPoint.empty()) {
        std::cerr << "[SMB] No mount point specified" << std::endl;
        return false;
    }
    
    std::cout << "[SMB] Unmounting " << preset.smbMountPoint << std::endl;
    
    // Check if actually mounted
    if (!isSmbMounted(preset.smbMountPoint)) {
        std::cout << "[SMB] Not mounted: " << preset.smbMountPoint << std::endl;
        preset.smbMounted = false;
        return true;
    }
    
    // Unmount
    std::string umountCmd = "umount \"" + preset.smbMountPoint + "\"";
    
    if (!executeSudoCommand(umountCmd)) {
        // Try force unmount if regular unmount fails
        std::cout << "[SMB] Regular unmount failed, trying force unmount..." << std::endl;
        std::string forceCmd = "umount -f \"" + preset.smbMountPoint + "\"";
        if (!executeSudoCommand(forceCmd)) {
            std::cerr << "[SMB] Force unmount also failed" << std::endl;
            return false;
        }
    }
    
    std::cout << "[SMB] ✅ Successfully unmounted: " << preset.smbMountPoint << std::endl;
    preset.smbMounted = false;
    preset.directories.clear();
    
    return true;
}

// ============================================================================
// WEBDAV MOUNT/UMOUNT FUNCTIONS
// ============================================================================

// Check if a path is a valid WebDAV mountpoint
bool isWebDavMounted(const std::string& mountPoint) {
    if (mountPoint.empty()) return false;
    
    // OPTIMIZED: Use native statfs() instead of system(mountpoint) - 10x faster!
    struct stat st;
    if (stat(mountPoint.c_str(), &st) != 0) {
        return false;
    }
    
    // Check parent directory to detect mountpoint
    std::string parentPath = mountPoint;
    size_t lastSlash = parentPath.find_last_of('/');
    if (lastSlash != std::string::npos && lastSlash > 0) {
        parentPath = parentPath.substr(0, lastSlash);
    } else {
        parentPath = "/";
    }
    
    struct stat parentSt;
    if (stat(parentPath.c_str(), &parentSt) != 0) {
        return false;
    }
    
    // A mountpoint has different device ID than its parent
    return (st.st_dev != parentSt.st_dev);
}

// Mount WebDAV share
bool mountWebDAV(FtpPreset& preset) {
    // Fallback: wenn davUrl nicht gesetzt, baue ihn aus ip
    if (preset.davUrl.empty() && !preset.ip.empty()) {
        std::string protocol = preset.davUseSSL ? "https" : "http";
        preset.davUrl = protocol + "://" + preset.ip + "/webdav";
    }
    
    // Fallback: wenn davMountPoint nicht gesetzt, erstelle einen
    if (preset.davMountPoint.empty()) {
        preset.davMountPoint = "/mnt/webdav_" + preset.name;
    }
    
    if (preset.davUrl.empty() || preset.davMountPoint.empty()) {
        std::cerr << "[WebDAV] Invalid configuration: missing URL or mount point" << std::endl;
        showStatusNotification("❌ WebDAV: Ungültige Konfiguration", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        return false;
    }
    
    std::cout << "[WebDAV] Mounting " << preset.davUrl 
              << " -> " << preset.davMountPoint << std::endl;
    
    // Extract server from URL for notification
    std::string serverName = preset.davUrl;
    size_t startPos = serverName.find("://");
    if (startPos != std::string::npos) {
        startPos += 3;
        size_t endPos = serverName.find("/", startPos);
        serverName = serverName.substr(startPos, endPos - startPos);
    }
    showStatusNotification("⏳ WebDAV: Verbinde mit " + serverName + "...", ImVec4(0.5f, 0.8f, 1.0f, 1.0f));
    
    // Create mount point directory with sudo if needed
    struct stat st;
    if (stat(preset.davMountPoint.c_str(), &st) != 0) {
        std::cout << "[WebDAV] Creating mount point: " << preset.davMountPoint << std::endl;
        std::string mkdirCmd = "mkdir -p \"" + preset.davMountPoint + "\"";
        if (!executeSudoCommand(mkdirCmd)) {
            std::cerr << "[WebDAV] Failed to create mount point" << std::endl;
            showStatusNotification("🔐 WebDAV: Warte auf Passwort...", ImVec4(1.0f, 1.0f, 0.3f, 1.0f));
            return false;
        }
        
        // Set permissions so current user can access
        std::string chownCmd = "chown $USER:$USER \"" + preset.davMountPoint + "\"";
        executeSudoCommand(chownCmd);
    }
    
    // Check if already mounted
    if (isWebDavMounted(preset.davMountPoint)) {
        std::cout << "[WebDAV] Already mounted: " << preset.davMountPoint << std::endl;
        preset.davMounted = true;
        showStatusNotification("✅ WebDAV: Bereits verbunden (" + preset.name + ")", ImVec4(0.3f, 1.0f, 0.3f, 1.0f));
        return true;
    }
    
    // Create davfs2 secrets file for authentication
    std::string secretsFile = std::string(getenv("HOME")) + "/.davfs2/secrets";
    std::string secretsDir = std::string(getenv("HOME")) + "/.davfs2";
    
    // Ensure .davfs2 directory exists
    std::string mkdirDavCmd = "mkdir -p \"" + secretsDir + "\" 2>/dev/null";
    system(mkdirDavCmd.c_str());
    
    // Check if secrets file exists, if not create it
    struct stat secretsSt;
    bool secretsExist = (stat(secretsFile.c_str(), &secretsSt) == 0);
    
    if (!secretsExist) {
        // Create empty secrets file with secure permissions
        std::ofstream secrets(secretsFile);
        if (secrets.is_open()) {
            secrets << "# davfs2 secrets file - Format: URL username password\n";
            secrets.close();
            chmod(secretsFile.c_str(), 0600);
        }
    }
    
    // Add credentials to secrets file (append)
    std::ofstream secrets(secretsFile, std::ios::app);
    if (secrets.is_open()) {
        secrets << preset.davUrl << " " << preset.username << " " << preset.password << "\n";
        secrets.close();
        chmod(secretsFile.c_str(), 0600); // Ensure secure permissions
    }
    
    // Build mount command
    std::string mountCmd = "mount -t davfs ";
    
    // Add options
    if (!preset.davOptions.empty()) {
        mountCmd += "-o " + preset.davOptions + " ";
    } else {
        // Default options: current user's UID/GID, file/dir permissions
        mountCmd += "-o uid=" + std::to_string(getuid()) + 
                   ",gid=" + std::to_string(getgid()) + 
                   ",file_mode=0600,dir_mode=0700 ";
    }
    
    mountCmd += "\"" + preset.davUrl + "\" ";
    mountCmd += "\"" + preset.davMountPoint + "\"";
    
    std::cout << "[WebDAV] Executing mount..." << std::endl;
    
    // Execute mount command with sudo
    if (!executeSudoCommand(mountCmd)) {
        std::cerr << "[WebDAV] Mount failed" << std::endl;
        preset.davMounted = false;
        showStatusNotification("❌ WebDAV: Mount fehlgeschlagen (" + preset.name + ")", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        return false;
    }
    
    // Verify mount succeeded
    if (!isWebDavMounted(preset.davMountPoint)) {
        std::cerr << "[WebDAV] Mount command succeeded but mountpoint verification failed" << std::endl;
        preset.davMounted = false;
        showStatusNotification("❌ WebDAV: Mount fehlgeschlagen (" + preset.name + ")", ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        return false;
    }
    
    std::cout << "[WebDAV] ✅ Successfully mounted: " << preset.davMountPoint << std::endl;
    preset.davMounted = true;
    showStatusNotification("✅ WebDAV: Erfolgreich verbunden (" + preset.name + ")", ImVec4(0.3f, 1.0f, 0.3f, 1.0f));
    
    // Auto-discover directories after mount
    preset.directories.clear();
    preset.directories.push_back(preset.davMountPoint);
    
    return true;
}

// Unmount WebDAV share
bool unmountWebDAV(FtpPreset& preset) {
    if (preset.davMountPoint.empty()) {
        std::cerr << "[WebDAV] No mount point specified" << std::endl;
        return false;
    }
    
    std::cout << "[WebDAV] Unmounting " << preset.davMountPoint << std::endl;
    
    // Check if actually mounted
    if (!isWebDavMounted(preset.davMountPoint)) {
        std::cout << "[WebDAV] Not mounted: " << preset.davMountPoint << std::endl;
        preset.davMounted = false;
        return true;
    }
    
    // Unmount
    std::string umountCmd = "sudo umount \"" + preset.davMountPoint + "\" 2>&1";
    
    FILE* pipe = popen(umountCmd.c_str(), "r");
    if (!pipe) {
        std::cerr << "[WebDAV] Failed to execute umount command" << std::endl;
        return false;
    }
    
    char buffer[256];
    std::string output;
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        output += buffer;
    }
    int exitCode = pclose(pipe);
    
    if (exitCode != 0) {
        // Try force unmount if regular unmount fails
        std::cout << "[WebDAV] Regular unmount failed, trying force unmount..." << std::endl;
        std::string forceCmd = "sudo umount -f \"" + preset.davMountPoint + "\" 2>&1";
        exitCode = system(forceCmd.c_str());
        
        if (exitCode != 0) {
            std::cerr << "[WebDAV] Force unmount also failed: " << output << std::endl;
            return false;
        }
    }
    
    std::cout << "[WebDAV] ✅ Successfully unmounted: " << preset.davMountPoint << std::endl;
    preset.davMounted = false;
    preset.directories.clear();
    
    // Clean up secrets file entry (optional - commented out to preserve other entries)
    // Could implement secrets file cleanup here if needed
    
    return true;
}

bool connectAndFetchDirectories(FtpPreset& preset, int presetIndex = -1) {
    std::cout << "[FTP] Connecting to " << preset.serviceType << "://" 
              << preset.ip << ":" << preset.port << std::endl;
    
    appState.serverDirectories.clear();
    appState.isConnected = false;
    
    // Check if credentials are needed
    if (preset.username.empty() || preset.username == "anonymous") {
        if (preset.serviceType != "FTP") {
            // Non-FTP services need credentials
            appState.showCredentialsDialog = true;
            return false;
        }
    }
    
    if (preset.serviceType == "FTP") {
        // Echte FTP-Verbindung mit libcurl (ASYNCHRON)
        std::string ftpUrl = "ftp://" + preset.ip + ":" + std::to_string(preset.port) + "/";
        
        // WICHTIG: Verwende gespeicherte Credentials aus Preset
        std::string user = preset.username;
        std::string pass = preset.password;
        
        // Wenn keine Credentials gespeichert, verwende anonymous
        if (user.empty()) {
            user = "anonymous";
            pass = "anonymous@example.com";
        }
        
        // ==================== INTELLIGENT CACHE CHECK ====================
        // Prüfe ob cached Daten verfügbar UND frisch sind
        bool useCachedData = false;
        int cacheAge = 0;
        {
            std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
            
            // Prüfe ob ROOT-Verzeichnis im Cache ist
            std::string rootKey = ftpUrl + "/";
            auto it = ftpDirCache.find(rootKey);
            
            if (it != ftpDirCache.end()) {
                time_t now = time(nullptr);
                cacheAge = (now - it->second.timestamp);
                
                // Cache ist frisch wenn < 1 Stunde alt
                if (cacheAge < 3600) {
                    useCachedData = true;
                    std::cout << "[FTP Browser] ✅ Found FRESH cache (age: " << (cacheAge/60) << " minutes)" << std::endl;
                } else {
                    std::cout << "[FTP Browser] ⚠️ Cache EXPIRED (age: " << (cacheAge/3600) << " hours) - will refresh" << std::endl;
                }
            } else {
                std::cout << "[FTP Browser] ❌ No cache found - will scan server" << std::endl;
            }
        }
        
        if (useCachedData) {
            // FAST PATH: Verwende gecachte Daten SOFORT
            std::cout << "[FTP Browser] 🚀 FAST MODE: Loading from cache..." << std::endl;
            
            appState.serverDirectories.clear();
            appState.serverDirectories.reserve(100);
            
            {
                std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
                
                // Extrahiere alle Verzeichnisse aus Cache die zu diesem Server gehören
                for (const auto& [key, entry] : ftpDirCache) {
                    if (key.find(ftpUrl) == 0) {
                        // Extrahiere relativen Pfad
                        std::string relPath = key.substr(ftpUrl.length());
                        if (relPath.empty()) relPath = "/";
                        
                        appState.serverDirectories.push_back(relPath);
                        
                        // Füge auch alle Unterverzeichnisse hinzu
                        for (const auto& subdir : entry.subdirs) {
                            std::string fullPath = relPath;
                            if (fullPath != "/") fullPath += "/";
                            fullPath += subdir;
                            appState.serverDirectories.push_back(fullPath);
                        }
                    }
                }
            }
            
            // Sortiere und entferne Duplikate
            std::sort(appState.serverDirectories.begin(), appState.serverDirectories.end());
            auto last = std::unique(appState.serverDirectories.begin(), appState.serverDirectories.end());
            appState.serverDirectories.erase(last, appState.serverDirectories.end());
            
            std::cout << "[FTP Browser] ✅ Loaded " << appState.serverDirectories.size() 
                      << " directories from cache (instant!)" << std::endl;
            
            appState.isConnected = true;
            appState.connectionStatus = "✅ Cache geladen! Prüfe Server im Hintergrund...";
            appState.isScanningFtp = false;
            
            // Speichere verbundenen Preset-Index
            if (presetIndex >= 0) {
                appState.connectedPresetIndex = presetIndex;
            }
            
            // HINTERGRUND-ABGLEICH: Starte asynchronen Server-Scan zur Verifizierung
            std::cout << "[FTP Browser] 🔄 Starting background verification scan..." << std::endl;
            std::thread([ftpUrl, user, pass, cacheAge]() {
                std::vector<std::string> tempDirectories;
                tempDirectories.reserve(1000);
                tempDirectories.push_back("/");
                
                auto startTime = std::chrono::steady_clock::now();
                
                std::cout << "[FTP Background] Verifying cache against server..." << std::endl;
                bool ftpSuccess = fetchFtpDirectories(ftpUrl, user, pass, tempDirectories);
                
                if (ftpSuccess) {
                    auto endTime = std::chrono::steady_clock::now();
                    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
                    
                    // Vergleiche mit Cache
                    size_t cachedCount;
                    {
                        std::lock_guard<std::mutex> lock(appState.serverDirectoriesMutex);
                        cachedCount = appState.serverDirectories.size();
                    }
                    size_t actualCount = tempDirectories.size();
                    
                    std::cout << "[FTP Background] ✅ Verification complete (" << (duration/1000.0) << "s)" << std::endl;
                    std::cout << "[FTP Background] Cache: " << cachedCount << " dirs, Server: " << actualCount << " dirs" << std::endl;
                    
                    if (actualCount != cachedCount) {
                        std::cout << "[FTP Background] ⚠️ Difference detected! Updating cache..." << std::endl;
                        
                        // Aktualisiere serverDirectories mit echten Daten
                        {
                            std::lock_guard<std::mutex> lock(appState.serverDirectoriesMutex);
                            appState.serverDirectories = tempDirectories;
                        }
                        
                        // Aktualisiere Cache
                        {
                            std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
                            for (const auto& dir : tempDirectories) {
                                std::string cacheKey = ftpUrl + dir;
                                if (ftpDirCache.find(cacheKey) == ftpDirCache.end()) {
                                    FTPDirCacheEntry entry;
                                    entry.timestamp = time(nullptr);
                                    ftpDirCache[cacheKey] = entry;
                                }
                            }
                        }
                        
                        appState.connectionStatus = "✅ Verbunden & verifiziert! " + std::to_string(actualCount) + 
                                                   " Verzeichnisse (Cache aktualisiert)";
                    } else {
                        std::cout << "[FTP Background] ✅ Cache is up-to-date!" << std::endl;
                        appState.connectionStatus = "✅ Verbunden & verifiziert! " + std::to_string(actualCount) + 
                                                   " Verzeichnisse (Cache korrekt)";
                    }
                } else {
                    std::cout << "[FTP Background] ❌ Verification failed - using cached data" << std::endl;
                    appState.connectionStatus = "✅ Verbunden (Cache, Server nicht erreichbar)";
                }
            }).detach();
            
            return true;
        }
        
        // SLOW PATH: Cache nicht verfügbar oder veraltet - scanne Server
        std::cout << "[FTP Browser] 🐌 SLOW MODE: Scanning server..." << std::endl;
        
        // Root-Verzeichnis immer hinzufügen
        appState.serverDirectories.clear();
        appState.serverDirectories.push_back("/");
        
        appState.connectionStatus = "Starte asynchronen FTP-Scan...";
        appState.isScanningFtp = true;
        std::cout << "[FTP] Starting async FTP directory scan..." << std::endl;
        
        // ASYNCHRONER FTP-SCAN in separatem Thread (OPTIMIERT)
        std::thread([ftpUrl, user, pass]() {
            // Temporärer Vektor mit Pre-Allocation
            std::vector<std::string> tempDirectories;
            tempDirectories.reserve(1000); // Pre-allocate für schnellere Inserts
            tempDirectories.push_back("/"); // Root directory
            
            // Retry-Logik: 2 Versuche (3 → 2 für Geschwindigkeit)
            bool ftpSuccess = false;
            int maxRetries = 2;
            
            auto startTime = std::chrono::steady_clock::now();
            
            for (int attempt = 1; attempt <= maxRetries; attempt++) {
                appState.connectionStatus = "Verbinde mit FTP (Versuch " + 
                                           std::to_string(attempt) + "/" + std::to_string(maxRetries) + ")...";
                std::cout << "[FTP] " << appState.connectionStatus << std::endl;
                std::cout << "[FTP] Connecting as: " << user << std::endl;
                
                ftpSuccess = fetchFtpDirectories(ftpUrl, user, pass, tempDirectories);
                
                if (ftpSuccess) {
                    auto endTime = std::chrono::steady_clock::now();
                    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
                    
                    appState.connectionStatus = "[X] Verbunden! " + std::to_string(tempDirectories.size()) + 
                                              " Verzeichnisse in " + std::to_string(duration) + "ms";
                    std::cout << "[FTP] [X] Successfully fetched " << tempDirectories.size() 
                             << " directories in " << duration << "ms" << std::endl;
                    break;
                } else if (attempt < maxRetries) {
                    appState.connectionStatus = "Verbindungsfehler - versuche erneut...";
                    std::cout << "[FTP] Attempt " << attempt << " failed, retrying..." << std::endl;
                    // OPTIMIZED: Removed 300ms sleep - immediate retry for better UX
                }
            }
            
            if (!ftpSuccess) {
                appState.connectionStatus = "Verbindung fehlgeschlagen nach " + std::to_string(maxRetries) + " Versuchen";
                std::cerr << "[FTP] Failed to fetch directories from " << ftpUrl << " after " 
                         << maxRetries << " attempts" << std::endl;
                
                // Wenn Verbindung fehlschlägt, verwende Fallback
                if (user == "anonymous") {
                    std::cout << "[FTP] Login failed - using fallback directories" << std::endl;
                    
                    // Zeige Fallback-Verzeichnisse
                    tempDirectories = {
                        "/", "/pub", "/upload", "/backup", "/shared", "/home", "/data",
                        "/downloads", "/music", "/videos", "/documents"
                    };
                    
                    appState.showCredentialsDialog = true;
                } else {
                    // Fallback auf Beispielstruktur wenn FTP nicht erreichbar
                    std::cout << "[FTP] Connection failed - using fallback directory structure" << std::endl;
                    tempDirectories = {
                        "/", "/pub", "/upload", "/backup", "/shared", "/home", "/data",
                        "/downloads", "/music", "/videos", "/documents", "/pictures"
                    };
                }
            }
            
            // Thread-sicher in appState.serverDirectories übertragen
            {
                std::lock_guard<std::mutex> lock(appState.serverDirectoriesMutex);
                appState.serverDirectories = tempDirectories;
            }
            
            appState.isScanningFtp = false;
            std::cout << "[FTP] Async scan complete: " << appState.serverDirectories.size() 
                     << " directories found" << std::endl;
        }).detach();
        
    } else if (preset.serviceType == "NFS") {
        // NFS: Nutze Mount-Point als Basis-Verzeichnis
        if (preset.nfsMounted && !preset.nfsMountPoint.empty()) {
            appState.serverDirectories = {preset.nfsMountPoint};
            std::cout << "[FTP] NFS mounted at: " << preset.nfsMountPoint << std::endl;
        } else {
            std::cout << "[FTP] Error: NFS not mounted!" << std::endl;
            return false;
        }
        
    } else if (preset.serviceType == "SMB") {
        // SMB: Nutze Mount-Point als Basis-Verzeichnis
        if (preset.smbMounted && !preset.smbMountPoint.empty()) {
            appState.serverDirectories = {preset.smbMountPoint};
            std::cout << "[FTP] SMB mounted at: " << preset.smbMountPoint << std::endl;
        } else {
            std::cout << "[FTP] Error: SMB not mounted!" << std::endl;
            return false;
        }
        
    } else if (preset.serviceType == "WebDAV") {
        // WebDAV: Nutze Mount-Point als Basis-Verzeichnis
        if (preset.davMounted && !preset.davMountPoint.empty()) {
            appState.serverDirectories = {preset.davMountPoint};
            std::cout << "[FTP] WebDAV mounted at: " << preset.davMountPoint << std::endl;
        } else {
            std::cout << "[FTP] Error: WebDAV not mounted!" << std::endl;
            return false;
        }
        
    } else if (preset.serviceType == "SFTP") {
        // SFTP: Benötigt libssh2 - nicht implementiert
        std::cout << "[FTP] Error: SFTP not yet implemented!" << std::endl;
        return false;
    }
    
    appState.isConnected = true;
    appState.connectedPresetIndex = presetIndex;
    
    std::cout << "[FTP] Connected! Found " << appState.serverDirectories.size() 
              << " directories (preset index: " << presetIndex << ")" << std::endl;
    
    return true;
}

// Lightning Speed: Ping einzelnen Host (async)
bool pingHost(const std::string& ip, int timeout) {
    // Ultra-Fast TCP Connect Test (keine ICMP/system calls!)
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;
    
    // Non-blocking mode für Timeout
    fcntl(sock, F_SETFL, O_NONBLOCK);
    
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(80); // Port 80 (HTTP) oder 21 (FTP)
    inet_pton(AF_INET, ip.c_str(), &addr.sin_addr);
    
    connect(sock, (struct sockaddr*)&addr, sizeof(addr));
    
    // Select mit Timeout
    fd_set fdset;
    FD_ZERO(&fdset);
    FD_SET(sock, &fdset);
    
    struct timeval tv;
    tv.tv_sec = timeout;
    tv.tv_usec = 0;
    
    int result = select(sock + 1, nullptr, &fdset, nullptr, &tv);
    close(sock);
    
    return (result > 0);
}

// Lightning Speed: Asynchroner Netzwerk-Scanner
std::mutex hostsMutex;

void scanIPRange(const std::string& baseIP, int start, int end, int timeout, 
                std::vector<std::string>* results) {
    // Batch-Processing: Mehrere IPs parallel scannen
    const int BATCH_SIZE = 10;
    std::vector<std::future<std::pair<std::string, bool>>> futures;
    
    for (int i = start; i <= end; i++) {
        if (!appState.scanThreadRunning) break; // Abbruch wenn gestoppt
        
        std::string ip = baseIP + std::to_string(i);
        
        // Async batch
        futures.push_back(std::async(std::launch::async, [ip, timeout]() {
            return std::make_pair(ip, pingHost(ip, timeout));
        }));
        
        // Batch-Limit erreicht oder letzter Host
        if (futures.size() >= BATCH_SIZE || i == end) {
            for (auto& future : futures) {
                auto result = future.get();
                if (result.second) {
                    std::lock_guard<std::mutex> lock(hostsMutex);
                    results->push_back(result.first);
                    std::cout << "[Scanner] Found: " << result.first << std::endl;
                }
                appState.scannedHosts++;
            }
            futures.clear();
        }
    }
}

void startLightningScan(const std::string& subnet) {
    appState.scanThreadRunning = true;
    appState.scannedHosts = 0;
    appState.discoveredHosts.clear();
    
    // Parse subnet (z.B. "192.168.1.0/24")
    std::string baseIP = subnet.substr(0, subnet.find_last_of('.') + 1);
    int rangeSize = 254; // /24 = 1-254
    
    if (subnet.find("/24") != std::string::npos) {
        rangeSize = 254;
    } else if (subnet.find("/16") != std::string::npos) {
        rangeSize = 65534; // Warnung: sehr lange!
    }
    
    appState.totalHostsToScan = rangeSize;
    
    std::cout << "[Lightning Scanner] Starting scan of " << subnet 
              << " with " << appState.scannerThreads << " threads" << std::endl;
    
    // Teile den IP-Bereich in Chunks für jeden Thread
    std::vector<std::thread> threads;
    int hostsPerThread = rangeSize / appState.scannerThreads;
    
    for (int t = 0; t < appState.scannerThreads; t++) {
        int start = 1 + (t * hostsPerThread);
        int end = (t == appState.scannerThreads - 1) ? rangeSize : start + hostsPerThread - 1;
        
        threads.emplace_back(scanIPRange, baseIP, start, end, 
                           appState.scanTimeout, &appState.discoveredHosts);
    }
    
    // Warte auf alle Threads (in separatem Thread, um UI nicht zu blocken)
    std::thread([threads = std::move(threads)]() mutable {
        for (auto& t : threads) {
            if (t.joinable()) t.join();
        }
        
        appState.scanningNetwork = false;
        appState.scanThreadRunning = false;
        
        std::cout << "[Lightning Scanner] Scan complete! Found " 
                 << appState.discoveredHosts.size() << " hosts" << std::endl;
    }).detach();
}

// Fetch directories from FTP server (legacy compatibility)
void fetchServerDirectories(int presetIndex) {
    if (presetIndex < 0 || presetIndex >= (int)appState.ftpPresets.size()) return;
    
    auto& preset = appState.ftpPresets[presetIndex];
    preset.directories.clear();
    
    std::cout << "[FTP] Fetching directories from " << preset.ip << "..." << std::endl;
    
    // Simulierte Verzeichnisse (später echte FTP-Abfrage)
    preset.directories = {
        "/pub", "/upload", "/backup", "/shared", "/data",
        "/home", "/downloads", "/documents", "/pictures", "/videos"
    };
    
    appState.connectedPresetIndex = presetIndex;
    std::cout << "[FTP] Found " << preset.directories.size() << " directories" << std::endl;
}

// Helper: Format file size
std::string formatSize(long long bytes) {
    const char* units[] = {"B", "KB", "MB", "GB", "TB"};
    int unit = 0;
    double size = (double)bytes;
    
    while (size >= 1024.0 && unit < 4) {
        size /= 1024.0;
        unit++;
    }
    
    char buffer[64];
    snprintf(buffer, sizeof(buffer), "%.2f %s", size, units[unit]);
    return std::string(buffer);
}

// ============================================================================
// INPUT HISTORY & AUTO-COMPLETION
// ============================================================================
struct InputHistory {
    std::vector<std::string> items;
    int maxItems = 50;
    
    void add(const std::string& input) {
        if (input.empty()) return;
        
        // Remove duplicates
        items.erase(std::remove(items.begin(), items.end(), input), items.end());
        
        // Add to front
        items.insert(items.begin(), input);
        
        // Limit size
        if (items.size() > maxItems) {
            items.resize(maxItems);
        }
    }
    
    std::vector<std::string> getSuggestions(const std::string& input) const {
        std::vector<std::string> suggestions;
        if (input.empty()) return suggestions;
        
        std::string inputLower = input;
        std::transform(inputLower.begin(), inputLower.end(), inputLower.begin(), ::tolower);
        
        for (const auto& item : items) {
            std::string itemLower = item;
            std::transform(itemLower.begin(), itemLower.end(), itemLower.begin(), ::tolower);
            
            if (itemLower.find(inputLower) != std::string::npos) {
                suggestions.push_back(item);
                if (suggestions.size() >= 10) break; // Max 10 suggestions
            }
        }
        
        return suggestions;
    }
};

// Global history instances
static InputHistory localSearchHistory;
static InputHistory ftpSearchHistory;

// ============================================================================

// Format time duration in seconds to human-readable format (Midnight Commander style)
std::string formatTime(int seconds) {
    if (seconds < 0) return "--:--:--";
    
    int hours = seconds / 3600;
    int minutes = (seconds % 3600) / 60;
    int secs = seconds % 60;
    
    char buffer[32];
    if (hours > 0) {
        snprintf(buffer, sizeof(buffer), "%02d:%02d:%02d", hours, minutes, secs);
    } else {
        snprintf(buffer, sizeof(buffer), "%02d:%02d", minutes, secs);
    }
    return std::string(buffer);
}

// Get mounted drives/partitions
struct MountInfo {
    std::string device;
    std::string mountPoint;
    std::string fsType;
    long long totalSpace;
    long long freeSpace;
};

std::vector<MountInfo> getMountedDrives() {
    std::vector<MountInfo> drives;
    
    FILE* mtab = setmntent("/etc/mtab", "r");
    if (!mtab) return drives;
    
    struct mntent* entry;
    while ((entry = getmntent(mtab)) != nullptr) {
        // Filter nur echte Dateisysteme
        std::string fstype = entry->mnt_type;
        if (fstype == "ext4" || fstype == "ext3" || fstype == "ext2" || 
            fstype == "btrfs" || fstype == "xfs" || fstype == "ntfs" || 
            fstype == "vfat" || fstype == "exfat" || fstype == "f2fs") {
            
            MountInfo info;
            info.device = entry->mnt_fsname;
            info.mountPoint = entry->mnt_dir;
            info.fsType = entry->mnt_type;
            
            // Get space info
            struct statvfs vfs;
            if (statvfs(entry->mnt_dir, &vfs) == 0) {
                info.totalSpace = (long long)vfs.f_blocks * vfs.f_frsize;
                info.freeSpace = (long long)vfs.f_bavail * vfs.f_frsize;
            } else {
                info.totalSpace = 0;
                info.freeSpace = 0;
            }
            
            drives.push_back(info);
        }
    }
    
    endmntent(mtab);
    return drives;
}

// Scan directory recursively
std::vector<std::string> scanDirectory(const std::string& path, bool recursive = true, int maxDepth = 10) {
    std::vector<std::string> dirs;
    
    if (maxDepth <= 0) return dirs;
    
    DIR* dir = opendir(path.c_str());
    if (!dir) return dirs;
    
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        
        // Skip hidden directories if option is disabled
        if (!appState.scanHiddenFiles && name[0] == '.') continue;
        
        std::string fullPath = path + "/" + name;
        struct stat st;
        
        // Use lstat to detect symlinks
        if (lstat(fullPath.c_str(), &st) != 0) continue;
        
        // Handle symlinks
        if (S_ISLNK(st.st_mode)) {
            if (!appState.followSymlinks) continue;
            // Follow symlink
            if (stat(fullPath.c_str(), &st) != 0) continue;
        }
        
        if (S_ISDIR(st.st_mode)) {
            dirs.push_back(fullPath);
            if (recursive) {
                auto subdirs = scanDirectory(fullPath, true, maxDepth - 1);
                dirs.insert(dirs.end(), subdirs.begin(), subdirs.end());
            }
        }
    }
    
    closedir(dir);
    return dirs;
}

// Helper: Get directory tree
struct TreeNode {
    std::string name;
    std::string fullPath;
    bool isDir;
    std::vector<TreeNode*> children;
    bool expanded = false;
    
    ~TreeNode() {
        for (auto* child : children) delete child;
    }
};

TreeNode* buildDirectoryTree(const std::string& rootPath) {
    TreeNode* root = new TreeNode();
    root->name = rootPath;
    root->fullPath = rootPath;
    root->isDir = true;
    
    DIR* dir = opendir(rootPath.c_str());
    if (!dir) return root;
    
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        
        std::string fullPath = rootPath + "/" + name;
        struct stat st;
        if (stat(fullPath.c_str(), &st) != 0) continue;
        
        TreeNode* node = new TreeNode();
        node->name = name;
        node->fullPath = fullPath;
        node->isDir = S_ISDIR(st.st_mode);
        
        if (node->isDir && name[0] != '.') {  // Skip hidden dirs
            root->children.push_back(node);
        } else {
            delete node;
        }
    }
    closedir(dir);
    
    // Sort by name
    std::sort(root->children.begin(), root->children.end(),
              [](const TreeNode* a, const TreeNode* b) {
                  return a->name < b->name;
              });
    
    return root;
}

void renderTreeNode(TreeNode* node, std::set<std::string>& selectedDirs) {
    ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_OpenOnArrow;
    if (node->children.empty()) {
        flags |= ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen;
    }
    
    bool isSelected = selectedDirs.count(node->fullPath) > 0;
    if (isSelected) {
        flags |= ImGuiTreeNodeFlags_Selected;
    }
    
    // Apply saved expanded state
    bool wasExpanded = expandedNodes.count(node->fullPath) > 0;
    if (wasExpanded && !node->children.empty()) {
        flags |= ImGuiTreeNodeFlags_DefaultOpen;
    }
    
    std::string label = (node->isDir ? "[DIR] " : "[FILE] ") + node->name;
    bool opened = ImGui::TreeNodeEx(node->fullPath.c_str(), flags, "%s", label.c_str());
    
    // Track expanded state changes
    if (!node->children.empty()) {
        if (opened && !wasExpanded) {
            std::lock_guard<std::mutex> lock(expandedNodesMutex);
            expandedNodes.insert(node->fullPath);
        } else if (!opened && wasExpanded) {
            std::lock_guard<std::mutex> lock(expandedNodesMutex);
            expandedNodes.erase(node->fullPath);
        }
    }
    
    // FIX: Better click detection - check both left and right mouse button
    if (node->isDir && (ImGui::IsItemClicked(0) || ImGui::IsItemClicked(1))) {
        if (isSelected) {
            selectedDirs.erase(node->fullPath);
        } else {
            // Filter: Exclude network mount points (NFS/SMB/WebDAV)
            if (!isNetworkMountPoint(node->fullPath, appState)) {
                selectedDirs.insert(node->fullPath);
            } else {
                std::cout << "[Directory Tree] ⚠️ Netzwerk-Mount ignoriert: " << node->fullPath << std::endl;
            }
        }
    }
    
    if (opened && !node->children.empty()) {
        for (auto* child : node->children) {
            renderTreeNode(child, selectedDirs);
        }
        ImGui::TreePop();
    }
}

// Ensure text visibility for all themes
void ensureTextVisibility() {
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;
    
    // Ensure text is always visible with good contrast
    ImVec4 bgColor = colors[ImGuiCol_WindowBg];
    float bgBrightness = (bgColor.x + bgColor.y + bgColor.z) / 3.0f;
    
    // If background is dark, use light text
    if (bgBrightness < 0.5f) {
        colors[ImGuiCol_Text] = ImVec4(0.95f, 0.95f, 0.95f, 1.0f);
        colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.0f);
        colors[ImGuiCol_CheckMark] = ImVec4(0.90f, 0.90f, 0.90f, 1.0f);
    } else {
        // If background is light, use dark text
        colors[ImGuiCol_Text] = ImVec4(0.05f, 0.05f, 0.05f, 1.0f);
        colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.0f);
        colors[ImGuiCol_CheckMark] = ImVec4(0.10f, 0.10f, 0.10f, 1.0f);
    }
    
    // Ensure frames and borders are visible
    float frameBrightness = (colors[ImGuiCol_FrameBg].x + colors[ImGuiCol_FrameBg].y + colors[ImGuiCol_FrameBg].z) / 3.0f;
    if (std::fabs(frameBrightness - bgBrightness) < 0.1f) {
        // Frame color too similar to background, adjust
        if (bgBrightness < 0.5f) {
            colors[ImGuiCol_FrameBg] = ImVec4(bgColor.x + 0.1f, bgColor.y + 0.1f, bgColor.z + 0.1f, 1.0f);
            colors[ImGuiCol_FrameBgHovered] = ImVec4(bgColor.x + 0.15f, bgColor.y + 0.15f, bgColor.z + 0.15f, 1.0f);
            colors[ImGuiCol_FrameBgActive] = ImVec4(bgColor.x + 0.2f, bgColor.y + 0.2f, bgColor.z + 0.2f, 1.0f);
        } else {
            colors[ImGuiCol_FrameBg] = ImVec4(bgColor.x - 0.1f, bgColor.y - 0.1f, bgColor.z - 0.1f, 1.0f);
            colors[ImGuiCol_FrameBgHovered] = ImVec4(bgColor.x - 0.15f, bgColor.y - 0.15f, bgColor.z - 0.15f, 1.0f);
            colors[ImGuiCol_FrameBgActive] = ImVec4(bgColor.x - 0.2f, bgColor.y - 0.2f, bgColor.z - 0.2f, 1.0f);
        }
    }
    
    // Ensure borders are visible
    colors[ImGuiCol_Border] = ImVec4(
        bgBrightness < 0.5f ? 0.6f : 0.4f,
        bgBrightness < 0.5f ? 0.6f : 0.4f,
        bgBrightness < 0.5f ? 0.6f : 0.4f,
        0.8f
    );
}

// Apply theme
void applyTheme(int themeIndex) {
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;
    
    switch(themeIndex) {
        case 0: ImGui::StyleColorsDark(); break;
        case 1: ImGui::StyleColorsLight(); break;
        case 2: ImGui::StyleColorsClassic(); break;
        
        case 3: // Quake 3 Light Blue (Default)
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.60f, 0.80f, 0.95f, 0.95f);
            colors[ImGuiCol_TitleBg] = ImVec4(0.40f, 0.65f, 0.85f, 1.0f);
            colors[ImGuiCol_TitleBgActive] = ImVec4(0.50f, 0.75f, 0.95f, 1.0f);
            colors[ImGuiCol_Button] = ImVec4(0.45f, 0.70f, 0.90f, 1.0f);
            colors[ImGuiCol_ButtonHovered] = ImVec4(0.55f, 0.80f, 1.0f, 1.0f);
            colors[ImGuiCol_ButtonActive] = ImVec4(0.35f, 0.60f, 0.80f, 1.0f);
            colors[ImGuiCol_Text] = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
            colors[ImGuiCol_Border] = ImVec4(0.30f, 0.50f, 0.70f, 1.0f);
            break;
            
        case 4: // Nord Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.18f, 0.20f, 0.25f, 0.95f);
            colors[ImGuiCol_TitleBg] = ImVec4(0.23f, 0.26f, 0.32f, 1.0f);
            colors[ImGuiCol_Button] = ImVec4(0.35f, 0.47f, 0.65f, 1.0f);
            break;
            
        case 5: // Dracula
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.16f, 0.16f, 0.21f, 0.95f);
            colors[ImGuiCol_TitleBg] = ImVec4(0.19f, 0.19f, 0.25f, 1.0f);
            colors[ImGuiCol_Button] = ImVec4(0.74f, 0.34f, 0.90f, 1.0f);
            break;
            
        case 6: // Monokai
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.16f, 0.15f, 0.14f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.98f, 0.96f, 0.24f, 1.0f);
            colors[ImGuiCol_Text] = ImVec4(0.97f, 0.97f, 0.95f, 1.0f);
            break;
            
        case 7: // Solarized Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.0f, 0.17f, 0.21f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.15f, 0.55f, 0.82f, 1.0f);
            break;
            
        case 8: // Solarized Light
            ImGui::StyleColorsLight();
            colors[ImGuiCol_WindowBg] = ImVec4(0.99f, 0.96f, 0.89f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.15f, 0.55f, 0.82f, 1.0f);
            break;
            
        case 9: // Gruvbox Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.16f, 0.15f, 0.13f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.84f, 0.60f, 0.13f, 1.0f);
            break;
            
        case 10: // Material Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.13f, 0.14f, 0.15f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.0f, 0.47f, 0.84f, 1.0f);
            break;
            
        case 11: // Material Light
            ImGui::StyleColorsLight();
            colors[ImGuiCol_WindowBg] = ImVec4(0.98f, 0.98f, 0.98f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.0f, 0.47f, 0.84f, 1.0f);
            break;
            
        case 12: // One Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.16f, 0.17f, 0.21f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.38f, 0.56f, 0.98f, 1.0f);
            break;
            
        case 13: // Atom Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.14f, 0.15f, 0.17f, 0.95f);
            break;
            
        case 14: // VS Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.12f, 0.12f, 0.12f, 0.95f);
            break;
            
        case 15: // VS Light
            ImGui::StyleColorsLight();
            colors[ImGuiCol_WindowBg] = ImVec4(1.0f, 1.0f, 1.0f, 0.95f);
            break;
            
        case 16: // GitHub Dark
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.08f, 0.10f, 0.12f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.13f, 0.52f, 0.93f, 1.0f);
            break;
            
        case 17: // GitHub Light
            ImGui::StyleColorsLight();
            colors[ImGuiCol_WindowBg] = ImVec4(1.0f, 1.0f, 1.0f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.13f, 0.52f, 0.93f, 1.0f);
            break;
            
        case 18: // Oceanic Next
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.11f, 0.14f, 0.17f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.40f, 0.74f, 0.84f, 1.0f);
            break;
            
        case 19: // Tomorrow Night
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.11f, 0.12f, 0.13f, 0.95f);
            break;
            
        case 20: // Cyberpunk
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.05f, 0.0f, 0.15f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(1.0f, 0.0f, 0.8f, 1.0f);
            colors[ImGuiCol_Text] = ImVec4(0.0f, 1.0f, 1.0f, 1.0f);
            break;
            
        case 21: // Synthwave
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.10f, 0.0f, 0.20f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.97f, 0.20f, 0.75f, 1.0f);
            break;
            
        case 22: // Vaporwave
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.60f, 0.40f, 0.80f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(1.0f, 0.60f, 0.90f, 1.0f);
            colors[ImGuiCol_Text] = ImVec4(0.0f, 1.0f, 1.0f, 1.0f);
            break;
            
        case 23: // Forest
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.05f, 0.15f, 0.05f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.13f, 0.55f, 0.13f, 1.0f);
            break;
            
        case 24: // Desert
            ImGui::StyleColorsLight();
            colors[ImGuiCol_WindowBg] = ImVec4(0.96f, 0.87f, 0.70f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.85f, 0.65f, 0.35f, 1.0f);
            break;
            
        case 25: // Ocean
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.0f, 0.20f, 0.35f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.0f, 0.50f, 0.75f, 1.0f);
            break;
            
        case 26: // Sunset
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.20f, 0.10f, 0.15f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(1.0f, 0.40f, 0.20f, 1.0f);
            break;
            
        case 27: // Midnight
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.02f, 0.02f, 0.08f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.10f, 0.10f, 0.40f, 1.0f);
            break;
            
        case 28: // Ice
            ImGui::StyleColorsLight();
            colors[ImGuiCol_WindowBg] = ImVec4(0.85f, 0.95f, 1.0f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.60f, 0.85f, 1.0f, 1.0f);
            break;
            
        case 29: // Fire
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.20f, 0.05f, 0.0f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(1.0f, 0.30f, 0.0f, 1.0f);
            break;
            
        case 30: // Purple Haze
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.15f, 0.05f, 0.25f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.60f, 0.20f, 0.90f, 1.0f);
            break;
            
        case 31: // Golden
            ImGui::StyleColorsLight();
            colors[ImGuiCol_WindowBg] = ImVec4(1.0f, 0.95f, 0.70f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(1.0f, 0.84f, 0.0f, 1.0f);
            break;
            
        case 32: // Matrix
            ImGui::StyleColorsDark();
            colors[ImGuiCol_WindowBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.95f);
            colors[ImGuiCol_Button] = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
            colors[ImGuiCol_Text] = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
            break;
    }
    
    // Save theme after applying
    saveThemeSettings();
}

// Render Save Scan State Dialog
void renderSaveStateDialog() {
    if (!appState.showSaveStateDialog) return;
    
    ImGui::SetNextWindowSize(ImVec2(500, 400), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f), 
                           ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    
    if (ImGui::Begin("[SAVE] Scan-State speichern", &appState.showSaveStateDialog, ImGuiWindowFlags_None)) {
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Speichern Sie den aktuellen Scan-Fortschritt");
        ImGui::Separator();
        ImGui::Spacing();
        
        ImGui::Text("Dateiname:");
        ImGui::InputText("##savefilename", appState.saveStateFilename, sizeof(appState.saveStateFilename));
        
        ImGui::Spacing();
        ImGui::TextDisabled("Speicherort: %s/", getenv("HOME"));
        
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "ℹ️ Gespeicherte Informationen:");
        ImGui::BulletText("Scan-Konfiguration (Filter, Optionen)");
        ImGui::BulletText("Ausgewählte Verzeichnisse (Lokal + FTP)");
        ImGui::BulletText("Alle gefundenen Duplikate");
        ImGui::BulletText("Statistiken (Dateien, Größen, Gruppen)");
        
        ImGui::Spacing();
        ImGui::Separator();
        
        if (ImGui::Button("[SAVE] Speichern", ImVec2(120, 0))) {
            std::string fullPath = std::string(getenv("HOME")) + "/" + appState.saveStateFilename;
            saveScanState(fullPath);
            appState.showSaveStateDialog = false;
            appState.scanStatus = "Scan-State gespeichert: " + std::string(appState.saveStateFilename);
        }
        
        ImGui::SameLine();
        if (ImGui::Button("Abbrechen", ImVec2(120, 0))) {
            appState.showSaveStateDialog = false;
        }
        
        ImGui::End();
    }
}

// Render Load Scan State Dialog
void renderLoadStateDialog() {
    if (!appState.showLoadStateDialog) return;
    
    ImGui::SetNextWindowSize(ImVec2(500, 300), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f), 
                           ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    
    if (ImGui::Begin("[DIR] Scan-State laden", &appState.showLoadStateDialog, ImGuiWindowFlags_None)) {
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Laden Sie einen gespeicherten Scan-Fortschritt");
        ImGui::Separator();
        ImGui::Spacing();
        
        ImGui::Text("Dateiname:");
        ImGui::InputText("##loadfilename", appState.saveStateFilename, sizeof(appState.saveStateFilename));
        
        ImGui::Spacing();
        ImGui::TextDisabled("Speicherort: %s/", getenv("HOME"));
        
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "⚠️ Warnung:");
        ImGui::TextWrapped("Das Laden eines Scan-States überschreibt die aktuellen Scan-Ergebnisse!");
        
        ImGui::Spacing();
        ImGui::Separator();
        
        if (ImGui::Button("[DIR] Laden", ImVec2(120, 0))) {
            std::string fullPath = std::string(getenv("HOME")) + "/" + appState.saveStateFilename;
            if (loadScanState(fullPath)) {
                appState.showLoadStateDialog = false;
                appState.scanStatus = "Scan-State geladen: " + std::string(appState.saveStateFilename);
            } else {
                appState.scanStatus = "Fehler beim Laden: " + std::string(appState.saveStateFilename);
            }
        }
        
        ImGui::SameLine();
        if (ImGui::Button("Abbrechen", ImVec2(120, 0))) {
            appState.showLoadStateDialog = false;
        }
        
        ImGui::End();
    }
}

// Generische Funktion für Verzeichnisbaum-Anzeige (alle Scanner nutzen diese)
void renderDirectoryTree(const std::vector<std::string>& directories, 
                        std::set<std::string>& selectedDirs,
                        int maxDisplayDepth,
                        const char* searchFilter,
                        const char* uniquePrefix,
                        bool showStats = true) {
    
    if (directories.empty()) {
        ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), 
                          "Keine Verzeichnisse verfügbar!");
        return;
    }
    
    // Sortiere Verzeichnisse für hierarchische Anzeige
    std::vector<std::string> sortedDirs = directories;
    std::sort(sortedDirs.begin(), sortedDirs.end());
    sortedDirs.erase(std::unique(sortedDirs.begin(), sortedDirs.end()), sortedDirs.end());
    
    // Statistiken berechnen
    if (showStats) {
        int maxDepth = 0;
        int countPerDepth[10] = {0};
        for (const auto& dir : sortedDirs) {
            int depth = std::count(dir.begin(), dir.end(), '/');
            if (depth > maxDepth) maxDepth = depth;
            if (depth < 10) countPerDepth[depth]++;
        }
        
        ImGui::Text("Gefunden: %zu Verzeichnisse, Max Tiefe: %d", sortedDirs.size(), maxDepth);
        for (int i = 0; i <= maxDepth && i < 10; i++) {
            ImGui::Text("  Ebene %d: %d Verzeichnisse", i, countPerDepth[i]);
        }
        ImGui::Separator();
    }
    
    // Filter anwenden - Multi-Suchbegriff Unterstützung (Leerzeichen oder Komma getrennt)
    std::string filterStr = searchFilter ? searchFilter : "";
    std::transform(filterStr.begin(), filterStr.end(), filterStr.begin(), ::tolower);
    
    // Parse Suchbegriffe (getrennt durch Leerzeichen, Komma oder Semikolon)
    std::vector<std::string> searchTerms;
    if (!filterStr.empty()) {
        std::string term;
        for (char c : filterStr) {
            if (c == ' ' || c == ',' || c == ';') {
                if (!term.empty()) {
                    searchTerms.push_back(term);
                    term.clear();
                }
            } else {
                term += c;
            }
        }
        if (!term.empty()) {
            searchTerms.push_back(term);
        }
    }
    
    // Erstelle Set der gefilterten Verzeichnisse (direkt passend zum Filter)
    std::set<std::string> matchedDirs;
    if (!searchTerms.empty()) {
        for (const auto& dir : sortedDirs) {
            std::string dirLower = dir;
            std::transform(dirLower.begin(), dirLower.end(), dirLower.begin(), ::tolower);
            
            // Verzeichnis muss MINDESTENS EINEN Suchbegriff enthalten (ODER-Verknüpfung)
            bool matchesAny = false;
            for (const auto& term : searchTerms) {
                if (dirLower.find(term) != std::string::npos) {
                    matchesAny = true;
                    break;
                }
            }
            
            if (matchesAny) {
                matchedDirs.insert(dir);
            }
        }
    }
    
    // Sammle alle sichtbaren Verzeichnisse für Kontext-Menü
    std::vector<std::string> visibleDirs;
    for (const auto& dir : sortedDirs) {
        int depth = std::count(dir.begin(), dir.end(), '/');
        if (depth > maxDisplayDepth) continue;
        
        // Filter anwenden
        if (!searchTerms.empty()) {
            std::string dirLower = dir;
            std::transform(dirLower.begin(), dirLower.end(), dirLower.begin(), ::tolower);
            
            // Verzeichnis muss MINDESTENS EINEN Suchbegriff enthalten (ODER-Verknüpfung)
            bool matchesAny = false;
            for (const auto& term : searchTerms) {
                if (dirLower.find(term) != std::string::npos) {
                    matchesAny = true;
                    break;
                }
            }
            
            if (!matchesAny) {
                continue; // Verzeichnis passt nicht zum Filter
            }
            
            // Wenn treeSearchShowSubdirs=false: Unterverzeichnisse von Suchergebnissen ausblenden
            if (!appState.treeSearchShowSubdirs) {
                // Prüfe ob dieses Verzeichnis ein Unterverzeichnis eines gefundenen Verzeichnisses ist
                bool isSubdirOfMatched = false;
                for (const auto& matched : matchedDirs) {
                    if (dir != matched && dir.find(matched + "/") == 0) {
                        // Dies ist ein Unterverzeichnis eines direkt gefundenen Verzeichnisses
                        isSubdirOfMatched = true;
                        break;
                    }
                }
                if (isSubdirOfMatched) {
                    continue; // Überspringe Unterverzeichnisse
                }
            }
        }
        
        visibleDirs.push_back(dir);
    }
    
    // Rechtsklick Kontext-Menü für gesamten Bereich
    if (ImGui::BeginPopupContextWindow((std::string("tree_context_") + uniquePrefix).c_str())) {
        if (ImGui::MenuItem("Alle markieren")) {
            // Markiere alle sichtbaren Verzeichnisse, entferne redundante
            for (const auto& dir : visibleDirs) {
                // Prüfe ob bereits durch Eltern-Verzeichnis abgedeckt
                bool coveredByParent = false;
                for (const auto& selectedDir : selectedDirs) {
                    if (dir != selectedDir && dir.find(selectedDir + "/") == 0) {
                        coveredByParent = true;
                        break;
                    }
                }
                
                if (!coveredByParent) {
                    // Entferne redundante Unterverzeichnisse
                    std::vector<std::string> toRemove;
                    for (const auto& selectedDir : selectedDirs) {
                        if (selectedDir.find(dir + "/") == 0) {
                            toRemove.push_back(selectedDir);
                        }
                    }
                    for (const auto& removeDir : toRemove) {
                        selectedDirs.erase(removeDir);
                    }
                    
                    selectedDirs.insert(dir);
                }
            }
        }
        
        if (ImGui::MenuItem("Alle abwählen")) {
            selectedDirs.clear();
        }
        
        ImGui::Separator();
        ImGui::TextDisabled("Sichtbare Verzeichnisse: %zu", visibleDirs.size());
        ImGui::TextDisabled("Ausgewählt: %zu", selectedDirs.size());
        
        ImGui::EndPopup();
    }
    
    // Zeige Verzeichnisse mit Einrückung basierend auf Tiefe
    int displayedCount = 0;
    for (const auto& dir : visibleDirs) {
        int depth = std::count(dir.begin(), dir.end(), '/');
        
        displayedCount++;
        bool isSelected = (selectedDirs.find(dir) != selectedDirs.end());
        
        // Prüfe ob bereits durch Eltern-Verzeichnis abgedeckt
        bool coveredByParent = false;
        std::string parentPath = "";
        for (const auto& selectedDir : selectedDirs) {
            if (dir != selectedDir && dir.find(selectedDir + "/") == 0) {
                coveredByParent = true;
                parentPath = selectedDir;
                break;
            }
        }
        
        // Einrückung basierend auf Tiefe
        for (int i = 0; i < depth; i++) {
            ImGui::Indent(20.0f);
        }
        
        // Checkbox für Auswahl
        bool selected = isSelected;
        std::string label = (dir == "/" ? "ROOT (/)" : dir.substr(dir.find_last_of('/') + 1));
        std::string uniqueLabel = label + "##" + std::string(uniquePrefix) + "_" + 
                                 std::to_string(displayedCount) + "_" + dir;
        
        // Zeige Warnung wenn bereits durch Eltern abgedeckt
        if (coveredByParent && !isSelected) {
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.5f, 0.5f, 0.5f, 1.0f));
            ImGui::Checkbox(uniqueLabel.c_str(), &selected);
            ImGui::PopStyleColor();
        } else {
            if (ImGui::Checkbox(uniqueLabel.c_str(), &selected)) {
                if (selected) {
                    // Entferne redundante Unterverzeichnisse
                    std::vector<std::string> toRemove;
                    for (const auto& selectedDir : selectedDirs) {
                        if (selectedDir.find(dir + "/") == 0) {
                            toRemove.push_back(selectedDir);
                        }
                    }
                    for (const auto& removeDir : toRemove) {
                        selectedDirs.erase(removeDir);
                    }
                    
                    selectedDirs.insert(dir);
                } else {
                    selectedDirs.erase(dir);
                }
            }
        }
        
        // Tooltip mit vollem Pfad
        if (ImGui::IsItemHovered()) {
            if (coveredByParent) {
                ImGui::SetTooltip("%s\n[INFO] Bereits enthalten in: %s", dir.c_str(), parentPath.c_str());
            } else {
                ImGui::SetTooltip("%s", dir.c_str());
            }
        }
        
        // Einrückung zurücksetzen
        for (int i = 0; i < depth; i++) {
            ImGui::Unindent(20.0f);
        }
    }
    
    if (displayedCount == 0 && !searchTerms.empty()) {
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                          "Keine Verzeichnisse entsprechen dem Filter.");
        ImGui::TextDisabled("💡 Tipp: Mehrere Begriffe mit Leerzeichen/Komma (ODER-Verknüpfung)");
    }
}

// Render Local Directory Browser
void renderLocalBrowser() {
    if (!appState.showLocalBrowser) return;
    
    // Normal window setup
    ImGui::SetNextWindowSize(ImVec2(1000, 800), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f), 
                           ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    
    ImGui::SetNextWindowBgAlpha(0.95f);
    
    // Set window background to be opaque
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.1f, 0.1f, 0.1f, 0.95f));
    
    // Normales Fenster mit Close-Button
    ImGuiWindowFlags flags = ImGuiWindowFlags_None;
    
    if (ImGui::Begin("🗂️ LOKALE VERZEICHNISSE", &appState.showLocalBrowser, flags)) {
        
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Wählen Sie Verzeichnisse zum Scannen:");
        ImGui::Separator();
        
        // Auto-Detect und Suchfeld
        static char searchFilter[256] = "";
        static bool showHistory = false;
        
        // FORCE Focus: Wenn Window Focused ist UND nichts anderes aktiv ist, fokussiere das Input
        if (ImGui::IsWindowFocused() && !ImGui::IsAnyItemActive()) {
            ImGui::SetKeyboardFocusHere();
        }
        
        if (ImGui::InputText("[FIND] Suche/Filter", searchFilter, sizeof(searchFilter))) {
            // Input changed - speichere in History wenn Enter gedrückt
            if (ImGui::IsItemDeactivatedAfterEdit() && strlen(searchFilter) > 0) {
                std::string search(searchFilter);
                // Entferne Duplikate
                auto it = std::find(appState.searchHistory.begin(), appState.searchHistory.end(), search);
                if (it != appState.searchHistory.end()) {
                    appState.searchHistory.erase(it);
                }
                // Füge am Anfang ein
                appState.searchHistory.insert(appState.searchHistory.begin(), search);
                // Limitiere Größe
                if (appState.searchHistory.size() > appState.maxSearchHistory) {
                    appState.searchHistory.resize(appState.maxSearchHistory);
                }
                // Speichere History
                saveSearchHistory();
            }
        }
        
        // History Button
        ImGui::SameLine();
        if (ImGui::Button("📜")) {
            showHistory = !showHistory;
        }
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Such-History anzeigen");
        }
        
        // History Dropdown
        if (showHistory && !appState.searchHistory.empty()) {
            ImGui::SameLine();
            ImGui::SetNextItemWidth(250);
            if (ImGui::BeginCombo("##searchhistory", "Vorherige Suchen...")) {
                for (const auto& hist : appState.searchHistory) {
                    if (ImGui::Selectable(hist.c_str())) {
                        strncpy(searchFilter, hist.c_str(), sizeof(searchFilter) - 1);
                        searchFilter[sizeof(searchFilter) - 1] = '\0';
                        showHistory = false;
                    }
                }
                ImGui::EndCombo();
            }
        }
        
        ImGui::SameLine();
        if (ImGui::Button("Auto-Detect")) {
            // Automatische Erkennung häufiger Verzeichnisse
            std::vector<std::string> autoDetectPaths = {
                std::string(getenv("HOME") ? getenv("HOME") : "") + "/Documents",
                std::string(getenv("HOME") ? getenv("HOME") : "") + "/Downloads",
                std::string(getenv("HOME") ? getenv("HOME") : "") + "/Pictures",
                std::string(getenv("HOME") ? getenv("HOME") : "") + "/Music",
                std::string(getenv("HOME") ? getenv("HOME") : "") + "/Videos",
                std::string(getenv("HOME") ? getenv("HOME") : "") + "/Desktop",
                "/mnt", "/media"
            };
            
            for (const auto& path : autoDetectPaths) {
                struct stat st;
                if (stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
                    std::cout << "[Auto-Detect] Found: " << path << std::endl;
                    strncpy(searchFilter, path.c_str(), sizeof(searchFilter) - 1);
                    searchFilter[sizeof(searchFilter) - 1] = '\0';
                    break;
                }
            }
        }
        
        static char customPath[512] = "";
        ImGui::InputText("Pfad", customPath, sizeof(customPath));
        ImGui::SameLine();
        if (ImGui::Button("Hinzufügen")) {
            if (strlen(customPath) > 0) {
                std::string path = customPath;
                // Filter: Exclude network mount points (NFS/SMB/WebDAV)
                if (!isNetworkMountPoint(path, appState)) {
                    appState.selectedLocalDirs.insert(path);
                } else {
                    std::cout << "[Local Browser] ⚠️ Netzwerk-Mount ignoriert: " << path << std::endl;
                }
                // Close all windows except main window
                appState.showLocalBrowser = false;
                appState.showFtpBrowser = false;
                appState.showServerBrowser = false;
                appState.showSettings = false;
                appState.showAbout = false;
                appState.showNetworkScanner = false;
                appState.showResults = false;
                memset(customPath, 0, sizeof(customPath));
            }
        }
        
        ImGui::Spacing();
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                          "Ausgewählt: %zu Verzeichnis(se)", appState.selectedLocalDirs.size());
        
        ImGui::BeginChild("SelectedDirs", ImVec2(0, 100), true);
        std::string dirToRemove;
        bool removeAll = false;
        
        for (const auto& dir : appState.selectedLocalDirs) {
            ImGui::BulletText("%s", dir.c_str());
            
            // Rechtsklick-Kontextmenü
            if (ImGui::BeginPopupContextItem(("DirCtx##" + dir).c_str())) {
                if (ImGui::MenuItem("Entfernen")) {
                    dirToRemove = dir;
                }
                if (ImGui::MenuItem("Alle Pfade entfernen")) {
                    removeAll = true;
                }
                ImGui::Separator();
                if (ImGui::MenuItem("Im Dateimanager öffnen")) {
                    std::string cmd = "xdg-open \"" + dir + "\" &";
                    system(cmd.c_str());
                }
                if (ImGui::MenuItem("Pfad kopieren")) {
                    ImGui::SetClipboardText(dir.c_str());
                }
                ImGui::EndPopup();
            }
            
            ImGui::SameLine(ImGui::GetWindowWidth() - 80);
            if (ImGui::SmallButton(("Entfernen##" + dir).c_str())) {
                dirToRemove = dir;
            }
        }
        
        if (removeAll) {
            appState.selectedLocalDirs.clear();
        } else if (!dirToRemove.empty()) {
            appState.selectedLocalDirs.erase(dirToRemove);
        }
        ImGui::EndChild();
        
        ImGui::Separator();
        
        ImGui::BeginTabBar("BrowserTabs");
        
        // Common Directories Tab - IMPROVED WITH RECURSIVE TREE (JETZT ZUERST)
        if (ImGui::BeginTabItem("[DIR] Verzeichnisse")) {
            static std::vector<std::string> scannedDirs;
            static bool dirsScanned = false;
            static bool autoScanDone = false;
            static bool isScanning = false;
            static int maxScanDepth = 7; // VERZEICHNISBAUM: Nur 7 Ebenen zum Auswählen
            // Nutze appState.localTreeMaxDepth für Anzeige-Limit
            static std::mutex scanMutex;
            
            // Automatischer Scan beim ersten Öffnen (ASYNCHRON)
            if (!autoScanDone && !isScanning) {
                autoScanDone = true;
                
                // CACHE: Prüfe ob Cache vorhanden und aktuell (< 24 Stunden alt)
                {
                    std::lock_guard<std::mutex> lock(dirCacheMutex);
                    time_t now = time(nullptr);
                    int cache_age_hours = (now - dirCacheTimestamp) / 3600;
                    
                    if (!cachedLocalDirs.empty() && cache_age_hours < 24) {
                        // Cache ist aktuell - verwende ihn direkt!
                        std::cout << "[Local Browser] Using cached directory tree (" 
                                  << cachedLocalDirs.size() << " dirs, " 
                                  << cache_age_hours << " hours old)" << std::endl;
                        scannedDirs = cachedLocalDirs;
                        dirsScanned = true;
                        isScanning = false;
                        ImGui::EndTabItem();
                        ImGui::EndTabBar();
                        ImGui::End();
                        ImGui::PopStyleColor();
                        return;
                    }
                }
                
                isScanning = true;
                dirsScanned = false;
                scannedDirs.clear();
                
                std::cout << "[Local Browser] Starting async scan (depth " << maxScanDepth << ")..." << std::endl;
                
                // ASYNCHRONER SCAN in separatem Thread
                std::thread([&scannedDirs, &dirsScanned, &isScanning, maxScanDepth]() {
                    // OPTIMIERT: Nur wichtige Pfade, /proc /sys /dev ausgeschlossen (blockieren System)
                    std::vector<std::string> startPaths = {
                        "/home", "/mnt", "/media", "/opt", "/srv", "/usr/local"
                    };
                    
                    // Pre-allocate für geschwindigkeit - MASSIV für 700k+ Dirs
                    scannedDirs.reserve(500000);
                    
                    // Paralleles Scannen mit Thread-Pool
                    std::vector<std::thread> workers;
                    std::mutex localMutex;
                    std::atomic<int> activeThreads{0};
                    // MAXIMALE GESCHWINDIGKEIT: Alle CPU-Kerne nutzen!
                    int numThreads = std::max(16, (int)std::thread::hardware_concurrency());
                    
                    // Rekursive Scan-Funktion mit Batch-Verarbeitung
                    std::function<void(const std::string&, int, int)> scanLocal = 
                        [&](const std::string& path, int depth, int maxDepth) {
                        
                        if (depth > maxDepth) return;
                        
                        // GROSSE Batch-Sammlung für minimales Locking
                        std::vector<std::string> localBatch;
                        localBatch.reserve(2000);
                        localBatch.push_back(path);
                        
                        DIR* d = opendir(path.c_str());
                        if (!d) {
                            std::lock_guard<std::mutex> lock(localMutex);
                            scannedDirs.insert(scannedDirs.end(), localBatch.begin(), localBatch.end());
                            return;
                        }
                        
                        struct dirent* entry;
                        std::vector<std::string> subdirs;
                        subdirs.reserve(50);
                        
                        while ((entry = readdir(d)) != nullptr) {
                            std::string name = entry->d_name;
                            if (name == "." || name == "..") continue;
                            if (!appState.scanHiddenFiles && name[0] == '.') continue;
                            
                            std::string fullPath = path + "/" + name;
                            struct stat st;
                            
                            // Direkte stat() wenn keine Symlinks verfolgt werden
                            if (!appState.followSymlinks) {
                                if (lstat(fullPath.c_str(), &st) == 0 && S_ISDIR(st.st_mode) && !S_ISLNK(st.st_mode)) {
                                    subdirs.push_back(fullPath);
                                }
                            } else {
                                if (stat(fullPath.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
                                    subdirs.push_back(fullPath);
                                }
                            }
                        }
                        closedir(d);
                        
                        // Batch-Update
                        {
                            std::lock_guard<std::mutex> lock(localMutex);
                            scannedDirs.insert(scannedDirs.end(), localBatch.begin(), localBatch.end());
                            
                            // Progress nur alle 10000 Verzeichnisse (weniger I/O)
                            if (scannedDirs.size() % 10000 == 0) {
                                std::cout << "[Local Browser] " << scannedDirs.size() << " dirs..." << std::endl;
                            }
                        }
                        
                        // Rekursiv scannen (ohne Sort für Geschwindigkeit)
                        for (const auto& subdir : subdirs) {
                            scanLocal(subdir, depth + 1, maxDepth);
                        }
                    };
                    
                    // Paralleles Scannen der Start-Pfade
                    for (const auto& startPath : startPaths) {
                        struct stat st;
                        if (stat(startPath.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
                            activeThreads++;
                            workers.push_back(std::thread([&, startPath]() {
                                std::cout << "[Local Browser] Scanning: " << startPath << std::endl;
                                scanLocal(startPath, 0, maxScanDepth);
                                activeThreads--;
                            }));
                            
                            // Limitiere parallele Threads
                            if (workers.size() >= numThreads) {
                                for (auto& w : workers) {
                                    if (w.joinable()) w.join();
                                }
                                workers.clear();
                            }
                        }
                    }
                    
                    // Warte auf alle Threads
                    for (auto& w : workers) {
                        if (w.joinable()) w.join();
                    }
                    
                    dirsScanned = true;
                    isScanning = false;
                    std::cout << "[Local Browser] [X] Scan complete: " << scannedDirs.size() << " directories" << std::endl;
                    
                    // CACHE: Speichere gescannte Verzeichnisse für nächsten Start
                    {
                        std::lock_guard<std::mutex> lock(dirCacheMutex);
                        cachedLocalDirs = scannedDirs;
                    }
                    saveDirCache();
                    
                }).detach();
            }
            
            ImGui::BeginChild("CommonDirs", ImVec2(0, -40), true);
            
            if (isScanning) {
                ImGui::Text("[...] Scanne Verzeichnisse im Hintergrund...");
                ImGui::Text("Gefunden: %zu Verzeichnisse", scannedDirs.size());
                ImGui::Text("(UI bleibt responsiv)");
            } else if (!dirsScanned) {
                ImGui::Text("Lade Verzeichnisse...");
            } else if (scannedDirs.empty()) {
                ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), 
                                  "Keine Verzeichnisse gefunden!");
            } else {
                // Nutze generische Tree-Display-Funktion
                renderDirectoryTree(scannedDirs, appState.selectedLocalDirs, 
                                   appState.localTreeMaxDepth, searchFilter, "local", true);
            }
            
            ImGui::EndChild();
            
            // Statuszeile unten mit Zähler
            ImGui::Separator();
            if (isScanning) {
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                                  "[...] Scanne... %zu Verzeichnisse gefunden", scannedDirs.size());
            } else if (dirsScanned) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), 
                                  "[X] %zu Verzeichnisse geladen | %zu ausgewählt", 
                                  scannedDirs.size(), appState.selectedLocalDirs.size());
            } else {
                ImGui::Text("Bereit zum Scannen");
            }
            
            ImGui::EndTabItem();
        }
        
        // Mounted Drives Tab (JETZT ZWEITER)
        if (ImGui::BeginTabItem("[DIR] Laufwerke")) {
            ImGui::BeginChild("MountedDrives", ImVec2(0, -40), true);
            
            static std::vector<MountInfo> drives;
            static bool drivesLoaded = false;
            
            if (!drivesLoaded) {
                drives = getMountedDrives();
                drivesLoaded = true;
            }
            
            if (ImGui::Button("[SYNC] Aktualisieren")) {
                drives = getMountedDrives();
            }
            
            ImGui::Separator();
            
            for (const auto& drive : drives) {
                std::string label = drive.mountPoint + " (" + drive.fsType + ") - " + 
                                   formatSize(drive.freeSpace) + " / " + 
                                   formatSize(drive.totalSpace) + " frei";
                
                if (ImGui::Selectable(label.c_str())) {
                    // Filter: Exclude network mount points (NFS/SMB/WebDAV)
                    if (!isNetworkMountPoint(drive.mountPoint, appState)) {
                        appState.selectedLocalDirs.insert(drive.mountPoint);
                    } else {
                        std::cout << "[Local Browser] ⚠️ Netzwerk-Mount ignoriert: " << drive.mountPoint << std::endl;
                    }
                    // Close all windows except main window
                    appState.showLocalBrowser = false;
                    appState.showFtpBrowser = false;
                    appState.showServerBrowser = false;
                    appState.showSettings = false;
                    appState.showAbout = false;
                    appState.showNetworkScanner = false;
                    appState.showResults = false;
                }
                
                if (ImGui::IsItemHovered()) {
                    ImGui::SetTooltip("Device: %s", drive.device.c_str());
                }
            }
            
            ImGui::EndChild();
            ImGui::EndTabItem();
        }
        
        ImGui::EndTabBar();
        
        if (ImGui::Button("Fertig", ImVec2(120, 0))) {
            appState.showLocalBrowser = false;
        }
        ImGui::SameLine();
        if (ImGui::Button("Alle löschen", ImVec2(120, 0))) {
            appState.selectedLocalDirs.clear();
        }
    }
    ImGui::End();
    ImGui::PopStyleColor(); // Pop WindowBg color
}

// Auto-discover NFS mount points and add them to local directories
void autoDiscoverNFSMounts() {
    std::cout << "[NFS] Auto-discovering NFS mount points..." << std::endl;
    
    FILE* fp = fopen("/proc/mounts", "r");
    if (!fp) {
        std::cerr << "[NFS] Could not read /proc/mounts" << std::endl;
        return;
    }
    
    char line[1024];
    int count = 0;
    
    while (fgets(line, sizeof(line), fp)) {
        // Format: device mount fstype options ...
        char device[256], mount_point[256], fstype[32];
        
        if (sscanf(line, "%255s %255s %31s", device, mount_point, fstype) == 3) {
            // Check if it's an NFS mount (nfs, nfs4, etc)
            if (strstr(fstype, "nfs") != nullptr) {
                // Check if mount point is under /mnt/ (common for NFS)
                if (strstr(mount_point, "/mnt/") != nullptr) {
                    // Just discover, DON'T auto-add to scan list
                    std::cout << "[NFS] ✅ Auto-discovered: " << mount_point << " (fstype: " << fstype << ")" << std::endl;
                    count++;
                }
            }
        }
    }
    
    fclose(fp);
    
    if (count > 0) {
        std::cout << "[NFS] ✅ Auto-discovered " << count << " NFS mount points" << std::endl;
    } else {
        std::cout << "[NFS] ℹ️  No NFS mounts found in /proc/mounts" << std::endl;
    }
}


// Render Local Directory Browser Windows
// Render Local Directory Browser Windows
void renderLocalBrowserWindows() {
    // This function is now disabled - use renderNfsDirectoryBrowser() instead
    // which opens a nice tree view when double-clicking NFS presets
    return;
}



// Render Network Scanner / FTP Browser

// Render NFS Directory Browser - Single mount point with tree
void renderNfsDirectoryBrowser() {
    if (appState.selectedNfsMountPath.empty()) return;
    
    ImGui::SetNextWindowSize(ImVec2(900, 700), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(200, 100), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowBgAlpha(0.95f);
    
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.1f, 0.1f, 0.1f, 0.95f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 8));
    
    std::string windowTitle = "📂 NFS Verzeichnisbaum - " + appState.selectedNfsMountPath;
    bool is_open = true;
    
    if (ImGui::Begin(windowTitle.c_str(), &is_open, ImGuiWindowFlags_None)) {
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "NFS Mount Browser");
        ImGui::Text("Pfad: %s", appState.selectedNfsMountPath.c_str());
        ImGui::Separator();

        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "📂 Verzeichnisbaum (Checkbox zum Auswählen):");

        // Echtzeit NFS-Suche bis Tiefe 7 (mit Enter bestätigen)
        ImGui::PushItemWidth(400);
        static char searchBuf[256] = "";
        
        // ImGuiInputTextFlags_EnterReturnsTrue enables Enter key confirmation
        bool searchTriggered = ImGui::InputText("🔍 Echtzeit-Suche (Enter bestätigen)", searchBuf, 
                                                sizeof(searchBuf), ImGuiInputTextFlags_EnterReturnsTrue);
        
        // Update search term on every keystroke (real-time feedback)
        appState.nfsSearchTerm = searchBuf;
        
        ImGui::PopItemWidth();
        
        ImGui::SameLine();
        if (ImGui::Button("Suchen")) {
            searchTriggered = true;  // Manual trigger via button
        }
        
        // Start search on Enter or Button click
        if (searchTriggered && !appState.nfsSearchTerm.empty() && !appState.nfsSearchActive.load()) {
            appState.nfsSearchActive = true;
            appState.nfsSearchRootPath = appState.selectedNfsMountPath;
            appState.nfsSearchResults.clear();
            
            std::cout << "[NFS Search] 🔍 Starting search for: '" << appState.nfsSearchTerm 
                      << "' in " << appState.nfsSearchRootPath << " (depth 7)" << std::endl;
            
            // Background-Thread für asynchrone Suche (Tiefe 7)
            std::thread([&appState]() {
                std::string rootPath = appState.nfsSearchRootPath;
                std::string searchTerm = appState.nfsSearchTerm;
                std::vector<std::string> results;
                
                // Parse multiple search terms (comma-separated)
                std::vector<std::string> searchTerms;
                std::string currentTerm;
                for (char c : searchTerm) {
                    if (c == ',' || c == ';' || c == ' ') {
                        if (!currentTerm.empty()) {
                            // Convert to lowercase
                            std::transform(currentTerm.begin(), currentTerm.end(), currentTerm.begin(), ::tolower);
                            searchTerms.push_back(currentTerm);
                            currentTerm.clear();
                        }
                    } else {
                        currentTerm += c;
                    }
                }
                if (!currentTerm.empty()) {
                    std::transform(currentTerm.begin(), currentTerm.end(), currentTerm.begin(), ::tolower);
                    searchTerms.push_back(currentTerm);
                }
                
                // Fallback: if no terms parsed, use original
                if (searchTerms.empty()) {
                    std::string term = searchTerm;
                    std::transform(term.begin(), term.end(), term.begin(), ::tolower);
                    searchTerms.push_back(term);
                }
                
                std::cout << "[NFS Search] Thread started, searching for " << searchTerms.size() 
                          << " term(s): ";
                for (const auto& t : searchTerms) std::cout << "'" << t << "' ";
                std::cout << std::endl;
                
                // Rekursive Suche bis Tiefe 7
                int dirsScanned = 0;
                int filesScanned = 0;
                
                std::function<void(const std::string&, int)> searchRecursive;
                searchRecursive = [&](const std::string& dir, int depth) {
                    if (depth > 7 || !appState.nfsSearchActive.load()) return;
                    
                    dirsScanned++;
                    if (dirsScanned % 50 == 0) {
                        std::cout << "[NFS Search] Progress: " << dirsScanned << " dirs, " 
                                  << filesScanned << " files scanned (depth " << depth << ")" << std::endl;
                    }
                    
                    DIR* d = opendir(dir.c_str());
                    if (!d) {
                        std::cout << "[NFS Search] ⚠️  Can't open: " << dir << std::endl;
                        return;
                    }
                    
                    struct dirent* entry;
                    while ((entry = readdir(d)) != nullptr) {
                        if (!appState.nfsSearchActive.load()) break;
                        
                        std::string name = entry->d_name;
                        if (name == "." || name == "..") continue;
                        
                        std::string fullPath = dir;
                        if (!fullPath.empty() && fullPath.back() != '/') fullPath += "/";
                        fullPath += name;
                        
                        filesScanned++;
                        
                        // Case-insensitive match on filename - check against ALL search terms
                        std::string lowerName = name;
                        std::transform(lowerName.begin(), lowerName.end(), lowerName.begin(), ::tolower);
                        
                        bool matchFound = false;
                        for (const auto& term : searchTerms) {
                            if (lowerName.find(term) != std::string::npos) {
                                matchFound = true;
                                break;
                            }
                        }
                        
                        if (matchFound) {
                            // Check if it's a directory - prioritize directories
                            struct stat st;
                            bool isDir = false;
                            if (lstat(fullPath.c_str(), &st) == 0) {
                                isDir = S_ISDIR(st.st_mode);
                            }
                            
                            results.push_back(fullPath);
                            std::cout << "[NFS Search] ✅ Match found (" << (isDir ? "DIR" : "FILE") 
                                      << "): " << name << " -> " << fullPath << std::endl;
                        }
                        
                        // Recurse into directories
                        struct stat st;
                        if (lstat(fullPath.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
                            searchRecursive(fullPath, depth + 1);
                        }
                    }
                    closedir(d);
                };
                
                std::cout << "[NFS Search] Starting recursive scan from: " << rootPath << std::endl;
                searchRecursive(rootPath, 0);
                
                if (appState.nfsSearchActive.load()) {
                    appState.nfsSearchResults = results;
                    std::cout << "[NFS Search] ✅✅✅ SEARCH COMPLETE! ✅✅✅" << std::endl;
                    std::cout << "[NFS Search] Total matches: " << results.size() << std::endl;
                    std::cout << "[NFS Search] Directories scanned: " << dirsScanned << std::endl;
                    std::cout << "[NFS Search] Files/dirs checked: " << filesScanned << std::endl;
                    std::cout << "[NFS Search] Search terms: ";
                    for (const auto& t : searchTerms) std::cout << "'" << t << "' ";
                    std::cout << std::endl;
                } else {
                    std::cout << "[NFS Search] ❌ Search cancelled by user after " 
                              << dirsScanned << " dirs" << std::endl;
                }
                appState.nfsSearchActive = false;
            }).detach();
        }
        
        ImGui::SameLine();
        if (ImGui::Button("Abbrechen") && appState.nfsSearchActive.load()) {
            appState.nfsSearchActive = false;
        }
        
        if (appState.nfsSearchActive.load()) {
            ImGui::SameLine();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⏳ Suche läuft...");
        }
        
        // Show search results with checkboxes and visual feedback
        if (!appState.nfsSearchResults.empty()) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "📋 Suchergebnisse: %zu Treffer", appState.nfsSearchResults.size());
            
            // Buttons for bulk actions
            if (ImGui::Button("✅ Alle auswählen")) {
                for (const auto& result : appState.nfsSearchResults) {
                    appState.selectedLocalDirs.insert(result);
                }
                std::cout << "[NFS Search] ✅ Alle " << appState.nfsSearchResults.size() << " Ergebnisse ausgewählt" << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("❌ Alle abwählen")) {
                for (const auto& result : appState.nfsSearchResults) {
                    appState.selectedLocalDirs.erase(result);
                }
                std::cout << "[NFS Search] ❌ Alle Ergebnisse abgewählt" << std::endl;
            }
            
            ImGui::BeginChild("NfsSearchResults", ImVec2(0, 200), true);
            
            // Right-click context menu
            if (ImGui::BeginPopupContextWindow("SearchResultsContext")) {
                if (ImGui::MenuItem("✅ Alle auswählen")) {
                    for (const auto& result : appState.nfsSearchResults) {
                        appState.selectedLocalDirs.insert(result);
                    }
                    std::cout << "[NFS Search] ✅ Alle ausgewählt (Kontextmenü)" << std::endl;
                }
                if (ImGui::MenuItem("❌ Alle abwählen")) {
                    for (const auto& result : appState.nfsSearchResults) {
                        appState.selectedLocalDirs.erase(result);
                    }
                    std::cout << "[NFS Search] ❌ Alle abgewählt (Kontextmenü)" << std::endl;
                }
                ImGui::Separator();
                if (ImGui::MenuItem("🔄 Auswahl umkehren")) {
                    for (const auto& result : appState.nfsSearchResults) {
                        if (appState.selectedLocalDirs.find(result) != appState.selectedLocalDirs.end()) {
                            appState.selectedLocalDirs.erase(result);
                        } else {
                            appState.selectedLocalDirs.insert(result);
                        }
                    }
                    std::cout << "[NFS Search] 🔄 Auswahl umgekehrt" << std::endl;
                }
                ImGui::EndPopup();
            }
            
            int resultIndex = 0;
            for (const auto& result : appState.nfsSearchResults) {
                ImGui::PushID(resultIndex++);
                
                // Check if already selected
                bool isSelected = (appState.selectedLocalDirs.find(result) != appState.selectedLocalDirs.end());
                
                // Checkbox for selection
                if (ImGui::Checkbox("##select", &isSelected)) {
                    if (isSelected) {
                        appState.selectedLocalDirs.insert(result);
                        std::cout << "[NFS Search] ✅ Added: " << result << std::endl;
                    } else {
                        appState.selectedLocalDirs.erase(result);
                        std::cout << "[NFS Search] ❌ Removed: " << result << std::endl;
                    }
                }
                
                ImGui::SameLine();
                
                // Color-code selected items
                if (isSelected) {
                    ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "%s", result.c_str());
                } else {
                    ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "%s", result.c_str());
                }
                
                ImGui::PopID();
            }
            
            ImGui::EndChild();
            
            // Show selection summary
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                              "✓ Ausgewählt: %zu von %zu Verzeichnissen", 
                              appState.selectedLocalDirs.size(), 
                              appState.nfsSearchResults.size());
            ImGui::Separator();
        }

        std::vector<std::string> notLike;
        std::vector<std::string> like;
        std::vector<std::string> searchTerms;  // Tree remains lazy-loaded

        ImGui::BeginChild("NfsTree", ImVec2(0, -60), true);

        std::string selectedTreePath;

        renderDirectoryTreeUI(
            appState.selectedNfsMountPath,
            appState.localTreeMaxDepth,
            true,
            notLike,
            like,
            selectedTreePath,
            &appState.selectedLocalDirs,
            searchTerms);

        // Selection now handled by checkbox in tree - don't auto-add!
        if (!selectedTreePath.empty()) {
            // REMOVED: appState.selectedLocalDirs.insert(selectedTreePath);
            std::cout << "[NFS] Tree path clicked: " << selectedTreePath << " (use checkbox to add)" << std::endl;
        }

        ImGui::EndChild();

        ImGui::Separator();
        ImGui::Text("Ausgewählte Verzeichnisse: %zu", appState.selectedLocalDirs.size());
        
        if (ImGui::Button("Scan starten", ImVec2(120, 0))) {
            appState.selectedNfsMountPath = "";  // Close this window
            is_open = false;
        }
        ImGui::SameLine();
        if (ImGui::Button("Abbrechen", ImVec2(120, 0))) {
            appState.selectedNfsMountPath = "";
            is_open = false;
        }
        
        ImGui::End();
    }
    
    ImGui::PopStyleVar();
    ImGui::PopStyleColor();
    
    // If user clicked close button, clear the mount path and auto-unmount if enabled
    if (!is_open) {
        // Auto-Unmount wenn aktiviert und Mount nicht in Auto-Mount Liste
        if (appState.nfsAutoUnmount && !appState.selectedNfsMountPath.empty()) {
            // Finde das Preset für diesen Mount
            for (auto& preset : appState.ftpPresets) {
                if (preset.serviceType == "NFS" && preset.nfsMountPoint == appState.selectedNfsMountPath) {
                    // Nur unmounten wenn nicht Auto-Mount aktiviert ist
                    if (!preset.nfsAutoMount && preset.nfsMounted) {
                        std::cout << "[NFS] 🔄 Auto-Unmount: " << preset.nfsMountPoint << std::endl;
                        unmountNFS(preset);
                        saveFtpPresets();
                    }
                    break;
                }
            }
        }
        appState.selectedNfsMountPath = "";
    }
}

void renderNetworkScanner() {
    if (!appState.showNetworkScanner) {
        // Reset Tab-Wechsel Flag wenn Dialog geschlossen ist
        appState.switchToFtpTab = 0;
        return;
    }
    
    // FORCE window to be always on top and movable
    ImGui::SetNextWindowSize(ImVec2(900, 600), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, 20), 
                           ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.0f));
    
    ImGui::SetNextWindowBgAlpha(0.95f);
    
    // Set window background to be opaque
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.1f, 0.1f, 0.1f, 0.95f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(4, 4));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    
    // Normal movable window
    ImGuiWindowFlags flags = ImGuiWindowFlags_None;
    
    // Add window close button
    ImGui::SetNextWindowCollapsed(false, ImGuiCond_FirstUseEver);
    
    if (ImGui::Begin("🌐 NETZWERK & FTP SCANNER (Titelleiste ziehen zum Bewegen)", &appState.showNetworkScanner, flags)) {
        
        if (ImGui::BeginTabBar("NetworkTabs")) {
            
            // FTP Connection Tab - Auto-Select wenn Flag gesetzt (NOW FIRST!)
            ImGuiTabItemFlags ftpFlags = ImGuiTabItemFlags_None;
            if (appState.switchToFtpTab == 1) {
                ftpFlags = ImGuiTabItemFlags_SetSelected;
                appState.switchToFtpTab = 0; // Sofort zurücksetzen
            }
            
            if (ImGui::BeginTabItem("[FTP] FTP-Verbindung", nullptr, ftpFlags)) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Server-Presets & Verbindung");
            ImGui::Separator();
            
            // Gespeicherte Presets anzeigen (mit vollständigen Infos)
            if (!appState.ftpPresets.empty()) {
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[CLIP] Gespeicherte Server-Presets:");
                ImGui::BeginChild("SavedFtpPresets", ImVec2(0, 150), true);
                
                static int presetToDelete = -1;
                
                for (size_t i = 0; i < appState.ftpPresets.size(); i++) {
                    const auto& preset = appState.ftpPresets[i];
                    
                    // Zeige: [Dienst] Name - IP:Port
                    std::string displayText = "[" + preset.serviceType + "] " + preset.name + " - " + 
                                             preset.ip + ":" + std::to_string(preset.port);
                    
                    // Farbe basierend auf Service-Typ: NFS=Blau, FTP=Rot, SMB=Gelb, WebDAV=Grün
                    ImVec4 textColor;
                    if (preset.serviceType == "NFS") {
                        textColor = ImVec4(0.3f, 0.6f, 1.0f, 1.0f); // NFS = BLAU
                    } else if (preset.serviceType == "FTP") {
                        textColor = ImVec4(1.0f, 0.3f, 0.3f, 1.0f); // FTP = ROT
                    } else if (preset.serviceType == "SFTP") {
                        textColor = ImVec4(1.0f, 0.6f, 0.2f, 1.0f); // SFTP = ORANGE
                    } else if (preset.serviceType == "SMB") {
                        textColor = ImVec4(1.0f, 1.0f, 0.3f, 1.0f); // SMB = GELB
                    } else if (preset.serviceType == "WebDAV") {
                        textColor = ImVec4(0.3f, 1.0f, 0.3f, 1.0f); // WebDAV = GRÜN
                    } else {
                        textColor = ImVec4(0.8f, 0.8f, 0.8f, 1.0f); // Standard = GRAU
                    }
                    
                    ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                    bool isSelected = (appState.connectedPresetIndex == (int)i);
                    bool clicked = ImGui::Selectable(displayText.c_str(), isSelected, ImGuiSelectableFlags_AllowDoubleClick);
                    ImGui::PopStyleColor();
                    
                    if (clicked) {
                        // Einfachklick: Daten ins Formular laden
                        appState.selectedFtpHost = preset.ip;
                        appState.ftpPort = preset.port;
                        appState.ftpUsername = preset.username;
                        appState.ftpPassword = preset.password;
                        std::cout << "[FTP] Loaded preset: " << preset.name << std::endl;
                    }
                    
                    // Doppelklick: Direkt verbinden und Verzeichnisse holen
                    if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) {
                        appState.selectedFtpHost = preset.ip;
                        appState.ftpPort = preset.port;
                        appState.ftpUsername = preset.username;
                        appState.ftpPassword = preset.password;
                        appState.connectedPresetIndex = i;
                        
                        std::cout << "[FTP] Auto-connecting to: " << preset.name << std::endl;
                        
                        // Make a copy to modify
                        FtpPreset presetCopy = preset;
                        
                        // Try to connect and fetch directories
                        if (connectAndFetchDirectories(presetCopy, i)) {
                            // Success - show browser
                            appState.showServerBrowser = true;
                            
                            // Update preset with any new credentials
                            appState.ftpPresets[i] = presetCopy;
                        }
                        // If failed and needs credentials, connectAndFetchDirectories opens dialog
                    }
                    
                    // Rechtsklick-Menü
                    if (ImGui::BeginPopupContextItem(("ftp_preset_ctx_" + std::to_string(i)).c_str())) {
                        if (ImGui::MenuItem("[PLUG] Verbinden")) {
                            appState.selectedFtpHost = preset.ip;
                            appState.ftpPort = preset.port;
                            appState.ftpUsername = preset.username;
                            appState.ftpPassword = preset.password;
                            appState.connectedPresetIndex = i;
                        }
                        if (ImGui::MenuItem("[X] Preset löschen")) {
                            presetToDelete = i;
                        }
                        ImGui::EndPopup();
                    }
                }
                
                // Delete preset AFTER the loop to avoid iterator invalidation
                if (presetToDelete >= 0 && presetToDelete < (int)appState.ftpPresets.size()) {
                    std::cout << "[FTP] Deleting preset: " << appState.ftpPresets[presetToDelete].name << std::endl;
                    appState.ftpPresets.erase(appState.ftpPresets.begin() + presetToDelete);
                    
                    // Update connectedPresetIndex if needed
                    if (appState.connectedPresetIndex == presetToDelete) {
                        appState.connectedPresetIndex = -1; // Disconnected
                        appState.serverDirectories.clear();
                    } else if (appState.connectedPresetIndex > presetToDelete) {
                        appState.connectedPresetIndex--; // Adjust index
                    }
                    
                    saveFtpPresets();
                    presetToDelete = -1;
                }
                
                ImGui::EndChild();
                ImGui::Text("[TIP] Doppelklick auf Preset zum direkten Verbinden");
                ImGui::Spacing();
            }
            
            // Neues Preset erstellen / Verbindungsdetails
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Verbindungsdetails:");
            
            static char presetName[128] = "Mein Server";
            static char ftpHost[256] = "";
            static char serviceType[32] = "FTP";
            static char username[128] = "anonymous";
            static char password[128] = "";
            
            // Auto-fill wenn aus Netzwerk-Scan ausgewählt
            if (!appState.selectedFtpHost.empty()) {
                strncpy(ftpHost, appState.selectedFtpHost.c_str(), sizeof(ftpHost) - 1);
            }
            
            ImGui::Columns(2, "ConnectionDetails", false);
            ImGui::SetColumnWidth(0, 120);
            
            ImGui::Text("Preset-Name:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##PresetName", presetName, sizeof(presetName));
            ImGui::NextColumn();
            
            ImGui::Text("Dienst:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            const char* serviceTypes[] = { "FTP", "SFTP", "SMB", "NFS", "WebDAV" };
            static int currentService = 0;
            if (ImGui::Combo("##ServiceType", &currentService, serviceTypes, IM_ARRAYSIZE(serviceTypes))) {
                strncpy(serviceType, serviceTypes[currentService], sizeof(serviceType) - 1);
                // Auto-adjust default port
                if (strcmp(serviceType, "FTP") == 0) appState.ftpPort = 21;
                else if (strcmp(serviceType, "SFTP") == 0) appState.ftpPort = 22;
                else if (strcmp(serviceType, "SMB") == 0) appState.ftpPort = 445;
                else if (strcmp(serviceType, "NFS") == 0) appState.ftpPort = 2049;
                else if (strcmp(serviceType, "WebDAV") == 0) appState.ftpPort = 8080;
            }
            ImGui::NextColumn();
            
            ImGui::Text("Server/IP:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##Host", ftpHost, sizeof(ftpHost));
            appState.selectedFtpHost = ftpHost;
            ImGui::NextColumn();
            
            ImGui::Text("Port:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputInt("##Port", &appState.ftpPort);
            ImGui::NextColumn();
            
            ImGui::Text("Benutzername:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##Username", username, sizeof(username));
            appState.ftpUsername = username;
            ImGui::NextColumn();
            
            ImGui::Text("Passwort:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##Password", password, sizeof(password), ImGuiInputTextFlags_Password);
            appState.ftpPassword = password;
            ImGui::NextColumn();
            
            ImGui::Columns(1);
            
            ImGui::Spacing();
            
            // Buttons: Preset speichern und Verbinden
            if (ImGui::Button("[CLIP] Als Preset speichern", ImVec2(200, 0))) {
                if (strlen(ftpHost) > 0 && strlen(presetName) > 0) {
                    FtpPreset newPreset;
                    newPreset.name = presetName;
                    newPreset.ip = ftpHost;
                    newPreset.serviceType = serviceType;
                    newPreset.port = appState.ftpPort;
                    newPreset.username = username;
                    newPreset.password = password;
                    
                    appState.ftpPresets.push_back(newPreset);
                    saveFtpPresets();
                    
                    std::cout << "[FTP] Saved preset: " << presetName << " (" << serviceType 
                             << "://" << ftpHost << ":" << appState.ftpPort << ")" << std::endl;
                }
            }
            
            ImGui::SameLine();
            
            static bool connected = false;
            if (!connected) {
                if (ImGui::Button("[PLUG] Verbinden", ImVec2(150, 0))) {
                    if (!appState.selectedFtpHost.empty()) {
                        std::cout << "[FTP] Connecting to " << serviceType << "://" 
                                 << appState.selectedFtpHost << ":" << appState.ftpPort 
                                 << " as " << username << std::endl;
                        connected = true;
                    }
                }
            } else {
                if (ImGui::Button("[X] Trennen", ImVec2(150, 0))) {
                    connected = false;
                    appState.connectedPresetIndex = -1;
                }
                
                ImGui::SameLine();
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), 
                                  "[OK] Verbunden mit %s", appState.selectedFtpHost.c_str());
            }
            
            if (connected) {
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "FTP Verzeichnisse:");
                
                ImGui::BeginChild("FtpDirs", ImVec2(0, 200), true);
                static std::vector<std::string> ftpDirs = {
                    "/pub", "/upload", "/backup", "/shared", "/data"
                };
                
                for (const auto& dir : ftpDirs) {
                    bool isSelected = appState.selectedFtpDirs.count(dir) > 0;
                    if (ImGui::Selectable(("[DIR] " + dir).c_str(), isSelected)) {
                        if (isSelected) {
                            appState.selectedFtpDirs.erase(dir);
                        } else {
                            appState.selectedFtpDirs.insert(dir);
                        }
                    }
                }
                ImGui::EndChild();
                
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), 
                                  "Ausgewählt: %zu Verzeichnis(se)", 
                                  appState.selectedFtpDirs.size());
            }
            
            ImGui::EndTabItem(); // End FTP Tab
        }
        
        // ====================================================================
        // NFS BROWSER TAB
        // ====================================================================
        if (ImGui::BeginTabItem("[NFS] NFS-Mount")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "NFS Shares & Mount-Verwaltung");
            ImGui::Separator();
            
            // Static variables for form (must be declared before use)
            static char nfsName[128] = "Mein NFS Share";
            static char nfsServer[256] = "192.168.1.100";
            static char nfsExportPath[256] = "/export";
            static char nfsMountPoint[256] = "/mnt/nfs_share";
            static char nfsOptions[256] = "vers=4,rw";
            static char nfsUsername[256] = "nfsuser";
            static char nfsPassword[256] = "";
            static bool nfsAutoMount = false;
            
            // Gespeicherte NFS Presets anzeigen
            if (!appState.ftpPresets.empty()) {
                std::vector<FtpPreset*> nfsPresets;
                for (auto& preset : appState.ftpPresets) {
                    if (preset.serviceType == "NFS") {
                        nfsPresets.push_back(&preset);
                    }
                }
                
                if (!nfsPresets.empty()) {
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[FOLDER] Gespeicherte NFS Shares:");
                    ImGui::SameLine();
                    ImGui::Checkbox("🔄 Auto-Unmount", &appState.nfsAutoUnmount);
                    if (ImGui::IsItemHovered()) {
                        ImGui::SetTooltip("Automatisch unmounten wenn Browser geschlossen wird\n(außer bei Auto-Mount Shares)");
                    }
                    ImGui::BeginChild("SavedNfsPresets", ImVec2(0, 150), true);
                    
                    static int nfsPresetToDelete = -1;
                    
                    for (size_t i = 0; i < nfsPresets.size(); i++) {
                        auto* preset = nfsPresets[i];
                        
                        // Status icon and text
                        const char* statusIcon = preset->nfsMounted ? "[OK]" : "[X]";
                        // NFS = BLAU
                        ImVec4 statusColor = preset->nfsMounted ? 
                            ImVec4(0.3f, 0.6f, 1.0f, 1.0f) : ImVec4(0.2f, 0.3f, 0.5f, 1.0f);
                        
                        std::string displayText = std::string(statusIcon) + " " + preset->name + 
                                                 " - " + preset->ip + ":" + preset->nfsExportPath;
                        
                        // Create unique ID for this row
                        ImGui::PushID((int)i);
                        
                        // Selectable item
                        ImGui::PushStyleColor(ImGuiCol_Text, statusColor);
                        bool isSelected = preset->nfsMounted;
                        bool clicked = ImGui::Selectable(displayText.c_str(), isSelected, ImGuiSelectableFlags_AllowDoubleClick | ImGuiSelectableFlags_SpanAllColumns);
                        ImGui::PopStyleColor();
                        
                        // Detect double-click on the selectable
                        if (clicked && ImGui::IsMouseDoubleClicked(0)) {
                            if (preset->nfsMounted) {
                                // Already mounted - open directory browser
                                appState.selectedNfsMountPath = preset->nfsMountPoint;
                                std::cout << "[NFS] ✅ Opening directory browser for: " << preset->nfsMountPoint << std::endl;
                            } else {
                                // Not mounted yet - mount it first
                                std::cout << "[NFS] Mounting: " << preset->name << std::endl;
                                if (mountNFS(*preset)) {
                                    // Open browser but DON'T auto-add to scan list
                                    appState.selectedNfsMountPath = preset->nfsMountPoint;
                                    std::cout << "[NFS] ✅ Directory browser opens for: " << preset->nfsMountPoint << std::endl;
                                    saveFtpPresets();
                                }
                            }
                        }
                        
                        // Right-click context menu on selectable
                        if (ImGui::BeginPopupContextItem(("nfs_preset_ctx_" + std::to_string(i)).c_str())) {
                            if (ImGui::MenuItem("📂 Verzeichnisbaum öffnen")) {
                                if (preset->nfsMounted) {
                                    appState.selectedNfsMountPath = preset->nfsMountPoint;
                                } else {
                                    if (mountNFS(*preset)) {
                                        // Open browser but DON'T auto-add to scan list
                                        appState.selectedNfsMountPath = preset->nfsMountPoint;
                                        saveFtpPresets();
                                    }
                                }
                            }
                            ImGui::Separator();
                            if (!preset->nfsMounted) {
                                if (ImGui::MenuItem("⚡ Mount")) {
                                    if (mountNFS(*preset)) {
                                        // Just mount, DON'T auto-add to scan list
                                        saveFtpPresets();
                                    }
                                }
                            } else {
                                if (ImGui::MenuItem("🔌 Unmount")) {
                                    unmountNFS(*preset);
                                    appState.selectedLocalDirs.erase(preset->nfsMountPoint);
                                    saveFtpPresets();
                                }
                            }
                            if (ImGui::MenuItem("🗑️ Preset löschen")) {
                                // Find actual index in ftpPresets
                                for (size_t j = 0; j < appState.ftpPresets.size(); j++) {
                                    if (&appState.ftpPresets[j] == preset) {
                                        nfsPresetToDelete = j;
                                        break;
                                    }
                                }
                            }
                            ImGui::EndPopup();
                        }
                        
                        // Single click: Load ALL preset data into form (including username/password)
                        if (clicked && !ImGui::IsMouseDoubleClicked(0)) {
                            std::cout << "[NFS] Loaded preset: " << preset->name << std::endl;
                            std::cout << "[NFS] ├─ Server: " << preset->ip << std::endl;
                            std::cout << "[NFS] ├─ Export: " << preset->nfsExportPath << std::endl;
                            std::cout << "[NFS] ├─ Mount: " << preset->nfsMountPoint << std::endl;
                            std::cout << "[NFS] ├─ Username: " << (preset->username.empty() ? "(none)" : preset->username) << std::endl;
                            std::cout << "[NFS] ├─ Password: " << (preset->password.empty() ? "(none)" : "***") << std::endl;
                            std::cout << "[NFS] ├─ Options: " << (preset->nfsOptions.empty() ? "(default)" : preset->nfsOptions) << std::endl;
                            std::cout << "[NFS] └─ Auto-Mount: " << (preset->nfsAutoMount ? "YES" : "NO") << std::endl;
                            
                            strcpy(nfsName, preset->name.c_str());
                            strcpy(nfsServer, preset->ip.c_str());
                            strcpy(nfsExportPath, preset->nfsExportPath.c_str());
                            strcpy(nfsMountPoint, preset->nfsMountPoint.c_str());
                            strcpy(nfsOptions, preset->nfsOptions.c_str());
                            strcpy(nfsUsername, preset->username.c_str());        // Load username
                            strcpy(nfsPassword, preset->password.c_str());        // Load password
                            nfsAutoMount = preset->nfsAutoMount;
                        }
                        
                        ImGui::PopID();
                    }
                    
                    // Delete preset AFTER the loop
                    if (nfsPresetToDelete >= 0 && nfsPresetToDelete < (int)appState.ftpPresets.size()) {
                        auto& preset = appState.ftpPresets[nfsPresetToDelete];
                        std::cout << "[NFS] Deleting preset: " << preset.name << std::endl;
                        
                        // Unmount if mounted
                        if (preset.nfsMounted) {
                            unmountNFS(preset);
                        }
                        
                        appState.ftpPresets.erase(appState.ftpPresets.begin() + nfsPresetToDelete);
                        saveFtpPresets();
                        nfsPresetToDelete = -1;
                    }
                    
                    ImGui::EndChild();
                    ImGui::Text("[TIP] Doppelklick zum Mount/Unmount");
                    ImGui::Spacing();
                }
            }
            
            // Neues NFS Preset erstellen
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Neues NFS Share hinzufügen:");
            
            // Variables already declared at the beginning of this tab
            
            ImGui::Columns(2, "NfsDetails", false);
            ImGui::SetColumnWidth(0, 140);
            
            ImGui::Text("Preset-Name:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##NfsName", nfsName, sizeof(nfsName));
            ImGui::NextColumn();
            
            ImGui::Text("NFS Server:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##NfsServer", nfsServer, sizeof(nfsServer));
            ImGui::NextColumn();
            
            ImGui::Text("Export Pfad:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##NfsExport", nfsExportPath, sizeof(nfsExportPath));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Der Share-Pfad auf dem NFS Server, z.B. /export/data");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Benutzername:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##NfsUsername", nfsUsername, sizeof(nfsUsername));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Optional: Benutzername für Secure NFS / Kerberos");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Passwort:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##NfsPassword", nfsPassword, sizeof(nfsPassword), ImGuiInputTextFlags_Password);
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Optional: Passwort für Secure NFS / Kerberos");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Mount Point:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##NfsMountPoint", nfsMountPoint, sizeof(nfsMountPoint));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Lokaler Pfad wo der Share gemountet wird, z.B. /mnt/nfs_share");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Mount Options:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##NfsOptions", nfsOptions, sizeof(nfsOptions));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("NFS Mount-Optionen, z.B. vers=4,rw,nolock\nLeer lassen für Standard (vers=4,rw,nolock)");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Auto-Mount:");
            ImGui::NextColumn();
            ImGui::Checkbox("##NfsAutoMount", &nfsAutoMount);
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Automatisch beim Programmstart mounten");
            }
            ImGui::NextColumn();
            
            ImGui::Columns(1);
            ImGui::Spacing();
            
            // Buttons
            if (ImGui::Button("[CLIP] Als NFS Preset speichern", ImVec2(220, 0))) {
                if (strlen(nfsServer) > 0 && strlen(nfsExportPath) > 0 && strlen(nfsMountPoint) > 0) {
                    FtpPreset newPreset;
                    newPreset.name = nfsName;
                    newPreset.ip = nfsServer;
                    newPreset.serviceType = "NFS";
                    newPreset.port = 2049;
                    newPreset.username = nfsUsername;
                    newPreset.password = nfsPassword;
                    newPreset.nfsExportPath = nfsExportPath;
                    newPreset.nfsMountPoint = nfsMountPoint;
                    newPreset.nfsOptions = nfsOptions;
                    newPreset.nfsAutoMount = nfsAutoMount;
                    newPreset.nfsMounted = false;
                    
                    appState.ftpPresets.push_back(newPreset);
                    saveFtpPresets();
                    
                    std::cout << "[NFS] Saved preset: " << nfsName << " (" 
                             << nfsServer << ":" << nfsExportPath << " -> " 
                             << nfsMountPoint << ")" << std::endl;
                }
            }
            
            ImGui::SameLine();
            
            if (ImGui::Button("[PLUG] Jetzt mounten", ImVec2(150, 0))) {
                if (strlen(nfsServer) > 0 && strlen(nfsExportPath) > 0 && strlen(nfsMountPoint) > 0) {
                    FtpPreset tempPreset;
                    tempPreset.name = nfsName;
                    tempPreset.ip = nfsServer;
                    tempPreset.serviceType = "NFS";
                    tempPreset.username = nfsUsername;
                    tempPreset.password = nfsPassword;
                    tempPreset.nfsExportPath = nfsExportPath;
                    tempPreset.nfsMountPoint = nfsMountPoint;
                    tempPreset.nfsOptions = nfsOptions;
                    
                    if (mountNFS(tempPreset)) {
                        // Just mount, DON'T auto-add to scan list
                        // Open local browser to show mounted directory
                        appState.showLocalBrowser = true;
                        ImGui::OpenPopup("NfsMountSuccess");
                    } else {
                        ImGui::OpenPopup("NfsMountFailed");
                    }
                }
            }
            
            // Success/Failure popups
            if (ImGui::BeginPopupModal("NfsMountSuccess", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "✅ NFS Share erfolgreich gemountet!");
                ImGui::Text("Mount Point: %s", nfsMountPoint);
                ImGui::Spacing();
                ImGui::Text("Das NFS-Share ist jetzt verfügbar!");
                ImGui::Text("Es wird als lokales Verzeichnis behandelt.");
                ImGui::Spacing();
                if (ImGui::Button("Scanner öffnen", ImVec2(150, 0))) {
                    ImGui::CloseCurrentPopup();
                    // Just open scanner, DON'T auto-add to scan list
                    // User must use checkbox to select directories
                }
                ImGui::SameLine();
                if (ImGui::Button("Schließen", ImVec2(120, 0))) {
                    ImGui::CloseCurrentPopup();
                }
                ImGui::EndPopup();
            }
            
            if (ImGui::BeginPopupModal("NfsMountFailed", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "❌ NFS Mount fehlgeschlagen!");
                ImGui::Text("Prüfe:");
                ImGui::BulletText("NFS Server erreichbar?");
                ImGui::BulletText("Export Pfad korrekt?");
                ImGui::BulletText("NFS-Client installiert? (nfs-utils)");
                ImGui::BulletText("Root-Rechte? (sudo erforderlich)");
                ImGui::Spacing();
                if (ImGui::Button("OK", ImVec2(120, 0))) {
                    ImGui::CloseCurrentPopup();
                }
                ImGui::EndPopup();
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "ℹ️ NFS-Hinweise:");
            ImGui::BulletText("NFS-Client muss installiert sein: sudo dnf install nfs-utils");
            ImGui::BulletText("Root-Rechte erforderlich: FileDuper mit sudo starten");
            ImGui::BulletText("Nach dem Mount erscheint das Share wie ein lokales Verzeichnis");
            ImGui::BulletText("Nutze den normalen Verzeichnis-Scan für NFS-Shares");
            ImGui::BulletText("NFSv4 empfohlen für beste Performance und Sicherheit");
            
            ImGui::EndTabItem(); // End NFS Tab
        }
        
        // ====================================================================
        // SMB/CIFS BROWSER TAB
        // ====================================================================
        if (ImGui::BeginTabItem("[SMB] SMB/CIFS-Mount")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Windows Shares & SMB-Verwaltung");
            ImGui::Separator();
            
            // Static variables for form (must be declared before use)
            static char smbName[128] = "Mein SMB Share";
            static char smbServer[256] = "192.168.1.100";
            static char smbShareName[256] = "shared";
            static char smbMountPoint[256] = "/mnt/smb_share";
            static char smbUsername[128] = "user";
            static char smbPassword[128] = "";
            static char smbDomain[128] = "";
            static char smbWorkgroup[128] = "WORKGROUP";
            static char smbOptions[256] = "vers=3.0";
            static bool smbAutoMount = false;
            
            // Gespeicherte SMB Presets anzeigen
            if (!appState.ftpPresets.empty()) {
                std::vector<FtpPreset*> smbPresets;
                for (auto& preset : appState.ftpPresets) {
                    if (preset.serviceType == "SMB") {
                        smbPresets.push_back(&preset);
                    }
                }
                
                if (!smbPresets.empty()) {
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[FOLDER] Gespeicherte SMB/CIFS Shares:");
                    ImGui::BeginChild("SavedSmbPresets", ImVec2(0, 150), true);
                    
                    static int smbPresetToDelete = -1;
                    
                    for (size_t i = 0; i < smbPresets.size(); i++) {
                        auto* preset = smbPresets[i];
                        
                        // Status icon
                        const char* statusIcon = preset->smbMounted ? "[OK]" : "[X]";
                        // SMB = GELB
                        ImVec4 statusColor = preset->smbMounted ? 
                            ImVec4(1.0f, 1.0f, 0.3f, 1.0f) : ImVec4(0.6f, 0.6f, 0.2f, 1.0f);
                        
                        std::string displayText = std::string(statusIcon) + " " + preset->name + 
                                                 " - " + preset->smbSharePath;
                        if (!preset->smbDomain.empty()) {
                            displayText += " (Domain: " + preset->smbDomain + ")";
                        }
                        
                        ImGui::PushStyleColor(ImGuiCol_Text, statusColor);
                        bool isSelected = preset->smbMounted;
                        if (ImGui::Selectable(displayText.c_str(), isSelected, ImGuiSelectableFlags_AllowDoubleClick)) {
                            // Single click: Load into form
                            std::cout << "[SMB] Loaded preset: " << preset->name << std::endl;
                            strcpy(smbName, preset->name.c_str());
                            strcpy(smbServer, preset->ip.c_str());
                            strcpy(smbShareName, preset->smbSharePath.c_str());
                            strcpy(smbMountPoint, preset->smbMountPoint.c_str());
                            strcpy(smbUsername, preset->username.c_str());
                            strcpy(smbPassword, preset->password.c_str());
                            strcpy(smbDomain, preset->smbDomain.c_str());
                            strcpy(smbWorkgroup, preset->smbWorkgroup.c_str());
                            strcpy(smbOptions, preset->smbOptions.c_str());
                            smbAutoMount = preset->smbAutoMount;
                        }
                        ImGui::PopStyleColor();
                        
                        // Mount/Unmount Button
                        ImGui::SameLine();
                        if (preset->smbMounted) {
                            std::string unmount_btn = "🔌 Unmount##smb_unmount_" + std::to_string(i);
                            if (ImGui::SmallButton(unmount_btn.c_str())) {
                                std::cout << "[SMB] Unmounting: " << preset->name << std::endl;
                                unmountSMB(*preset);
                                appState.selectedLocalDirs.erase(preset->smbMountPoint);
                                saveFtpPresets();
                            }
                        } else {
                            std::string mount_btn = "⚡ Mount##smb_mount_" + std::to_string(i);
                            if (ImGui::SmallButton(mount_btn.c_str())) {
                                std::cout << "[SMB] Mounting: " << preset->name << std::endl;
                                if (mountSMB(*preset)) {
                                    // Just mount, DON'T auto-add to scan list
                                    appState.showLocalBrowser = true;
                                    saveFtpPresets();
                                }
                            }
                        }
                        
                        // Double click: Mount/Unmount
                        if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) {
                            if (preset->smbMounted) {
                                std::cout << "[SMB] Unmounting: " << preset->name << std::endl;
                                unmountSMB(*preset);
                                saveFtpPresets();
                            } else {
                                std::cout << "[SMB] Mounting: " << preset->name << std::endl;
                                if (mountSMB(*preset)) {
                                    // Just mount, DON'T auto-add to scan list
                                    appState.showLocalBrowser = true;
                                    std::cout << "[SMB] ✅ showLocalBrowser gesetzt!" << std::endl;
                                    saveFtpPresets();
                                }
                            }
                        }
                        
                        // Context menu
                        if (ImGui::BeginPopupContextItem(("smb_preset_ctx_" + std::to_string(i)).c_str())) {
                            if (ImGui::MenuItem("📂 Verzeichnisbaum öffnen")) {
                                if (preset->smbMounted) {
                                    appState.showLocalBrowser = true;
                                } else {
                                    if (mountSMB(*preset)) {
                                        appState.showLocalBrowser = true;
                                        saveFtpPresets();
                                    }
                                }
                            }
                            ImGui::Separator();
                            if (!preset->smbMounted) {
                                if (ImGui::MenuItem("⚡ Mount")) {
                                    if (mountSMB(*preset)) {
                                        // Just mount, DON'T auto-add to scan list
                                        appState.showLocalBrowser = true;
                                        saveFtpPresets();
                                    }
                                }
                            } else {
                                if (ImGui::MenuItem("🔌 Unmount")) {
                                    unmountSMB(*preset);
                                    appState.selectedLocalDirs.erase(preset->smbMountPoint);
                                    saveFtpPresets();
                                }
                            }
                            if (ImGui::MenuItem("🗑️ Preset löschen")) {
                                // Find actual index in ftpPresets
                                for (size_t j = 0; j < appState.ftpPresets.size(); j++) {
                                    if (&appState.ftpPresets[j] == preset) {
                                        smbPresetToDelete = j;
                                        break;
                                    }
                                }
                            }
                            ImGui::EndPopup();
                        }
                    }
                    
                    // Delete preset AFTER the loop
                    if (smbPresetToDelete >= 0 && smbPresetToDelete < (int)appState.ftpPresets.size()) {
                        auto& preset = appState.ftpPresets[smbPresetToDelete];
                        std::cout << "[SMB] Deleting preset: " << preset.name << std::endl;
                        
                        // Unmount if mounted
                        if (preset.smbMounted) {
                            unmountSMB(preset);
                        }
                        
                        appState.ftpPresets.erase(appState.ftpPresets.begin() + smbPresetToDelete);
                        saveFtpPresets();
                        smbPresetToDelete = -1;
                    }
                    
                    ImGui::EndChild();
                    ImGui::Text("[TIP] Doppelklick zum Mount/Unmount");
                    ImGui::Spacing();
                }
            }
            
            // Neues SMB Share hinzufügen
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Neues SMB/CIFS Share hinzufügen:");
            
            // Variables already declared at the beginning of this tab
            
            ImGui::Columns(2, "SmbDetails", false);
            ImGui::SetColumnWidth(0, 140);
            
            ImGui::Text("Preset-Name:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbName", smbName, sizeof(smbName));
            ImGui::NextColumn();
            
            ImGui::Text("SMB Server:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbServer", smbServer, sizeof(smbServer));
            ImGui::NextColumn();
            
            ImGui::Text("Share-Name:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbShareName", smbShareName, sizeof(smbShareName));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Der Share-Name auf dem Server, z.B. 'shared' für //server/shared");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Mount Point:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbMountPoint", smbMountPoint, sizeof(smbMountPoint));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Lokaler Pfad wo der Share gemountet wird, z.B. /mnt/smb_share");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Benutzername:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbUsername", smbUsername, sizeof(smbUsername));
            ImGui::NextColumn();
            
            ImGui::Text("Passwort:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbPassword", smbPassword, sizeof(smbPassword), ImGuiInputTextFlags_Password);
            ImGui::NextColumn();
            
            ImGui::Text("Domain:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbDomain", smbDomain, sizeof(smbDomain));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Windows Domain (optional, z.B. MYDOMAIN)");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Workgroup:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbWorkgroup", smbWorkgroup, sizeof(smbWorkgroup));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Windows Workgroup (optional, Standard: WORKGROUP)");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Mount Options:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##SmbOptions", smbOptions, sizeof(smbOptions));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("CIFS Mount-Optionen, z.B. vers=3.0,uid=1000,gid=1000\nLeer lassen für Standard");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Auto-Mount:");
            ImGui::NextColumn();
            ImGui::Checkbox("##SmbAutoMount", &smbAutoMount);
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Automatisch beim Programmstart mounten");
            }
            ImGui::NextColumn();
            
            ImGui::Columns(1);
            ImGui::Spacing();
            
            // Buttons
            if (ImGui::Button("[CLIP] Als SMB Preset speichern", ImVec2(220, 0))) {
                if (strlen(smbServer) > 0 && strlen(smbShareName) > 0 && strlen(smbMountPoint) > 0) {
                    FtpPreset newPreset;
                    newPreset.name = smbName;
                    newPreset.ip = smbServer;
                    newPreset.serviceType = "SMB";
                    newPreset.port = 445;
                    newPreset.username = smbUsername;
                    newPreset.password = smbPassword;
                    
                    // Build share path: //server/share
                    newPreset.smbSharePath = "//" + std::string(smbServer) + "/" + std::string(smbShareName);
                    newPreset.smbMountPoint = smbMountPoint;
                    newPreset.smbDomain = smbDomain;
                    newPreset.smbWorkgroup = smbWorkgroup;
                    newPreset.smbOptions = smbOptions;
                    newPreset.smbAutoMount = smbAutoMount;
                    newPreset.smbMounted = false;
                    
                    appState.ftpPresets.push_back(newPreset);
                    saveFtpPresets();
                    
                    std::cout << "[SMB] Saved preset: " << smbName << " (" 
                             << newPreset.smbSharePath << " -> " 
                             << smbMountPoint << ")" << std::endl;
                }
            }
            
            ImGui::SameLine();
            
            if (ImGui::Button("[PLUG] Jetzt mounten", ImVec2(150, 0))) {
                if (strlen(smbServer) > 0 && strlen(smbShareName) > 0 && strlen(smbMountPoint) > 0) {
                    FtpPreset tempPreset;
                    tempPreset.name = smbName;
                    tempPreset.ip = smbServer;
                    tempPreset.serviceType = "SMB";
                    tempPreset.username = smbUsername;
                    tempPreset.password = smbPassword;
                    tempPreset.smbSharePath = "//" + std::string(smbServer) + "/" + std::string(smbShareName);
                    tempPreset.smbMountPoint = smbMountPoint;
                    tempPreset.smbDomain = smbDomain;
                    tempPreset.smbWorkgroup = smbWorkgroup;
                    tempPreset.smbOptions = smbOptions;
                    
                    if (mountSMB(tempPreset)) {
                        // Just mount, DON'T auto-add to scan list
                        // Für diese Stelle brauchen wir ein neues Temp-Dialog
                        // Zeige einfach eine Bestätigung
                        ImGui::OpenPopup("SmbMountSuccess");
                    } else {
                        ImGui::OpenPopup("SmbMountFailed");
                    }
                }
            }
            
            // Success/Failure popups
            if (ImGui::BeginPopupModal("SmbMountSuccess", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "✅ SMB Share erfolgreich gemountet!");
                ImGui::Text("Mount Point: %s", smbMountPoint);
                ImGui::Spacing();
                if (ImGui::Button("OK", ImVec2(120, 0))) {
                    ImGui::CloseCurrentPopup();
                }
                ImGui::EndPopup();
            }
            
            if (ImGui::BeginPopupModal("SmbMountFailed", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "❌ SMB Mount fehlgeschlagen!");
                ImGui::Text("Prüfe:");
                ImGui::BulletText("SMB Server erreichbar?");
                ImGui::BulletText("Share-Name korrekt?");
                ImGui::BulletText("Benutzername/Passwort richtig?");
                ImGui::BulletText("CIFS-Utils installiert? (cifs-utils)");
                ImGui::BulletText("Root-Rechte? (sudo erforderlich)");
                ImGui::BulletText("Firewall-Regeln? (Port 445/139)");
                ImGui::Spacing();
                if (ImGui::Button("OK", ImVec2(120, 0))) {
                    ImGui::CloseCurrentPopup();
                }
                ImGui::EndPopup();
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "ℹ️ SMB/CIFS-Hinweise:");
            ImGui::BulletText("CIFS-Utils muss installiert sein: sudo dnf install cifs-utils");
            ImGui::BulletText("Root-Rechte erforderlich: FileDuper mit sudo starten");
            ImGui::BulletText("Nach dem Mount erscheint das Share wie ein lokales Verzeichnis");
            ImGui::BulletText("Nutze den normalen Verzeichnis-Scan für SMB-Shares");
            ImGui::BulletText("SMB 3.0 empfohlen für beste Sicherheit und Performance");
            ImGui::BulletText("Windows 10/11 Shares: SMB 3.0 oder höher verwenden");
            
            ImGui::EndTabItem(); // End SMB Tab
        }
        
        // ====================================================================
        // WEBDAV BROWSER TAB
        // ====================================================================
        if (ImGui::BeginTabItem("[WebDAV] WebDAV-Mount")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "WebDAV/Cloud Storage & Mount-Verwaltung");
            ImGui::Separator();
            
            // Static variables for form (must be declared before use)
            static char davName[128] = "Mein WebDAV";
            static char davUrl[512] = "https://cloud.example.com/remote.php/dav/files/user/";
            static char davMountPoint[256] = "/mnt/webdav";
            static char davUsername[128] = "user";
            static char davPassword[128] = "";
            static char davOptions[256] = "";
            static bool davUseSSL = true;
            static bool davAutoMount = false;
            
            // Gespeicherte WebDAV Presets anzeigen
            std::vector<FtpPreset*> davPresets;
            for (auto& preset : appState.ftpPresets) {
                if (preset.serviceType == "WebDAV") {
                    davPresets.push_back(&preset);
                }
            }
            
            if (!davPresets.empty()) {
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[CLOUD] Gespeicherte WebDAV Shares:");
                ImGui::BeginChild("SavedDavPresets", ImVec2(0, 150), true);
                    
                    static int davPresetToDelete = -1;
                    
                    for (size_t i = 0; i < davPresets.size(); i++) {
                        auto* preset = davPresets[i];
                        
                        // Status icon
                        const char* statusIcon = preset->davMounted ? "[OK]" : "[X]";
                        // WebDAV = GRÜN
                        ImVec4 statusColor = preset->davMounted ? 
                            ImVec4(0.3f, 1.0f, 0.3f, 1.0f) : ImVec4(0.2f, 0.5f, 0.2f, 1.0f);
                        
                        // Show SSL/TLS icon
                        const char* sslIcon = preset->davUseSSL ? "[LOCK]" : "[UNLOCK]";
                        
                        std::string displayText = std::string(statusIcon) + " " + sslIcon + " " + 
                                                 preset->name + " - " + preset->davUrl;
                        
                        ImGui::PushStyleColor(ImGuiCol_Text, statusColor);
                        bool isSelected = preset->davMounted;
                        if (ImGui::Selectable(displayText.c_str(), isSelected, ImGuiSelectableFlags_AllowDoubleClick)) {
                            // Single click: Load into form
                            std::cout << "[WebDAV] Loaded preset: " << preset->name << std::endl;
                            strcpy(davName, preset->name.c_str());
                            strcpy(davUrl, preset->davUrl.c_str());
                            strcpy(davMountPoint, preset->davMountPoint.c_str());
                            strcpy(davUsername, preset->username.c_str());
                            strcpy(davPassword, preset->password.c_str());
                            strcpy(davOptions, preset->davOptions.c_str());
                            davUseSSL = preset->davUseSSL;
                            davAutoMount = preset->davAutoMount;
                        }
                        ImGui::PopStyleColor();
                        
                        // Mount/Unmount Button
                        ImGui::SameLine();
                        if (preset->davMounted) {
                            std::string unmount_btn = "🔌 Unmount##dav_unmount_" + std::to_string(i);
                            if (ImGui::SmallButton(unmount_btn.c_str())) {
                                std::cout << "[WebDAV] Unmounting: " << preset->name << std::endl;
                                unmountWebDAV(*preset);
                                appState.selectedLocalDirs.erase(preset->davMountPoint);
                                saveFtpPresets();
                            }
                        } else {
                            std::string mount_btn = "⚡ Mount##dav_mount_" + std::to_string(i);
                            if (ImGui::SmallButton(mount_btn.c_str())) {
                                std::cout << "[WebDAV] Mounting: " << preset->name << std::endl;
                                if (mountWebDAV(*preset)) {
                                    // Just mount, DON'T auto-add to scan list
                                    appState.showLocalBrowser = true;
                                    saveFtpPresets();
                                }
                            }
                        }
                        
                        // Double click: Mount/Unmount
                        if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) {
                            if (preset->davMounted) {
                                std::cout << "[WebDAV] Unmounting: " << preset->name << std::endl;
                                unmountWebDAV(*preset);
                                saveFtpPresets();
                            } else {
                                std::cout << "[WebDAV] Mounting: " << preset->name << std::endl;
                                if (mountWebDAV(*preset)) {
                                    // Just mount, DON'T auto-add to scan list
                                    appState.showLocalBrowser = true;
                                    saveFtpPresets();
                                }
                            }
                        }
                        
                        // Context menu
                        if (ImGui::BeginPopupContextItem(("dav_preset_ctx_" + std::to_string(i)).c_str())) {
                            if (ImGui::MenuItem("📂 Verzeichnisbaum öffnen")) {
                                if (preset->davMounted) {
                                    appState.showLocalBrowser = true;
                                } else {
                                    if (mountWebDAV(*preset)) {
                                        appState.showLocalBrowser = true;
                                        saveFtpPresets();
                                    }
                                }
                            }
                            ImGui::Separator();
                            if (!preset->davMounted) {
                                if (ImGui::MenuItem("⚡ Mount")) {
                                    if (mountWebDAV(*preset)) {
                                        // Just mount, DON'T auto-add to scan list
                                        saveFtpPresets();
                                    }
                                }
                            } else {
                                if (ImGui::MenuItem("🔌 Unmount")) {
                                    unmountWebDAV(*preset);
                                    appState.selectedLocalDirs.erase(preset->davMountPoint);
                                    saveFtpPresets();
                                }
                            }
                            if (ImGui::MenuItem("🗑️ Preset löschen")) {
                                // Find actual index in ftpPresets
                                for (size_t j = 0; j < appState.ftpPresets.size(); j++) {
                                    if (&appState.ftpPresets[j] == preset) {
                                        davPresetToDelete = j;
                                        break;
                                    }
                                }
                            }
                            ImGui::EndPopup();
                        }
                    }
                    
                    // Delete preset AFTER the loop
                    if (davPresetToDelete >= 0 && davPresetToDelete < (int)appState.ftpPresets.size()) {
                        auto& preset = appState.ftpPresets[davPresetToDelete];
                        std::cout << "[WebDAV] Deleting preset: " << preset.name << std::endl;
                        
                        // Unmount if mounted
                        if (preset.davMounted) {
                            unmountWebDAV(preset);
                        }
                        
                        appState.ftpPresets.erase(appState.ftpPresets.begin() + davPresetToDelete);
                        saveFtpPresets();
                        davPresetToDelete = -1;
                    }
                    
                    ImGui::EndChild();
                    ImGui::Text("[TIP] Doppelklick zum Mount/Unmount");
                    ImGui::Spacing();
                }
            
            // Neues WebDAV Share hinzufügen
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Neues WebDAV Share hinzufügen:");
            
            // Variables already declared at the beginning of this tab
            
            ImGui::Columns(2, "DavDetails", false);
            ImGui::SetColumnWidth(0, 140);
            
            ImGui::Text("Preset-Name:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##DavName", davName, sizeof(davName));
            ImGui::NextColumn();
            
            ImGui::Text("WebDAV URL:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##DavUrl", davUrl, sizeof(davUrl));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Vollständige WebDAV URL:\nNextcloud: https://server/remote.php/dav/files/user/\nownCloud: https://server/remote.php/webdav/");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Mount Point:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##DavMountPoint", davMountPoint, sizeof(davMountPoint));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Lokaler Pfad wo der Share gemountet wird, z.B. /mnt/webdav");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Benutzername:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##DavUsername", davUsername, sizeof(davUsername));
            ImGui::NextColumn();
            
            ImGui::Text("Passwort:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##DavPassword", davPassword, sizeof(davPassword), ImGuiInputTextFlags_Password);
            ImGui::NextColumn();
            
            ImGui::Text("HTTPS/SSL:");
            ImGui::NextColumn();
            ImGui::Checkbox("##DavUseSSL", &davUseSSL);
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("HTTPS (empfohlen) vs HTTP");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Mount Options:");
            ImGui::NextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##DavOptions", davOptions, sizeof(davOptions));
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("davfs2 Mount-Optionen, z.B. uid=1000,gid=1000,file_mode=0600\nLeer lassen für Standard");
            }
            ImGui::NextColumn();
            
            ImGui::Text("Auto-Mount:");
            ImGui::NextColumn();
            ImGui::Checkbox("##DavAutoMount", &davAutoMount);
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Automatisch beim Programmstart mounten");
            }
            ImGui::NextColumn();
            
            ImGui::Columns(1);
            ImGui::Spacing();
            
            // Buttons
            if (ImGui::Button("[CLIP] Als WebDAV Preset speichern", ImVec2(240, 0))) {
                if (strlen(davUrl) > 0 && strlen(davMountPoint) > 0) {
                    FtpPreset newPreset;
                    newPreset.name = davName;
                    newPreset.serviceType = "WebDAV";
                    newPreset.port = davUseSSL ? 443 : 80;
                    newPreset.username = davUsername;
                    newPreset.password = davPassword;
                    
                    newPreset.davUrl = davUrl;
                    newPreset.davMountPoint = davMountPoint;
                    newPreset.davOptions = davOptions;
                    newPreset.davUseSSL = davUseSSL;
                    newPreset.davAutoMount = davAutoMount;
                    newPreset.davMounted = false;
                    
                    // Extract server IP/hostname from URL for display
                    std::string urlStr = davUrl;
                    size_t startPos = urlStr.find("://");
                    if (startPos != std::string::npos) {
                        startPos += 3;
                        size_t endPos = urlStr.find("/", startPos);
                        newPreset.ip = urlStr.substr(startPos, endPos - startPos);
                    }
                    
                    appState.ftpPresets.push_back(newPreset);
                    saveFtpPresets();
                    
                    std::cout << "[WebDAV] Saved preset: " << davName << " (" 
                             << davUrl << " -> " << davMountPoint << ")" << std::endl;
                }
            }
            
            ImGui::SameLine();
            
            if (ImGui::Button("[PLUG] Jetzt mounten", ImVec2(150, 0))) {
                if (strlen(davUrl) > 0 && strlen(davMountPoint) > 0) {
                    FtpPreset tempPreset;
                    tempPreset.name = davName;
                    tempPreset.serviceType = "WebDAV";
                    tempPreset.username = davUsername;
                    tempPreset.password = davPassword;
                    tempPreset.davUrl = davUrl;
                    tempPreset.davMountPoint = davMountPoint;
                    tempPreset.davOptions = davOptions;
                    tempPreset.davUseSSL = davUseSSL;
                    
                    if (mountWebDAV(tempPreset)) {
                        // Just mount, DON'T auto-add to scan list
                        // Open local browser to show mounted directory
                        appState.showLocalBrowser = true;
                        ImGui::OpenPopup("DavMountSuccess");
                    } else {
                        ImGui::OpenPopup("DavMountFailed");
                    }
                }
            }
            
            // Success/Failure popups
            if (ImGui::BeginPopupModal("DavMountSuccess", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "✅ WebDAV Share erfolgreich gemountet!");
                ImGui::Text("Mount Point: %s", davMountPoint);
                ImGui::Spacing();
                if (ImGui::Button("OK", ImVec2(120, 0))) {
                    ImGui::CloseCurrentPopup();
                }
                ImGui::EndPopup();
            }
            
            if (ImGui::BeginPopupModal("DavMountFailed", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "❌ WebDAV Mount fehlgeschlagen!");
                ImGui::Text("Prüfe:");
                ImGui::BulletText("WebDAV URL korrekt? (inkl. /remote.php/dav/...)");
                ImGui::BulletText("Server erreichbar? (HTTPS/HTTP)");
                ImGui::BulletText("Benutzername/Passwort richtig?");
                ImGui::BulletText("davfs2 installiert? (davfs2 package)");
                ImGui::BulletText("Root-Rechte? (sudo erforderlich)");
                ImGui::BulletText("~/.davfs2/secrets Permissions (0600)?");
                ImGui::Spacing();
                if (ImGui::Button("OK", ImVec2(120, 0))) {
                    ImGui::CloseCurrentPopup();
                }
                ImGui::EndPopup();
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "ℹ️ WebDAV-Hinweise:");
            ImGui::BulletText("davfs2 muss installiert sein: sudo dnf install davfs2");
            ImGui::BulletText("Root-Rechte erforderlich: FileDuper mit sudo starten");
            ImGui::BulletText("Nach dem Mount erscheint das Share wie ein lokales Verzeichnis");
            ImGui::BulletText("Nutze den normalen Verzeichnis-Scan für WebDAV-Shares");
            ImGui::BulletText("Nextcloud: /remote.php/dav/files/username/");
            ImGui::BulletText("ownCloud: /remote.php/webdav/");
            ImGui::BulletText("HTTPS stark empfohlen für Cloud-Storage!");
            
            ImGui::EndTabItem(); // End WebDAV Tab
        }
        
        // Network Discovery Tab (NOW FIFTH!)
        if (ImGui::BeginTabItem("[SCAN] Netzwerk-Scan")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Netzwerk durchsuchen");
            ImGui::Separator();
            
            static char subnet[64] = "";
            ImGui::InputText("Subnetz", subnet, sizeof(subnet));
            ImGui::SameLine();
            
            if (!appState.scanningNetwork) {
                if (ImGui::Button(appState.useLightningSpeed ? 
                                 "[[*]] Lightning Scan" : "[SCAN] Scan starten", 
                                 ImVec2(150, 0))) {
                    appState.scanningNetwork = true;
                    
                    if (appState.useLightningSpeed) {
                        // Lightning Speed: Asynchroner Multi-Thread-Scan
                        startLightningScan(std::string(subnet));
                    } else {
                        // Legacy: Auch asynchron, nicht blockierend
                        std::thread([subnet]() {
                            appState.discoveredHosts.clear();
                            std::cout << "[Network] Scanning " << subnet << std::endl;
                            
                            std::string cmd = "timeout 10 nmap -sn " + std::string(subnet) + 
                                             " 2>/dev/null | grep 'Nmap scan report' | awk '{print $5}' > /tmp/fileduper_scan.txt";
                            
                            system(cmd.c_str());
                            
                            std::ifstream scanFile("/tmp/fileduper_scan.txt");
                            if (scanFile.is_open()) {
                                std::string line;
                                while (std::getline(scanFile, line)) {
                                    if (!line.empty() && line != "()" && line.find('.') != std::string::npos) {
                                        appState.discoveredHosts.push_back(line);
                                    }
                                }
                                scanFile.close();
                            }
                            
                            if (appState.discoveredHosts.empty()) {
                                system("arp -a | grep -oE '([0-9]{1,3}\\.){3}[0-9]{1,3}' > /tmp/fileduper_arp.txt");
                                std::ifstream arpFile("/tmp/fileduper_arp.txt");
                                if (arpFile.is_open()) {
                                    std::string line;
                                    while (std::getline(arpFile, line)) {
                                        if (!line.empty()) {
                                            appState.discoveredHosts.push_back(line);
                                        }
                                    }
                                    arpFile.close();
                                }
                            }
                            
                            appState.scanningNetwork = false;
                            std::cout << "[Network] Found " << appState.discoveredHosts.size() << " hosts" << std::endl;
                        }).detach();
                    }
                }
            } else {
                // Progress anzeigen bei Lightning Speed
                if (appState.useLightningSpeed && appState.totalHostsToScan > 0) {
                    float progress = float(appState.scannedHosts) / float(appState.totalHostsToScan);
                    ImGui::ProgressBar(progress, ImVec2(150, 0));
                    
                    if (ImGui::IsItemHovered()) {
                        ImGui::SetTooltip("Scanned: %d/%d hosts", 
                                         appState.scannedHosts.load(), 
                                         appState.totalHostsToScan.load());
                    }
                } else {
                    ImGui::Button("[WAIT] Scanne...", ImVec2(150, 0));
                }
                
                // Stop-Button
                ImGui::SameLine();
                if (ImGui::Button("[STOP]", ImVec2(70, 0))) {
                    appState.scanThreadRunning = false;
                    appState.scanningNetwork = false;
                    std::cout << "[Lightning] Scan stopped by user" << std::endl;
                }
            }
            
            ImGui::Spacing();
            
            // Scanner-Info
            if (appState.useLightningSpeed) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), 
                                  "[*] Lightning Mode: %d Threads @ %ds Timeout", 
                                  appState.scannerThreads, appState.scanTimeout);
            }
            
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                              "Gefundene Hosts: %zu", appState.discoveredHosts.size());
            
            ImGui::BeginChild("DiscoveredHosts", ImVec2(0, -40), true);
            for (size_t i = 0; i < appState.discoveredHosts.size(); i++) {
                const auto& host = appState.discoveredHosts[i];
                
                // Selectable mit Doppelklick
                bool selected = appState.selectedFtpHost == host;
                if (ImGui::Selectable(("[PC] " + host).c_str(), 
                                     selected,
                                     ImGuiSelectableFlags_AllowDoubleClick)) {
                    // Einfachklick: nur auswählen
                    appState.selectedFtpHost = (host.find(' ') != std::string::npos) 
                                              ? host.substr(0, host.find(' ')) 
                                              : host;
                }
                
                // Doppelklick: auswählen UND zur FTP-Verbindung wechseln
                if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) {
                    size_t spacePos = host.find(' ');
                    appState.selectedFtpHost = (spacePos != std::string::npos) 
                                              ? host.substr(0, spacePos) 
                                              : host;
                    
                    // Setze Flag für Tab-Wechsel zur FTP-Verbindung
                    appState.switchToFtpTab = 1;
                    std::cout << "[Network] Double-clicked: " << appState.selectedFtpHost 
                             << " - switching to FTP tab" << std::endl;
                }
                
                // Rechtsklick-Menü
                if (ImGui::BeginPopupContextItem(("ctx_" + std::to_string(i)).c_str())) {
                    if (ImGui::MenuItem("[PLUG] Mit FTP verbinden")) {
                        size_t spacePos = host.find(' ');
                        appState.selectedFtpHost = (spacePos != std::string::npos) 
                                                  ? host.substr(0, spacePos) 
                                                  : host;
                        appState.switchToFtpTab = 1; // Wechsle zum FTP Tab
                        std::cout << "[Network] Connect to: " << appState.selectedFtpHost << std::endl;
                    }
                    if (ImGui::MenuItem("[CLIP] Als Preset speichern")) {
                        std::string ip = (host.find(' ') != std::string::npos) 
                                        ? host.substr(0, host.find(' ')) 
                                        : host;
                        addFtpPreset(ip);
                    }
                    if (ImGui::MenuItem("[CLIP] IP kopieren")) {
                        std::cout << "[Network] Copy: " << host << std::endl;
                    }
                    if (ImGui::MenuItem("[SYNC] Ping")) {
                        std::cout << "[Network] Ping: " << host << std::endl;
                    }
                    ImGui::EndPopup();
                }
            }
            ImGui::EndChild();
            
            ImGui::Text("[TIP] Tipp: Doppelklick auf einen Host zum Verbinden");
            
            ImGui::EndTabItem(); // End Network Scan Tab
        }
        
        ImGui::EndTabBar(); // End TabBar
        }  // End BeginTabBar if-block
        
        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::Button("Fertig", ImVec2(120, 0))) {
            appState.showNetworkScanner = false;
        }
    }  // End Begin if-block
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar();
    ImGui::PopStyleVar();
}

// Render Main Window
void renderMainWindow() {
    ImVec2 displaySize = ImGui::GetIO().DisplaySize;
    
    // HAUPTFENSTER STATISCH - immer volle Größe, nicht beweglich, nicht resizable
    ImGui::SetNextWindowSize(displaySize);
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    
    // Hauptfenster: statisch, nicht beweglich, nicht resizable, bleibt im Hintergrund
    ImGuiWindowFlags flags = ImGuiWindowFlags_MenuBar | 
                            ImGuiWindowFlags_NoBringToFrontOnFocus |
                            ImGuiWindowFlags_NoMove |
                            ImGuiWindowFlags_NoResize |
                            ImGuiWindowFlags_NoCollapse;
    
    if (ImGui::Begin("FileDuper - Hauptfenster", nullptr, flags)) {
        
        // Menu Bar
        if (ImGui::BeginMenuBar()) {
            if (ImGui::BeginMenu("Datei")) {
                if (ImGui::MenuItem("Beenden")) {
                    glfwSetWindowShouldClose(glfwGetCurrentContext(), GLFW_TRUE);
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Bearbeiten")) {
                if (ImGui::MenuItem("[CFG] Einstellungen", "Ctrl+,")) {
                    appState.showSettings = true;
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Netzwerk")) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[*] Scanner");
                ImGui::Separator();
                
                if (ImGui::MenuItem("[SCAN] Netzwerk & FTP öffnen")) {
                    appState.showNetworkScanner = true;
                }
                
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Einstellungen");
                
                if (ImGui::Checkbox("[*] Lightning Speed", &appState.useLightningSpeed)) {
                    saveScannerSettings(); // Speichere sofort
                }
                
                ImGui::SliderInt("Threads", &appState.scannerThreads, 16, 512);
                if (ImGui::IsItemDeactivatedAfterEdit()) { // Nur beim Loslassen speichern
                    saveScannerSettings();
                }
                if (ImGui::IsItemHovered()) {
                    ImGui::SetTooltip("Mehr Threads = schneller (16-512)");
                }
                
                ImGui::SliderInt("Timeout (s)", &appState.scanTimeout, 1, 3);
                if (ImGui::IsItemDeactivatedAfterEdit()) { // Nur beim Loslassen speichern
                    saveScannerSettings();
                }
                if (ImGui::IsItemHovered()) {
                    ImGui::SetTooltip("Timeout pro Host in Sekunden");
                }
                
                ImGui::Spacing();
                ImGui::Text("Aktuell: %d Threads @ %ds", 
                           appState.scannerThreads, appState.scanTimeout);
                
                ImGui::Separator();
                if (ImGui::MenuItem("Standard wiederherstellen")) {
                    appState.scannerThreads = 128; // Lightning Speed default
                    appState.scanTimeout = 1;
                    appState.useLightningSpeed = true;
                    saveScannerSettings(); // Speichere neue Defaults
                }
                
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Ansicht")) {
                if (ImGui::BeginMenu("Theme (33 verfügbar)")) {
                    // Gruppe 1: Standard Themes
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Standard");
                    ImGui::Separator();
                    for (int i = 0; i < 4; i++) {
                        if (ImGui::MenuItem(appState.themes[i], nullptr, appState.currentTheme == i)) {
                            appState.currentTheme = i;
                            applyTheme(i);
                        }
                    }
                    
                    ImGui::Spacing();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Entwickler Themes");
                    ImGui::Separator();
                    for (int i = 4; i < 13; i++) {
                        if (ImGui::MenuItem(appState.themes[i], nullptr, appState.currentTheme == i)) {
                            appState.currentTheme = i;
                            applyTheme(i);
                        }
                    }
                    
                    ImGui::Spacing();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "IDE Themes");
                    ImGui::Separator();
                    for (int i = 13; i < 20; i++) {
                        if (ImGui::MenuItem(appState.themes[i], nullptr, appState.currentTheme == i)) {
                            appState.currentTheme = i;
                            applyTheme(i);
                        }
                    }
                    
                    ImGui::Spacing();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Retro/Synthwave");
                    ImGui::Separator();
                    for (int i = 20; i < 23; i++) {
                        if (ImGui::MenuItem(appState.themes[i], nullptr, appState.currentTheme == i)) {
                            appState.currentTheme = i;
                            applyTheme(i);
                        }
                    }
                    
                    ImGui::Spacing();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Natur Themes");
                    ImGui::Separator();
                    for (int i = 23; i < 30; i++) {
                        if (ImGui::MenuItem(appState.themes[i], nullptr, appState.currentTheme == i)) {
                            appState.currentTheme = i;
                            applyTheme(i);
                        }
                    }
                    
                    ImGui::Spacing();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Spezial");
                    ImGui::Separator();
                    for (int i = 30; i < 33; i++) {
                        if (ImGui::MenuItem(appState.themes[i], nullptr, appState.currentTheme == i)) {
                            appState.currentTheme = i;
                            applyTheme(i);
                        }
                    }
                    
                    ImGui::EndMenu();
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Hilfe")) {
                if (ImGui::MenuItem("Über")) {
                    appState.showAbout = true;
                }
                ImGui::EndMenu();
            }
            
            ImGui::EndMenuBar();
        }
        
        // Title
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 1.0f), "FileDuper - Duplicate File Scanner");
        ImGui::PopFont();
        ImGui::Separator();
        
        // Layout: 2 columns
        ImGui::Columns(2, "main_columns", true);
        
        // Left Column: Directory Selection
        ImGui::BeginChild("LeftPanel", ImVec2(0, -160), true);
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[DIR] Scan-Quellen");
        ImGui::Separator();
        
        if (ImGui::Button("[DIR] Lokale Verzeichnisse...", ImVec2(-1, 40))) {
            appState.showLocalBrowser = true;
        }
        
        if (ImGui::Button("[NET] Netzwerk & FTP...", ImVec2(-1, 40))) {
            appState.showNetworkScanner = true;
        }
        
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[SCAN] Ausgewählte Verzeichnisse");
        ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), 
                          "Lokal: %zu | Remote: %zu | Total: %zu", 
                          appState.selectedLocalDirs.size(),
                          appState.selectedFtpDirs.size(),
                          appState.selectedLocalDirs.size() + appState.selectedFtpDirs.size());
        ImGui::Text("[TIP] Rechtsklick zum Entfernen");
        
        ImGui::BeginChild("SelectedList", ImVec2(0, 150), true);
        
        // Local directories
        int idx = 0;
        std::string dirToRemove = "";
        bool removeAll = false;
        
        std::vector<std::string> localDirsToRemove;
        for (const auto& dir : appState.selectedLocalDirs) {
            std::string label = "[LOCAL] " + dir;
            
            // X Button zum direkten Entfernen
            ImGui::PushID(("x_local_" + std::to_string(idx)).c_str());
            if (ImGui::SmallButton("X")) {
                localDirsToRemove.push_back(dir);
            }
            ImGui::PopID();
            ImGui::SameLine();
            
            ImGui::Selectable(label.c_str());
            
            // Rechtsklick-Menü
            if (ImGui::BeginPopupContextItem(("local_ctx_" + std::to_string(idx)).c_str())) {
                if (ImGui::MenuItem("[X] Entfernen")) {
                    dirToRemove = dir;
                }
                if (ImGui::MenuItem("[XX] Alle entfernen")) {
                    removeAll = true;
                }
                ImGui::EndPopup();
            }
            idx++;
        }
        
        // FTP directories
        std::vector<std::string> ftpDirsToRemove;
        for (const auto& dir : appState.selectedFtpDirs) {
            std::string label = "[REMOTE] " + dir;
            
            // X Button zum direkten Entfernen
            ImGui::PushID(("x_ftp_" + std::to_string(idx)).c_str());
            if (ImGui::SmallButton("X")) {
                ftpDirsToRemove.push_back(dir);
            }
            ImGui::PopID();
            ImGui::SameLine();
            
            ImGui::TextColored(ImVec4(0.5f, 0.8f, 1.0f, 1.0f), "%s", label.c_str());
            
            // Rechtsklick-Menü
            if (ImGui::BeginPopupContextItem(("ftp_ctx_" + std::to_string(idx)).c_str())) {
                if (ImGui::MenuItem("[X] Entfernen")) {
                    dirToRemove = dir;
                }
                if (ImGui::MenuItem("[XX] Alle entfernen")) {
                    removeAll = true;
                }
                ImGui::EndPopup();
            }
            idx++;
        }
        
        ImGui::EndChild();
        
        // Handle removals (NOT during scan)
        if (!appState.scanning) {
            // Entferne über X-Button
            for (const auto& dir : localDirsToRemove) {
                appState.selectedLocalDirs.erase(dir);
            }
            for (const auto& dir : ftpDirsToRemove) {
                appState.selectedFtpDirs.erase(dir);
            }
            
            // Entferne über Rechtsklick
            if (removeAll) {
                appState.selectedLocalDirs.clear();
                appState.selectedFtpDirs.clear();
            } else if (!dirToRemove.empty()) {
                appState.selectedLocalDirs.erase(dirToRemove);
                appState.selectedFtpDirs.erase(dirToRemove);
            }
        }
        
        ImGui::Spacing();
        ImGui::Separator();
        
        // Scan buttons
        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "Status: %s | Lokale: %zu | FTP: %zu", 
                         appState.scanning ? "SCANNEND" : "BEREIT",
                         appState.selectedLocalDirs.size(),
                         appState.selectedFtpDirs.size());
        
        // Transfer Button (Upload zu NFS/FTP/SMB/WebDAV)
        if (!appState.scanning && !appState.selectedLocalDirs.empty()) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.4f, 0.8f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 0.6f, 1.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.0f, 0.8f, 1.0f, 1.0f));
            
            if (ImGui::Button("📤 Verzeichnisse übertragen", ImVec2(-1, 40))) {
                ImGui::OpenPopup("TransferDialog");
            }
            ImGui::PopStyleColor(3);
        }
        
        // Scan Button
        if (!appState.scanning) {
            // Grüner Start-Button
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.6f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 0.8f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.0f, 1.0f, 0.0f, 1.0f));
            
            if (ImGui::Button("[GO] SCAN STARTEN", ImVec2(-1, 60))) {
                if (!appState.selectedLocalDirs.empty() || !appState.selectedFtpDirs.empty()) {
                    appState.scanning = true;
                    appState.scanProgress = 0.0f;
                    appState.filesScanned = 0;
                    appState.bytesProcessed = 0;
                    appState.scanStatus = "Scanne Dateien...";
                    appState.scanStartTime = time(nullptr);
                    
                    if (scanThread.joinable()) scanThread.join();
                    scanThread = std::thread(performScan);
                }
            }
            ImGui::PopStyleColor(3);
        } else {
            // Roter STOP-Button
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.0f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.0f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.0f, 0.0f, 1.0f));
            
            if (ImGui::Button("[X] SCAN STOPPEN", ImVec2(-1, 60))) {
                stopScan = true;
                appState.scanStatus = "[STOP] Wird abgebrochen...";
            }
            ImGui::PopStyleColor(3);
            
            // Transfer Dialog
            if (ImGui::BeginPopupModal("TransferDialog", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "📤 Verzeichnisse übertragen");
                ImGui::Separator();
                ImGui::Spacing();
                
                ImGui::Text("Ausgewählte Verzeichnisse: %zu", appState.selectedLocalDirs.size());
                ImGui::Spacing();
                
                static int transferTarget = 0;  // 0=NFS, 1=FTP, 2=SMB, 3=WebDAV
                ImGui::Text("Ziel auswählen:");
                ImGui::RadioButton("NFS Mount", &transferTarget, 0);
                ImGui::RadioButton("FTP Server", &transferTarget, 1);
                ImGui::RadioButton("SMB/CIFS Share", &transferTarget, 2);
                ImGui::RadioButton("WebDAV Server", &transferTarget, 3);
                
                ImGui::Spacing();
                ImGui::Separator();
                
                static char targetPath[512] = "/mnt/nfs_share/backup";
                ImGui::Text("Ziel-Pfad:");
                ImGui::InputText("##TargetPath", targetPath, sizeof(targetPath));
                
                ImGui::Spacing();
                static bool preserveStructure = true;
                ImGui::Checkbox("Verzeichnisstruktur beibehalten", &preserveStructure);
                
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();
                
                if (ImGui::Button("🚀 Transfer starten", ImVec2(200, 0))) {
                    // Start transfer in background thread
                    std::string target = targetPath;
                    std::thread([target, preserveStructure, transferTarget]() {
                        std::cout << "[Transfer] Starting transfer to: " << target << std::endl;
                        
                        for (const auto& srcDir : appState.selectedLocalDirs) {
                            std::string destPath = target;
                            if (preserveStructure) {
                                // Keep directory structure
                                destPath = target + srcDir;
                            } else {
                                // Flatten: just copy directory name
                                size_t lastSlash = srcDir.find_last_of('/');
                                std::string dirName = (lastSlash != std::string::npos) ? srcDir.substr(lastSlash) : srcDir;
                                destPath = target + dirName;
                            }
                            
                            // Use rsync for efficient transfer
                            std::string cmd;
                            if (transferTarget == 0) {  // NFS
                                cmd = "rsync -av --progress \"" + srcDir + "/\" \"" + destPath + "/\"";
                            } else if (transferTarget == 1) {  // FTP
                                cmd = "lftp -e 'mirror -R \"" + srcDir + "\" \"" + destPath + "\"; quit' " + target;
                            } else if (transferTarget == 2) {  // SMB
                                cmd = "rsync -av --progress \"" + srcDir + "/\" \"" + destPath + "/\"";
                            } else {  // WebDAV
                                cmd = "rsync -av --progress \"" + srcDir + "/\" \"" + destPath + "/\"";
                            }
                            
                            std::cout << "[Transfer] Executing: " << cmd << std::endl;
                            int result = system(cmd.c_str());
                            
                            if (result == 0) {
                                std::cout << "[Transfer] ✅ Success: " << srcDir << " -> " << destPath << std::endl;
                            } else {
                                std::cout << "[Transfer] ❌ Failed: " << srcDir << std::endl;
                            }
                        }
                        
                        std::cout << "[Transfer] Transfer completed!" << std::endl;
                    }).detach();
                    
                    ImGui::CloseCurrentPopup();
                }
                
                ImGui::SameLine();
                if (ImGui::Button("Abbrechen", ImVec2(120, 0))) {
                    ImGui::CloseCurrentPopup();
                }
                
                ImGui::EndPopup();
            }
            
            // Pause/Resume Button
            if (appState.scanPaused) {
                if (ImGui::Button("[PLAY] FORTSETZEN", ImVec2(-1, 30))) {
                    appState.scanPaused = false;
                }
            } else {
                if (ImGui::Button("[PAUSE] PAUSE", ImVec2(-1, 30))) {
                    appState.scanPaused = true;
                }
            }
        }
        
        // ===== SYSTEM STATUS BALKEN (In linker Spalte) =====
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[SYS] System-Status");
        ImGui::Separator();
        
        // CPU Status - Nutze tatsächliche Hardware-Werte
        float cpuLoad = appState.cpuUsage / 100.0f; // cpuUsage ist 0-100
        
        ImGui::Text("CPU:");
        ImGui::SameLine(60);
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(0.0f, 0.8f, 0.0f, 1.0f));
        ImGui::ProgressBar(cpuLoad, ImVec2(-200, 12));
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
        ImGui::Text("%7.3f %% | %6.3f °C", appState.cpuUsage, (float)appState.cpuTemp);
        
        // GPU Status - Nutze tatsächliche Hardware-Werte
        float gpuLoad = appState.gpuUsage / 100.0f; // gpuUsage ist 0-100
        
        ImGui::Text("GPU:");
        ImGui::SameLine(60);
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(0.8f, 0.4f, 0.0f, 1.0f));
        ImGui::ProgressBar(gpuLoad, ImVec2(-200, 12));
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
        if (appState.gpuPower > 0.1f) {
            // Zeige Power nur wenn Wert > 0.1W (echte Messung verfügbar)
            ImGui::Text("%7.3f %% | %6.3f W", appState.gpuUsage, appState.gpuPower);
        } else {
            // Keine Power-Messung verfügbar
            ImGui::Text("%7.3f %% | N/A", appState.gpuUsage);
        }
        
        // NPU Status - Nur anzeigen wenn NPU vorhanden ist
        if (appState.hasNPU) {
            float npuLoad = appState.npuUsage / 100.0f; // npuUsage ist 0-100
            
            ImGui::Text("NPU:");
            ImGui::SameLine(60);
            ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(0.4f, 0.4f, 0.8f, 1.0f));
            ImGui::ProgressBar(npuLoad, ImVec2(-200, 12));
            ImGui::PopStyleColor();
            ImGui::SameLine();
            ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
            ImGui::Text("%7.3f %%", appState.npuUsage);
        }
        
        // Hash-Berechnung Status - Zeige tatsächliche Hash-Geschwindigkeit
        float hashLoad = 0.0f;
        if (appState.scanning && appState.hashSpeed > 0.0f) {
            // Normalisiere auf typische Max-Geschwindigkeit (z.B. 2000 MB/s)
            hashLoad = std::min(1.0f, appState.hashSpeed / 2000.0f);
        }
        
        ImGui::Text("Hash:");
        ImGui::SameLine(60);
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(1.0f, 0.8f, 0.0f, 1.0f));
        ImGui::ProgressBar(hashLoad, ImVec2(-200, 12));
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
        
        // Hash-Anzeige: Zeige Speed + Algorithmus
        if (appState.scanning) {
            // Während des Scans: Zeige aktuelle Geschwindigkeit
            if (appState.hashSpeed > 0.0f) {
                // Zeige aktuellen Hash-Algorithmus oder Fallback
                std::string algoName = appState.currentHashAlgo.empty() ? appState.hashAlgorithm : appState.currentHashAlgo;
                if (algoName == "AUTO") algoName = "XXHASH64";  // Fallback für AUTO
                ImGui::Text("%8.3f MB/s | %s", appState.hashSpeed, algoName.c_str());
            } else {
                // Scan läuft aber noch keine Hash-Speed gemessen
                std::string algoName = appState.currentHashAlgo.empty() ? appState.hashAlgorithm : appState.currentHashAlgo;
                if (algoName == "AUTO") algoName = "XXHASH64";
                ImGui::Text("Starte... | %s", algoName.c_str());
            }
        } else {
            ImGui::Text("Idle");
        }
        
        // Netzwerk Status - Zeige tatsächliche Netzwerk-Bandbreite
        float networkLoad = 0.0f;
        if (appState.networkBandwidth > 0.0f) {
            // Normalisiere auf typische Netzwerk-Geschwindigkeit (z.B. 100 MB/s für Gigabit)
            networkLoad = std::min(1.0f, appState.networkBandwidth / 100.0f);
        }
        
        ImGui::Text("Netz:");
        ImGui::SameLine(60);
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(0.0f, 0.8f, 0.8f, 1.0f));
        ImGui::ProgressBar(networkLoad, ImVec2(-200, 12));
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
        if (appState.networkBandwidth >= 1.0f) {
            ImGui::Text("%8.3f MB/s", appState.networkBandwidth);
        } else {
            ImGui::Text("%8.3f KB/s", appState.networkBandwidth * 1024.0f);
        }
        
        // Dateien Status
        float fileProgress = 0.0f;
        if (appState.scanning && appState.totalFiles > 0 && appState.filesScanned <= appState.totalFiles) {
            // Nutze filesScanned vs totalFiles für echten Fortschritt (nur beim Hashing)
            fileProgress = (float)appState.filesScanned / (float)appState.totalFiles;
        } else if (!appState.scanning && appState.totalFiles > 0) {
            // Scan abgeschlossen
            fileProgress = 1.0f;
        }
        
        ImGui::Text("Files:");
        ImGui::SameLine(60);
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(0.6f, 0.0f, 0.8f, 1.0f));
        ImGui::ProgressBar(fileProgress, ImVec2(-200, 12));
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
        if (appState.scanning) {
            // Während des Scans: Zeige verarbeitete Dateien
            if (appState.totalFiles > 0) {
                ImGui::Text("%d / %d files | %s", 
                           appState.filesScanned,
                           appState.totalFiles,
                           formatSize(appState.bytesProcessed).c_str());
            } else {
                ImGui::Text("%d files | %s", 
                           appState.filesScanned,
                           formatSize(appState.bytesProcessed).c_str());
            }
            
            // Zeige aktuell bearbeitete Datei (Hashing)
            if (!appState.currentHashingFile.empty()) {
                // Kürze langen Pfad für bessere Anzeige
                std::string displayPath = appState.currentHashingFile;
                if (displayPath.length() > 60) {
                    displayPath = "..." + displayPath.substr(displayPath.length() - 57);
                }
                ImGui::TextColored(ImVec4(0.5f, 1.0f, 0.5f, 1.0f), "  Hashing: %s", displayPath.c_str());
            }
        } else if (appState.totalFiles > 0) {
            // Nach dem Scan: Zeige Gesamtzahl
            ImGui::Text("%d / %d files (%6.2f %%)", 
                       appState.filesScanned,
                       appState.totalFiles,
                       fileProgress * 100.0f);
        } else {
            // Nur Anzahl zeigen
            ImGui::Text("%s", formatSize(appState.bytesProcessed).c_str());
        }
        
        // RAM Status - Nutze tatsächliche RAM-Auslastung
        float ramUsageKB = (float)appState.ramUsageKB;
        float ramMB = ramUsageKB / 1024.0f;
        float ramGB = ramMB / 1024.0f;
        // Normalisiere auf 16GB System (typisch)
        float ramLoad = ramGB / 16.0f;
        
        ImGui::Text("RAM:");
        ImGui::SameLine(60);
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(0.8f, 0.0f, 0.4f, 1.0f));
        ImGui::ProgressBar(std::min(ramLoad, 1.0f), ImVec2(-200, 12));
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
        if (ramGB >= 1.0f) {
            ImGui::Text("%7.3f GB", ramGB);
        } else {
            ImGui::Text("%7.3f MB", ramMB);
        }
        
        ImGui::EndChild();  // End LeftPanel
        
        ImGui::NextColumn();
        
        // Right Column: Results & Statistics
        ImGui::BeginChild("RightPanel", ImVec2(0, -160), true);
        
        ImGui::BeginTabBar("RightPanelTabs");
        
        // Results Tab
        if (ImGui::BeginTabItem("[STAT] Ergebnisse")) {
                if (appState.duplicateGroups > 0) {
                    ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "[OK] Scan abgeschlossen!");
                    ImGui::Spacing();
                    
                    ImGui::Text("Duplikat-Gruppen: %d", appState.duplicateGroups);
                    ImGui::Text("Duplikat-Dateien: %d", appState.duplicateFiles);
                    ImGui::Text("Platzverschwendung: %s", formatSize(appState.duplicateSize).c_str());
                
                    ImGui::Separator();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Duplikat-Gruppen:");
                    ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "🛡️ Älteste Datei = Original (geschützt)");
                    
                    ImGui::BeginChild("ResultsList", ImVec2(0, -40), true);
                    {
                        std::lock_guard<std::mutex> lock(resultsMutex);
                        for (size_t i = 0; i < appState.duplicates.size(); i++) {
                            auto& group = appState.duplicates[i];
                            
                            // Sort files by modification time (oldest first = original)
                            // Only sort once and cache the result
                            if (!group.sorted) {
                                // First time: Fetch mtimes and sort
                                if (group.mtimes.size() != group.files.size()) {
                                    group.mtimes.clear();
                                    group.mtimes.reserve(group.files.size());
                                    
                                    for (size_t idx = 0; idx < group.files.size(); idx++) {
                                        const auto& file = group.files[idx];
                                        time_t mtime = 0;
                                        
                                        // FTP files: Use index as pseudo-time (first found = original)
                                        if (isFtpFile(file)) {
                                            mtime = idx; // Simple counter
                                        } else {
                                            // Local files: Use actual modification time
                                            struct stat st;
                                            if (stat(file.c_str(), &st) == 0) {
                                                mtime = st.st_mtime;
                                            }
                                        }
                                        group.mtimes.push_back(mtime);
                                    }
                                }
                                
                                // Sort files and mtimes together
                                std::vector<size_t> indices(group.files.size());
                                std::iota(indices.begin(), indices.end(), 0);
                                std::sort(indices.begin(), indices.end(),
                                         [&group](size_t a, size_t b) { return group.mtimes[a] < group.mtimes[b]; });
                                
                                // Reorder files and mtimes based on sorted indices
                                std::vector<std::string> sortedFiles;
                                std::vector<time_t> sortedMtimes;
                                sortedFiles.reserve(group.files.size());
                                sortedMtimes.reserve(group.files.size());
                                
                                for (size_t idx : indices) {
                                    sortedFiles.push_back(std::move(group.files[idx]));
                                    sortedMtimes.push_back(group.mtimes[idx]);
                                }
                                
                                group.files = std::move(sortedFiles);
                                group.mtimes = std::move(sortedMtimes);
                                group.sorted = true; // Mark as sorted - never sort again!
                            }
                            
                            // KOMPAKTE ANZEIGE - Files are now pre-sorted!
                            ImGui::Separator();
                            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                                             "▶ Gruppe %zu (%zu Dateien, %s)", 
                                             i + 1, group.files.size(), formatSize(group.size).c_str());
                            
                            // Show original file path (first file is always oldest after sorting)
                            if (!group.files.empty()) {
                                const auto& originalFile = group.files[0];
                                std::string originalDir = originalFile.substr(0, originalFile.find_last_of("/\\"));
                                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "  [DIR] Original aus: ");
                                ImGui::SameLine();
                                ImGui::TextColored(ImVec4(0.7f, 0.9f, 0.7f, 1.0f), "%s", originalDir.c_str());
                            }
                            
                            // Show all files compactly (files are already sorted)
                            for (size_t j = 0; j < group.files.size(); j++) {
                                const auto& file = group.files[j];
                                bool isOriginal = (j == 0); // First file = oldest = original
                                
                                ImGui::PushID((int)(i * 1000 + j));
                                
                                if (isOriginal) {
                                    // Original: Show with shield icon, no checkbox
                                    ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "  🛡️ [ORIGINAL]");
                                    ImGui::SameLine();
                                    
                                    // Use Selectable for better right-click detection
                                    std::string displayText = file;
                                    ImGui::Selectable(displayText.c_str(), false, ImGuiSelectableFlags_AllowOverlap);
                                    
                                    // Right-click menu for original file
                                    if (ImGui::BeginPopupContextItem(("menu_orig_" + std::to_string(i) + "_" + std::to_string(j)).c_str())) {
                                        if (ImGui::MenuItem("[DIR] Öffnen")) {
                                            std::string openCmd;
                                            if (isFtpFile(file)) {
                                                std::cout << "[OPEN] FTP file opening not yet implemented" << std::endl;
                                            } else {
                                                openCmd = "xdg-open \"" + file + "\" &";
                                                std::cout << "[OPEN] Opening: " << file << std::endl;
                                                system(openCmd.c_str());
                                            }
                                        }
                                        if (ImGui::MenuItem("[DIR] Im Dateimanager anzeigen")) {
                                            if (!isFtpFile(file)) {
                                                size_t lastSlash = file.find_last_of('/');
                                                if (lastSlash != std::string::npos) {
                                                    std::string dir = file.substr(0, lastSlash);
                                                    std::cout << "[OPEN] Opening directory: " << dir << std::endl;
                                                    pid_t pid = fork();
                                                    if (pid == 0) {
                                                        execl("/usr/bin/xdg-open", "xdg-open", dir.c_str(), nullptr);
                                                        _exit(1);
                                                    }
                                                }
                                            }
                                        }
                                        if (ImGui::MenuItem("[COPY] Pfad kopieren")) {
                                            std::string copyCmd = "echo -n \"" + file + "\" | xclip -selection clipboard 2>/dev/null";
                                            system(copyCmd.c_str());
                                            std::cout << "[CLIPBOARD] Copied: " << file << std::endl;
                                        }
                                        ImGui::EndPopup();
                                    }
                                } else {
                                    // Duplicate: Show with checkbox
                                    ImGui::Text("  ");
                                    ImGui::SameLine();
                                    bool marked = appState.markedForDeletion[file];
                                    if (ImGui::Checkbox("##mark", &marked)) {
                                        appState.markedForDeletion[file] = marked;
                                    }
                                    ImGui::SameLine();
                                    
                                    // Use Selectable for better mouse interaction (right-click and double-click)
                                    std::string displayText = file;
                                    bool selected = false;
                                    if (ImGui::Selectable(displayText.c_str(), &selected, ImGuiSelectableFlags_AllowOverlap)) {
                                        // Single click does nothing
                                    }
                                    
                                    // Double-click to open file
                                    if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) {
                                        if (isFtpFile(file)) {
                                            // FTP file - download and open temp
                                            std::cout << "[OPEN] FTP file not yet supported for opening" << std::endl;
                                        } else {
                                            // OPTIMIZED: Use fork/exec instead of system()
                                            std::cout << "[OPEN] Opening: " << file << std::endl;
                                            pid_t pid = fork();
                                            if (pid == 0) {
                                                execl("/usr/bin/xdg-open", "xdg-open", file.c_str(), nullptr);
                                                _exit(1);
                                            }
                                        }
                                    }
                                    
                                    // Right-click menu - must be after Selectable
                                    if (ImGui::BeginPopupContextItem(("menu_" + std::to_string(i) + "_" + std::to_string(j)).c_str())) {
                                        if (ImGui::MenuItem("[DIR] Öffnen")) {
                                            std::string openCmd;
                                            if (isFtpFile(file)) {
                                                std::cout << "[OPEN] FTP file opening not yet implemented" << std::endl;
                                            } else {
                                                openCmd = "xdg-open \"" + file + "\" &";
                                                std::cout << "[OPEN] Opening: " << file << std::endl;
                                                system(openCmd.c_str());
                                            }
                                        }
                                        if (ImGui::BeginMenu("[TOOL] Öffnen mit...")) {
                                            if (!isFtpFile(file)) {
                                                // Get file extension
                                                std::string ext = "";
                                                size_t dotPos = file.find_last_of('.');
                                                if (dotPos != std::string::npos) {
                                                    ext = file.substr(dotPos);
                                                    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                                                }
                                                
                                                // Show appropriate applications based on file type
                                                if (ext == ".mp3" || ext == ".wav" || ext == ".flac" || ext == ".ogg" || ext == ".m4a") {
                                                        if (ImGui::MenuItem("[MUSIC] Audacious")) {
                                                            system(("audacious \"" + file + "\" &").c_str());
                                                        }
                                                        if (ImGui::MenuItem("[MUSIC] VLC")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/vlc", "vlc", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[MUSIC] Rhythmbox")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/rhythmbox", "rhythmbox", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                    } else if (ext == ".mp4" || ext == ".avi" || ext == ".mkv" || ext == ".mov" || ext == ".wmv") {
                                                        if (ImGui::MenuItem("[VIDEO] VLC")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/vlc", "vlc", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[VIDEO] MPV")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/mpv", "mpv", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[VIDEO] Celluloid")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/celluloid", "celluloid", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                    } else if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".gif" || ext == ".bmp" || ext == ".webp") {
                                                        if (ImGui::MenuItem("[IMAGE] GIMP")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/gimp", "gimp", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[IMAGE] Eye of GNOME")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/eog", "eog", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[IMAGE] Gwenview")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/gwenview", "gwenview", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                    } else if (ext == ".txt" || ext == ".log" || ext == ".md" || ext == ".json" || ext == ".xml" || ext == ".csv") {
                                                        if (ImGui::MenuItem("[TEXT] gedit")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/gedit", "gedit", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[TEXT] Kate")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/kate", "kate", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[TEXT] VS Code")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/code", "code", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                    } else if (ext == ".pdf") {
                                                        if (ImGui::MenuItem("[DOC] Evince")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/evince", "evince", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[DOC] Okular")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/okular", "okular", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                    } else {
                                                        // Generic applications for unknown file types
                                                        if (ImGui::MenuItem("[TEXT] Text Editor")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/gedit", "gedit", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                        if (ImGui::MenuItem("[FIND] Hex Editor")) {
                                                            pid_t pid = fork();
                                                            if (pid == 0) {
                                                                execl("/usr/bin/ghex", "ghex", file.c_str(), nullptr);
                                                                _exit(1);
                                                            }
                                                        }
                                                    }
                                                    
                                                    ImGui::Separator();
                                                    if (ImGui::MenuItem("[CFG] Andere Anwendung...")) {
                                                        // OPTIMIZED: Use fork/exec instead of system() for xdg-open
                                                        std::cout << "[OPEN] Opening file chooser for: " << file << std::endl;
                                                        pid_t pid = fork();
                                                        if (pid == 0) {
                                                            execl("/usr/bin/xdg-open", "xdg-open", file.c_str(), nullptr);
                                                            _exit(1);
                                                        }
                                                    }
                                                } else {
                                                    ImGui::TextDisabled("Nur für lokale Dateien");
                                                }
                                                ImGui::EndMenu();
                                            }
                                            if (ImGui::MenuItem("[DIR] Im Dateimanager anzeigen")) {
                                                std::string showCmd;
                                                if (isFtpFile(file)) {
                                                    std::cout << "[OPEN] FTP directory browsing not yet implemented" << std::endl;
                                                } else {
                                                    // Extract directory path
                                                    size_t lastSlash = file.find_last_of('/');
                                                    if (lastSlash != std::string::npos) {
                                                        std::string dir = file.substr(0, lastSlash);
                                                        showCmd = "xdg-open \"" + dir + "\" &";
                                                        std::cout << "[OPEN] Opening directory: " << dir << std::endl;
                                                        system(showCmd.c_str());
                                                    }
                                                }
                                            }
                                            if (ImGui::MenuItem("[COPY] Pfad kopieren")) {
                                                // Copy to clipboard (uses xclip)
                                                std::string copyCmd = "echo -n \"" + file + "\" | xclip -selection clipboard 2>/dev/null";
                                                system(copyCmd.c_str());
                                                std::cout << "[CLIPBOARD] Copied: " << file << std::endl;
                                            }
                                            ImGui::Separator();
                                            
                                            // Markieren-Optionen
                                            if (ImGui::BeginMenu("[+] Markieren")) {
                                                if (ImGui::MenuItem("Diese Gruppe markieren")) {
                                                    // Mark all files in this group for deletion
                                                    int marked = 0;
                                                    for (const auto& dupFile : group.files) {
                                                        if (appState.markedForDeletion.find(dupFile) == appState.markedForDeletion.end()) {
                                                            appState.markedForDeletion[dupFile] = true;
                                                            marked++;
                                                        }
                                                    }
                                                    std::cout << "[MARK] Marked " << marked << " files from this group" << std::endl;
                                                }
                                                
                                                if (ImGui::MenuItem("[+][+] ALLE Gruppen markieren")) {
                                                    // Mark ALL duplicates from ALL groups
                                                    int totalMarked = 0;
                                                    for (const auto& [hash, files] : appState.filesByHash) {
                                                        if (files.size() < 2) continue; // Skip non-duplicates
                                                        for (const auto& dupFile : files) {
                                                            if (appState.markedForDeletion.find(dupFile) == appState.markedForDeletion.end()) {
                                                                appState.markedForDeletion[dupFile] = true;
                                                                totalMarked++;
                                                            }
                                                        }
                                                    }
                                                    std::cout << "[MARK] Marked " << totalMarked << " files from ALL groups" << std::endl;
                                                }
                                                
                                                ImGui::EndMenu();
                                            }
                                            
                                            if (ImGui::MenuItem("[DEL] Duplikat entfernen")) {
                                                // Get file size before deletion
                                                long long fileSize = 0;
                                                if (isFtpFile(file)) {
                                                    fileSize = group.size; // Use known size from scan
                                                } else {
                                                    struct stat st;
                                                    if (stat(file.c_str(), &st) == 0) {
                                                        fileSize = st.st_size;
                                                    }
                                                }
                                                
                                                // Delete this file (local or FTP)
                                                if (deleteFile(file)) {
                                                    std::cout << "[DELETE] Removed: " << file << std::endl;
                                                    // Remove from group
                                                    auto it = std::find(group.files.begin(), group.files.end(), file);
                                                    if (it != group.files.end()) {
                                                        group.files.erase(it);
                                                    }
                                                    appState.markedForDeletion.erase(file);
                                                    
                                                    // Show success popup
                                                    appState.deletedFilesCount = 1;
                                                    appState.deletedFilesSize = fileSize;
                                                    appState.showDeleteSuccess = true;
                                                } else {
                                                    std::cerr << "[DELETE] Failed to remove: " << file << std::endl;
                                                }
                                            }
                                            
                                            // Löschen-Optionen mit Untermenü
                                            if (ImGui::BeginMenu("[DEL] Duplikate löschen")) {
                                                if (ImGui::MenuItem("Diese Gruppe löschen")) {
                                                    // Find best original file (the one that fits best in its directory)
                                                    size_t bestOriginalIdx = findBestOriginalFile(group.files);
                                                    
                                                    // Delete all duplicates except the best original
                                                    int removed = 0;
                                                    long long totalSize = 0;
                                                    long long singleFileSize = group.size; // Size of ONE file in the group
                                                    
                                                    std::vector<std::string> filesToKeep;
                                                    std::vector<time_t> mtimesToKeep;
                                                    
                                                    for (size_t k = 0; k < group.files.size(); k++) {
                                                        if (k == bestOriginalIdx) {
                                                            // Keep this file as original
                                                            filesToKeep.push_back(group.files[k]);
                                                            if (k < group.mtimes.size()) {
                                                                mtimesToKeep.push_back(group.mtimes[k]);
                                                            }
                                                            continue;
                                                        }
                                                        
                                                        const auto& dupFile = group.files[k];
                                                        
                                                        // Get file size - each duplicate has same size as original
                                                        if (isFtpFile(dupFile)) {
                                                            totalSize += singleFileSize; // Add size of THIS duplicate
                                                        } else {
                                                            struct stat st;
                                                            if (stat(dupFile.c_str(), &st) == 0) {
                                                                totalSize += st.st_size;
                                                            }
                                                        }
                                                        
                                                        if (deleteFile(dupFile)) {
                                                            std::cout << "[DELETE] Removed duplicate: " << dupFile << std::endl;
                                                            removed++;
                                                            appState.markedForDeletion.erase(dupFile);
                                                        } else {
                                                            std::cerr << "[DELETE] Failed to delete: " << dupFile << std::endl;
                                                            // Keep file if deletion failed
                                                            filesToKeep.push_back(group.files[k]);
                                                            if (k < group.mtimes.size()) {
                                                                mtimesToKeep.push_back(group.mtimes[k]);
                                                            }
                                                        }
                                                    }
                                                    
                                                    // Update group with remaining files
                                                    if (removed > 0) {
                                                        group.files = filesToKeep;
                                                        group.mtimes = mtimesToKeep;
                                                        group.sorted = false; // Re-sort needed if order changed
                                                        
                                                        std::cout << "[DELETE] Kept original: " << group.files[0] << std::endl;
                                                        std::cout << "[DELETE] Removed " << removed << " duplicates from this group" << std::endl;
                                                        
                                                        // Show success popup
                                                        appState.deletedFilesCount = removed;
                                                        appState.deletedFilesSize = totalSize;
                                                        appState.showDeleteSuccess = true;
                                                    }
                                                }
                                                
                                                ImGui::Separator();
                                                
                                                if (ImGui::MenuItem("[DEL][DEL][DEL] ALLE Gruppen löschen")) {
                                                    // Delete ALL duplicates from ALL groups
                                                    int totalRemoved = 0;
                                                    long long totalSizeDeleted = 0;
                                                    
                                                    for (auto& grp : appState.duplicates) {
                                                        if (grp.files.size() < 2) continue; // Skip non-duplicates
                                                        
                                                        size_t bestIdx = findBestOriginalFile(grp.files);
                                                        long long fileSize = grp.size;
                                                        
                                                        std::vector<std::string> keep;
                                                        std::vector<time_t> keepMtimes;
                                                        
                                                        for (size_t k = 0; k < grp.files.size(); k++) {
                                                            if (k == bestIdx) {
                                                                keep.push_back(grp.files[k]);
                                                                if (k < grp.mtimes.size()) {
                                                                    keepMtimes.push_back(grp.mtimes[k]);
                                                                }
                                                                continue;
                                                            }
                                                            
                                                            if (deleteFile(grp.files[k])) {
                                                                totalRemoved++;
                                                                totalSizeDeleted += fileSize;
                                                                appState.markedForDeletion.erase(grp.files[k]);
                                                                std::cout << "[DELETE] Removed: " << grp.files[k] << std::endl;
                                                            } else {
                                                                keep.push_back(grp.files[k]);
                                                                if (k < grp.mtimes.size()) {
                                                                    keepMtimes.push_back(grp.mtimes[k]);
                                                                }
                                                            }
                                                        }
                                                        
                                                        grp.files = keep;
                                                        grp.mtimes = keepMtimes;
                                                        grp.sorted = false;
                                                    }
                                                    
                                                    std::cout << "[DELETE] Removed " << totalRemoved << " duplicates from ALL groups" << std::endl;
                                                    
                                                    if (totalRemoved > 0) {
                                                        appState.deletedFilesCount = totalRemoved;
                                                        appState.deletedFilesSize = totalSizeDeleted;
                                                        appState.showDeleteSuccess = true;
                                                    }
                                                }
                                                
                                                ImGui::EndMenu();
                                            }
                                            ImGui::EndPopup();
                                        }
                                    }
                                    
                                    ImGui::PopID();
                                }
                                
                                ImGui::Spacing();
                        }
                    }
                    ImGui::EndChild();
                    
                    // Count marked files
                    int markedCount = 0;
                    for (const auto& pair : appState.markedForDeletion) {
                        if (pair.second) markedCount++;
                    }
                    
                    // Buttons row
                    if (markedCount > 0) {
                        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.2f, 0.2f, 1.0f));
                        if (ImGui::Button(("[DEL] Markierte löschen (" + std::to_string(markedCount) + ")").c_str(), ImVec2(-1, 0))) {
                            // Delete all marked files
                            int removed = 0;
                            long long totalSize = 0;
                            std::vector<std::string> toRemove;
                            for (const auto& pair : appState.markedForDeletion) {
                                if (pair.second) {
                                    // Get file size before deletion
                                    if (isFtpFile(pair.first)) {
                                        // For FTP files, find size from duplicate groups
                                        for (const auto& group : appState.duplicates) {
                                            if (std::find(group.files.begin(), group.files.end(), pair.first) != group.files.end()) {
                                                totalSize += group.size;
                                                break;
                                            }
                                        }
                                    } else {
                                        struct stat st;
                                        if (stat(pair.first.c_str(), &st) == 0) {
                                            totalSize += st.st_size;
                                        }
                                    }
                                    
                                    if (deleteFile(pair.first)) {
                                        std::cout << "[DELETE] Removed: " << pair.first << std::endl;
                                        removed++;
                                        toRemove.push_back(pair.first);
                                        
                                        // Remove from duplicate groups
                                        for (auto& group : appState.duplicates) {
                                            auto it = std::find(group.files.begin(), group.files.end(), pair.first);
                                            if (it != group.files.end()) {
                                                group.files.erase(it);
                                            }
                                        }
                                    }
                                }
                            }
                            // Clear marked list
                            for (const auto& file : toRemove) {
                                appState.markedForDeletion.erase(file);
                            }
                            
                            // POST-DELETE CLEANUP: Lösche leere Verzeichnisse nach Duplikat-Löschung
                            if (removed > 0 && appState.deleteEmptyDirs) {
                                std::cout << "[Post-Delete Cleanup] Cleaning up empty directories..." << std::endl;
                                int totalEmptyDirs = 0;
                                
                                for (const auto& dir : appState.selectedLocalDirs) {
                                    int emptyDirs = 0;
                                    deleteEmptyDirectories(dir, emptyDirs);
                                    totalEmptyDirs += emptyDirs;
                                }
                                
                                if (totalEmptyDirs > 0) {
                                    std::cout << "[Post-Delete Cleanup] Deleted " << totalEmptyDirs << " empty directories" << std::endl;
                                }
                            }
                            
                            // Show success popup
                            if (removed > 0) {
                                appState.deletedFilesCount = removed;
                                appState.deletedFilesSize = totalSize;
                                appState.showDeleteSuccess = true;
                            }
                            
                            std::cout << "[DELETE] Removed " << removed << " marked files" << std::endl;
                        }
                        ImGui::PopStyleColor();
                    } else {
                        if (ImGui::Button("Ergebnisse exportieren", ImVec2(-1, 0))) {
                            std::cout << "[FileDuper] Exportiere Ergebnisse" << std::endl;
                        }
                    }
                } else {
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                                      "Keine Duplikate gefunden.");
                    ImGui::Spacing();
                    ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), 
                                      "Starten Sie einen Scan um Duplikate zu finden.");
                }
                ImGui::EndTabItem();
            }
            
            // Statistics Tab
            if (ImGui::BeginTabItem("[CHART] Statistiken")) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Live-Statistiken");
                ImGui::Separator();
                
                // Performance Section - KOMPAKT
                ImGui::BeginChild("StatsPerf", ImVec2(0, 100), true);
                {
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[PERF] Performance");
                    ImGui::Separator();
                    
                    ImGui::Columns(2, nullptr, false);
                    ImGui::Text("Hash-Speed:");
                    ImGui::NextColumn();
                    if (appState.hashSpeed >= 1.0f) {
                        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "%.2f MB/s", appState.hashSpeed);
                    } else if (appState.hashSpeed > 0.0f) {
                        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "%.1f KB/s", appState.hashSpeed * 1024.0f);
                    } else {
                        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "0.0 KB/s");
                    }
                    ImGui::NextColumn();
                    
                    ImGui::Text("Hash-Algo:");
                    ImGui::NextColumn();
                    // Zeige den tatsächlich verwendeten Hash-Algorithmus
                    if (appState.scanning && !appState.currentHashAlgo.empty()) {
                        std::string algoName = appState.currentHashAlgo;
                        if (algoName == "AUTO") algoName = "XXHASH64";  // Fallback
                        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "%s", algoName.c_str());
                    } else if (!appState.hashAlgorithm.empty()) {
                        std::string algoName = appState.hashAlgorithm;
                        if (algoName == "AUTO") algoName = "XXHASH64";
                        ImGui::TextColored(ImVec4(0.8f, 0.8f, 0.8f, 1.0f), "%s", algoName.c_str());
                    } else {
                        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "N/A");
                    }
                    ImGui::NextColumn();
                    
                    ImGui::Text("I/O Durchsatz:");
                    ImGui::NextColumn();
                    if (appState.scanSpeed >= 1.0f) {
                        ImGui::TextColored(ImVec4(0.5f, 0.5f, 1.0f, 1.0f), "%.2f MB/s", appState.scanSpeed);
                    } else if (appState.scanSpeed > 0.0f) {
                        ImGui::TextColored(ImVec4(0.5f, 0.5f, 1.0f, 1.0f), "%.1f KB/s", appState.scanSpeed * 1024.0f);
                    } else {
                        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "0.0 KB/s");
                    }
                    ImGui::NextColumn();
                    
                    ImGui::Text("Dateien/Sek:");
                    ImGui::NextColumn();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "%.1f", appState.filesPerSecond);
                    ImGui::NextColumn();
                    
                    ImGui::Text("Threads:");
                    ImGui::NextColumn();
                    ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "%d/%d aktiv", 
                                      appState.threadsActive, appState.threadCount);
                    ImGui::Columns(1);
                }
                ImGui::EndChild();
                
                // Progress Section - KOMPAKT
                ImGui::BeginChild("StatsProgress", ImVec2(0, 100), true);
                {
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[DIR] Fortschritt");
                    ImGui::Separator();
                    
                    ImGui::Text("Dateien:");
                    // Show real progress based on filesScanned / totalFiles
                    float fileProgress = 0.0f;
                    if (appState.scanning && appState.totalFiles > 0 && appState.filesScanned <= appState.totalFiles) {
                        fileProgress = (float)appState.filesScanned / (float)appState.totalFiles;
                        ImGui::ProgressBar(fileProgress, ImVec2(-1, 0), 
                                         (std::to_string((int)(fileProgress * 100.0f)) + "%").c_str());
                    } else if (!appState.scanning && appState.totalFiles > 0) {
                        ImGui::ProgressBar(1.0f, ImVec2(-1, 0), "100%");
                    } else {
                        // No total files yet - show counting
                        ImGui::ProgressBar(0.0f, ImVec2(-1, 0), "Zähle...");
                    }
                    ImGui::Text("  %d / %d gescannt", appState.filesScanned, appState.totalFiles);
                    
                    ImGui::Spacing();
                    ImGui::Text("Daten:");
                    float bytesProgress = 0.0f;
                    if (appState.totalBytes > 0) {
                        bytesProgress = (float)appState.bytesProcessed / (float)appState.totalBytes;
                    }
                    ImGui::ProgressBar(bytesProgress, ImVec2(-1, 0), 
                                      (std::to_string((int)(bytesProgress * 100.0f)) + "%").c_str());
                    ImGui::Text("  %s / %s", 
                               formatSize(appState.bytesProcessed).c_str(),
                               formatSize(appState.totalBytes).c_str());
                }
                ImGui::EndChild();
                
                // Time Section - KOMPAKT
                ImGui::BeginChild("StatsTime", ImVec2(0, 100), true);
                {
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[TIME] Zeit");
                    ImGui::Separator();
                    
                    if (appState.scanStartTime > 0) {
                        time_t elapsed = time(nullptr) - appState.scanStartTime;
                        ImGui::Text("Vergangen: %02ld:%02ld:%02ld", 
                                   elapsed / 3600, (elapsed % 3600) / 60, elapsed % 60);
                        
                        if (appState.scanning && appState.scanProgress > 0.01f) {
                            // Estimate remaining time
                            time_t estimated = (time_t)(elapsed / appState.scanProgress) - elapsed;
                            ImGui::Text("Verbleibend: ~%02ld:%02ld:%02ld", 
                                       estimated / 3600, (estimated % 3600) / 60, estimated % 60);
                        }
                    } else {
                        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "Kein aktiver Scan");
                    }
                    
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "[SCAN] Duplikate");
                    ImGui::Text("Gruppen: %d", appState.duplicateGroups);
                    ImGui::Text("Dateien: %d", appState.duplicateFiles);
                    ImGui::Text("Größe: %s", formatSize(appState.duplicateSize).c_str());
                }
                ImGui::EndChild();
                
                ImGui::EndTabItem();
            }
            
            ImGui::EndTabBar();
        ImGui::EndChild();
        
        ImGui::Columns(1);
        
        // Status Bar mit erweiterten Statistiken
        // Positioniere Statusleiste am unteren Fensterrand (120px hoch)
        float statusBarHeight = 120.0f;
        float windowHeight = ImGui::GetWindowHeight();
        ImGui::SetCursorPosY(windowHeight - statusBarHeight);
        
        ImGui::Separator();
        
        // Child Window für Statusleiste damit alle Interaktionen funktionieren
        if (ImGui::BeginChild("StatusBarRegion", ImVec2(0, statusBarHeight), false, ImGuiWindowFlags_NoScrollbar)) {
            // Höhere Statusleiste durch größere Schrift
            ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]); // Standard Font aber mit mehr Padding
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8, 8)); // Mehr vertikaler Abstand
            
            ImGui::Columns(3, nullptr, false);
        
        // Linke Spalte - Status & Statistiken
        ImGui::Text("Status: %s", appState.scanStatus.c_str());
        
        // Erweiterte Statistiken (wenn Daten vorhanden)
        if (appState.scanning || appState.duplicateGroups > 0) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), 
                              "[EXPORT] Dateien: %d | Duplikate: %d Gruppen (%d Dateien) | %.1f GB Verschwendung",
                              appState.filesScanned, appState.duplicateGroups, appState.duplicateFiles,
                              appState.duplicateSize / (1024.0 * 1024.0 * 1024.0));
        }
        
        // Thread & Performance Info mit GPU Hash und Netzwerk - IMMER ANZEIGEN
        // Netzwerk-Geschwindigkeit formatieren
        std::string networkSpeedStr;
        if (appState.networkBandwidth >= 1.0f) {
            char buf[64];
            snprintf(buf, sizeof(buf), "%.3f MB/s", appState.networkBandwidth);
            networkSpeedStr = buf;
        } else {
            char buf[64];
            snprintf(buf, sizeof(buf), "%.3f KB/s", appState.networkBandwidth * 1024.0f);
            networkSpeedStr = buf;
        }
        
        // GPU Hash Speed
        std::string gpuHashStr = "";
        if (appState.gpuHashSpeed > 0.0f) {
            char buf[32];
            snprintf(buf, sizeof(buf), " | GPU: %.3f GB/s", appState.gpuHashSpeed);
            gpuHashStr = buf;
        }
        
        // System-Status immer anzeigen
        std::string speedStr;
        if (appState.scanning && appState.hashSpeed > 0.0f) {
            char speedBuf[64];
            snprintf(speedBuf, sizeof(speedBuf), "%.1f MB/s", appState.hashSpeed);
            speedStr = speedBuf;
        } else {
            speedStr = "Idle";
        }
        
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f),
                          "[SYS] Threads: %d | Speed: %s%s | Net: %s | Files: %d (%.1f/s)",
                          appState.threadsActive, speedStr.c_str(), gpuHashStr.c_str(), 
                          networkSpeedStr.c_str(), appState.filesScanned, appState.filesPerSecond);
        
        ImGui::NextColumn();
        
        // Mittlere Spalte - Hardware Status mit RAM - IMMER ANZEIGEN - nach rechts verschoben
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 20);  // 20px nach rechts
        if (appState.useHardwareAcceleration || appState.useGPU) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "[TOOL] HW-Accel: ON");
            ImGui::SameLine();
        }
        if (appState.useLightningSpeed) {
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "[*] Lightning");
            ImGui::SameLine();
        }
        
        // Hash-Algorithmus anzeigen - mit aktuellem Algorithmus
        if (appState.scanning && !appState.currentHashAlgo.empty()) {
            ImGui::Text("| Hash: %s", appState.currentHashAlgo.c_str());
        } else {
            ImGui::Text("| Hash: %s", appState.hashAlgorithm.c_str());
        }
        
        // RAM Usage - immer aktualisieren und anzeigen
        long long currentRAM = getCurrentRAMUsageKB();
        if (currentRAM > 0) {
            appState.ramUsageKB = currentRAM;
        }
        
        if (appState.ramUsageKB >= 1024 * 1024) {
            ImGui::Text("[RAM] %.2f GB", appState.ramUsageKB / (1024.0 * 1024.0));
        } else if (appState.ramUsageKB >= 1024) {
            ImGui::Text("[RAM] %.1f MB", appState.ramUsageKB / 1024.0);
        } else if (appState.ramUsageKB > 0) {
            ImGui::Text("[RAM] %lld KB", appState.ramUsageKB);
        } else {
            ImGui::Text("[RAM] N/A");
        }
        
        ImGui::NextColumn();
        
        // Rechte Spalte - Theme Selector
        ImGui::Text("Theme:");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        if (ImGui::BeginCombo("##ThemeCombo", appState.themes[appState.currentTheme])) {
            for (int i = 0; i < 33; i++) {
                bool isSelected = (appState.currentTheme == i);
                if (ImGui::Selectable(appState.themes[i], isSelected)) {
                    appState.currentTheme = i;
                    applyTheme(i);
                }
                if (isSelected) {
                    ImGui::SetItemDefaultFocus();
                }
            }
            ImGui::EndCombo();
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("[<]")) {
            appState.currentTheme = (appState.currentTheme - 1 + 33) % 33;
            applyTheme(appState.currentTheme);
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("[>]")) {
            appState.currentTheme = (appState.currentTheme + 1) % 33;
            applyTheme(appState.currentTheme);
        }
        
        ImGui::PopStyleVar(); // ItemSpacing
        ImGui::PopFont();
        
        ImGui::Columns(1);
        }
        ImGui::EndChild(); // StatusBarRegion
    }
    ImGui::End();
}

// Render Settings Dialog
void renderSettings() {
    if (!appState.showSettings) return;
    
    // FORCE window to be always on top and movable
    ImGui::SetNextWindowSize(ImVec2(600, 500), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f), 
                           ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    
    ImGui::SetNextWindowBgAlpha(0.95f);
    
    // Set window background to be opaque
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.1f, 0.1f, 0.1f, 0.95f));
    
    // Normal movable window
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoFocusOnAppearing;
    
    if (ImGui::Begin("⚙️ EINSTELLUNGEN (Titelleiste ziehen zum Bewegen)", &appState.showSettings, flags)) {
        ImGui::BeginTabBar("SettingsTabs");
        
        // Hash Algorithm Tab
        if (ImGui::BeginTabItem("[HASH] Hash-Algorithmen")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "🔒 Hash-Algorithmus-Auswahl");
            ImGui::Separator();
            
            // Hardware Detection
            ImGui::Text("Erkannte Hardware: %s", appState.detectedHardware.c_str());
            ImGui::Checkbox("Hardware-Beschleunigung nutzen", &appState.useHardwareAcceleration);
            ImGui::TextDisabled("SIMD (SSE/AVX), GPU (CUDA/OpenCL), NPU");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("Hash-Preset:");
            
            // Preset Selection
            static int presetIndex = 0;
            const char* presets[] = { "AUTO (Empfohlen)", "FAST (Geschwindigkeit)", "BALANCED (Balance)", "SECURE (Sicherheit)", "CUSTOM (Manuell)" };
            
            if (ImGui::Combo("##HashPreset", &presetIndex, presets, 5)) {
                switch (presetIndex) {
                    case 0: appState.hashPreset = "AUTO"; appState.hashAlgorithm = "AUTO"; break;
                    case 1: appState.hashPreset = "FAST"; appState.hashAlgorithm = "XXHASH64"; break;
                    case 2: appState.hashPreset = "BALANCED"; appState.hashAlgorithm = "BLAKE2B"; break;
                    case 3: appState.hashPreset = "SECURE"; appState.hashAlgorithm = "SHA256"; break;
                    case 4: appState.hashPreset = "CUSTOM"; break;
                }
            }
            
            ImGui::Spacing();
            ImGui::TextDisabled("💡 Preset-Erklärung:");
            if (presetIndex == 0) {
                ImGui::TextDisabled("  AUTO: Wählt automatisch basierend auf Dateityp");
                ImGui::TextDisabled("  • Videos/Bilder → xxHash64 (ultra-schnell)");
                ImGui::TextDisabled("  • Archive/Docs → BLAKE2B (ausgewogen)");
                ImGui::TextDisabled("  • Executables → SHA256 (sicher)");
            } else if (presetIndex == 1) {
                ImGui::TextDisabled("  FAST: xxHash64 für maximale Geschwindigkeit");
                ImGui::TextDisabled("  • Ideal für große Medienbibliotheken");
                ImGui::TextDisabled("  • 10-20x schneller als MD5");
            } else if (presetIndex == 2) {
                ImGui::TextDisabled("  BALANCED: BLAKE2B für gute Balance");
                ImGui::TextDisabled("  • Schneller als SHA-2, sicherer als MD5");
                ImGui::TextDisabled("  • Guter Kompromiss für alle Dateien");
            } else if (presetIndex == 3) {
                ImGui::TextDisabled("  SECURE: SHA256 für maximale Sicherheit");
                ImGui::TextDisabled("  • Kryptographisch sicher");
                ImGui::TextDisabled("  • Ideal für wichtige/sensitive Dateien");
            }
            
            // Manual Algorithm Selection (only if CUSTOM)
            if (presetIndex == 4) {
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Text("Manueller Algorithmus:");
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️ Nur implementierte Algorithmen:");
                
                static int algoIndex = 0;
                const char* algorithms[] = { 
                    "xxHash3 (Schnellster, 128bit - EMPFOHLEN)", 
                    "xxHash64 (Sehr schnell, 64bit)",
                    "MD5 (Standard, 128bit)"
                };
                
                if (ImGui::Combo("##Algorithm", &algoIndex, algorithms, 3)) {
                    const char* algoNames[] = { "XXHASH3", "XXHASH64", "MD5" };
                    appState.hashAlgorithm = algoNames[algoIndex];
                }
                
                ImGui::Spacing();
                ImGui::TextDisabled("ℹ️ Algorithmus-Info:");
                if (algoIndex == 0) {
                    ImGui::TextDisabled("  xxHash3: Neueste Generation, SIMD-optimiert");
                    ImGui::TextDisabled("  Performance: ★★★★★ (15+ GB/s mit AVX2)");
                    ImGui::TextDisabled("  Sicherheit: ★★☆☆☆ (perfekt für Duplikate)");
                    ImGui::TextDisabled("  Ideal für: Alle Medien, große Dateien");
                    ImGui::TextDisabled("  Hardware: Nutzt CPU SIMD/AVX2/AVX512");
                    ImGui::TextDisabled("  Status: ✅ VOLL IMPLEMENTIERT");
                } else if (algoIndex == 1) {
                    ImGui::TextDisabled("  xxHash64: Bewährt, ultra-schnell");
                    ImGui::TextDisabled("  Performance: ★★★★★ (10+ GB/s)");
                    ImGui::TextDisabled("  Sicherheit: ★★☆☆☆ (für Duplikate OK)");
                    ImGui::TextDisabled("  Ideal für: Videos, Bilder, große Dateien");
                    ImGui::TextDisabled("  Hardware: Standard CPU");
                    ImGui::TextDisabled("  Status: ✅ VOLL IMPLEMENTIERT");
                } else if (algoIndex == 2) {
                    ImGui::TextDisabled("  MD5: Legacy, weit verbreitet");
                    ImGui::TextDisabled("  Performance: ★★★☆☆ (500 MB/s)");
                    ImGui::TextDisabled("  Sicherheit: ★★☆☆☆ (für Duplikate OK)");
                    ImGui::TextDisabled("  Ideal für: Kompatibilität, kleine Dateien");
                    ImGui::TextDisabled("  Hardware: Standard CPU");
                    ImGui::TextDisabled("  Status: ✅ VOLL IMPLEMENTIERT");
                }
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️ Performance-Hinweise:");
            ImGui::TextDisabled("• AUTO-Modus wird für die meisten Anwendungsfälle empfohlen");
            ImGui::TextDisabled("• FAST-Modus ist 10-20x schneller als MD5");
            ImGui::TextDisabled("• Hardware-Beschleunigung kann weitere 2-4x Speedup bringen");
            ImGui::TextDisabled("• Für große Medienbibliotheken: xxHash64");
            ImGui::TextDisabled("• Für wichtige Dokumente: SHA256 oder BLAKE2B");
            
            ImGui::EndTabItem();
        }
        
        // Performance Tab
        if (ImGui::BeginTabItem("[PERF] Performance")) {
            // ============================================
            // AUTO-TUNE MASTER BUTTON
            // ============================================
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.8f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 1.0f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.0f, 0.6f, 0.0f, 1.0f));
            
            if (ImGui::Button("🚀 AUTO-TUNE: ALLE SETTINGS FÜR MAXIMALE PERFORMANCE", ImVec2(-1, 50))) {
                std::cout << "[AUTO-TUNE] Starting automatic performance optimization..." << std::endl;
                
                // 1. Detect hardware
                unsigned int cpuCores = std::thread::hardware_concurrency();
                bool hasAVX2 = hasAVX2Support();
                
                // 2. Set optimal thread counts
                appState.threadCount = std::max(8, (int)(cpuCores * 1.5)); // 1.5x CPU cores for I/O overlap
                appState.ftpMaxThreads = std::min(16, (int)cpuCores);
                
                // 3. Enable all performance features
                appState.useLightningSpeed = true;
                appState.useAsyncIO = true;
                appState.useMemoryMapping = true;
                appState.useCurlPooling = true;
                appState.useTCPPing = true;
                appState.autoTuneThreads = true;
                appState.cacheFileHashes = true;
                appState.smartTimeout = true;
                appState.ftpPipelining = true;
                appState.ftpKeepAlive = true;
                appState.ftpUseLsR = true;
                appState.ftpUseParallelScan = true;
                appState.skipEmptyFiles = true;
                
                // 4. Set optimal hash algorithm
                if (hasAVX2) {
                    appState.useFastHash = true;
                    appState.avx2Profile = "Maximum";
                    appState.avx2ForceEnabled = false; // Don't force if detected
                    std::cout << "[AUTO-TUNE] ✅ AVX2 detected - using XXHASH64 + AVX2" << std::endl;
                } else {
                    appState.useFastHash = true; // Still fast without AVX2
                    appState.avx2Profile = "Compatible";
                    std::cout << "[AUTO-TUNE] ⚠️ No AVX2 - using XXHASH64 without SIMD" << std::endl;
                }
                
                // 5. Set optimal buffer size (larger = faster for sequential I/O)
                appState.bufferSize = 32768; // 32MB buffer for maximum throughput
                
                // 6. FTP optimizations
                appState.ftpConnectTimeout = 5;  // Quick timeout
                appState.ftpReadTimeout = 10;    // Reasonable read timeout
                appState.ftpMaxRetries = 2;      // Don't waste time on dead connections
                appState.batchScanSize = 50;     // Large batches
                
                // 7. Scan depth settings
                appState.ftpScanMaxDepth = 999;  // No limits
                
                // 8. PARALLEL PROCESSING OPTIMIZATION (NEW!)
                appState.parallelDirectoryScan = true;
                appState.dirScanThreads = std::min(8, (int)cpuCores);
                appState.parallelFtpDirScan = true;
                appState.ftpDirScanThreads = std::min(4, (int)cpuCores / 2);
                appState.parallelCleanup = true;
                appState.cleanupThreads = std::min(4, (int)cpuCores / 2);
                appState.parallelCacheLoad = true;
                appState.cacheLoadThreads = std::min(4, (int)cpuCores / 2);
                
                // 9. Hardware acceleration
                appState.useHardwareAcceleration = true;
                // Don't enable GPU unless we know it's beneficial
                // appState.useGPU = false; // Keep user's choice
                
                // Save all settings
                saveScannerSettings();
                
                std::cout << "[AUTO-TUNE] ============================================" << std::endl;
                std::cout << "[AUTO-TUNE] 🎯 Performance Optimization Complete!" << std::endl;
                std::cout << "[AUTO-TUNE] CPU Cores: " << cpuCores << std::endl;
                std::cout << "[AUTO-TUNE] Hash Threads: " << appState.threadCount << std::endl;
                std::cout << "[AUTO-TUNE] FTP Threads: " << appState.ftpMaxThreads << std::endl;
                std::cout << "[AUTO-TUNE] Dir Scan Threads: " << appState.dirScanThreads << std::endl;
                std::cout << "[AUTO-TUNE] FTP Dir Scan Threads: " << appState.ftpDirScanThreads << std::endl;
                std::cout << "[AUTO-TUNE] Cleanup Threads: " << appState.cleanupThreads << std::endl;
                std::cout << "[AUTO-TUNE] Cache Load Threads: " << appState.cacheLoadThreads << std::endl;
                std::cout << "[AUTO-TUNE] Buffer Size: " << appState.bufferSize << " KB" << std::endl;
                std::cout << "[AUTO-TUNE] AVX2 Support: " << (hasAVX2 ? "YES ✅" : "NO ❌") << std::endl;
                std::cout << "[AUTO-TUNE] Hash Algorithm: XXHASH64 (Fast)" << std::endl;
                std::cout << "[AUTO-TUNE] Lightning Mode: ENABLED 🚀" << std::endl;
                std::cout << "[AUTO-TUNE] Parallel Processing: ALL ENABLED ✅" << std::endl;
                std::cout << "[AUTO-TUNE] ============================================" << std::endl;
            }
            
            ImGui::PopStyleColor(3);
            
            ImGui::Spacing();
            ImGui::TextDisabled("⚡ Optimiert automatisch ALLE Settings für maximale Performance auf dieser Hardware");
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
            
            // ============================================
            
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[>>] Paralleles Hashing");
            ImGui::Separator();
            ImGui::TextDisabled("Konfiguriere die Thread-Anzahl für parallele Hash-Berechnung");
            ImGui::Spacing();
            
            // Hash-Threads mit erweiterten Bereich (1-128 für I/O-bound Workloads)
            if (ImGui::SliderInt("🔢 Hash-Threads", &appState.threadCount, 1, 128)) {
                saveScannerSettings();
                std::cout << "[Config] Hash threads set to: " << appState.threadCount << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("Auto##hash")) {
                // For small files: 2-4x CPU cores (I/O-bound), for large files: 1x cores
                int cpuCores = std::thread::hardware_concurrency();
                appState.threadCount = std::min(128, cpuCores * 2);
                saveScannerSettings();
                std::cout << "[Config] Hash threads auto-set to: " << appState.threadCount << " (CPU cores: " << cpuCores << ")" << std::endl;
            }
            
            ImGui::Spacing();
            ImGui::TextColored(ImVec4(0.5f, 1.0f, 0.5f, 1.0f), "💡 Empfohlen:");
            ImGui::TextDisabled("  • Kleine Dateien (<1MB): 48-128 Threads");
            ImGui::TextDisabled("  • HDD/SATA SSD: 4-8 Threads");
            ImGui::TextDisabled("  • NVMe SSD: 16-48 Threads");
            ImGui::TextDisabled("  • NAS/Netzwerk: 8-12 Threads");
            ImGui::Spacing();
            
            // ============================================
            // PERFORMANCE TUNING SETTINGS (NEW)
            // ============================================
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 0.8f, 0.0f, 1.0f), "[⚡] Performance Tuning");
            ImGui::Separator();
            ImGui::TextDisabled("Optimiere Mutex-Locks und UI-Updates für maximale Geschwindigkeit");
            ImGui::Spacing();
            
            // Hash Batch Size
            if (ImGui::SliderInt("🔄 Hash Batch-Größe", &appState.hashBatchSize, 100, 50000)) {
                saveScannerSettings();
                std::cout << "[Config] Hash batch size set to: " << appState.hashBatchSize << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("Auto##batch")) {
                appState.hashBatchSize = 10000; // OPTIMIZED: 10x larger = 90% less mutex locks
                saveScannerSettings();
                std::cout << "[Config] Hash batch size auto-set to: " << appState.hashBatchSize << std::endl;
            }
            ImGui::TextDisabled("  • OPTIMIZED: 10000 (10x larger batches = 90%% less mutex locks)");
            ImGui::TextDisabled("  • Größere Batches = weniger Mutex-Locks = schneller");
            ImGui::TextDisabled("  • Kleine Dateien: 10000-50000");
            ImGui::TextDisabled("  • Große Dateien: 100-1000");
            ImGui::Spacing();
            
            // Status Update Interval
            if (ImGui::SliderInt("📊 Status-Update-Intervall", &appState.statusUpdateInterval, 10, 10000)) {
                saveScannerSettings();
                std::cout << "[Config] Status update interval set to: " << appState.statusUpdateInterval << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("Auto##status")) {
                appState.statusUpdateInterval = 1000; // Optimal für die meisten Systeme
                saveScannerSettings();
                std::cout << "[Config] Status update interval auto-set to: " << appState.statusUpdateInterval << std::endl;
            }
            ImGui::TextDisabled("  • UI wird nur alle X Dateien aktualisiert");
            ImGui::TextDisabled("  • Höher = schneller aber weniger Live-Updates");
            ImGui::TextDisabled("  • Empfohlen: 1000 für kleine Dateien");
            ImGui::Spacing();
            
            // ============================================
            // FTP HASH PERFORMANCE SETTINGS (NEW)
            // ============================================
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[🌐] FTP Hash Performance");
            ImGui::Separator();
            ImGui::TextDisabled("Optimiere FTP-Datei-Hashing für schnellere Duplikaterkennung");
            ImGui::Spacing();
            
            // FTP Hash Timeout
            if (ImGui::SliderInt("⏱️ FTP Hash Timeout (Sek)", &appState.ftpHashTimeout, 1, 60)) {
                saveScannerSettings();
                std::cout << "[Config] FTP hash timeout set to: " << appState.ftpHashTimeout << "s" << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("Auto##ftptimeout")) {
                appState.ftpHashTimeout = 5; // ADAPTIVE: Auto-scales for large files
                saveScannerSettings();
                std::cout << "[Config] FTP hash timeout auto-set to: " << appState.ftpHashTimeout << "s" << std::endl;
            }
            ImGui::TextDisabled("  • ADAPTIVE: Auto-scales for files >100MB (1s per 10MB)");
            ImGui::TextDisabled("  • Small files: Use this timeout (5s default)");
            ImGui::TextDisabled("  • Large files: Auto-calculated (e.g., 800MB = 80s)");
            ImGui::TextDisabled("  • Empfohlen: 5s für LAN, 15s für Internet");
            ImGui::Spacing();
            
            // FTP Hash Retries
            if (ImGui::SliderInt("🔁 FTP Hash Wiederholungen", &appState.ftpHashRetries, 1, 10)) {
                saveScannerSettings();
                std::cout << "[Config] FTP hash retries set to: " << appState.ftpHashRetries << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("Auto##ftpretry")) {
                appState.ftpHashRetries = 3; // Optimal: 3 Versuche
                saveScannerSettings();
                std::cout << "[Config] FTP hash retries auto-set to: " << appState.ftpHashRetries << std::endl;
            }
            ImGui::TextDisabled("  • Wiederholungsversuche bei fehlgeschlagenen Downloads");
            ImGui::TextDisabled("  • Mehr = sicherer aber langsamer bei defekten Dateien");
            ImGui::TextDisabled("  • Empfohlen: 3 Versuche (mit exponential backoff)");
            ImGui::Spacing();
            
            // FTP Skip Failed Files
            if (ImGui::Checkbox("⏭️ Fehlerhafte FTP-Dateien überspringen", &appState.ftpSkipFailedFiles)) {
                saveScannerSettings();
                std::cout << "[Config] FTP skip failed files: " << (appState.ftpSkipFailedFiles ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("  • Überspringe Dateien nach max. Wiederholungen");
            ImGui::TextDisabled("  • AN = schneller (ignoriert defekte Dateien)");
            ImGui::TextDisabled("  • AUS = sicherer (versucht ewig, kann hängen bleiben)");
            ImGui::Spacing();
            
            // FTP Max Connections (MEGA OPTIMIZATION!)
            if (ImGui::SliderInt("🔗 Max FTP-Verbindungen", &appState.ftpMaxConnections, 1, 32)) {
                saveScannerSettings();
                std::cout << "[Config] FTP max connections set to: " << appState.ftpMaxConnections << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("Auto##ftpconn")) {
                appState.ftpMaxConnections = 8; // Optimal: 8 parallele Connections
                saveScannerSettings();
                std::cout << "[Config] FTP max connections auto-set to: " << appState.ftpMaxConnections << std::endl;
            }
            ImGui::TextDisabled("  • Parallele FTP-Verbindungen zum gleichen Server");
            ImGui::TextDisabled("  • Mehr = VIEL schneller (8-16x Speedup!)");
            ImGui::TextDisabled("  • Empfohlen: 8 für LAN, 4 für Internet");
            ImGui::Spacing();
            
            // FTP Reuse Connections
            if (ImGui::Checkbox("♻️ FTP-Verbindungen wiederverwenden", &appState.ftpReuseConnections)) {
                saveScannerSettings();
                std::cout << "[Config] FTP reuse connections: " << (appState.ftpReuseConnections ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("  • Wiederverwendung von TCP/FTP-Verbindungen");
            ImGui::TextDisabled("  • AN = MASSIV schneller (keine TCP-Handshakes mehr!)");
            ImGui::TextDisabled("  • Empfohlen: IMMER AN (außer bei instabilen Servern)");
            ImGui::Spacing();
            
            // FTP Min File Size
            if (ImGui::SliderInt("📏 Min. FTP-Dateigröße (Bytes)", &appState.ftpMinFileSize, 0, 10000)) {
                saveScannerSettings();
                std::cout << "[Config] FTP min file size set to: " << appState.ftpMinFileSize << " bytes" << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("Auto##ftpminsize")) {
                appState.ftpMinFileSize = 100; // Optimal: 100 Bytes
                saveScannerSettings();
                std::cout << "[Config] FTP min file size auto-set to: " << appState.ftpMinFileSize << " bytes" << std::endl;
            }
            ImGui::TextDisabled("  • Überspringe sehr kleine FTP-Dateien (Overhead zu groß)");
            ImGui::TextDisabled("  • 0 = alle Dateien hashen (langsam bei vielen kleinen)");
            ImGui::TextDisabled("  • 100-1000 = nur Dateien >= X Bytes hashen (VIEL schneller!)");
            ImGui::TextDisabled("  • Empfohlen: 100 Bytes (überspringt 1-Byte-Dateien etc.)");
            ImGui::Spacing();
            
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "💡 Performance-Tipp:");
            ImGui::TextDisabled("  Mit 128 Threads + 8 FTP-Connections + Connection Reuse:");
            ImGui::TextDisabled("  + 5s Timeout + 3 Retries + Skip Failed + Min 100 Bytes:");
            ImGui::TextDisabled("  → Bis zu 500x schneller bei FTP-Dateien!");
            
            // ============================================
            // PARALLEL PROCESSING SETTINGS (NEW!)
            // ============================================
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "[🚀] PARALLEL PROCESSING + OPTIMIZATIONS");
            ImGui::Separator();
            ImGui::TextDisabled("Paralleles Scannen + I/O-Optimierungen für maximale Performance");
            ImGui::Spacing();
            
            // Parallel Directory Scan
            if (ImGui::Checkbox("✅ Paralleles Directory-Scanning", &appState.parallelDirectoryScan)) {
                saveScannerSettings();
                std::cout << "[Config] Parallel directory scan: " << (appState.parallelDirectoryScan ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("  • Scanne mehrere lokale Verzeichnisse parallel");
            ImGui::TextDisabled("  • OPTIMIZED: 10k batches + string reuse = 90%% less locks");
            if (appState.parallelDirectoryScan) {
                if (ImGui::SliderInt("📁 Dir-Scan Threads", &appState.dirScanThreads, 1, 16)) {
                    saveScannerSettings();
                }
                ImGui::TextDisabled("  • Empfohlen: 8 Threads (optimal für 24 Cores)");
            }
            ImGui::Spacing();
            
            // Parallel FTP Directory Scan
            if (ImGui::Checkbox("✅ Paralleles FTP-Directory-Scanning", &appState.parallelFtpDirScan)) {
                saveScannerSettings();
                std::cout << "[Config] Parallel FTP directory scan: " << (appState.parallelFtpDirScan ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("  • Scanne mehrere FTP-Verzeichnisse parallel");
            if (appState.parallelFtpDirScan) {
                if (ImGui::SliderInt("🌐 FTP-Dir-Scan Threads", &appState.ftpDirScanThreads, 1, 8)) {
                    saveScannerSettings();
                }
                ImGui::TextDisabled("  • Empfohlen: 2-4 Threads (reduziert Netzwerk-Latenz)");
            }
            ImGui::Spacing();
            
            // Parallel Cleanup
            if (ImGui::Checkbox("✅ Paralleles Post-Scan Cleanup", &appState.parallelCleanup)) {
                saveScannerSettings();
                std::cout << "[Config] Parallel cleanup: " << (appState.parallelCleanup ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("  • Bereinige 0-Byte-Dateien/leere Dirs parallel");
            if (appState.parallelCleanup) {
                if (ImGui::SliderInt("🧹 Cleanup Threads", &appState.cleanupThreads, 1, 8)) {
                    saveScannerSettings();
                }
                ImGui::TextDisabled("  • Empfohlen: 4 Threads (schnelles Cleanup)");
            }
            ImGui::Spacing();
            
            // Parallel Cache Load
            if (ImGui::Checkbox("✅ Paralleles Cache-Laden", &appState.parallelCacheLoad)) {
                saveScannerSettings();
                std::cout << "[Config] Parallel cache load: " << (appState.parallelCacheLoad ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("  • Lade Directory/FTP-Caches parallel (schnellerer Start)");
            if (appState.parallelCacheLoad) {
                if (ImGui::SliderInt("💾 Cache-Load Threads", &appState.cacheLoadThreads, 1, 8)) {
                    saveScannerSettings();
                }
                ImGui::TextDisabled("  • Empfohlen: 4 Threads (optimal für I/O)");
            }
            ImGui::Spacing();
            
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "⚡ Performance Improvements:");
            ImGui::TextDisabled("  • Parallel Dir Scan: bis zu 8x schneller");
            ImGui::TextDisabled("  • Hash I/O Buffers: 1 MB chunks (16x larger, +20-30%%)");
            ImGui::TextDisabled("  • Directory Batching: 10k files (10x larger, -90%% locks)");
            ImGui::TextDisabled("  • String Optimizations: Buffer reuse (-50%% allocations)");
            ImGui::TextDisabled("  • Adaptive FTP Timeout: Auto-scales for large files");
            ImGui::TextDisabled("  • Parallel FTP Scan: bis zu 4x schneller");
            ImGui::TextDisabled("  • Parallel Cleanup: bis zu 4x schneller");
            ImGui::TextDisabled("  • GESAMT: 2-10x Geschwindigkeitssteigerung!");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️ Sicherheit:");
            ImGui::TextDisabled("  • Nur Dateien mit identischer Größe werden gehasht");
            ImGui::TextDisabled("  • Größenverifikation vor Hash-Berechnung");
            ImGui::TextDisabled("  • Thread-sichere Hash-Map mit Mutex");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Hash-Algorithmus:");
            ImGui::Spacing();
            
            if (ImGui::Checkbox("GPU-Beschleunigung (OpenCL)", &appState.useGPU)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("  • Nutzt GPU für Hash-Berechnung (experimentell)");
            
            if (ImGui::Checkbox("Schneller Hash (xxHash64)", &appState.useFastHash)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("  • xxHash64 ist schneller, MD5 ist kryptographisch sicherer");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[*] AVX2-Beschleunigung");
            ImGui::Separator();
            ImGui::TextDisabled("SIMD-optimierte Hash-Berechnung (2-4x schneller)");
            ImGui::Spacing();
            
            // AVX2 Detection
            bool avx2Available = hasAVX2Support();
            if (avx2Available) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "✅ AVX2 verfügbar auf diesem System");
            } else {
                ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "⚠️ AVX2 nicht verfügbar (CPU zu alt)");
            }
            ImGui::Spacing();
            
            // Performance Profile
            ImGui::Text("🎯 Performance-Profil:");
            static int profileIndex = 0;
            const char* profiles[] = { "Maximum (AVX2 überall)", "Balanced (Intelligent)", "Compatible (MD5 Fokus)" };
            
            // Set current index based on profile
            if (appState.avx2Profile == "Maximum") profileIndex = 0;
            else if (appState.avx2Profile == "Balanced") profileIndex = 1;
            else if (appState.avx2Profile == "Compatible") profileIndex = 2;
            
            if (ImGui::Combo("##AVX2Profile", &profileIndex, profiles, 3)) {
                const char* profileNames[] = { "Maximum", "Balanced", "Compatible" };
                appState.avx2Profile = profileNames[profileIndex];
                saveScannerSettings();
                std::cout << "[AVX2] Profile set to: " << appState.avx2Profile << std::endl;
            }
            
            ImGui::Spacing();
            ImGui::TextDisabled("[EXPORT] Profil-Erklärung:");
            if (profileIndex == 0) {
                ImGui::TextDisabled("  Maximum: AVX2 für alle Dateien >4KB");
                ImGui::TextDisabled("  • Videos/Bilder/Audio: XXHASH3+AVX2");
                ImGui::TextDisabled("  • Archive/Dokumente: XXHASH3+AVX2");
                ImGui::TextDisabled("  • Executables: XXHASH3+AVX2");
                ImGui::TextDisabled("  [*] Maximale Geschwindigkeit (2-4x Boost)");
            } else if (profileIndex == 1) {
                ImGui::TextDisabled("  Balanced: AVX2 für Medien, MD5 für Rest");
                ImGui::TextDisabled("  • Videos/Bilder/Audio: XXHASH3+AVX2");
                ImGui::TextDisabled("  • Archive: MD5 (Kompatibilität)");
                ImGui::TextDisabled("  • Dokumente/EXE: MD5 (Standard)");
                ImGui::TextDisabled("  ⚖️ Balance zwischen Speed & Kompatibilität");
            } else {
                ImGui::TextDisabled("  Compatible: Meist MD5, AVX2 nur für Riesen-Dateien");
                ImGui::TextDisabled("  • Dateien >1GB: XXHASH3+AVX2");
                ImGui::TextDisabled("  • Videos >100MB: XXHASH3+AVX2");
                ImGui::TextDisabled("  • Rest: MD5 (maximale Kompatibilität)");
                ImGui::TextDisabled("  🔒 Maximale Kompatibilität");
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("[CFG] Erweiterte AVX2-Einstellungen:");
            
            if (ImGui::Checkbox("AVX2 erzwingen (auch wenn nicht erkannt)", &appState.avx2ForceEnabled)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("⚠️ Nur aktivieren wenn CPU AVX2 hat aber nicht erkannt wird");
            
            ImGui::Spacing();
            if (ImGui::SliderInt("Min. Dateigröße für AVX2 (Bytes)", &appState.avx2MinFileSize, 128, 32768)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Dateien kleiner → MD5 (AVX2 Overhead vermeiden)");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Hardware-Status:");
            ImGui::Text("Erkannte Hardware: %s", appState.detectedHardware.c_str());
            if (avx2Available) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "CPU-Features: AVX2 ✅");
            }
            if (appState.useGPU && appState.detectedHardware.find("GPU") == std::string::npos) {
                ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "⚠️ Warnung: Keine GPU erkannt!");
            }
            
            ImGui::EndTabItem();
        }
        
        // Scan Options Tab
        if (ImGui::BeginTabItem("[SCAN] Scan-Optionen")) {
            ImGui::Text("Datei-Filter");
            ImGui::SliderInt("Min. Dateigröße (Bytes)", &appState.minFileSize, 0, 10240);
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.5f, 1.0f, 0.5f, 1.0f), "🌳 Verzeichnisbaum-Suche");
            if (ImGui::Checkbox("Unterverzeichnisse von Suchergebnissen anzeigen", &appState.treeSearchShowSubdirs)) {
                saveScannerSettings();
                std::cout << "[Config] Tree search show subdirs: " << (appState.treeSearchShowSubdirs ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("Bei Suchfilter: Unterverzeichnisse von gefundenen Ordnern ausblenden");
            
            ImGui::Spacing();
            ImGui::Separator();
            if (ImGui::Checkbox("Versteckte Dateien scannen", &appState.scanHiddenFiles)) {
                saveScannerSettings();
                std::cout << "[Config] Hidden files: " << (appState.scanHiddenFiles ? "ON" : "OFF") << std::endl;
            }
            if (ImGui::Checkbox("Symbolischen Links folgen", &appState.followSymlinks)) {
                saveScannerSettings();
                std::cout << "[Config] Follow symlinks: " << (appState.followSymlinks ? "ON" : "OFF") << std::endl;
            }
            if (ImGui::Checkbox("[DEL] Leere Verzeichnisse automatisch löschen", &appState.deleteEmptyDirs)) {
                saveScannerSettings();
                std::cout << "[Config] Delete empty dirs: " << (appState.deleteEmptyDirs ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("(Systemordner werden automatisch geschützt)");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️ Erweiterte Optionen");
            ImGui::Spacing();
            
            ImGui::Checkbox("Ergebnisse automatisch exportieren", &appState.autoExportResults);
            if (appState.autoExportResults) {
                ImGui::InputText("Export-Pfad", &appState.exportPath[0], 256);
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "🔋 Post-Scan-Aktionen");
            ImGui::Separator();
            ImGui::TextDisabled("Aktion nach Scan-Abschluss ausführen");
            
            if (ImGui::Checkbox("[*] Post-Scan-Aktion aktivieren", &appState.postScanActionEnabled)) {
                saveScannerSettings();
                std::cout << "[Config] Post-scan action: " << (appState.postScanActionEnabled ? "ON" : "OFF") << std::endl;
            }
            
            if (appState.postScanActionEnabled) {
                ImGui::Spacing();
                
                const char* actions[] = { 
                    "Nichts", 
                    "🔴 Herunterfahren", 
                    "💤 Suspend (Standby)", 
                    "🌙 Hibernate (Ruhezustand)", 
                    "🔔 Benachrichtigung",
                    "[DEL] Duplikate automatisch löschen"
                };
                
                if (ImGui::Combo("Aktion", &appState.postScanAction, actions, 6)) {
                    saveScannerSettings();
                }
                
                ImGui::Spacing();
                if (ImGui::SliderInt("Verzögerung (Sekunden)", &appState.postScanDelay, 0, 300)) {
                    saveScannerSettings();
                }
                ImGui::TextDisabled("Zeit zum Abbrechen der Aktion nach Scan");
                
                // Spezielle Optionen für Duplikat-Löschung
                if (appState.postScanAction == 5) {
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "[DEL] Duplikat-Lösch-Modus:");
                    
                    const char* deleteModes[] = {
                        "Älteste Datei behalten (Neuere löschen)",
                        "Neueste Datei behalten (Ältere löschen)",
                        "Erste gefundene behalten (Rest löschen)"
                    };
                    
                    if (ImGui::Combo("Lösch-Strategie", &appState.autoDeleteMode, deleteModes, 3)) {
                        saveScannerSettings();
                    }
                    ImGui::TextDisabled("Welche Dateien in jeder Duplikat-Gruppe behalten werden");
                    
                    ImGui::Spacing();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️ Info:");
                    ImGui::BulletText("Pro Duplikat-Gruppe wird 1 Datei behalten");
                    ImGui::BulletText("Alle anderen Kopien werden gelöscht");
                    ImGui::BulletText("Gelöschte Dateien sind PERMANENT weg!");
                    ImGui::BulletText("Nach %d Sekunden Verzögerung", appState.postScanDelay);
                }
                
                ImGui::Spacing();
                if (appState.postScanAction > 0) {
                    ImGui::Separator();
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️ Aktive Aktion:");
                    ImGui::Text("Nach Scan: %s", actions[appState.postScanAction]);
                    ImGui::Text("Verzögerung: %d Sekunden", appState.postScanDelay);
                    
                    if (appState.postScanAction <= 3) {
                        ImGui::Spacing();
                        ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), 
                                          "⚠️ System wird nach Scan automatisch %s!", 
                                          appState.postScanAction == 1 ? "heruntergefahren" :
                                          appState.postScanAction == 2 ? "in Standby versetzt" :
                                          "in Ruhezustand versetzt");
                    } else if (appState.postScanAction == 5) {
                        ImGui::Spacing();
                        ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), 
                                          "⚠️ WARNUNG: Duplikate werden automatisch GELÖSCHT!");
                        ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), 
                                          "Modus: %s", 
                                          appState.autoDeleteMode == 0 ? "Älteste behalten" :
                                          appState.autoDeleteMode == 1 ? "Neueste behalten" :
                                          "Erste behalten");
                    }
                }
            }
            
            ImGui::EndTabItem();
        }
        
        // Network Scanner Settings Tab
        if (ImGui::BeginTabItem("[[*]] Netzwerk-Scanner")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Lightning Speed Scanner");
            ImGui::Separator();
            
            ImGui::Checkbox("[*] Lightning Speed aktivieren", &appState.useLightningSpeed);
            ImGui::TextDisabled("Multi-threaded asynchroner Scanner");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("Performance-Einstellungen:");
            
            if (ImGui::SliderInt("Parallel-Threads", &appState.scannerThreads, 1, 512)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Mehr Threads = schneller, aber aggressiver");
            
            if (ImGui::SliderInt("Timeout (Sekunden)", &appState.scanTimeout, 1, 5)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Zeit pro Host bevor Timeout");
            
            if (ImGui::SliderInt("Batch-Größe", &appState.batchScanSize, 5, 50)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Anzahl paralleler IP-Pings pro Thread");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Scan-Methode:");
            
            if (ImGui::Checkbox("[>>] TCP Connect Scan (schnell)", &appState.useTCPPing)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Socket-basiert statt system() ping");
            
            if (ImGui::Checkbox("🧠 Auto-Tune Threads", &appState.autoTuneThreads)) {
                if (appState.autoTuneThreads) {
                    appState.scannerThreads = std::thread::hardware_concurrency() * 16;
                    saveScannerSettings();
                }
            }
            ImGui::TextDisabled("Automatisch basierend auf CPU-Kernen");
            
            if (ImGui::Checkbox("[TIME] Smart Timeout", &appState.smartTimeout)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Adaptiver Timeout je nach Netzwerk-Speed");
            
            ImGui::Spacing();
            ImGui::Separator();
            
            // Scanner-Statistiken
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Scanner-Info:");
            ImGui::Text("Aktuelle Threads: %d", appState.scannerThreads);
            ImGui::Text("Batch-Größe: %d IPs parallel", appState.batchScanSize);
            ImGui::Text("Timeout: %d Sekunde(n)", appState.scanTimeout);
            ImGui::Text("Scan-Methode: %s", appState.useTCPPing ? "TCP Connect" : "ICMP Ping");
            
            if (appState.scanThreadRunning) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), 
                                  "Status: AKTIV (%d/%d hosts)", 
                                  appState.scannedHosts.load(), 
                                  appState.totalHostsToScan.load());
            } else {
                ImGui::Text("Status: Bereit");
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextDisabled("💡 Empfehlung:");
            ImGui::TextDisabled("  • Heimnetzwerk (/24): 64-128 Threads, Batch 10");
            ImGui::TextDisabled("  • Großes Netzwerk (/16): 256-512 Threads, Batch 20");
            ImGui::TextDisabled("  • LAN: TCP Connect + Smart Timeout");
            ImGui::TextDisabled("  • WAN/VPN: ICMP Ping, höherer Timeout");
            
            ImGui::EndTabItem();
        }
        
        // Advanced Optimizations Tab
        if (ImGui::BeginTabItem("[[TOOL]] Erweitert")) {
            ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "⚠️ Erweiterte Performance-Optimierungen");
            ImGui::Separator();
            
            // File I/O Section
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Datei I/O:");
            if (ImGui::Checkbox("[*] Async I/O", &appState.useAsyncIO)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Asynchrones Lesen für parallelen Scan");
            
            if (ImGui::Checkbox("[SAVE] Memory Mapping (mmap)", &appState.useMemoryMapping)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Für Dateien > 1 GB (schneller aber mehr RAM)");
            
            if (ImGui::Checkbox("[DEL] Leere Dateien überspringen", &appState.skipEmptyFiles)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Ignoriert 0-Byte Dateien");
            
            if (ImGui::Checkbox("[DISK] Hash-Cache aktivieren", &appState.cacheFileHashes)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Speichert bekannte Hashes (schneller bei Re-Scan)");
            
            ImGui::Spacing();
            ImGui::Separator();
            
            // Network/FTP Section
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Netzwerk/FTP:");
            if (ImGui::Checkbox("🔄 CURL Connection Pooling", &appState.useCurlPooling)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Wiederverwendet FTP-Verbindungen (viel schneller!)");
            
            if (ImGui::Checkbox("[EXPORT] HTTP/FTP Pipelining", &appState.ftpPipelining)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Multiple Requests über eine Verbindung");
            
            if (ImGui::Checkbox("💓 TCP Keep-Alive", &appState.ftpKeepAlive)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Hält Verbindungen offen");
            
            ImGui::Spacing();
            if (ImGui::SliderInt("📦 CURL Buffer Size (KB)", &appState.curlBufferSize, 16000, 512000)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Größerer Buffer = schnellere Transfers (max: 500 KB)");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "[TIME] FTP Timeouts:");
            
            if (ImGui::SliderInt("Connect Timeout (s)", &appState.ftpConnectTimeout, 2, 30)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Verbindungsaufbau-Timeout (Default: 2s für LAN, 10s Internet)");
            
            if (ImGui::SliderInt("Response Timeout (s)", &appState.ftpResponseTimeout, 2, 30)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Antwort-Timeout pro Verzeichnis (Default: 5s)");
            
            if (ImGui::SliderInt("Read Timeout (s)", &appState.ftpReadTimeout, 5, 120)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Sekunden für Daten-Übertragung (Default: 15s)");
            
            if (ImGui::SliderInt("Max Retries", &appState.ftpMaxRetries, 1, 10)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Wiederholungsversuche bei Fehler (Default: 3)");
            
            ImGui::Spacing();
            ImGui::Separator();
            
            // Performance Stats
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Aktive Optimierungen:");
            int activeCount = 0;
            if (appState.useAsyncIO) activeCount++;
            if (appState.useCurlPooling) activeCount++;
            if (appState.useTCPPing) activeCount++;
            if (appState.cacheFileHashes) activeCount++;
            if (appState.ftpPipelining) activeCount++;
            if (appState.ftpKeepAlive) activeCount++;
            
            ImGui::Text("[X] %d/6 Performance-Features aktiv", activeCount);
            ImGui::ProgressBar((float)activeCount / 6.0f, ImVec2(-1, 0));
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextDisabled("💡 Empfohlene Konfiguration:");
            ImGui::TextDisabled("  LAN:  Alle Features AN, Connect 5s, Read 15s");
            ImGui::TextDisabled("  WAN:  Pooling AN, Connect 10s, Read 60s, Retries 5");
            ImGui::TextDisabled("  Slow: Nur Keep-Alive, Connect 30s, Read 120s");
            
            ImGui::Spacing();
            if (ImGui::Button("[>>] Performance-Profil: LAN", ImVec2(200, 0))) {
                appState.useAsyncIO = true;
                appState.useCurlPooling = true;
                appState.useTCPPing = true;
                appState.cacheFileHashes = true;
                appState.ftpPipelining = true;
                appState.ftpKeepAlive = true;
                appState.ftpConnectTimeout = 5;
                appState.ftpReadTimeout = 15;
                appState.ftpMaxRetries = 3;
                appState.scannerThreads = 128;
                appState.batchScanSize = 10;
                saveScannerSettings();
            }
            ImGui::SameLine();
            if (ImGui::Button("[NET] Performance-Profil: WAN", ImVec2(200, 0))) {
                appState.useAsyncIO = true;
                appState.useCurlPooling = true;
                appState.useTCPPing = false;
                appState.cacheFileHashes = true;
                appState.ftpPipelining = false;
                appState.ftpKeepAlive = true;
                appState.ftpConnectTimeout = 10;
                appState.ftpReadTimeout = 60;
                appState.ftpMaxRetries = 5;
                appState.scannerThreads = 64;
                appState.batchScanSize = 5;
                saveScannerSettings();
            }
            
            ImGui::EndTabItem();
        }
        
        // Theme Tab
        if (ImGui::BeginTabItem("[CFG] Erscheinungsbild")) {
            ImGui::Text("Theme auswählen (33 Themes verfügbar):");
            ImGui::Separator();
            
            // Theme Grid mit 3 Spalten
            ImGui::BeginChild("ThemeSelector", ImVec2(0, 300), true);
            ImGui::Columns(3, nullptr, false);
            
            for (int i = 0; i < 33; i++) {
                if (ImGui::RadioButton(appState.themes[i], appState.currentTheme == i)) {
                    appState.currentTheme = i;
                    applyTheme(i);
                }
                ImGui::NextColumn();
                
                // Nach jedem 3. Element eine neue Zeile
                if ((i + 1) % 3 == 0) {
                    ImGui::Separator();
                }
            }
            
            ImGui::Columns(1);
            ImGui::EndChild();
            
            ImGui::Spacing();
            ImGui::Text("Schnellwahl:");
            if (ImGui::Button("< Vorheriges")) {
                appState.currentTheme = (appState.currentTheme - 1 + 33) % 33;
                applyTheme(appState.currentTheme);
            }
            ImGui::SameLine();
            if (ImGui::Button("Nächstes >")) {
                appState.currentTheme = (appState.currentTheme + 1) % 33;
                applyTheme(appState.currentTheme);
            }
            ImGui::SameLine();
            if (ImGui::Button("Quake 3 (Standard)")) {
                appState.currentTheme = 3;
                applyTheme(3);
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Aktuelles Theme: %s", appState.themes[appState.currentTheme]);
            
            ImGui::EndTabItem();
        }
        
        // FTP Scan Optimization Tab (NEW)
        if (ImGui::BeginTabItem("[[>>]] FTP-Scan")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[*] FTP Verzeichnisbaum-Scan Beschleunigung");
            ImGui::Separator();
            ImGui::TextDisabled("Optimiert für schnelles Scannen tiefer FTP-Strukturen");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("� Scan-Methode:");
            
            if (ImGui::Checkbox("[*] LIST -R verwenden (Ultra-Fast)", &appState.ftpUseLsR)) {
                saveScannerSettings();
                std::cout << "[FTP] LIST -R: " << (appState.ftpUseLsR ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("Rekursive Auflistung mit einem Befehl (~240x schneller!)");
            if (!appState.ftpUseLsR) {
                ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), 
                                  "⚠️ Falls Server LIST -R nicht unterstützt automatisch Fallback");
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("�🔥 Parallel-Scan-Einstellungen (Fallback):");
            
            if (ImGui::Checkbox("[*] Paralleler Scan aktivieren", &appState.ftpUseParallelScan)) {
                saveScannerSettings();
                std::cout << "[FTP] Parallel scan: " << (appState.ftpUseParallelScan ? "ON" : "OFF") << std::endl;
            }
            ImGui::TextDisabled("Mehrere FTP-Verbindungen gleichzeitig (wenn LIST -R nicht geht)");
            
            ImGui::Spacing();
            if (ImGui::SliderInt("Max. Parallel-Threads", &appState.ftpMaxThreads, 1, 32)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Anzahl gleichzeitiger FTP-Verbindungen (Default: 16)");
            
            if (appState.ftpMaxThreads > 16) {
                ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), 
                                  "⚠️ >16 Threads können FTP-Server überlasten!");
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("[EXPORT] Scan-Tiefe:");
            
            if (ImGui::SliderInt("Max. Scan-Tiefe", &appState.ftpScanMaxDepth, 5, 50)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Wie tief in Unterverzeichnisse beim SCANNEN (Default: 30)");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("🌳 Verzeichnisbaum-Anzeige:");
            
            if (ImGui::SliderInt("Lokale Baum-Tiefe", &appState.localTreeMaxDepth, 1, 20)) {
                saveScannerSettings();
            }
            ImGui::TextDisabled("Maximale Tiefe für lokalen Verzeichnisbaum (Default: 10)");
            
            if (ImGui::SliderInt("FTP Baum-Tiefe", &appState.ftpTreeMaxDepth, 1, 20)) {
                saveScannerSettings();
                
                // Wenn FTP verbunden ist, automatisch neu scannen mit neuer Tiefe
                if (appState.connectedPresetIndex >= 0 && 
                    appState.connectedPresetIndex < (int)appState.ftpPresets.size()) {
                    auto& preset = appState.ftpPresets[appState.connectedPresetIndex];
                    std::cout << "[FTP] Re-scanning with new depth: " << appState.ftpTreeMaxDepth << std::endl;
                    
                    // Trigger re-scan in background
                    FtpPreset presetCopy = preset;
                    connectAndFetchDirectories(presetCopy, appState.connectedPresetIndex);
                }
            }
            ImGui::TextDisabled("Maximale Tiefe für FTP-Verzeichnisbaum (Default: 7)");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "[CACHE] FTP Verzeichnis-Cache:");
            
            // Show cache statistics
            {
                std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
                ImGui::Text("Gecachte Server-Verzeichnisse: %zu", ftpDirCache.size());
            }
            
            if (ImGui::Button("🗑️ FTP-Cache löschen und neu laden")) {
                std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
                ftpDirCache.clear();
                std::remove(ftpDirCacheFilePath.c_str());
                std::cout << "[FTP Cache] Cache cleared - directories will be reloaded on next scan" << std::endl;
            }
            ImGui::TextDisabled("Löscht gespeicherte FTP-Verzeichnislisten (beim nächsten Scan neu laden)");
            
            ImGui::Spacing();
            
            // Save Settings Button
            if (ImGui::Button("💾 Einstellungen jetzt speichern")) {
                saveSettings();
                std::cout << "[Settings] Manual save triggered" << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("🔄 Einstellungen neu laden")) {
                loadSettings();
                std::cout << "[Settings] Settings reloaded" << std::endl;
            }
            ImGui::SameLine();
            if (ImGui::Button("🔧 DEFAULT Settings")) {
                restoreDefaultSettings();
                appState.showSettingsRestoredMessage = true;
                appState.settingsMessageTimer = 3.0f; // Show for 3 seconds
                std::cout << "[Settings] ✅ DEFAULT settings SOFORT AKTIV & GESPEICHERT!" << std::endl;
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Alle Einstellungen SOFORT auf optimierte Standard-Werte zurücksetzen\n"
                                 "✅ SOFORT AKTIV - Kein Speichern nötig!\n"
                                 "✅ Paralleles Scannen: AN (8 Threads)\n"
                                 "✅ Paralleles FTP: AN (4 Threads)\n"
                                 "✅ Paralleles Cleanup: AN (4 Threads)\n"
                                 "✅ Paralleles Cache-Laden: AN (4 Threads)\n"
                                 "⚡ Hash-Batch: 10000 (optimal)\n"
                                 "🚀 Scanner-Threads: 128 (Lightning-Speed)\n"
                                 "🌐 FTP-Connections: 8 (maximale Speed)");
            }
            
            // Show success message if settings were restored
            if (appState.showSettingsRestoredMessage && appState.settingsMessageTimer > 0.0f) {
                ImGui::Spacing();
                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.0f, 1.0f, 0.0f, 1.0f));
                ImGui::TextWrapped("✅ DEFAULT SETTINGS SOFORT AKTIV & GESPEICHERT!");
                ImGui::PopStyleColor();
                ImGui::TextDisabled("Alle Optimierungen sind jetzt aktiviert und gespeichert.");
                appState.settingsMessageTimer -= ImGui::GetIO().DeltaTime;
                if (appState.settingsMessageTimer <= 0.0f) {
                    appState.showSettingsRestoredMessage = false;
                }
            }
            
            ImGui::TextDisabled("Einstellungen werden auch automatisch beim Beenden gespeichert");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "📈 Performance-Prognose:");
            
            // Calculate estimated speed-up
            float speedupFactor = 1.0f;
            if (appState.ftpUseParallelScan) {
                speedupFactor = std::min((float)appState.ftpMaxThreads, 8.0f); // Realistic max 8x
            }
            
            ImGui::Text("Geschwindigkeitsfaktor: %.1fx schneller", speedupFactor);
            ImGui::ProgressBar(speedupFactor / 16.0f, ImVec2(-1, 0));
            
            ImGui::Spacing();
            ImGui::TextDisabled("💡 Empfohlene Presets:");
            ImGui::Spacing();
            
            if (ImGui::Button("[>>] ULTRA (16 Threads, Tiefe 30)", ImVec2(-1, 0))) {
                appState.ftpMaxThreads = 16;
                appState.ftpScanMaxDepth = 30;
                appState.ftpConnectTimeout = 2;
                appState.ftpResponseTimeout = 5;
                appState.ftpUseParallelScan = true;
                saveScannerSettings();
            }
            ImGui::TextDisabled("Maximale Geschwindigkeit (Standard-Einstellung)");
            
            ImGui::Spacing();
            if (ImGui::Button("[*] BALANCED (8 Threads, Tiefe 25)", ImVec2(-1, 0))) {
                appState.ftpMaxThreads = 8;
                appState.ftpScanMaxDepth = 25;
                appState.ftpConnectTimeout = 3;
                appState.ftpResponseTimeout = 8;
                appState.ftpUseParallelScan = true;
                saveScannerSettings();
            }
            ImGui::TextDisabled("Gute Balance zwischen Speed & Server-Last");
            
            ImGui::Spacing();
            if (ImGui::Button("[<<] SAFE (4 Threads, Tiefe 20)", ImVec2(-1, 0))) {
                appState.ftpMaxThreads = 4;
                appState.ftpScanMaxDepth = 20;
                appState.ftpConnectTimeout = 5;
                appState.ftpResponseTimeout = 10;
                appState.ftpUseParallelScan = true;
                saveScannerSettings();
            }
            ImGui::TextDisabled("Schont den FTP-Server");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.5f, 1.0f, 0.5f, 1.0f), "[X] Aktive Optimierungen:");
            ImGui::BulletText("TCP Keep-Alive (schnellere Reconnects)");
            ImGui::BulletText("TCP NoDelay (sofortiges Senden)");
            ImGui::BulletText("Connection Reuse (keine neuen Handshakes)");
            ImGui::BulletText("64KB Buffer Pre-Allocation");
            if (appState.ftpUseParallelScan) {
                ImGui::BulletText("Paralleler Multi-Thread Scan (%d Threads)", appState.ftpMaxThreads);
            }
            
            ImGui::EndTabItem();
        }
        
        // Privacy & History Tab
        if (ImGui::BeginTabItem("[🔒] Datenschutz & History")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "🔒 Datenschutz & Eingabe-History");
            ImGui::Separator();
            
            ImGui::Spacing();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Eingabe-History:");
            ImGui::Text("Die Anwendung speichert Ihre Sucheingaben für Auto-Vervollständigung.");
            
            ImGui::Spacing();
            ImGui::Text("Lokale Suche History: %zu Einträge", localSearchHistory.items.size());
            ImGui::Text("FTP Suche History: %zu Einträge", ftpSearchHistory.items.size());
            
            ImGui::Spacing();
            ImGui::Separator();
            
            if (ImGui::Button("[🗑️] Lokale Such-History löschen", ImVec2(-1, 0))) {
                localSearchHistory.items.clear();
                std::cout << "[Privacy] Local search history cleared" << std::endl;
            }
            ImGui::TextDisabled("Löscht alle gespeicherten Sucheingaben im lokalen Verzeichnis-Browser");
            
            ImGui::Spacing();
            
            if (ImGui::Button("[🗑️] FTP Such-History löschen", ImVec2(-1, 0))) {
                ftpSearchHistory.items.clear();
                std::cout << "[Privacy] FTP search history cleared" << std::endl;
            }
            ImGui::TextDisabled("Löscht alle gespeicherten Sucheingaben im FTP-Browser");
            
            ImGui::Spacing();
            ImGui::Separator();
            
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.0f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.0f, 0.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.0f, 0.0f, 1.0f));
            
            if (ImGui::Button("[🗑️🗑️] ALLE History-Daten löschen", ImVec2(-1, 0))) {
                localSearchHistory.items.clear();
                ftpSearchHistory.items.clear();
                std::cout << "[Privacy] ALL search history cleared!" << std::endl;
            }
            
            ImGui::PopStyleColor(3);
            ImGui::TextDisabled("Löscht ALLE gespeicherten Sucheingaben (lokal + FTP)");
            
            ImGui::Spacing();
            ImGui::Separator();
            
            ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "ℹ️ Info:");
            ImGui::TextDisabled("• History wird nur im RAM gespeichert (nicht auf Festplatte)");
            ImGui::TextDisabled("• Beim Neustart der Anwendung wird alles automatisch gelöscht");
            ImGui::TextDisabled("• Maximale Einträge pro History: 50");
            
            ImGui::EndTabItem();
        }
        
        // Security Tab - Sudo Password Management
        if (ImGui::BeginTabItem("[LOCK] Sicherheit")) {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "🔒 Sicherheits-Einstellungen");
            ImGui::Separator();
            ImGui::Spacing();
            
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Root-Passwort Management");
            ImGui::Separator();
            
            ImGui::TextDisabled("FileDuper speichert dein Root-Passwort verschlüsselt für");
            ImGui::TextDisabled("NFS/SMB/WebDAV Auto-Mount beim Programmstart.");
            ImGui::Spacing();
            
            // Check if password file exists
            std::string passwordFile = std::string(getenv("HOME")) + "/.fileduper_sudo.cfg";
            struct stat buffer;
            bool passwordSaved = (stat(passwordFile.c_str(), &buffer) == 0);
            
            if (passwordSaved) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "✅ Passwort gespeichert");
                ImGui::TextDisabled("Speicherort: ~/.fileduper_sudo.cfg");
                ImGui::TextDisabled("Verschlüsselung: XOR mit Machine-Key (hostname+user)");
                ImGui::TextDisabled("Berechtigungen: 0600 (nur Owner kann lesen)");
                ImGui::Spacing();
                
                // Delete button
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.2f, 0.2f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.1f, 0.1f, 1.0f));
                
                if (ImGui::Button("🗑️ Passwort jetzt löschen", ImVec2(250, 40))) {
                    clearSudoPassword();
                    std::cout << "[Security] User deleted saved sudo password" << std::endl;
                }
                
                ImGui::PopStyleColor(3);
                
                ImGui::Spacing();
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️ Hinweis:");
                ImGui::TextDisabled("• Beim nächsten NFS/SMB/WebDAV-Mount wird erneut nach");
                ImGui::TextDisabled("  dem Passwort gefragt");
                ImGui::TextDisabled("• Das Passwort wird dann wieder automatisch gespeichert");
                
            } else {
                ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "❌ Kein Passwort gespeichert");
                ImGui::TextDisabled("Beim nächsten NFS/SMB/WebDAV-Mount wird nach dem");
                ImGui::TextDisabled("Root-Passwort gefragt und automatisch verschlüsselt gespeichert.");
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
            
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "🔐 Passwort-Speicherung (FTP/NFS/SMB/WebDAV)");
            ImGui::Separator();
            
            if (ImGui::Checkbox("💾 Passwörter dauerhaft speichern", &appState.savePasswordsPermanently)) {
                saveFtpPresets(); // Sofort speichern wenn geändert
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Wenn aktiviert: Benutzername/Passwort werden in Presets gespeichert\n"
                                 "Wenn deaktiviert: Nur Benutzername wird gespeichert, Passwort muss jedes Mal neu eingegeben werden");
            }
            
            ImGui::TextDisabled("• Standard: AN (Passwörter werden in ~/.fileduper_settings.json gespeichert)");
            ImGui::TextDisabled("• Deaktivieren für mehr Sicherheit (Passwort jedes Mal neu eingeben)");
            ImGui::TextDisabled("• Gilt für: FTP, NFS, SMB/CIFS, WebDAV Presets");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
            
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "🔐 Passwort-Cache (RAM)");
            ImGui::Separator();
            
            ImGui::TextDisabled("• Passwort wird nach erfolgreicher Validierung 5 Minuten im RAM gecacht");
            ImGui::TextDisabled("• Nach 5 Minuten Inaktivität wird erneut abgefragt");
            ImGui::TextDisabled("• RAM-Cache wird beim Beenden gelöscht (nicht persistent)");
            ImGui::Spacing();
            
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "ℹ️ Sicherheits-Info:");
            ImGui::TextDisabled("• Verschlüsselung: XOR mit hostname+username (maschinengebunden)");
            ImGui::TextDisabled("• File Permissions: 0600 (nur Owner Zugriff)");
            ImGui::TextDisabled("• Temporäre Passwort-Dateien werden sofort nach Verwendung gelöscht");
            ImGui::TextDisabled("• Kein Passwort in Prozess-Argumenten oder Shell-History");
            ImGui::TextDisabled("• Bei falscher Eingabe wird gespeichertes Passwort gelöscht");
            
            ImGui::EndTabItem();
        }
        
        ImGui::EndTabBar();
        
        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::Button("Speichern", ImVec2(120, 0))) {
            saveScannerSettings(); // Speichere alle Settings inkl. Hash-Config
            saveThemeSettings();
        }
        ImGui::SameLine();
        if (ImGui::Button("Abbrechen", ImVec2(120, 0))) {
            appState.showSettings = false;
        }
    }
    ImGui::End();
    ImGui::PopStyleColor(); // Pop background color
}

// Render Credentials Dialog
void renderCredentialsDialog() {
    if (!appState.showCredentialsDialog) return;
    
    ImGui::SetNextWindowSize(ImVec2(400, 200), ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f), 
                           ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    
    if (ImGui::Begin("[AUTH] Anmeldedaten erforderlich", &appState.showCredentialsDialog, 
                    ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoFocusOnAppearing)) {
        
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Server benötigt Anmeldung");
        ImGui::Separator();
        ImGui::Spacing();
        
        static char username[128] = "";
        static char password[128] = "";
        
        ImGui::Text("Server: %s", appState.selectedFtpHost.c_str());
        ImGui::Spacing();
        
        ImGui::Text("Benutzername:");
        ImGui::InputText("##CredUsername", username, sizeof(username));
        
        ImGui::Text("Passwort:");
        ImGui::InputText("##CredPassword", password, sizeof(password), ImGuiInputTextFlags_Password);
        
        ImGui::Spacing();
        ImGui::Separator();
        
        if (ImGui::Button("[OK] Verbinden", ImVec2(180, 0))) {
            appState.ftpUsername = username;
            appState.ftpPassword = password;
            
            // Update current preset if exists
            if (appState.connectedPresetIndex >= 0 && 
                appState.connectedPresetIndex < (int)appState.ftpPresets.size()) {
                auto& preset = appState.ftpPresets[appState.connectedPresetIndex];
                preset.username = username;
                preset.password = password;
                
                // WICHTIG: Speichere Presets mit neuen Credentials
                saveFtpPresets();
                std::cout << "[FTP] Credentials saved to preset: " << preset.name << std::endl;
                
                // Try to connect again
                if (connectAndFetchDirectories(preset, appState.connectedPresetIndex)) {
                    appState.showCredentialsDialog = false;
                    appState.showServerBrowser = true;
                }
            }
        }
        
        ImGui::SameLine();
        if (ImGui::Button("[X] Abbrechen", ImVec2(180, 0))) {
            appState.showCredentialsDialog = false;
        }
    }
    ImGui::End();
}

// Render Server Browser Dialog
void renderServerBrowser() {
    if (!appState.showServerBrowser) {
        return;
    }
    
    // NORMALES FENSTER - wie alle anderen Dialoge
    ImGui::SetNextWindowSize(ImVec2(700, 600), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, 
                                   ImGui::GetIO().DisplaySize.y * 0.5f), 
                           ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    
    // KEIN SetNextWindowFocus() - das blockiert Tastatur!
    ImGui::SetNextWindowBgAlpha(0.95f);
    
    // Set dark background
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.1f, 0.1f, 0.1f, 0.95f));
    
    // Dialog bleibt über Hauptfenster durch Render-Reihenfolge
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoFocusOnAppearing;
    
    if (ImGui::Begin("🌐 SERVER-VERZEICHNISSE (Titelleiste ziehen zum Bewegen)", &appState.showServerBrowser, flags)) {
        if (appState.connectedPresetIndex >= 0 && 
            appState.connectedPresetIndex < (int)appState.ftpPresets.size()) {
            auto& preset = appState.ftpPresets[appState.connectedPresetIndex];
            
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "[OK] Verbunden mit: %s", preset.name.c_str());
            ImGui::Text("%s://%s:%d", preset.serviceType.c_str(), preset.ip.c_str(), preset.port);
        }
        
        // Verbindungsstatus anzeigen (wenn vorhanden)
        if (!appState.connectionStatus.empty()) {
            if (appState.connectionStatus.find("Verbunden") != std::string::npos) {
                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "%s", appState.connectionStatus.c_str());
            } else if (appState.connectionStatus.find("fehlgeschlagen") != std::string::npos) {
                ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "%s", appState.connectionStatus.c_str());
            } else {
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "%s", appState.connectionStatus.c_str());
            }
        }
        
        ImGui::Separator();
        
        // Show scanning progress if in progress
        if (appState.isScanningFtp) {
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                              "[...] Scanne FTP-Verzeichnisse im Hintergrund...");
            size_t currentCount;
            {
                std::lock_guard<std::mutex> lock(appState.serverDirectoriesMutex);
                currentCount = appState.serverDirectories.size();
            }
            ImGui::Text("Gefunden: %zu Verzeichnisse", currentCount);
            ImGui::Text("(UI bleibt responsiv)");
            ImGui::Separator();
        }
        
        size_t dirCount;
        {
            std::lock_guard<std::mutex> lock(appState.serverDirectoriesMutex);
            dirCount = appState.serverDirectories.size();
        }
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                          "Verzeichnisse (%zu gefunden):", dirCount);
        ImGui::Text("[TIP] Mehrfachauswahl mit Checkboxen, dann 'Zum Scan hinzufügen'");
        ImGui::Spacing();
        
        // Debug: Zeige Anzahl der Verzeichnisse
        if (appState.serverDirectories.empty()) {
            ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), 
                              "[!] Keine Verzeichnisse gefunden. Verbindung fehlgeschlagen?");
        }
        
        // Directory Tree - zeige alle bis Tiefe 7
        ImGui::Separator();
        
        // FTP Search/Filter und Auto-Detect
        static char ftpSearchFilter[256] = "";
        
        ImGui::PushItemWidth(400);
        ImGui::InputText("##ftpfilter", ftpSearchFilter, sizeof(ftpSearchFilter));
        ImGui::PopItemWidth();
        
        ImGui::SameLine();
        if (ImGui::SmallButton("X")) {
            ftpSearchFilter[0] = '\0';
        }
        ImGui::SameLine();
        ImGui::Text("[FIND] FTP Suche (Tiefe %d)", appState.ftpTreeMaxDepth);
        
        // Enter adds to history
        if (ImGui::IsItemDeactivatedAfterEdit() && strlen(ftpSearchFilter) > 0) {
            ftpSearchHistory.add(ftpSearchFilter);
            std::cout << "[FTP Search] Filter set to: '" << ftpSearchFilter << "'" << std::endl;
        }
        
        ImGui::SameLine();
        if (ImGui::Button("Auto-Detect##FTP")) {
            // Automatische Erkennung häufiger FTP-Verzeichnisse
            std::vector<std::string> commonFtpDirs = {
                "/share", "/home", "/media", "/mnt", "/public", "/upload", "/downloads"
            };
            
            for (const auto& searchDir : commonFtpDirs) {
                for (const auto& serverDir : appState.serverDirectories) {
                    if (serverDir.find(searchDir) != std::string::npos) {
                        std::cout << "[FTP Auto-Detect] Found: " << serverDir << std::endl;
                        strncpy(ftpSearchFilter, searchDir.c_str(), sizeof(ftpSearchFilter) - 1);
                        ftpSearchFilter[sizeof(ftpSearchFilter) - 1] = '\0';
                        break;
                    }
                }
                if (strlen(ftpSearchFilter) > 0) break;
            }
        }
        
        // Thread-sicher serverDirectories kopieren
        std::vector<std::string> sortedDirs;
        {
            std::lock_guard<std::mutex> lock(appState.serverDirectoriesMutex);
            sortedDirs = appState.serverDirectories;
        }
        
        // Multi-term search support (like NFS)
        int filteredCount = 0;
        if (strlen(ftpSearchFilter) > 0) {
            // Parse search terms (comma, semicolon, space separated)
            std::vector<std::string> searchTerms;
            std::string filterStr = ftpSearchFilter;
            std::string term;
            
            for (char c : filterStr) {
                if (c == ',' || c == ';' || c == ' ') {
                    if (!term.empty()) {
                        std::transform(term.begin(), term.end(), term.begin(), ::tolower);
                        searchTerms.push_back(term);
                        term.clear();
                    }
                } else {
                    term += c;
                }
            }
            if (!term.empty()) {
                std::transform(term.begin(), term.end(), term.begin(), ::tolower);
                searchTerms.push_back(term);
            }
            
            // Count matches (OR-logic: any term matches)
            for (const auto& dir : sortedDirs) {
                std::string dirLower = dir;
                std::transform(dirLower.begin(), dirLower.end(), dirLower.begin(), ::tolower);
                
                for (const auto& searchTerm : searchTerms) {
                    if (dirLower.find(searchTerm) != std::string::npos) {
                        filteredCount++;
                        break; // Found match, no need to check other terms
                    }
                }
            }
            
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), 
                              "🔍 Gefunden: %d von %zu Verzeichnissen (Filter: '%s')", 
                              filteredCount, sortedDirs.size(), ftpSearchFilter);
            std::cout << "[FTP Search] 🔍 Gefunden: " << filteredCount 
                      << " von " << sortedDirs.size() << " Verzeichnissen (Begriffe: " << searchTerms.size() 
                      << ", Filter: '" << ftpSearchFilter << "')" << std::endl;
        } else {
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), 
                              "Verzeichnisse (bis Ebene %d, %zu gesamt):", appState.ftpTreeMaxDepth, sortedDirs.size());
        }
        ImGui::Spacing();
        
        if (sortedDirs.empty()) {
            ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), 
                              "FEHLER: Keine Verzeichnisse verfügbar!");
        } else {
            // Nutze generische Tree-Display-Funktion für FTP/Server
            renderDirectoryTree(sortedDirs, appState.selectedServerDirs, 
                               appState.ftpTreeMaxDepth, ftpSearchFilter, "ftp", true);
        }
        
        ImGui::Separator();
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), 
                          "Ausgewählt: %zu Verzeichnis(se)", appState.selectedServerDirs.size());
        
        ImGui::Spacing();
        
        // Buttons
        if (ImGui::Button("[+] Zum Scan hinzufügen", ImVec2(200, 0))) {
            std::cout << "[DEBUG] Button clicked! selectedServerDirs.size()=" 
                     << appState.selectedServerDirs.size() 
                     << " connectedPresetIndex=" << appState.connectedPresetIndex << std::endl;
            
            if (!appState.selectedServerDirs.empty() && 
                appState.connectedPresetIndex >= 0 && 
                appState.connectedPresetIndex < (int)appState.ftpPresets.size()) {
                
                auto& preset = appState.ftpPresets[appState.connectedPresetIndex];
                
                // NICHT mehr löschen - lokale Verzeichnisse bleiben erhalten!
                // appState.selectedLocalDirs.clear(); // ENTFERNT
                // appState.selectedFtpDirs.clear(); // ENTFERNT
                
                // Füge neue Server-Verzeichnisse HINZU (kombiniert mit lokalen)
                for (const auto& dir : appState.selectedServerDirs) {
                    // Speichere nur den Pfad, z.B. /sdb/Comedy
                    appState.selectedFtpDirs.insert(dir);
                    std::cout << "[FTP] Added to scan: " << dir << std::endl;
                }
                
                std::cout << "[FTP] Added " << appState.selectedServerDirs.size() 
                         << " FTP directories (total Local: " << appState.selectedLocalDirs.size()
                         << ", FTP: " << appState.selectedFtpDirs.size() << ")" << std::endl;
                
                appState.showServerBrowser = false;
                appState.selectedServerDirs.clear();
            }
        }
        
        ImGui::SameLine();
        if (ImGui::Button("[X] Abbrechen", ImVec2(150, 0))) {
            appState.showServerBrowser = false;
            appState.selectedServerDirs.clear();
        }
    }
    ImGui::End();
    ImGui::PopStyleColor(); // Pop background color
}

// Render Sudo Password Dialog
void renderSudoPasswordDialog() {
    if (!appState.showSudoPasswordPrompt) return;
    
    // Static buffer for password input
    static char sudoPasswordInput[256] = "";
    
    ImGui::SetNextWindowSize(ImVec2(400, 200), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("🔐 Sudo Passwort erforderlich", &appState.showSudoPasswordPrompt, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "⚠️  Sudo-Passwort erforderlich");
        ImGui::Text("NFS/SMB-Mount benötigt Admin-Rechte (sudo).");
        ImGui::Text("Das Passwort wird nur im RAM gespeichert.");
        ImGui::Spacing();
        
        ImGui::Text("Passwort:");
        ImGui::SameLine();
        ImGui::PushID("sudopass");
        
        // Set focus to password input when dialog opens
        if (ImGui::IsWindowAppearing()) {
            ImGui::SetKeyboardFocusHere();
        }
        
        bool password_submitted = ImGui::InputText("##sudopass", sudoPasswordInput, sizeof(sudoPasswordInput), 
                                                   ImGuiInputTextFlags_Password | ImGuiInputTextFlags_EnterReturnsTrue);
        ImGui::PopID();
        
        ImGui::Spacing();
        
        // Submit password either by pressing Enter or clicking OK button
        if (password_submitted || ImGui::Button("OK##sudook", ImVec2(100, 0))) {
            if (strlen(sudoPasswordInput) > 0) {
                appState.sudoPassword = std::string(sudoPasswordInput);
                appState.sudoPasswordAvailable = true;
                appState.sudoPasswordCacheTime = time(nullptr);  // Record when password was cached
                appState.showSudoPasswordPrompt = false;
                
                // Speichere Passwort dauerhaft auf Festplatte (verschlüsselt)
                saveSudoPassword(appState.sudoPassword);
                
                memset(sudoPasswordInput, 0, sizeof(sudoPasswordInput));
                std::cout << "[SUDO] ✅ Passwort gecacht für diese Sitzung & dauerhaft gespeichert" << std::endl;
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Abbrechen##sudocancel", ImVec2(100, 0))) {
            appState.showSudoPasswordPrompt = false;
            memset(sudoPasswordInput, 0, sizeof(sudoPasswordInput));
            std::cout << "[SUDO] Passwort-Eingabe abgebrochen" << std::endl;
        }
        ImGui::End();
    }
}

// Render SMB Mount Dialog
void renderSmbMountDialog() {
    if (!appState.showSmbMountDialog) return;
    if (appState.selectedSmbPresetForMount < 0 || 
        appState.selectedSmbPresetForMount >= (int)appState.ftpPresets.size()) return;
    
    auto& preset = appState.ftpPresets[appState.selectedSmbPresetForMount];
    
    ImGui::SetNextWindowSize(ImVec2(700, 500), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, 
                                   ImGui::GetIO().DisplaySize.y * 0.5f), 
                           ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    
    if (ImGui::Begin("[SMB] Verzeichnisse zum Scannen auswählen", &appState.showSmbMountDialog)) {
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "SMB-Freigabe: %s", preset.name.c_str());
        ImGui::Text("Mountpunkt: %s", preset.smbMountPoint.c_str());
        ImGui::Separator();
        
        // Lokale Verzeichnisse anzeigen
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Verfügbare Verzeichnisse:");
        ImGui::BeginChild("SmbDirList", ImVec2(0, 350), true);
        
        // Zeige Verzeichnisse aus smbMountPoint
        DIR* dir = opendir(preset.smbMountPoint.c_str());
        if (dir) {
            struct dirent* entry;
            std::vector<std::string> dirs;
            
            while ((entry = readdir(dir)) != nullptr) {
                if (entry->d_type == DT_DIR && entry->d_name[0] != '.') {
                    dirs.push_back(entry->d_name);
                }
            }
            closedir(dir);
            
            std::sort(dirs.begin(), dirs.end());
            
            for (const auto& dirName : dirs) {
                std::string fullPath = preset.smbMountPoint + "/" + dirName;
                bool isSelected = appState.selectedLocalDirs.count(fullPath) > 0;
                
                if (ImGui::Checkbox(dirName.c_str(), &isSelected)) {
                    if (isSelected) {
                        appState.selectedLocalDirs.insert(fullPath);
                    } else {
                        appState.selectedLocalDirs.erase(fullPath);
                    }
                }
            }
        } else {
            ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), 
                              "[!] Fehler: Verzeichnis kann nicht geöffnet werden");
        }
        
        ImGui::EndChild();
        ImGui::Separator();
        
        if (ImGui::Button("Zum Scan hinzufügen", ImVec2(200, 0))) {
            appState.showSmbMountDialog = false;
            saveFtpPresets();
        }
        ImGui::SameLine();
        if (ImGui::Button("Abbrechen", ImVec2(200, 0))) {
            appState.showSmbMountDialog = false;
        }
    }
    ImGui::End();
}

// ============================================================================
// PASSWORD ENCRYPTION/DECRYPTION FUNCTIONS
// ============================================================================

// Simple XOR encryption using hostname as key

// ============================================================================
// Render About Dialog
void renderAbout() {
    if (!appState.showAbout) return;
    
    ImGui::SetNextWindowSize(ImVec2(400, 250), ImGuiCond_Always);
    if (ImGui::Begin("Über FileDuper", &appState.showAbout, ImGuiWindowFlags_NoResize)) {
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 1.0f), "FileDuper");
        ImGui::Text("Version 2.0 - ImGui Edition");
        ImGui::Separator();
        ImGui::Text("Duplicate File Scanner");
        ImGui::Text("Findet und verwaltet doppelte Dateien");
        ImGui::Spacing();
        ImGui::Text("Features:");
        ImGui::BulletText("Schnelles Scanning");
        ImGui::BulletText("MD5/SHA Hash-Vergleich");
        ImGui::BulletText("Lokale & Netzwerk-Scans");
        ImGui::BulletText("Mehrere Themes");
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("© 2025");
        
        if (ImGui::Button("OK", ImVec2(120, 0))) {
            appState.showAbout = false;
        }
    }
    ImGui::End();
}

// File Access Error Dialog
void renderFileErrorDialog() {
    if (!appState.showFileErrorDialog) return;
    
    ImGui::SetNextWindowSize(ImVec2(700, 500), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f), 
                            ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    
    ImGuiWindowFlags flags = ImGuiWindowFlags_None;
    
    if (ImGui::Begin("⚠️ DATEIZUGRIFF-FEHLER", &appState.showFileErrorDialog, flags)) {
        ImGui::Spacing();
        ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "Warnung: Einige Dateien sind nicht mehr verfügbar!");
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        
        ImGui::TextWrapped("Während des Scans konnten folgende Dateien nicht gelesen werden. "
                          "Mögliche Ursachen: Datei gelöscht, Netzwerkverbindung unterbrochen, "
                          "USB-Gerät entfernt, oder fehlende Zugriffsrechte.");
        
        ImGui::Spacing();
        ImGui::Text("Nicht verfügbare Dateien: %d", appState.totalInaccessibleFiles);
        ImGui::Spacing();
        ImGui::Separator();
        
        // Liste der nicht verfügbaren Dateien (scrollbar wenn zu viele)
        ImGui::BeginChild("InaccessibleFilesList", ImVec2(0, 300), true);
        {
            std::lock_guard<std::mutex> lock(appState.inaccessibleFilesMutex);
            for (size_t i = 0; i < appState.inaccessibleFiles.size(); i++) {
                const auto& file = appState.inaccessibleFiles[i];
                ImGui::PushID(i);
                ImGui::TextColored(ImVec4(1.0f, 0.3f, 0.3f, 1.0f), "[X]");
                ImGui::SameLine();
                ImGui::TextWrapped("%s", file.c_str());
                ImGui::PopID();
            }
        }
        ImGui::EndChild();
        
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        
        // Buttons
        float buttonWidth = 150.0f;
        float spacing = 10.0f;
        float totalWidth = (buttonWidth * 2) + spacing;
        ImGui::SetCursorPosX((ImGui::GetWindowWidth() - totalWidth) * 0.5f);
        
        if (ImGui::Button("Liste löschen", ImVec2(buttonWidth, 30))) {
            std::lock_guard<std::mutex> lock(appState.inaccessibleFilesMutex);
            appState.inaccessibleFiles.clear();
            appState.totalInaccessibleFiles = 0;
        }
        
        ImGui::SameLine(0, spacing);
        if (ImGui::Button("Schließen", ImVec2(buttonWidth, 30))) {
            appState.showFileErrorDialog = false;
        }
        
        ImGui::Spacing();
        
        // Info
        ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), 
                          "Der Scan wird mit den verbleibenden Dateien fortgesetzt.");
    }
    ImGui::End();
}

// Delete Success Popup
void renderDeleteSuccess() {
    if (!appState.showDeleteSuccess) return;
    
    ImGui::SetNextWindowSize(ImVec2(450, 180), ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f), 
                            ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    
    if (ImGui::Begin("[DEL] Duplikate gelöscht", &appState.showDeleteSuccess, 
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove)) {
        ImGui::Spacing();
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "✅ Erfolgreich gelöscht!");
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        
        // Show statistics
        ImGui::Text("Gelöschte Duplikate:");
        ImGui::SameLine(200);
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "%d", appState.deletedFilesCount);
        
        ImGui::Text("Freigegebener Speicher:");
        ImGui::SameLine(200);
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 1.0f), "%s", formatSize(appState.deletedFilesSize).c_str());
        
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        
        // Center the OK button
        float buttonWidth = 120.0f;
        ImGui::SetCursorPosX((ImGui::GetWindowWidth() - buttonWidth) * 0.5f);
        if (ImGui::Button("OK", ImVec2(buttonWidth, 30))) {
            appState.showDeleteSuccess = false;
        }
    }
    ImGui::End();
}

// ============================================================================
// DUPLICATE SCANNER IMPLEMENTATION
// ============================================================================

// ============================================================================
// HARDWARE DETECTION & MONITORING
// ============================================================================

std::string detectHardwareCapabilities() {
    std::string result = "CPU";
    
    // Check for SIMD support (SSE, AVX)
    #if defined(__AVX2__)
        result = "CPU_AVX2";
    #elif defined(__AVX__)
        result = "CPU_AVX";
    #elif defined(__SSE4_2__)
        result = "CPU_SSE4.2";
    #elif defined(__SSE4_1__)
        result = "CPU_SSE4.1";
    #endif
    
    // Check for GPU - verbesserte Erkennung
    bool gpuFound = false;
    
    // 1. Check NVIDIA (über nvidia-smi oder /proc)
    std::ifstream cuda_check("/proc/driver/nvidia/version");
    if (cuda_check.good()) {
        result += "+GPU_NVIDIA";
        gpuFound = true;
    }
    cuda_check.close();
    
    // 2. Check AMD GPU über verschiedene Pfade
    for (int i = 0; i < 4; i++) {
        std::string cardPath = "/sys/class/drm/card" + std::to_string(i) + "/device/vendor";
        std::ifstream amd_check(cardPath);
        if (amd_check.good()) {
            std::string vendor;
            std::getline(amd_check, vendor);
            if (vendor.find("0x1002") != std::string::npos) { // AMD vendor ID
                result += "+GPU_AMD";
                gpuFound = true;
                break;
            } else if (vendor.find("0x8086") != std::string::npos) { // Intel vendor ID
                result += "+GPU_INTEL";
                gpuFound = true;
                break;
            }
        }
        amd_check.close();
    }
    
    // 3. Fallback: Check lspci output
    if (!gpuFound) {
        FILE* pipe = popen("lspci 2>/dev/null | grep -i 'vga\\|3d\\|display'", "r");
        if (pipe) {
            char buffer[256];
            std::string lspci_output;
            while (fgets(buffer, sizeof(buffer), pipe)) {
                lspci_output += buffer;
            }
            pclose(pipe);
            
            std::cout << "[GPU Debug] lspci output: " << lspci_output << std::endl;
            
            std::transform(lspci_output.begin(), lspci_output.end(), lspci_output.begin(), ::tolower);
            
            std::cout << "[GPU Debug] lowercase output: " << lspci_output << std::endl;
            
            if (lspci_output.find("nvidia") != std::string::npos) {
                result += "+GPU_NVIDIA";
                gpuFound = true;
                std::cout << "[GPU Debug] Found NVIDIA GPU" << std::endl;
            } else if (lspci_output.find("amd") != std::string::npos || 
                       lspci_output.find("radeon") != std::string::npos) {
                result += "+GPU_AMD";
                gpuFound = true;
                std::cout << "[GPU Debug] Found AMD GPU" << std::endl;
            } else if (lspci_output.find("intel") != std::string::npos) {
                result += "+GPU_INTEL";
                gpuFound = true;
                std::cout << "[GPU Debug] Found Intel GPU" << std::endl;
            } else {
                std::cout << "[GPU Debug] No GPU found in lspci output" << std::endl;
            }
        } else {
            std::cout << "[GPU Debug] Failed to run lspci" << std::endl;
        }
    }
    
    return result;
}

// Get current CPU usage percentage
float getCpuUsage() {
    static long long lastTotal = 0;
    static long long lastIdle = 0;
    
    std::ifstream stat("/proc/stat");
    if (!stat.is_open()) return 0.0f;
    
    std::string line;
    std::getline(stat, line);
    stat.close();
    
    std::istringstream ss(line);
    std::string cpu;
    long long user, nice, system, idle, iowait, irq, softirq, steal;
    
    ss >> cpu >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal;
    
    long long total = user + nice + system + idle + iowait + irq + softirq + steal;
    long long idleTime = idle + iowait;
    
    if (lastTotal == 0) {
        lastTotal = total;
        lastIdle = idleTime;
        return 0.0f;
    }
    
    long long totalDiff = total - lastTotal;
    long long idleDiff = idleTime - lastIdle;
    
    lastTotal = total;
    lastIdle = idleTime;
    
    if (totalDiff == 0) return 0.0f;
    
    return 100.0f * (1.0f - (float)idleDiff / (float)totalDiff);
}

// Get CPU temperature
int getCpuTemperature() {
    std::ifstream temp("/sys/class/thermal/thermal_zone0/temp");
    if (!temp.is_open()) return 0;
    
    int millidegrees;
    temp >> millidegrees;
    temp.close();
    
    return millidegrees / 1000; // Convert to Celsius
}

// Get GPU usage (NVIDIA, AMD, Intel)
float getGpuUsage() {
    float usage = 0.0f;
    
    // Try NVIDIA first
    FILE* pipe = popen("nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                usage = std::stof(buffer);
                pclose(pipe);
                return usage;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Try AMD ROCm
    pipe = popen("rocm-smi --showuse 2>/dev/null | grep 'GPU use' | awk '{print $4}' | tr -d '%'", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                usage = std::stof(buffer);
                pclose(pipe);
                return usage;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Try Intel GPU with intel_gpu_top (real GPU utilization)
    pipe = popen("timeout 0.5 intel_gpu_top -J -s 100 2>/dev/null | grep -m1 '\"Render/3D\"' -A3 | grep '\"busy\"' | awk '{print $2}' | tr -d ','", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                usage = std::stof(buffer);
                pclose(pipe);
                if (usage >= 0.0f && usage <= 100.0f) {
                    return usage;
                }
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Fallback: Intel GPU frequency-based estimation (less accurate)
    for (int cardNum = 0; cardNum <= 2; cardNum++) {
        std::string basePath = "/sys/class/drm/card" + std::to_string(cardNum);
        std::ifstream curFreq(basePath + "/gt_cur_freq_mhz");
        std::ifstream minFreq(basePath + "/gt_min_freq_mhz");
        std::ifstream maxFreq(basePath + "/gt_max_freq_mhz");
        
        if (curFreq.is_open() && minFreq.is_open() && maxFreq.is_open()) {
            int cur, min, max;
            curFreq >> cur;
            minFreq >> min;
            maxFreq >> max;
            
            if (max > min && cur >= min) {
                // Calculate usage percentage based on frequency
                float percent = 100.0f * (float)(cur - min) / (float)(max - min);
                return std::min(100.0f, std::max(0.0f, percent));
            }
        }
    }
    
    return -1.0f; // Return -1 to indicate no GPU found
}

// Get GPU power consumption in Watts
float getGpuPower() {
    // Method 1: Try NVIDIA GPU first
    FILE* pipe = popen("nvidia-smi --query-gpu=power.draw --format=csv,noheader,nounits 2>/dev/null", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                float power = std::stof(buffer);
                pclose(pipe);
                if (power > 0.0f) return power;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Method 2: Try AMD GPU via rocm-smi
    pipe = popen("rocm-smi --showpower 2>/dev/null | grep 'Average Graphics Package Power' | awk '{print $NF}' | tr -d 'W'", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                float power = std::stof(buffer);
                pclose(pipe);
                if (power > 0.0f) return power;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Method 3: Try Intel GPU via sysfs hwmon
    pipe = popen("cat /sys/class/drm/card*/device/hwmon/hwmon*/power1_average 2>/dev/null | head -1", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                // sysfs reports in microwatts, convert to watts
                long long microwatts = std::stoll(buffer);
                pclose(pipe);
                float power = microwatts / 1000000.0f;
                if (power > 0.0f) return power;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Method 4: Try intel_gpu_top (fallback)
    pipe = popen("timeout 0.5 intel_gpu_top -J -s 100 2>/dev/null | grep -m1 '\"power\"' -A3 | grep '\"GPU\"' | awk '{print $2}' | tr -d ','", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                float power = std::stof(buffer);
                pclose(pipe);
                if (power > 0.0f) return power;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Fallback: Estimate power based on GPU usage if no sensor available
    // Intel integrated GPUs typically use 5-15W idle, 15-50W under load
    if (appState.gpuUsage > 0.0f) {
        // Base power: 5W idle + usage-based dynamic power
        // Arrow Lake-S integrated GPU: ~5W idle, up to ~45W max
        float basePower = 5.0f;  // Idle power
        float maxDynamicPower = 40.0f;  // Max additional power under load
        float estimatedPower = basePower + (appState.gpuUsage / 100.0f) * maxDynamicPower;
        return estimatedPower;
    }
    
    return 0.0f;
}

// Get GPU memory bandwidth (estimated from usage and frequency)
// For Intel integrated GPUs, bandwidth is typically 50-100 GB/s depending on model
float getGpuMemBandwidth() {
    // Try to estimate from GPU usage - this is a rough approximation
    // Real bandwidth measurement would require perf counters
    float usage = appState.gpuUsage;
    if (usage > 0.0f) {
        // Intel Xe Graphics (Arrow Lake) typical: ~70 GB/s peak
        // Scale with usage percentage
        return (usage / 100.0f) * 70.0f;
    }
    return 0.0f;
}

// Get current network bandwidth in MB/s
float getNetworkBandwidth() {
    static unsigned long long lastRxBytes = 0;
    static unsigned long long lastTxBytes = 0;
    static auto lastTime = std::chrono::steady_clock::now();
    
    unsigned long long totalRxBytes = 0;
    unsigned long long totalTxBytes = 0;
    
    // Read all network interfaces from /proc/net/dev
    std::ifstream netDev("/proc/net/dev");
    if (!netDev.is_open()) return 0.0f;
    
    std::string line;
    // Skip header lines
    std::getline(netDev, line);
    std::getline(netDev, line);
    
    while (std::getline(netDev, line)) {
        // Parse interface line: "  eth0: bytes packets ..."
        size_t colonPos = line.find(':');
        if (colonPos == std::string::npos) continue;
        
        std::string interface = line.substr(0, colonPos);
        // Trim whitespace
        interface.erase(0, interface.find_first_not_of(" \t"));
        interface.erase(interface.find_last_not_of(" \t") + 1);
        
        // Skip loopback interface
        if (interface == "lo") continue;
        
        std::istringstream ss(line.substr(colonPos + 1));
        unsigned long long rxBytes, rxPackets, rxErrs, rxDrop, rxFifo, rxFrame, rxCompressed, rxMulticast;
        unsigned long long txBytes, txPackets, txErrs, txDrop, txFifo, txColls, txCarrier, txCompressed;
        
        ss >> rxBytes >> rxPackets >> rxErrs >> rxDrop >> rxFifo >> rxFrame >> rxCompressed >> rxMulticast
           >> txBytes >> txPackets >> txErrs >> txDrop >> txFifo >> txColls >> txCarrier >> txCompressed;
        
        totalRxBytes += rxBytes;
        totalTxBytes += txBytes;
    }
    netDev.close();
    
    auto currentTime = std::chrono::steady_clock::now();
    float elapsedSeconds = std::chrono::duration<float>(currentTime - lastTime).count();
    
    if (lastRxBytes == 0 || elapsedSeconds < 0.1f) {
        // First run or too soon
        lastRxBytes = totalRxBytes;
        lastTxBytes = totalTxBytes;
        lastTime = currentTime;
        return 0.0f;
    }
    
    // Calculate bandwidth in MB/s (both RX + TX)
    unsigned long long rxDiff = totalRxBytes - lastRxBytes;
    unsigned long long txDiff = totalTxBytes - lastTxBytes;
    unsigned long long totalDiff = rxDiff + txDiff;
    
    float bandwidthMBs = (totalDiff / elapsedSeconds) / (1024.0f * 1024.0f);
    
    lastRxBytes = totalRxBytes;
    lastTxBytes = totalTxBytes;
    lastTime = currentTime;
    
    return bandwidthMBs;
}

// Check if NPU is available in system
bool detectNPU() {
    // Try Intel NPU via /dev/accel (Arrow Lake, Meteor Lake)
    std::ifstream accelDevice("/sys/class/accel/accel0/device/uevent");
    if (accelDevice.is_open()) {
        accelDevice.close();
        return true;
    }
    
    // Try older Intel NPU path
    FILE* pipe = popen("ls /sys/class/npu/*/utilization 2>/dev/null | head -1", "r");
    if (pipe) {
        char buffer[256];
        bool found = (fgets(buffer, sizeof(buffer), pipe) != nullptr);
        pclose(pipe);
        if (found) return true;
    }
    
    // Try AMD AI Engine
    pipe = popen("ls /sys/class/amd_ai/*/utilization 2>/dev/null | head -1", "r");
    if (pipe) {
        char buffer[256];
        bool found = (fgets(buffer, sizeof(buffer), pipe) != nullptr);
        pclose(pipe);
        if (found) return true;
    }
    
    return false; // No NPU found
}

// Get NPU usage (Neural Processing Unit - Intel, AMD, Qualcomm)
float getNpuUsage() {
    // Try Intel NPU via /dev/accel (Arrow Lake, Meteor Lake)
    // Check if NPU device exists
    std::ifstream accelDevice("/sys/class/accel/accel0/device/uevent");
    if (accelDevice.is_open()) {
        accelDevice.close();
        
        // Intel NPU detected - try to get utilization from debugfs
        std::ifstream npuUtil("/sys/kernel/debug/accel/accel0/bo_info");
        if (npuUtil.is_open()) {
            // NPU is present and accessible
            // For now, return 0 as baseline (proper metrics need kernel support)
            return 0.0f;
        }
        
        // Try alternative path for NPU stats
        std::ifstream npuPower("/sys/class/accel/accel0/device/power_state");
        if (npuPower.is_open()) {
            std::string state;
            npuPower >> state;
            // If powered on, estimate some usage
            if (state == "D0") {
                return 0.0f; // Active but no load metric available
            }
        }
        
        // NPU exists but can't read metrics - return 0 to show it's there
        return 0.0f;
    }
    
    // Try older Intel NPU path
    FILE* pipe = popen("cat /sys/class/npu/*/utilization 2>/dev/null", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                float usage = std::stof(buffer);
                pclose(pipe);
                return usage;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    // Try AMD AI Engine
    pipe = popen("cat /sys/class/amd_ai/*/utilization 2>/dev/null", "r");
    if (pipe) {
        char buffer[128];
        if (fgets(buffer, sizeof(buffer), pipe)) {
            try {
                float usage = std::stof(buffer);
                pclose(pipe);
                return usage;
            } catch (...) {}
        }
        pclose(pipe);
    }
    
    return -1.0f; // Return -1 to indicate no NPU found
}

// Bandwidth test - measure disk read speed
float testDiskBandwidth(const std::string& path) {
    std::string testFile = path + "/.fileduper_bandwidth_test.tmp";
    const size_t testSize = 100 * 1024 * 1024; // 100 MB test
    const size_t bufferSize = 1024 * 1024; // 1 MB buffer
    
    std::cout << "[Bandwidth] Testing disk bandwidth for: " << path << std::endl;
    
    // Write test
    auto startWrite = std::chrono::high_resolution_clock::now();
    {
        std::ofstream out(testFile, std::ios::binary);
        if (!out.is_open()) {
            std::cout << "[Bandwidth] Cannot create test file, using default" << std::endl;
            return 500.0f; // Default 500 MB/s
        }
        
        std::vector<char> buffer(bufferSize, 'X');
        for (size_t written = 0; written < testSize; written += bufferSize) {
            out.write(buffer.data(), bufferSize);
        }
    }
    auto endWrite = std::chrono::high_resolution_clock::now();
    
    // Read test
    auto startRead = std::chrono::high_resolution_clock::now();
    {
        std::ifstream in(testFile, std::ios::binary);
        if (in.is_open()) {
            std::vector<char> buffer(bufferSize);
            while (in.read(buffer.data(), bufferSize)) {
                // Just read, measure speed
            }
        }
    }
    auto endRead = std::chrono::high_resolution_clock::now();
    
    // Calculate speeds
    auto writeDuration = std::chrono::duration_cast<std::chrono::milliseconds>(endWrite - startWrite).count();
    auto readDuration = std::chrono::duration_cast<std::chrono::milliseconds>(endRead - startRead).count();
    
    float writeSpeed = (float)testSize / (writeDuration / 1000.0f) / (1024.0f * 1024.0f);
    float readSpeed = (float)testSize / (readDuration / 1000.0f) / (1024.0f * 1024.0f);
    
    // Clean up
    std::remove(testFile.c_str());
    
    float bandwidth = std::min(writeSpeed, readSpeed); // Use slower of the two
    std::cout << "[Bandwidth] Write: " << writeSpeed << " MB/s, Read: " << readSpeed 
              << " MB/s, Using: " << bandwidth << " MB/s" << std::endl;
    
    return bandwidth;
}

// Auto-tune performance based on bandwidth
void autoTunePerformance(float bandwidth) {
    std::cout << "[Auto-Tune] Bandwidth: " << bandwidth << " MB/s" << std::endl;
    
    // Very slow (USB 2.0, slow HDD) - < 50 MB/s
    if (bandwidth < 50.0f) {
        appState.threadCount = 2;
        appState.bufferSize = 4096; // 4 KB
        std::cout << "[Auto-Tune] SLOW storage detected: 2 threads, 4KB buffer" << std::endl;
    }
    // Moderate (HDD, USB 3.0) - 50-150 MB/s
    else if (bandwidth < 150.0f) {
        appState.threadCount = 4;
        appState.bufferSize = 8192; // 8 KB
        std::cout << "[Auto-Tune] MODERATE storage detected: 4 threads, 8KB buffer" << std::endl;
    }
    // Fast (SATA SSD) - 150-500 MB/s
    else if (bandwidth < 500.0f) {
        appState.threadCount = 8;
        appState.bufferSize = 16384; // 16 KB
        std::cout << "[Auto-Tune] FAST storage detected: 8 threads, 16KB buffer" << std::endl;
    }
    // Very Fast (NVMe SSD) - > 500 MB/s
    else {
        appState.threadCount = std::thread::hardware_concurrency();
        appState.bufferSize = 65536; // 64 KB
        std::cout << "[Auto-Tune] NVME storage detected: " << appState.threadCount 
                  << " threads, 64KB buffer" << std::endl;
    }
}

// ============================================================================
// HASH ALGORITHMS - Multi-Algorithm Support
// ============================================================================

// Simple xxHash64 implementation (fast, non-cryptographic)
// Check if AVX2 is available at runtime
inline bool hasAVX2Support() {
    static int avx2_available = -1;
    if (avx2_available == -1) {
        #if defined(__x86_64__) || defined(_M_X64)
        __builtin_cpu_init();
        avx2_available = __builtin_cpu_supports("avx2") ? 1 : 0;
        #else
        avx2_available = 0;
        #endif
    }
    return avx2_available == 1;
}

// AVX2-optimized xxHash64 for large blocks (requires AVX2 support)
#if defined(__AVX2__)
#include <immintrin.h>

inline uint64_t xxHash64_avx2(const unsigned char* data, size_t len) {
    const uint64_t PRIME64_1 = 11400714785074694791ULL;
    const uint64_t PRIME64_2 = 14029467366897019727ULL;
    const uint64_t PRIME64_3 = 1609587929392839161ULL;
    const uint64_t PRIME64_4 = 9650029242287828579ULL;
    const uint64_t PRIME64_5 = 2870177450012600261ULL;
    
    uint64_t hash = PRIME64_5 + len;
    const unsigned char* end = data + len;
    
    // Process 32-byte chunks with AVX2
    if (len >= 32) {
        __m256i acc = _mm256_set1_epi64x(hash);
        const __m256i prime1 = _mm256_set1_epi64x(PRIME64_1);
        const __m256i prime2 = _mm256_set1_epi64x(PRIME64_2);
        
        while (data + 32 <= end) {
            __m256i chunk = _mm256_loadu_si256((__m256i*)data);
            
            // Mix with primes
            chunk = _mm256_mul_epu32(chunk, prime1);
            acc = _mm256_xor_si256(acc, chunk);
            
            // Rotate bits (emulated with shifts)
            __m256i left = _mm256_slli_epi64(acc, 11);
            __m256i right = _mm256_srli_epi64(acc, 53);
            acc = _mm256_or_si256(left, right);
            
            acc = _mm256_mul_epu32(acc, prime2);
            
            data += 32;
        }
        
        // Combine 4 x 64-bit lanes
        uint64_t tmp[4];
        _mm256_storeu_si256((__m256i*)tmp, acc);
        hash = tmp[0] ^ tmp[1] ^ tmp[2] ^ tmp[3];
    }
    
    // Process remaining bytes
    while (data < end) {
        hash ^= (*data++) * PRIME64_1;
        hash = ((hash << 11) | (hash >> 53)) * PRIME64_2;
    }
    
    // Final mix
    hash ^= hash >> 33;
    hash *= PRIME64_3;
    hash ^= hash >> 29;
    hash *= PRIME64_4;
    hash ^= hash >> 32;
    
    return hash;
}
#endif

// Fallback simple xxHash64 implementation
inline uint64_t xxHash64_simple(const unsigned char* data, size_t len) {
    const uint64_t PRIME64_1 = 11400714785074694791ULL;
    const uint64_t PRIME64_2 = 14029467366897019727ULL;
    const uint64_t PRIME64_3 = 1609587929392839161ULL;
    const uint64_t PRIME64_4 = 9650029242287828579ULL;
    const uint64_t PRIME64_5 = 2870177450012600261ULL;
    
    uint64_t hash = PRIME64_5 + len;
    
    for (size_t i = 0; i < len; i++) {
        hash ^= data[i] * PRIME64_1;
        hash = (hash << 11) | (hash >> 53);
        hash *= PRIME64_2;
    }
    
    hash ^= hash >> 33;
    hash *= PRIME64_3;
    hash ^= hash >> 29;
    hash *= PRIME64_4;
    hash ^= hash >> 32;
    
    return hash;
}

// Smart dispatcher: use AVX2 version if available and data is large enough
inline uint64_t xxHash64_optimized(const unsigned char* data, size_t len) {
    #if defined(__AVX2__)
    // Use AVX2 for chunks >= 128 bytes (overhead is worth it)
    if (len >= 128 && hasAVX2Support()) {
        return xxHash64_avx2(data, len);
    }
    #endif
    return xxHash64_simple(data, len);
}

// Auto-detect best hash algorithm based on file type, size and hardware
// Only uses IMPLEMENTED algorithms: XXHASH64, XXHASH3, MD5
// xxHash3 is 20-30% faster than xxHash64 on modern CPUs with SIMD/AVX2
std::string detectBestHashAlgorithm(const std::string& filepath, long long fileSize, const std::string& hardware) {
    // Get file extension
    std::string ext = "";
    size_t dotPos = filepath.find_last_of('.');
    if (dotPos != std::string::npos) {
        ext = filepath.substr(dotPos + 1);
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
    }
    
    // Check if AVX2 is available (runtime detection)
    bool hasAVX2 = appState.avx2ForceEnabled || hasAVX2Support();
    
    // Select algorithm based on AVX2 availability
    std::string fastHash = hasAVX2 ? "XXHASH3" : "XXHASH64";
    
    // Apply AVX2 Performance Profile
    if (appState.avx2Profile == "Maximum") {
        // MAXIMUM PERFORMANCE: AVX2 for almost everything
        // Only skip AVX2 for ultra-tiny files (overhead too high)
        if (fileSize < appState.avx2MinFileSize) {
            return "MD5"; // Files < 4KB: MD5 is faster due to AVX2 overhead
        }
        return fastHash; // Everything else: XXHASH3 with AVX2 boost!
        
    } else if (appState.avx2Profile == "Balanced") {
        // BALANCED: AVX2 for media & large files, MD5 for archives/docs
        
        // Small files - MD5 for compatibility
        if (fileSize < 100 * 1024) {
            return "MD5";
        }
        
        // Media files - always use AVX2 (performance critical)
        if (ext == "mp4" || ext == "mkv" || ext == "avi" || ext == "mov" || ext == "wmv" || ext == "flv" || ext == "webm" || ext == "m4v" ||
            ext == "jpg" || ext == "jpeg" || ext == "png" || ext == "gif" || ext == "bmp" || ext == "webp" || ext == "tiff" || ext == "svg" || ext == "raw" ||
            ext == "mp3" || ext == "flac" || ext == "wav" || ext == "ogg" || ext == "m4a" || ext == "aac" || ext == "wma" || ext == "opus") {
            return fastHash;
        }
        
        // Archives - MD5 for compatibility with stored checksums
        if (ext == "zip" || ext == "rar" || ext == "7z" || ext == "tar" || ext == "gz" || ext == "bz2" || ext == "xz" || ext == "iso") {
            return "MD5";
        }
        
        // Executables/Binaries - MD5 for security comparison
        if (ext == "exe" || ext == "dll" || ext == "so" || ext == "dylib" || ext == "bin" || ext == "app") {
            return "MD5";
        }
        
        // Documents - MD5 for compatibility
        if (ext == "pdf" || ext == "doc" || ext == "docx" || ext == "txt" || ext == "odt" || ext == "rtf" || ext == "xls" || ext == "xlsx") {
            return "MD5";
        }
        
        // Large unknown files - use AVX2
        if (fileSize > 10LL * 1024 * 1024) {
            return fastHash;
        }
        
        return "MD5"; // Default for balanced: compatibility
        
    } else { // "Compatible" mode
        // COMPATIBLE: Mostly MD5, AVX2 only for huge files and videos
        
        // Very large files (>1GB) - use AVX2 for speed
        if (fileSize > 1024LL * 1024 * 1024) {
            return fastHash;
        }
        
        // Large video files (>100MB) - use AVX2
        if (fileSize > 100LL * 1024 * 1024 && 
            (ext == "mp4" || ext == "mkv" || ext == "avi" || ext == "mov" || ext == "wmv" || ext == "flv" || ext == "webm" || ext == "m4v")) {
            return fastHash;
        }
        
        // Everything else: MD5 for maximum compatibility
        return "MD5";
    }
}

// Universal hash calculator with algorithm selection
std::string calculateHash(const std::string& filepath, const std::string& algorithm = "AUTO") {
    // First, get file size and decide on strategy
    struct stat st;
    if (stat(filepath.c_str(), &st) != 0) return "";
    
    // OPTIMIZATION: Check hash cache first (if enabled)
    if (appState.cacheFileHashes) {
        std::pair<ino_t, time_t> cacheKey = {st.st_ino, st.st_mtime};
        
        std::lock_guard<std::mutex> lock(hashCacheMutex);
        auto it = hashCache.find(cacheKey);
        if (it != hashCache.end()) {
            // Cache hit! Return cached hash
            return it->second;
        }
    }
    
    // OPTIMIZATION: Try memory mapping for large files (> 1MB)
    const long long MMAP_THRESHOLD = 1024 * 1024; // 1 MB
    bool useMmap = false;
    void* mappedData = nullptr;
    int fd = -1;
    long long fileSize = st.st_size;
    
    // Determine algorithm
    std::string algo = algorithm;
    if (algo == "AUTO") {
        algo = detectBestHashAlgorithm(filepath, st.st_size, "CPU");
    }
    // Always update current hash algo for display
    appState.currentHashAlgo = algo;
    
    // Try memory mapping if enabled and file is large enough
    if (appState.useMemoryMapping && fileSize >= MMAP_THRESHOLD) {
        fd = open(filepath.c_str(), O_RDONLY);
        if (fd != -1) {
            mappedData = mmap(nullptr, fileSize, PROT_READ, MAP_PRIVATE, fd, 0);
            if (mappedData != MAP_FAILED) {
                useMmap = true;
                
                // OPTIMIZATION: Advise kernel about sequential access
                if (appState.useAsyncIO) {
                    madvise(mappedData, fileSize, MADV_SEQUENTIAL | MADV_WILLNEED);
                }
            } else {
                close(fd);
                fd = -1;
            }
        }
    }
    
    std::stringstream ss;
    
    if (useMmap && mappedData) {
        // MEMORY MAPPED PATH - faster for large files
        unsigned char* data = static_cast<unsigned char*>(mappedData);
        
        if (algo == "XXHASH64" || algo == "XXHASH3") {
            uint64_t hash = 0;
            const size_t chunkSize = 1048576; // 1 MB chunks for better I/O performance
            
            for (long long offset = 0; offset < fileSize; offset += chunkSize) {
                size_t bytesToProcess = std::min((long long)chunkSize, fileSize - offset);
                uint64_t chunk_hash = xxHash64_optimized(data + offset, bytesToProcess);
                hash ^= chunk_hash;
                hash = (hash << 13) | (hash >> 51);
            }
            
            ss << std::hex << std::setw(16) << std::setfill('0') << hash;
        }
        else if (algo == "MD5") {
            MD5_CTX md5Context;
            MD5_Init(&md5Context);
            
            const size_t chunkSize = 1048576; // 1 MB chunks for better I/O performance
            for (long long offset = 0; offset < fileSize; offset += chunkSize) {
                size_t bytesToProcess = std::min((long long)chunkSize, fileSize - offset);
                MD5_Update(&md5Context, data + offset, bytesToProcess);
            }
            
            unsigned char result[MD5_DIGEST_LENGTH];
            MD5_Final(result, &md5Context);
            
            for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
                ss << std::hex << std::setw(2) << std::setfill('0') << (int)result[i];
            }
        }
        else {
            // Other algorithms - use MD5 fallback
            MD5_CTX md5Context;
            MD5_Init(&md5Context);
            
            const size_t chunkSize = 1048576; // 1 MB chunks for better I/O performance
            for (long long offset = 0; offset < fileSize; offset += chunkSize) {
                size_t bytesToProcess = std::min((long long)chunkSize, fileSize - offset);
                MD5_Update(&md5Context, data + offset, bytesToProcess);
            }
            
            unsigned char result[MD5_DIGEST_LENGTH];
            MD5_Final(result, &md5Context);
            
            ss << algo << ":";
            for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
                ss << std::hex << std::setw(2) << std::setfill('0') << (int)result[i];
            }
        }
        
        // Cleanup mmap
        munmap(mappedData, fileSize);
        close(fd);
    }
    else {
        // TRADITIONAL FILE I/O PATH
        FILE* file = fopen(filepath.c_str(), "rb");
        if (!file) return "";
        
        // OPTIMIZATION: Use async I/O hints if enabled
        if (appState.useAsyncIO) {
            int fd = fileno(file);
            if (fd != -1) {
                posix_fadvise(fd, 0, 0, POSIX_FADV_SEQUENTIAL | POSIX_FADV_WILLNEED);
            }
        }
        
        if (algo == "XXHASH64" || algo == "XXHASH3") {
            // xxHash64/xxHash3 - ultra fast with AVX2 optimization
            uint64_t hash = 0;
            unsigned char buffer[1048576]; // 1 MB buffer for better I/O performance
            size_t bytesRead;
            
            while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) != 0) {
                uint64_t chunk_hash = xxHash64_optimized(buffer, bytesRead);
                hash ^= chunk_hash;
                hash = (hash << 13) | (hash >> 51);
            }
            
            ss << std::hex << std::setw(16) << std::setfill('0') << hash;
        }
        else if (algo == "MD5") {
            // MD5 - fast, widely used
            MD5_CTX md5Context;
            MD5_Init(&md5Context);
            
            unsigned char buffer[1048576]; // 1 MB buffer for better I/O performance
            size_t bytesRead;
            
            while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) != 0) {
                MD5_Update(&md5Context, buffer, bytesRead);
            }
            
            unsigned char result[MD5_DIGEST_LENGTH];
            MD5_Final(result, &md5Context);
            
            for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
                ss << std::hex << std::setw(2) << std::setfill('0') << (int)result[i];
            }
        }
        else if (algo == "SHA256" || algo == "SHA512" || algo == "BLAKE2B" || algo == "BLAKE3") {
            // Für produktiven Code würde man hier OpenSSL's SHA256/512, libsodium's BLAKE2/3 nutzen
            // Fallback auf MD5 für jetzt
            MD5_CTX md5Context;
            MD5_Init(&md5Context);
            
            unsigned char buffer[1048576]; // 1 MB buffer for better I/O performance
            size_t bytesRead;
            
            while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) != 0) {
                MD5_Update(&md5Context, buffer, bytesRead);
            }
            
            unsigned char result[MD5_DIGEST_LENGTH];
            MD5_Final(result, &md5Context);
            
            ss << algo << ":"; // Prefix mit Algorithmus-Name
            for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
                ss << std::hex << std::setw(2) << std::setfill('0') << (int)result[i];
            }
        }
        else {
            // Unknown algorithm - fallback to MD5
            MD5_CTX md5Context;
            MD5_Init(&md5Context);
            
            unsigned char buffer[1048576]; // 1 MB buffer for better I/O performance
            size_t bytesRead;
            
            while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) != 0) {
                MD5_Update(&md5Context, buffer, bytesRead);
            }
            
            unsigned char result[MD5_DIGEST_LENGTH];
            MD5_Final(result, &md5Context);
            
            for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
                ss << std::hex << std::setw(2) << std::setfill('0') << (int)result[i];
            }
        }
        
        fclose(file);
    }
    
    std::string hashResult = ss.str();
    
    // OPTIMIZATION: Store hash in hash cache (if enabled)
    if (appState.cacheFileHashes && !hashResult.empty()) {
        std::pair<ino_t, time_t> cacheKey = {st.st_ino, st.st_mtime};
        
        std::lock_guard<std::mutex> lock(hashCacheMutex);
        hashCache[cacheKey] = hashResult;
    }
    
    // CACHE: Update file cache with computed hash (for both local and FTP files)
    {
        std::lock_guard<std::mutex> lock(fileCacheMutex);
        auto it = fileCache.find(filepath);
        if (it != fileCache.end()) {
            it->second.hash = hashResult;
        }
    }
    
    return hashResult;
}

// Legacy MD5 function for compatibility
std::string calculateMD5(const std::string& filepath) {
    return calculateHash(filepath, "MD5");
}

// Apply optimal CURL settings for FTP operations
void applyOptimalCurlSettings(CURL* curl) {
    // Buffer size optimization - CRITICAL for performance!
    // Use configured buffer size (default: 500 KB, max: 512000)
    long bufferSize = std::min(512000L, (long)appState.curlBufferSize);
    curl_easy_setopt(curl, CURLOPT_BUFFERSIZE, bufferSize);
    curl_easy_setopt(curl, CURLOPT_UPLOAD_BUFFERSIZE, bufferSize);
    
    // TCP optimizations
    curl_easy_setopt(curl, CURLOPT_TCP_NODELAY, 1L);          // Disable Nagle (instant send)
    curl_easy_setopt(curl, CURLOPT_TCP_FASTOPEN, 1L);         // TCP Fast Open if available
    
    // Connection reuse optimization
    curl_easy_setopt(curl, CURLOPT_FRESH_CONNECT, 0L);        // Reuse connections
    curl_easy_setopt(curl, CURLOPT_FORBID_REUSE, 0L);
    
    // OPTIMIZATION: Max parallel connections per server (8 default)
    if (appState.ftpReuseConnections) {
        curl_easy_setopt(curl, CURLOPT_MAXCONNECTS, (long)appState.ftpMaxConnections);
    }
    
    // Keep-Alive settings
    if (appState.ftpKeepAlive) {
        curl_easy_setopt(curl, CURLOPT_TCP_KEEPALIVE, 1L);
        curl_easy_setopt(curl, CURLOPT_TCP_KEEPIDLE, 20L);    // Start after 20s idle
        curl_easy_setopt(curl, CURLOPT_TCP_KEEPINTVL, 5L);    // 5s between probes
    }
    
    // HTTP/FTP Pipelining for parallel requests
    if (appState.ftpPipelining) {
        curl_easy_setopt(curl, CURLOPT_PIPEWAIT, 1L);         // Wait for pipelining
    }
    
    // Timeout settings from AppState
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, (long)appState.ftpConnectTimeout);
    curl_easy_setopt(curl, CURLOPT_FTP_RESPONSE_TIMEOUT, (long)appState.ftpResponseTimeout);
}

// Callback for calculating MD5 from streamed FTP data
struct FtpHashData {
    MD5_CTX md5Context;
    long long bytesRead;
};

static size_t FtpHashCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    FtpHashData* hashData = (FtpHashData*)userp;
    size_t realsize = size * nmemb;
    MD5_Update(&hashData->md5Context, contents, realsize);
    hashData->bytesRead += realsize;
    
    // Track actual file download traffic for network bandwidth
    appState.ftpBytesTransferred += realsize;
    
    return realsize;
}

// URL-encode a string (for FTP paths with spaces, etc.)
std::string urlEncode(const std::string& value) {
    std::ostringstream escaped;
    escaped.fill('0');
    escaped << std::hex;

    for (char c : value) {
        // Keep alphanumeric and other safe characters intact
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~' || c == '/') {
            escaped << c;
        } else {
            // Encode everything else as %XX
            escaped << '%' << std::setw(2) << int((unsigned char)c);
        }
    }

    return escaped.str();
}

// Delete FTP file
bool deleteFtpFile(const std::string& ftpUrl, const std::string& username, const std::string& password) {
    CURL* curl = curl_easy_init();
    if (!curl) {
        std::cerr << "[FTP DELETE] Failed to init CURL" << std::endl;
        return false;
    }
    
    std::cout << "[FTP DELETE] Original URL: " << ftpUrl << std::endl;
    
    // Extract full path from URL (after host:port)
    std::string fullPath;
    size_t pathStart = ftpUrl.find("://");
    if (pathStart != std::string::npos) {
        pathStart = ftpUrl.find('/', pathStart + 3);
        if (pathStart != std::string::npos) {
            fullPath = ftpUrl.substr(pathStart); // /share/Jan/Jana/.../file.mp3
        }
    }
    
    std::cout << "[FTP DELETE] Full path: " << fullPath << std::endl;
    
    // Extract base URL (ftp://host:port)
    std::string baseUrl = ftpUrl.substr(0, ftpUrl.find("://") + 3);
    size_t hostEnd = ftpUrl.find('/', baseUrl.length());
    if (hostEnd != std::string::npos) {
        baseUrl = ftpUrl.substr(0, hostEnd);
    }
    
    // Prepare DELE command with FULL PATH
    struct curl_slist* headerlist = NULL;
    std::string deleteCmd = "DELE " + fullPath;
    headerlist = curl_slist_append(headerlist, deleteCmd.c_str());
    
    std::cout << "[FTP DELETE] Base URL: " << baseUrl << std::endl;
    std::cout << "[FTP DELETE] Command: " << deleteCmd << std::endl;
    
    curl_easy_setopt(curl, CURLOPT_URL, baseUrl.c_str());
    curl_easy_setopt(curl, CURLOPT_USERNAME, username.c_str());
    curl_easy_setopt(curl, CURLOPT_PASSWORD, password.c_str());
    curl_easy_setopt(curl, CURLOPT_QUOTE, headerlist);
    curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L); // Debug output
    
    CURLcode res = curl_easy_perform(curl);
    
    if (res != CURLE_OK) {
        std::cerr << "[FTP DELETE] CURL error: " << curl_easy_strerror(res) << std::endl;
    } else {
        std::cout << "[FTP DELETE] SUCCESS!" << std::endl;
    }
    
    curl_slist_free_all(headerlist);
    curl_easy_cleanup(curl);
    
    return (res == CURLE_OK);
}

// Helper: Delete file (local or FTP)
bool deleteFile(const std::string& filepath) {
    // Check if it's an FTP file
    if (isFtpFile(filepath)) {
        std::cout << "[DELETE] FTP file detected: " << filepath << std::endl;
        
        // File already contains full FTP URL (ftp://host:port/path)
        // Find active FTP preset for credentials
        if (appState.connectedPresetIndex >= 0 && 
            appState.connectedPresetIndex < (int)appState.ftpPresets.size()) {
            const auto& preset = appState.ftpPresets[appState.connectedPresetIndex];
            
            std::cout << "[DELETE] Using FTP URL: " << filepath << std::endl;
            std::cout << "[DELETE] User: " << preset.username << std::endl;
            
            bool result = deleteFtpFile(filepath, preset.username, preset.password);
            std::cout << "[DELETE] FTP delete result: " << (result ? "SUCCESS" : "FAILED") << std::endl;
            return result;
        }
        std::cerr << "[DELETE] ERROR: No active FTP connection (connectedPresetIndex=" 
                  << appState.connectedPresetIndex << ")" << std::endl;
        return false;
    } else {
        // Local file
        std::cout << "[DELETE] Local file: " << filepath << std::endl;
        bool result = (remove(filepath.c_str()) == 0);
        if (!result) {
            std::cerr << "[DELETE] Failed to remove local file: " << strerror(errno) << std::endl;
        }
        return result;
    }
}

// Calculate MD5 hash of FTP file (streaming) - OPTIMIZED with retry logic
std::string calculateMD5FromFTP(const std::string& ftpUrl, const std::string& username, const std::string& password, long long fileSize = 0) {
    // Thread-safe error logging mutex
    static std::mutex ftpHashErrorMutex;
    
    // Retry loop with exponential backoff
    int maxRetries = appState.ftpHashRetries; // Default: 3
    
    // ADAPTIVE TIMEOUT: Scale with file size (assumes ~10 MB/s network speed)
    // Small files (< 100 MB): Use configured timeout (5s default)
    // Large files (> 100 MB): Calculate based on size (10 seconds per 100 MB)
    int timeout = appState.ftpHashTimeout;    // Default: 5 seconds
    if (fileSize > 100 * 1024 * 1024) {  // > 100 MB
        // ADAPTIVE TIMEOUT: Scale with file size
        // Calculate timeout: 10s per 100MB, minimum = configured timeout
        // Assumes ~10 MB/s network speed (conservative for FTP)
        int calculatedTimeout = (fileSize / (10 * 1024 * 1024)); // 10s per 10MB = 1s per MB
        timeout = std::max(timeout, calculatedTimeout);
        timeout = std::min(timeout, 300); // Cap at 5 minutes for safety
    }
    
    for (int attempt = 0; attempt < maxRetries; attempt++) {
        CURL* curl = curl_easy_init();
        if (!curl) {
            if (appState.ftpSkipFailedFiles && attempt == maxRetries - 1) {
                std::lock_guard<std::mutex> lock(ftpHashErrorMutex);
                std::cerr << "[FTP Hash] Failed to init CURL for: " << ftpUrl << std::endl;
            }
            continue;
        }
        
        // URL-encode the FTP URL to handle spaces and special characters
        std::string encodedUrl = ftpUrl;
        size_t pathStart = ftpUrl.find("://");
        if (pathStart != std::string::npos) {
            pathStart = ftpUrl.find('/', pathStart + 3); // Find path after host:port
            if (pathStart != std::string::npos) {
                std::string base = ftpUrl.substr(0, pathStart);
                std::string path = ftpUrl.substr(pathStart);
                encodedUrl = base + urlEncode(path);
            }
        }
        
        FtpHashData hashData;
        MD5_Init(&hashData.md5Context);
        hashData.bytesRead = 0;
        
        curl_easy_setopt(curl, CURLOPT_URL, encodedUrl.c_str());
        curl_easy_setopt(curl, CURLOPT_USERNAME, username.c_str());
        curl_easy_setopt(curl, CURLOPT_PASSWORD, password.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, FtpHashCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &hashData);
        
        // CRITICAL: Use CURL connection pooling for massive speedup!
        if (curlShareHandle && appState.useCurlPooling) {
            curl_easy_setopt(curl, CURLOPT_SHARE, curlShareHandle);
        }
        
        // Apply optimal CURL settings (pipelining, keep-alive, TCP optimizations)
        applyOptimalCurlSettings(curl);
        
        // OPTIMIZATION: Aggressive timeout - 5s instead of 60s
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, (long)timeout);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 2L); // 2s connect timeout
        
        // OPTIMIZATION: Low speed limit - abort if < 1KB/s for 3 seconds
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1024L);  // 1 KB/s
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 3L);      // for 3 seconds
        
        CURLcode res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        
        if (res == CURLE_OK) {
            // SUCCESS - calculate final hash
            unsigned char result[MD5_DIGEST_LENGTH];
            MD5_Final(result, &hashData.md5Context);
            
            std::stringstream ss;
            for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
                ss << std::hex << std::setw(2) << std::setfill('0') << (int)result[i];
            }
            
            return ss.str();
        }
        
        // RETRY LOGIC: Wait with exponential backoff (100ms, 200ms, 400ms)
        if (attempt < maxRetries - 1) {
            int waitMs = 100 * (1 << attempt); // 100, 200, 400 ms
            std::this_thread::sleep_for(std::chrono::milliseconds(waitMs));
        } else {
            // FINAL FAILURE: Log error only once (thread-safe)
            if (appState.ftpSkipFailedFiles) {
                std::lock_guard<std::mutex> lock(ftpHashErrorMutex);
                std::cerr << "[FTP Hash] Failed after " << maxRetries << " attempts: " 
                          << ftpUrl << " (" << curl_easy_strerror(res) << ")" << std::endl;
            }
        }
    }
    
    return ""; // Failed after all retries
}

// URL encode individual path components (not slashes)
std::string encodePathComponent(const std::string& component) {
    std::string result;
    for (char c : component) {
        if (c == ' ') {
            result += "%20";
        } else if (c == '!') {
            result += "%21";
        } else if (c == '#') {
            result += "%23";
        } else if (c == '$') {
            result += "%24";
        } else if (c == '&') {
            result += "%26";
        } else if (c == '\'') {
            result += "%27";
        } else if (c == '(') {
            result += "%28";
        } else if (c == ')') {
            result += "%29";
        } else if (c == '*') {
            result += "%2A";
        } else if (c == '+') {
            result += "%2B";
        } else if (c == ',') {
            result += "%2C";
        } else {
            result += c;
        }
    }
    return result;
}

// Encode FTP path (encode components, keep slashes)
std::string encodeFtpPath(const std::string& path) {
    std::string result;
    std::string component;
    
    for (char c : path) {
        if (c == '/') {
            if (!component.empty()) {
                result += encodePathComponent(component);
                component.clear();
            }
            result += '/';
        } else {
            component += c;
        }
    }
    
    // Don't forget last component
    if (!component.empty()) {
        result += encodePathComponent(component);
    }
    
    return result;
}

// URL-encode a path for FTP (handles spaces, umlauts, special characters)
// Preserves slashes for proper FTP path structure
std::string urlEncodePath(const std::string& path) {
    CURL* curl = curl_easy_init();
    if (!curl) return path;
    
    std::string result;
    std::istringstream pathStream(path);
    std::string segment;
    bool first = true;
    
    // Split path by '/' and encode each segment separately
    while (std::getline(pathStream, segment, '/')) {
        if (!first) {
            result += "/";
        }
        first = false;
        
        if (segment.empty()) {
            continue; // Skip empty segments (e.g., leading slash)
        }
        
        char* encoded = curl_easy_escape(curl, segment.c_str(), segment.length());
        if (encoded) {
            result += encoded;
            curl_free(encoded);
        } else {
            result += segment;
        }
    }
    
    curl_easy_cleanup(curl);
    
    // Preserve leading slash if original path had one
    if (path[0] == '/') {
        result = "/" + result;
    }
    
    return result;
}

// Get FTP directory listing with cache support
std::vector<std::string> getFtpSubdirectories(const std::string& ftpDir, const std::string& baseUrl,
                                              const std::string& username, const std::string& password,
                                              bool useCache = true) {
    // Build cache key: server:port/path
    std::string cacheKey = baseUrl + ftpDir;
    
    // Check cache first (if enabled)
    if (useCache) {
        std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
        auto it = ftpDirCache.find(cacheKey);
        if (it != ftpDirCache.end()) {
            // Check if cache is still fresh (< 24 hours old)
            time_t now = time(nullptr);
            int age_hours = (now - it->second.timestamp) / 3600;
            
            if (age_hours < 24) {
                std::cout << "[FTP Cache] Using cached directory list for: " << ftpDir 
                          << " (" << it->second.subdirs.size() << " subdirs, age: " 
                          << age_hours << "h)" << std::endl;
                return it->second.subdirs;
            } else {
                std::cout << "[FTP Cache] Cache expired for: " << ftpDir << " (age: " << age_hours << "h)" << std::endl;
            }
        }
    }
    
    // No cache or expired - fetch from server
    std::cout << "[FTP] Fetching directory list from server: " << ftpDir << std::endl;
    
    CURL* curl = curl_easy_init();
    if (!curl) return {};
    
    std::string readBuffer;
    readBuffer.reserve(65536);
    
    // Build URL
    std::string encodedPath = urlEncodePath(ftpDir);
    std::string fullUrl = baseUrl;
    if (!fullUrl.empty() && fullUrl.back() != '/') fullUrl += '/';
    if (!encodedPath.empty() && encodedPath.front() == '/') {
        encodedPath = encodedPath.substr(1);
    }
    fullUrl += encodedPath;
    if (fullUrl.back() != '/') fullUrl += "/";
    
    curl_easy_setopt(curl, CURLOPT_URL, fullUrl.c_str());
    curl_easy_setopt(curl, CURLOPT_USERNAME, username.c_str());
    curl_easy_setopt(curl, CURLOPT_PASSWORD, password.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
    applyOptimalCurlSettings(curl);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, (long)(appState.ftpResponseTimeout * 2));
    
    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    
    if (res != CURLE_OK) {
        std::cerr << "[FTP] Error fetching directory " << ftpDir << ": " << curl_easy_strerror(res) << std::endl;
        return {};
    }
    
    // Parse subdirectories
    std::vector<std::string> subdirs;
    std::istringstream iss(readBuffer);
    std::string line;
    
    while (std::getline(iss, line)) {
        if (line.empty()) continue;
        bool isDir = (line[0] == 'd');
        if (!isDir) continue;
        
        // Extract directory name
        size_t lastSpace = line.rfind(' ');
        if (lastSpace != std::string::npos) {
            std::string dirName = line.substr(lastSpace + 1);
            if (dirName != "." && dirName != "..") {
                subdirs.push_back(dirName);
            }
        }
    }
    
    // Update cache
    if (useCache) {
        std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
        FTPDirCacheEntry entry;
        entry.path = ftpDir;
        entry.subdirs = subdirs;
        entry.timestamp = time(nullptr);
        ftpDirCache[cacheKey] = std::move(entry);
        
        std::cout << "[FTP Cache] Cached " << subdirs.size() << " subdirectories for: " << ftpDir << std::endl;
        
        // Auto-save cache after update
        saveFtpDirCache();
    }
    
    return subdirs;
}

// Scan FTP directory for files recursively (max depth 20)
void scanFtpDirectory(const std::string& ftpDir, const std::string& baseUrl, 
                     const std::string& username, const std::string& password,
                     std::map<long long, std::vector<std::string>>& filesBySize,
                     int depth = 0, int maxDepth = 30) {
    if (stopScan) return;
    if (depth > maxDepth) {
        std::cout << "[FTP Scan] Max depth " << maxDepth << " reached, skipping: " << ftpDir << std::endl;
        return;
    }
    
    CURL* curl = curl_easy_init();
    if (!curl) return;
    
    std::string readBuffer;
    readBuffer.reserve(65536); // Pre-allocate 64KB buffer for large directories
    
    // Build URL - URL-encode the path to handle spaces and special characters
    std::string encodedPath = urlEncodePath(ftpDir);
    
    // Fix: Ensure baseUrl ends with / before combining with path
    std::string fullUrl = baseUrl;
    if (!fullUrl.empty() && fullUrl.back() != '/') {
        fullUrl += '/'; // Add trailing slash to baseUrl if missing
    }
    if (!encodedPath.empty() && encodedPath.front() == '/') {
        encodedPath = encodedPath.substr(1); // Remove leading slash from path to avoid double slash
    }
    fullUrl += encodedPath;
    if (fullUrl.back() != '/') fullUrl += "/";
    
    std::cout << "[FTP Scan] Depth " << depth << ": " << fullUrl << std::endl;
    
    curl_easy_setopt(curl, CURLOPT_URL, fullUrl.c_str());
    curl_easy_setopt(curl, CURLOPT_USERNAME, username.c_str());
    curl_easy_setopt(curl, CURLOPT_PASSWORD, password.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
    
    // Apply optimal CURL settings (pipelining, keep-alive, TCP optimizations)
    applyOptimalCurlSettings(curl);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, (long)(appState.ftpResponseTimeout * 2));
    
    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    
    if (res != CURLE_OK) {
        std::cerr << "[FTP Scan] Error scanning " << ftpDir << ": " << curl_easy_strerror(res) << std::endl;
        return;
    }
    
    // Parse FTP LIST output
    std::istringstream iss(readBuffer);
    std::string line;
    int fileCount = 0;
    int dirCount = 0;
    std::vector<std::string> subdirs;
    
    std::cout << "[FTP Scan] Parsing directory: " << ftpDir << std::endl;
    
    while (std::getline(iss, line) && !stopScan) {
        // Check for pause
        while (appState.scanPaused && !stopScan) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        if (stopScan) break;
        
        if (line.empty()) continue;
        
        // FTP LIST Format: -rwxrws---   1 root ftpusers  2887197 Aug 21  2013 filename.ext
        //                   drwxrws---   2 root ftpusers     4096 Jul 12 06:49 subdirname
        bool isFile = (line[0] == '-');
        bool isDir = (line[0] == 'd');
        
        if (isFile) {
            // Find filename by looking for the last occurrence of year or time pattern
            // Then everything after that is the filename
            
            // Simple regex-free approach: Find the size (big number) then skip 3 tokens (month day year/time)
            std::vector<std::string> tokens;
            std::istringstream lineStream(line);
            std::string token;
            while (lineStream >> token) {
                tokens.push_back(token);
            }
            
            // We need at least: perm(1) links(1) user(1) group(1) size(1) month(1) day(1) time/year(1) filename(1+)
            if (tokens.size() < 9) continue;
            
            // Find the size field (should be a number after user/group)
            long long fileSize = 0;
            int sizeIndex = -1;
            
            // Size is typically at index 4, but can vary
            int maxCheck = (tokens.size() < 6) ? tokens.size() : 6;
            for (int i = 3; i < maxCheck; i++) {
                bool isNumber = true;
                for (char c : tokens[i]) {
                    if (!isdigit(c)) {
                        isNumber = false;
                        break;
                    }
                }
                
                if (isNumber && !tokens[i].empty()) {
                    try {
                        fileSize = std::stoll(tokens[i]);
                        sizeIndex = i;
                        break;
                    } catch (...) {
                        continue;
                    }
                }
            }
            
            if (sizeIndex == -1) continue;
            
            // Skip empty files if setting is enabled
            if (fileSize == 0 && appState.skipEmptyFiles) continue;
            
            // Skip files with size 0 completely for deduplication
            if (fileSize == 0) continue;
            
            // Filename starts after size + 3 tokens (month day year/time)
            int filenameStartIndex = sizeIndex + 4;
            if (filenameStartIndex >= tokens.size()) continue;
            
            // Reconstruct filename (may contain spaces)
            std::string filename;
            for (int i = filenameStartIndex; i < tokens.size(); i++) {
                if (i > filenameStartIndex) filename += " ";
                filename += tokens[i];
            }
            
            if (!filename.empty()) {
                // Store full FTP URL including host and port
                std::string fullPath = baseUrl;
                if (!fullPath.empty() && fullPath.back() != '/') {
                    fullPath += '/';
                }
                std::string pathWithoutLeadingSlash = ftpDir;
                if (!pathWithoutLeadingSlash.empty() && pathWithoutLeadingSlash.front() == '/') {
                    pathWithoutLeadingSlash = pathWithoutLeadingSlash.substr(1);
                }
                fullPath += pathWithoutLeadingSlash;
                if (fullPath.back() != '/') fullPath += "/";
                fullPath += filename;
                
                // Debug: Zeige gespeicherten Pfad
                if (fileCount < 3) { // Nur für erste paar Dateien
                    std::cout << "[FTP Scan] Stored path: " << fullPath << std::endl;
                }
                
                {
                    std::lock_guard<std::mutex> lock(resultsMutex);
                    filesBySize[fileSize].push_back(fullPath);
                    fileCount++;
                    appState.filesScanned++;
                    appState.bytesProcessed += fileSize;
                }
                
                // CACHE: Store FTP file metadata for next scan (mtime not available in LIST, use 0)
                {
                    std::lock_guard<std::mutex> lock(fileCacheMutex);
                    CachedFileInfo cacheInfo;
                    cacheInfo.size = fileSize;
                    cacheInfo.mtime = 0; // FTP LIST doesn't provide mtime reliably
                    cacheInfo.inode = 0; // FTP files have no inode
                    cacheInfo.hash = ""; // Will be filled during hash calculation
                    fileCache[fullPath] = cacheInfo;
                }
            }
        } else if (isDir) {
            // Parse directory name
            std::vector<std::string> tokens;
            std::istringstream lineStream(line);
            std::string token;
            while (lineStream >> token) {
                tokens.push_back(token);
            }
            
            if (tokens.size() < 9) continue;
            
            // Find size field to skip to filename
            int sizeIndex = -1;
            for (int i = 3; i < 6 && i < tokens.size(); i++) {
                bool isNumber = true;
                for (char c : tokens[i]) {
                    if (!isdigit(c)) {
                        isNumber = false;
                        break;
                    }
                }
                if (isNumber && !tokens[i].empty()) {
                    sizeIndex = i;
                    break;
                }
            }
            
            if (sizeIndex == -1) continue;
            
            // Directory name starts after size + 3 tokens
            int dirnameStartIndex = sizeIndex + 4;
            if (dirnameStartIndex >= tokens.size()) continue;
            
            std::string dirname;
            for (int i = dirnameStartIndex; i < tokens.size(); i++) {
                if (i > dirnameStartIndex) dirname += " ";
                dirname += tokens[i];
            }
            
            // Ignore . and ..
            if (dirname != "." && dirname != ".." && !dirname.empty()) {
                std::string subdirPath = ftpDir;
                if (subdirPath.back() != '/') subdirPath += "/";
                subdirPath += dirname;
                subdirs.push_back(subdirPath);
                dirCount++;
                
                // NOTE: serverDirectories wird NUR beim Connect gefüllt, nicht während des Scans
                // Dies verhindert, dass bei jedem Scan neue Verzeichnisse hinzugefügt werden
                std::cout << "[FTP Scan]   Found subdir: " << dirname << std::endl;
            }
        }
    }
    
    std::cout << "[FTP Scan] Found " << fileCount << " files and " << dirCount << " subdirectories in " << ftpDir << " (depth " << depth << ")" << std::endl;
    
    // Recursively scan subdirectories (up to maxDepth)
    if (depth < maxDepth) {
        // ULTRA-PARALLEL SCANNING: Start parallel from depth 1 (configurable)
        bool useParallel = (appState.ftpUseParallelScan && depth >= 1 && subdirs.size() > 1);
        
        if (useParallel) {
            std::vector<std::thread> threads;
            
            // Use configured max threads (default 16 für Ultra-Speed)
            int maxThreads = std::min(appState.ftpMaxThreads, static_cast<int>(subdirs.size()));
            
            // Copy values to avoid dangling references in threads
            std::string baseUrlCopy = baseUrl;
            std::string usernameCopy = username;
            std::string passwordCopy = password;
            int nextDepth = depth + 1;
            
            for (int t = 0; t < maxThreads; t++) {
                threads.emplace_back([t, maxThreads, &subdirs, &filesBySize, baseUrlCopy, usernameCopy, passwordCopy, nextDepth, maxDepth]() {
                    for (size_t i = t; i < subdirs.size() && !stopScan; i += maxThreads) {
                        // Check for pause
                        while (appState.scanPaused && !stopScan) {
                            std::this_thread::sleep_for(std::chrono::milliseconds(100));
                        }
                        if (stopScan) break;
                        
                        try {
                            scanFtpDirectory(subdirs[i], baseUrlCopy, usernameCopy, passwordCopy, filesBySize, nextDepth, maxDepth);
                        } catch (const std::exception& e) {
                            std::cerr << "[FTP Scan] Exception in subdirectory " << subdirs[i] << ": " << e.what() << std::endl;
                        } catch (...) {
                            std::cerr << "[FTP Scan] Unknown exception in subdirectory " << subdirs[i] << std::endl;
                        }
                    }
                });
            }
            
            // Wait for all threads
            for (auto& thread : threads) {
                if (thread.joinable()) {
                    thread.join();
                }
            }
        } else {
            // Serial scanning for shallow levels
            for (const auto& subdir : subdirs) {
                if (stopScan) break;
                try {
                    scanFtpDirectory(subdir, baseUrl, username, password, filesBySize, depth + 1, maxDepth);
                } catch (const std::exception& e) {
                    std::cerr << "[FTP Scan] Exception in subdirectory " << subdir << ": " << e.what() << std::endl;
                } catch (...) {
                    std::cerr << "[FTP Scan] Unknown exception in subdirectory " << subdir << std::endl;
                }
            }
        }
    } else if (!subdirs.empty()) {
        std::cout << "[FTP Scan] Max depth reached, skipping " << subdirs.size() << " subdirectories" << std::endl;
    }
}

// Check if directory is a system directory that should not be deleted
bool isSystemDirectory(const std::string& path) {
    // List of protected system directories (case-insensitive patterns)
    static const std::vector<std::string> systemDirs = {
        "/bin", "/boot", "/dev", "/etc", "/home", "/lib", "/lib64", "/media", 
        "/mnt", "/opt", "/proc", "/root", "/run", "/sbin", "/srv", "/sys", 
        "/tmp", "/usr", "/var", "/snap", "/swapfile", "/lost+found"
    };
    
    // Normalize path (remove trailing slashes)
    std::string normalizedPath = path;
    while (normalizedPath.size() > 1 && normalizedPath.back() == '/') {
        normalizedPath.pop_back();
    }
    
    // Check if path starts with any system directory
    for (const auto& sysDir : systemDirs) {
        if (normalizedPath == sysDir || normalizedPath.find(sysDir + "/") == 0) {
            return true;
        }
    }
    
    // Also protect directories directly under /mnt (mount points like /mnt/sdb, /mnt/backup, etc.)
    if (normalizedPath.find("/mnt/") == 0) {
        size_t slashCount = std::count(normalizedPath.begin(), normalizedPath.end(), '/');
        if (slashCount <= 2) { // /mnt/something - protect mount point itself
            return true;
        }
    }
    
    return false;
}

// Check if directory is empty (contains no files or subdirectories, excluding . and ..)
bool isDirectoryEmpty(const std::string& path) {
    DIR* dir = opendir(path.c_str());
    if (!dir) return false; // Can't open - assume not empty for safety
    
    struct dirent* entry;
    int count = 0;
    
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        // Skip . and ..
        if (name == "." || name == "..") continue;
        
        // Found something - not empty
        count++;
        break;
    }
    closedir(dir);
    
    return (count == 0);
}

// Delete zero-byte files recursively (excluding system directories)
int deleteZeroByteFiles(const std::string& path, int& deletedCount) {
    if (stopScan) return deletedCount;
    
    // Safety check: never delete in system directories
    if (isSystemDirectory(path)) {
        return deletedCount;
    }
    
    DIR* dir = opendir(path.c_str());
    if (!dir) return deletedCount;
    
    struct dirent* entry;
    std::vector<std::string> subdirs;
    
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        
        std::string fullPath = path + "/" + name;
        struct stat st;
        
        if (lstat(fullPath.c_str(), &st) == 0) {
            if (S_ISDIR(st.st_mode)) {
                subdirs.push_back(fullPath);
            } else if (S_ISREG(st.st_mode) && st.st_size == 0) {
                // Delete 0-byte file
                if (remove(fullPath.c_str()) == 0) {
                    deletedCount++;
                    std::cout << "[Cleanup] Deleted 0-byte file: " << fullPath << std::endl;
                } else {
                    std::cerr << "[Cleanup] Failed to delete 0-byte file " << fullPath << ": " << strerror(errno) << std::endl;
                }
            }
        }
    }
    closedir(dir);
    
    // Recursively process subdirectories
    for (const auto& subdir : subdirs) {
        deleteZeroByteFiles(subdir, deletedCount);
    }
    
    return deletedCount;
}

// Recursively delete empty directories (post-order traversal)
// Returns true if the directory was deleted or is empty
bool deleteEmptyDirectories(const std::string& path, int& deletedCount) {
    if (stopScan) return false;
    
    // Safety check: never delete system directories
    if (isSystemDirectory(path)) {
        return false;
    }
    
    DIR* dir = opendir(path.c_str());
    if (!dir) return false;
    
    // Collect subdirectories
    std::vector<std::string> subdirs;
    struct dirent* entry;
    
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        
        std::string fullPath = path + "/" + name;
        struct stat st;
        
        if (lstat(fullPath.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
            subdirs.push_back(fullPath);
        }
    }
    closedir(dir);
    
    // Recursively process subdirectories first (post-order)
    for (const auto& subdir : subdirs) {
        deleteEmptyDirectories(subdir, deletedCount);
    }
    
    // Now check if current directory is empty and safe to delete
    if (isDirectoryEmpty(path) && !isSystemDirectory(path)) {
        if (rmdir(path.c_str()) == 0) {
            deletedCount++;
            std::cout << "[Cleanup] Deleted empty directory: " << path << std::endl;
            return true;
        } else {
            std::cerr << "[Cleanup] Failed to delete " << path << ": " << strerror(errno) << std::endl;
        }
    }
    
    return false;
}

// Recursively scan directory for files (OHNE Tiefenbegrenzung - alle Unterverzeichnisse!)
void scanDirectoryRecursive(const std::string& path, std::map<long long, std::vector<std::string>>& filesBySize, int depth = 0, int maxDepth = 999) {
    if (stopScan) return;
    // KEINE Tiefenbegrenzung beim Local Scan - scannt ALLE Unterverzeichnisse!
    
    // OPTIMIZATION: Larger batches reduce lock overhead (10000 instead of 1000)
    std::unordered_map<std::string, CachedFileInfo> localFileCache;
    localFileCache.reserve(10000);
    long long localBytesProcessed = 0;
    int localFilesScanned = 0;
    
    DIR* dir = opendir(path.c_str());
    if (!dir) return;
    
    // OPTIMIZATION: Pre-allocate for large directories (reduce reallocs)
    std::vector<std::string> entries;
    entries.reserve(512); // Increased from 128 to 512
    
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        const char* name = entry->d_name;
        // OPTIMIZATION: Fast check for . and .. without string allocation
        if (name[0] == '.' && (name[1] == '\0' || (name[1] == '.' && name[2] == '\0'))) {
            continue;
        }
        entries.emplace_back(name);
    }
    closedir(dir);
    
    // OPTIMIZATION: Sort alphanumerically for better disk cache performance
    std::sort(entries.begin(), entries.end());
    
    // OPTIMIZATION: Reserve path buffer to avoid repeated allocations
    std::string fullPath;
    fullPath.reserve(path.length() + 256); // Pre-allocate for typical filename
    
    // Process sorted entries
    for (const auto& name : entries) {
        if (stopScan) break;
        
        // Skip hidden files if option is disabled
        if (!appState.scanHiddenFiles && name[0] == '.') {
            continue;
        }
        
        // OPTIMIZATION: Reuse fullPath buffer instead of creating new strings
        fullPath = path;
        fullPath += '/';
        fullPath += name;
        
        struct stat st;
        // OPTIMIZATION: Use stat() directly instead of lstat+stat for symlinks
        // stat() follows symlinks automatically, only use lstat if we need to detect them
        bool useStat = true;
        
        if (!appState.followSymlinks) {
            // Need to detect symlinks - use lstat first
            if (lstat(fullPath.c_str(), &st) == 0 && S_ISLNK(st.st_mode)) {
                continue; // Skip symlink
            }
            useStat = false; // Already have stat from lstat
        }
        
        if (useStat && stat(fullPath.c_str(), &st) != 0) {
            continue; // File disappeared or inaccessible
        }
        
            if (S_ISDIR(st.st_mode)) {
                // Recursive scan subdirectory (ALLE Unterverzeichnisse, keine Begrenzung!)
                scanDirectoryRecursive(fullPath, filesBySize, depth + 1, maxDepth);
            } else if (S_ISREG(st.st_mode)) {
                // Regular file
                // Skip empty files if setting is enabled
                if (st.st_size == 0 && appState.skipEmptyFiles) {
                    continue;
                }
                
                // OPTIMIZATION: Only process files > 0 bytes (empty files can't have hash duplicates)
                if (st.st_size > 0) {
                    filesBySize[st.st_size].push_back(fullPath);
                    
                    // CACHE: Store file metadata for next scan (batched - no lock here)
                    CachedFileInfo cacheInfo;
                    cacheInfo.size = st.st_size;
                    cacheInfo.mtime = st.st_mtime;
                    cacheInfo.inode = st.st_ino;
                    cacheInfo.hash = ""; // Will be filled during hash calculation
                    
                    localFileCache[fullPath] = cacheInfo;
                    
                    localBytesProcessed += st.st_size;
                    localFilesScanned++;
                    
                    // OPTIMIZATION: Larger batches (10000 instead of 1000) reduce lock overhead by 90%
                    if (localFilesScanned % 10000 == 0) {
                        {
                            std::lock_guard<std::mutex> lock(fileCacheMutex);
                            for (const auto& entry : localFileCache) {
                                fileCache[entry.first] = entry.second;
                            }
                            localFileCache.clear();
                        }
                        {
                            std::lock_guard<std::mutex> lock(resultsMutex);
                            appState.filesScanned += localFilesScanned;
                            appState.bytesProcessed += localBytesProcessed;
                            localFilesScanned = 0;
                            localBytesProcessed = 0;
                        }
                    }
                }
            }
        }  // Ende der for-Schleife über entries
    
    // Final batch flush
    if (!localFileCache.empty()) {
            std::lock_guard<std::mutex> lock(fileCacheMutex);
            for (const auto& entry : localFileCache) {
                fileCache[entry.first] = entry.second;
            }
            localFileCache.clear();
        }
        if (localFilesScanned > 0 || localBytesProcessed > 0) {
            std::lock_guard<std::mutex> lock(resultsMutex);
            appState.filesScanned += localFilesScanned;
            appState.bytesProcessed += localBytesProcessed;
        }
}

// Scan FTP directory using cache (FAST MODE - no directory listing needed!)
void scanFtpDirectoryCached(const std::string& ftpDir, const std::string& baseUrl,
                           const std::string& username, const std::string& password,
                           std::map<long long, std::vector<std::string>>& filesBySize) {
    std::cout << "[FTP Cache Scan] Processing: " << ftpDir << std::endl;
    
    // Build cache key
    std::string cacheKey = baseUrl + ftpDir;
    
    // Get cached directory entry
    FTPDirCacheEntry cachedEntry;
    {
        std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
        auto it = ftpDirCache.find(cacheKey);
        if (it == ftpDirCache.end()) {
            std::cout << "[FTP Cache Scan] ERROR: Cache miss for " << cacheKey << std::endl;
            return;
        }
        cachedEntry = it->second;
    }
    
    std::cout << "[FTP Cache Scan] Found " << cachedEntry.subdirs.size() << " cached subdirectories" << std::endl;
    
    // Recursively scan all cached subdirectories
    // We know the directory structure from cache, so we can scan files directly
    // without expensive FTP LIST commands!
    for (const auto& subdir : cachedEntry.subdirs) {
        if (stopScan) break;
        
        // Pause handling
        while (appState.scanPaused && !stopScan) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        if (stopScan) break;
        
        // Build full path
        std::string fullPath = ftpDir;
        if (!fullPath.empty() && fullPath.back() != '/') fullPath += '/';
        fullPath += subdir;
        
        // Recursively scan this subdirectory using cache
        scanFtpDirectoryCached(fullPath, baseUrl, username, password, filesBySize);
    }
    
    // Now scan files in this directory
    // We still need to get file list, but we KNOW the directory exists (from cache)
    // This is much faster than doing full recursive FTP LIST
    
    CURL* curl = curl_easy_init();
    if (!curl) return;
    
    std::string readBuffer;
    readBuffer.reserve(65536);
    
    // Build URL
    std::string encodedPath = urlEncodePath(ftpDir);
    std::string fullUrl = baseUrl;
    if (!fullUrl.empty() && fullUrl.back() != '/') fullUrl += '/';
    if (!encodedPath.empty() && encodedPath.front() == '/') encodedPath = encodedPath.substr(1);
    fullUrl += encodedPath;
    if (fullUrl.back() != '/') fullUrl += "/";
    
    curl_easy_setopt(curl, CURLOPT_URL, fullUrl.c_str());
    curl_easy_setopt(curl, CURLOPT_USERNAME, username.c_str());
    curl_easy_setopt(curl, CURLOPT_PASSWORD, password.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
    
    applyOptimalCurlSettings(curl);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, (long)(appState.ftpResponseTimeout * 2));
    
    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    
    if (res != CURLE_OK) {
        std::cerr << "[FTP Cache Scan] Error listing files in " << ftpDir << ": " << curl_easy_strerror(res) << std::endl;
        return;
    }
    
    // Parse FTP LIST output (only files this time, we already know subdirs from cache!)
    std::istringstream iss(readBuffer);
    std::string line;
    int fileCount = 0;
    
    while (std::getline(iss, line) && !stopScan) {
        if (line.empty()) continue;
        
        // Check if it's a file (not directory)
        if (line[0] != 'd' && line[0] != 'l') {
            // Parse file size and name
            std::istringstream lineStream(line);
            std::string permissions, links, owner, group;
            long long size;
            std::string month, day, time, filename;
            
            lineStream >> permissions >> links >> owner >> group >> size >> month >> day >> time;
            std::getline(lineStream, filename);
            
            if (!filename.empty() && filename[0] == ' ') filename = filename.substr(1);
            if (filename.empty() || filename == "." || filename == "..") continue;
            
            // Build full FTP path
            std::string filePath = fullUrl + filename;
            
            // Add to filesBySize for duplicate detection
            {
                std::lock_guard<std::mutex> lock(resultsMutex);
                filesBySize[size].push_back(filePath);
                appState.filesScanned++;
                appState.bytesProcessed += size;
                appState.totalBytes += size;
                appState.ftpBytesTransferred += size;
            }
            
            fileCount++;
        }
    }
    
    std::cout << "[FTP Cache Scan] Found " << fileCount << " files in " << ftpDir << std::endl;
}

// Main scan function (runs in separate thread)
void performScan() {
    stopScan = false;
    
    std::cout << "[Scanner] Starting duplicate scan..." << std::endl;
    
    // PRE-SCAN CLEANUP: Delete 0-byte files and empty directories
    if (appState.deleteEmptyDirs && !appState.selectedLocalDirs.empty()) {
        std::cout << "[Pre-Scan Cleanup] Cleaning up 0-byte files and empty directories..." << std::endl;
        
        int totalZeroByteFiles = 0;
        int totalEmptyDirs = 0;
        
        for (const auto& dir : appState.selectedLocalDirs) {
            if (stopScan) break;
            
            // Delete 0-byte files
            int zeroFiles = 0;
            deleteZeroByteFiles(dir, zeroFiles);
            totalZeroByteFiles += zeroFiles;
            
            // Delete empty directories
            int emptyDirs = 0;
            deleteEmptyDirectories(dir, emptyDirs);
            totalEmptyDirs += emptyDirs;
        }
        
        if (totalZeroByteFiles > 0 || totalEmptyDirs > 0) {
            std::cout << "[Pre-Scan Cleanup] Deleted " << totalZeroByteFiles << " zero-byte files and " 
                      << totalEmptyDirs << " empty directories" << std::endl;
        } else {
            std::cout << "[Pre-Scan Cleanup] No cleanup needed" << std::endl;
        }
    }
    
    // Clear previous results und starte Timer für Scan-Speed
    auto scanStartTime = std::chrono::steady_clock::now();
    long long lastScanBytes = 0;
    
    {
        std::lock_guard<std::mutex> lock(resultsMutex);
        appState.duplicates.clear();
        appState.duplicateGroups = 0;
        appState.duplicateFiles = 0;
        appState.duplicateSize = 0;
        appState.filesScanned = 0;
        appState.bytesProcessed = 0;
        appState.totalBytes = 0; // Reset total bytes at scan start
        appState.hashSpeed = 0.0f;
        appState.scanSpeed = 0.0f;
        appState.filesPerSecond = 0.0f;
        appState.networkBandwidth = 0.0f;
        appState.ftpBytesTransferred = 0;
        appState.currentHashAlgo = appState.hashAlgorithm;
        appState.ramUsageKB = getCurrentRAMUsageKB();
    }
    
    // Test bandwidth and auto-tune if not done yet
    if (!appState.bandwidthTested && !appState.selectedLocalDirs.empty()) {
        appState.scanStatus = "Teste Disk-Bandbreite...";
        std::cout << "[Scanner] Testing disk bandwidth..." << std::endl;
        
        // Test first selected directory
        std::string testPath = *appState.selectedLocalDirs.begin();
        appState.diskBandwidth = testDiskBandwidth(testPath);
        
        // Auto-tune performance based on bandwidth
        autoTunePerformance(appState.diskBandwidth);
        
        appState.bandwidthTested = true;
        
        std::cout << "[Scanner] Bandwidth test complete: " << appState.diskBandwidth << " MB/s" << std::endl;
        std::cout << "[Scanner] Auto-tuned: " << appState.threadCount << " threads" << std::endl;
    }
    
    // Step 1: Group files by size
    std::map<long long, std::vector<std::string>> filesBySize;
    
    // Scan local directories - PARALLEL OR SERIAL based on settings
    std::cout << "[Scanner] ======================================" << std::endl;
    std::cout << "[Scanner] Starting scan of " << appState.selectedLocalDirs.size() << " local directories:" << std::endl;
    int dirNum = 1;
    for (const auto& dir : appState.selectedLocalDirs) {
        std::cout << "[Scanner]   " << dirNum++ << ". " << dir << std::endl;
    }
    std::cout << "[Scanner] ======================================" << std::endl;
    
    if (appState.parallelDirectoryScan && appState.selectedLocalDirs.size() > 1) {
        // PARALLEL MODE - Scan multiple directories simultaneously
        std::cout << "[Scanner] 🚀 PARALLEL MODE: Using " << appState.dirScanThreads << " threads for directory scanning" << std::endl;
        
        std::vector<std::thread> scanThreads;
        std::mutex filesBySizeMutex;
        std::atomic<int> dirsCompleted{0};
        
        // Convert set to vector for indexed access
        std::vector<std::string> dirsToScan(appState.selectedLocalDirs.begin(), appState.selectedLocalDirs.end());
        int totalDirs = dirsToScan.size();
        
        // Create thread pool for directory scanning
        int numThreads = std::min(appState.dirScanThreads, totalDirs);
        for (int t = 0; t < numThreads; t++) {
            scanThreads.emplace_back([&, t]() {
                // Each thread processes directories round-robin
                for (int i = t; i < totalDirs; i += numThreads) {
                    if (stopScan) break;
                    
                    // Pause handling
                    while (appState.scanPaused && !stopScan) {
                        appState.scanStatus = "⏸ PAUSIERT - Drücke Fortsetzen";
                        std::this_thread::sleep_for(std::chrono::milliseconds(100));
                    }
                    if (stopScan) break;
                    
                    const auto& dir = dirsToScan[i];
                    
                    std::cout << "[Scanner Thread-" << t << "] >>> Scanning directory " << (i+1) << "/" << totalDirs << ": " << dir << std::endl;
                    
                    int filesBefore = appState.filesScanned;
                    
                    // Local map for this thread
                    std::map<long long, std::vector<std::string>> localFilesBySize;
                    scanDirectoryRecursive(dir, localFilesBySize);
                    
                    // Merge into global map (thread-safe)
                    {
                        std::lock_guard<std::mutex> lock(filesBySizeMutex);
                        for (const auto& [size, files] : localFilesBySize) {
                            filesBySize[size].insert(filesBySize[size].end(), files.begin(), files.end());
                        }
                    }
                    
                    int filesFound = appState.filesScanned - filesBefore;
                    std::cout << "[Scanner Thread-" << t << "] <<< Completed " << (i+1) << ": " << filesFound << " files" << std::endl;
                    dirsCompleted++;
                }
            });
        }
        
        // Wait for all threads to complete
        for (auto& thread : scanThreads) {
            thread.join();
        }
        
        std::cout << "[Scanner] ✅ PARALLEL SCAN COMPLETE: " << dirsCompleted.load() << "/" << totalDirs << " directories" << std::endl;
        
    } else {
        // SERIAL MODE - Traditional single-threaded scanning
        std::cout << "[Scanner] SERIAL MODE: Scanning directories one-by-one" << std::endl;
        
        dirNum = 1;
        for (const auto& dir : appState.selectedLocalDirs) {
            if (stopScan) break;
            
            // Pause handling
            while (appState.scanPaused && !stopScan) {
                appState.scanStatus = "⏸ PAUSIERT - Drücke Fortsetzen";
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            if (stopScan) break;
            
            std::cout << "[Scanner] >>> Scanning local directory " << dirNum << "/" << appState.selectedLocalDirs.size() << ": " << dir << std::endl;
            appState.scanStatus = "Durchsuche lokal (" + std::to_string(dirNum) + "/" + std::to_string(appState.selectedLocalDirs.size()) + "): " + dir;
            
            int filesBefore = appState.filesScanned;
            long long bytesBefore = appState.bytesProcessed;
            
            scanDirectoryRecursive(dir, filesBySize);
            
            int filesFound = appState.filesScanned - filesBefore;
            long long bytesFound = appState.bytesProcessed - bytesBefore;
            
            // Berechne Scan-Speed (I/O Durchsatz)
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - scanStartTime).count();
            if (elapsed > 0) {
                double seconds = elapsed / 1000.0;
                long long totalBytes = appState.bytesProcessed - lastScanBytes;
                appState.scanSpeed = (totalBytes / seconds) / (1024.0 * 1024.0);
            }
            
            std::cout << "[Scanner] <<< Completed directory " << dirNum << ": Found " << filesFound << " files in " << dir << std::endl;
            dirNum++;
        }
    }
    
    // Clean up empty directories after local scan (if enabled)
    if (appState.deleteEmptyDirs && !appState.selectedLocalDirs.empty() && !stopScan) {
        std::cout << "[Post-Scan Cleanup] Starting cleanup..." << std::endl;
        appState.scanStatus = "Räume 0-Byte-Dateien und leere Verzeichnisse auf...";
        
        if (appState.parallelCleanup && appState.selectedLocalDirs.size() > 1) {
            // PARALLEL CLEANUP - Process multiple directories simultaneously
            std::cout << "[Post-Scan Cleanup] 🚀 PARALLEL MODE: Using " << appState.cleanupThreads << " threads" << std::endl;
            
            std::vector<std::thread> cleanupThreads;
            std::atomic<int> totalZeroByteFiles{0};
            std::atomic<int> totalEmptyDirs{0};
            
            std::vector<std::string> dirsToClean(appState.selectedLocalDirs.begin(), appState.selectedLocalDirs.end());
            int numThreads = std::min(appState.cleanupThreads, (int)dirsToClean.size());
            
            for (int t = 0; t < numThreads; t++) {
                cleanupThreads.emplace_back([&, t]() {
                    for (int i = t; i < (int)dirsToClean.size(); i += numThreads) {
                        if (stopScan) break;
                        
                        const auto& dir = dirsToClean[i];
                        
                        // Delete 0-byte files
                        int zeroFiles = 0;
                        deleteZeroByteFiles(dir, zeroFiles);
                        totalZeroByteFiles += zeroFiles;
                        
                        // Delete empty directories
                        int emptyDirs = 0;
                        deleteEmptyDirectories(dir, emptyDirs);
                        totalEmptyDirs += emptyDirs;
                    }
                });
            }
            
            for (auto& thread : cleanupThreads) {
                thread.join();
            }
            
            if (totalZeroByteFiles.load() > 0 || totalEmptyDirs.load() > 0) {
                std::cout << "[Post-Scan Cleanup] ✅ Deleted " << totalZeroByteFiles.load() 
                          << " zero-byte files and " << totalEmptyDirs.load() << " empty directories (parallel)" << std::endl;
            } else {
                std::cout << "[Post-Scan Cleanup] ✅ Nothing to clean up" << std::endl;
            }
            
        } else {
            // SERIAL CLEANUP - Traditional single-threaded
            std::cout << "[Post-Scan Cleanup] SERIAL MODE: Single-threaded cleanup" << std::endl;
            
            int totalZeroByteFiles = 0;
            int totalEmptyDirs = 0;
            
            for (const auto& dir : appState.selectedLocalDirs) {
                if (stopScan) break;
                
                // First delete 0-byte files
                int zeroFiles = 0;
                deleteZeroByteFiles(dir, zeroFiles);
                totalZeroByteFiles += zeroFiles;
                
                // Then delete empty directories
                int emptyDirs = 0;
                deleteEmptyDirectories(dir, emptyDirs);
                totalEmptyDirs += emptyDirs;
            }
            
            if (totalZeroByteFiles > 0 || totalEmptyDirs > 0) {
                std::cout << "[Post-Scan Cleanup] [X] Deleted " << totalZeroByteFiles 
                          << " zero-byte files and " << totalEmptyDirs << " empty directories" << std::endl;
            } else {
                std::cout << "[Post-Scan Cleanup] [X] Nothing to clean up" << std::endl;
            }
        }
    }
    
    // Scan FTP directories
    if (appState.connectedPresetIndex >= 0 && appState.connectedPresetIndex < appState.ftpPresets.size()) {
        const auto& preset = appState.ftpPresets[appState.connectedPresetIndex];
        std::string ftpUrl = "ftp://" + preset.ip + ":" + std::to_string(preset.port);
        
        // Initialize FTP bandwidth tracking
        appState.ftpBytesTransferred = 0;
        appState.ftpScanStartTime = std::chrono::steady_clock::now();
        
        // CACHE: Check if we can use cached FTP directory trees
        std::cout << "[FTP Scanner] Checking FTP directory cache..." << std::endl;
        bool useCachedFtpDirs = false;
        {
            std::lock_guard<std::mutex> lock(ftpDirCacheMutex);
            if (!ftpDirCache.empty()) {
                std::cout << "[FTP Scanner] Found " << ftpDirCache.size() << " cached FTP directories" << std::endl;
                
                // Check if ALL selected FTP dirs are in cache and fresh (< 1 hour old)
                bool allCached = true;
                time_t now = time(nullptr);
                
                for (const auto& ftpDir : appState.selectedFtpDirs) {
                    std::string cacheKey = ftpUrl + ftpDir;
                    auto it = ftpDirCache.find(cacheKey);
                    
                    if (it == ftpDirCache.end()) {
                        allCached = false;
                        std::cout << "[FTP Scanner] Cache miss for: " << cacheKey << std::endl;
                        break;
                    }
                    
                    int age_seconds = (now - it->second.timestamp);
                    if (age_seconds > 3600) { // Cache older than 1 hour
                        allCached = false;
                        std::cout << "[FTP Scanner] Cache too old (" << (age_seconds/60) << " minutes) for: " << cacheKey << std::endl;
                        break;
                    }
                }
                
                if (allCached) {
                    useCachedFtpDirs = true;
                    std::cout << "[FTP Scanner] ✓ Using cached FTP directory trees (instant scan!)" << std::endl;
                    appState.scanStatus = "Nutze gecachte FTP-Verzeichnisse (sofort!)";
                }
            }
        }
        
        if (useCachedFtpDirs) {
            // Use cached FTP directories - scan only files, not directory structure!
            std::cout << "[FTP Scanner] === FAST MODE: Scanning files from cache ===" << std::endl;
            
            for (const auto& ftpDir : appState.selectedFtpDirs) {
                if (stopScan) break;
                
                // Pause handling
                while (appState.scanPaused && !stopScan) {
                    appState.scanStatus = "⏸ PAUSIERT - Drücke Fortsetzen";
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                }
                if (stopScan) break;
                
                std::cout << "[FTP Scanner] Processing cached FTP: " << ftpDir << std::endl;
                appState.scanStatus = "Durchsuche FTP (Cache): " + ftpDir;
                
                // Scan using cache (no directory listing needed!)
                scanFtpDirectoryCached(ftpDir, ftpUrl, preset.username, preset.password, filesBySize);
            }
        } else {
            // No cache or cache outdated - do full FTP scan
            std::cout << "[FTP Scanner] === SLOW MODE: Full FTP directory scan ===" << std::endl;
            
            for (const auto& ftpDir : appState.selectedFtpDirs) {
                if (stopScan) break;
                
                // Pause handling
                while (appState.scanPaused && !stopScan) {
                    appState.scanStatus = "⏸ PAUSIERT - Drücke Fortsetzen";
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                }
                if (stopScan) break;
                
                std::cout << "[Scanner] Scanning FTP: " << ftpDir << " (Max Depth: " << appState.ftpScanMaxDepth 
                          << ", Threads: " << appState.ftpMaxThreads << ")" << std::endl;
                appState.scanStatus = "Durchsuche FTP: " + ftpDir;
                scanFtpDirectory(ftpDir, ftpUrl, preset.username, preset.password, filesBySize, 0, appState.ftpScanMaxDepth);
            }
        }
    }
    
    if (stopScan) {
        appState.scanning = false;
        appState.scanStatus = "Abgebrochen";
        return;
    }
    
    {
        std::lock_guard<std::mutex> lock(resultsMutex);
        appState.scanStatus = "Analysiere Dateien...";
        appState.scanProgress = std::max(appState.scanProgress, 0.3f);  // NEVER GO BACKWARDS
        std::cout << "[Scanner] Status: Analysiere Dateien... (30%)" << std::endl;
    }
    
    std::cout << "[Scanner] Found " << filesBySize.size() << " unique file sizes" << std::endl;
    std::cout << "[Scanner] Total files scanned: " << appState.filesScanned << std::endl;
    
    // Log first 10 files for debugging
    int logCount = 0;
    for (const auto& [size, files] : filesBySize) {
        if (logCount++ < 10) {
            for (const auto& file : files) {
                std::cout << "[Scanner]   - " << file << " (" << size << " bytes)" << std::endl;
            }
        }
    }
    
    // Step 2: Calculate hashes for files with same size
    std::map<std::string, std::vector<std::string>> filesByHash;
    
    {
    int totalToHash = 0;
    for (const auto& [size, files] : filesBySize) {
        if (files.size() > 1) {
            totalToHash += files.size();
            std::cout << "[Scanner] Found " << files.size() << " files with size " << size << " bytes" << std::endl;
        }
    }
    
    // Set total files for progress tracking (nur die Dateien die gehasht werden müssen)
    int totalFilesScanned = appState.filesScanned;  // Merke alle gescannten Dateien
    appState.totalFiles = totalToHash;  // Setze auf Dateien die gehasht werden müssen
    appState.filesScanned = 0;  // Reset für Hash-Fortschritt
    
    std::cout << "[Scanner] Need to hash " << totalToHash << " files (out of " << totalFilesScanned << " scanned)" << std::endl;
    
    {
        std::lock_guard<std::mutex> lock(resultsMutex);
        if (totalToHash == 0) {
            appState.scanStatus = "Keine Dateien mit gleicher Größe gefunden";
            appState.scanProgress = std::max(appState.scanProgress, 0.5f);  // NEVER GO BACKWARDS
            std::cout << "[Scanner] Status: Keine Dateien mit gleicher Größe gefunden (50%)" << std::endl;
        } else {
            appState.scanStatus = "Berechne Hashes...";
            appState.scanProgress = std::max(appState.scanProgress, 0.4f);  // NEVER GO BACKWARDS
            std::cout << "[Scanner] Status: Berechne Hashes... (40%)" << std::endl;
        }
    }
    
    // Small delay to show status
    std::cout << "[Scanner] Waiting 0.5s..." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    
    // PARALLELES HASHING mit konfigurierbarem Thread-Pool
    std::atomic<int> hashedCount{0};
    std::mutex hashMapMutex;
    
    // Reset filesScanned to 0 for hashing progress tracking
    appState.filesScanned = 0;
    
    // Verwende konfigurierte Thread-Anzahl aus Settings (1-128)
    unsigned int numThreads = std::max(1, std::min(128, appState.threadCount));
    std::cout << "[Scanner] Using " << numThreads << " parallel hashing threads (configured in settings)" << std::endl;
    
    // Initialize FTP bandwidth tracking for hashing phase
    appState.ftpBytesTransferred = 0;
    appState.ftpScanStartTime = std::chrono::steady_clock::now();
    
    // Initialize hash speed tracking (Reset für jeden neuen Scan)
    auto hashSpeedStartTime = std::chrono::steady_clock::now();
    long long hashSpeedLastBytes = 0;
    int hashSpeedLastCount = 0;
    
    // SICHERHEIT: Process each size group in parallel - nur Dateien mit EXAKT gleicher Größe
    for (const auto& [size, files] : filesBySize) {
        if (stopScan) break;
        
        // Pause handling in Hash phase
        while (appState.scanPaused && !stopScan) {
            appState.scanStatus = "PAUSE PAUSIERT - Drücke Fortsetzen";
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        if (stopScan) break;
        
        // SICHERHEITSFILTER 1: Skip files mit unique size (keine Duplikate möglich)
        if (files.size() <= 1) {
            std::cout << "[Scanner] Skipping 1 file of size " << size << " bytes (unique size)" << std::endl;
            continue;
        }
        
        // SICHERHEITSFILTER 2: Verifiziere dass alle Dateien in dieser Gruppe exakt gleiche Größe haben
        bool sizeVerified = true;
        for (const auto& file : files) {
            // FTP-Dateien überspringen - sie haben keine lokale stat() Möglichkeit
            if (isFtpFile(file)) {
                continue; // FTP-Dateien wurden bereits beim Scan mit Größe versehen
            }
            
            struct stat st;
            if (stat(file.c_str(), &st) == 0) {
                if (st.st_size != size) {
                    std::cerr << "[Scanner] WARNING: Size mismatch for " << file << " (expected " << size << ", got " << st.st_size << ")" << std::endl;
                    sizeVerified = false;
                    break;
                }
            } else {
                // Datei nicht mehr verfügbar
                std::cerr << "[Scanner] ERROR: File not accessible: " << file << " (errno: " << errno << ")" << std::endl;
                {
                    std::lock_guard<std::mutex> lock(appState.inaccessibleFilesMutex);
                    appState.inaccessibleFiles.push_back(file);
                    appState.totalInaccessibleFiles++;
                    appState.showFileErrorDialog = true;
                }
                // Weiter scannen ohne diese Datei
                sizeVerified = false;
                break;
            }
        }
        
        if (!sizeVerified) {
            std::cout << "[Scanner] Skipping size group " << size << " (size verification failed)" << std::endl;
            continue;
        }
        
        // OPTIMIZATION: Sort files ONCE before threading (not per-thread)
        // Alphanumeric sorting improves disk cache locality
        std::vector<std::string> sortedFiles = files;  // Copy needed because files is const
        std::sort(sortedFiles.begin(), sortedFiles.end());
        
        std::cout << "[Scanner] Hashing " << sortedFiles.size() << " files of size " << size << " bytes (parallel, verified)" << std::endl;
        
        // Split files into chunks for parallel processing
        std::vector<std::thread> threads;
        size_t chunkSize = (sortedFiles.size() + numThreads - 1) / numThreads;
        
        // Update active thread count
        appState.threadsActive = std::min((int)numThreads, (int)sortedFiles.size());
        
        for (unsigned int t = 0; t < numThreads && t * chunkSize < sortedFiles.size(); t++) {
            size_t start = t * chunkSize;
            size_t end = std::min(start + chunkSize, sortedFiles.size());
            
            threads.emplace_back([&, start, end, t]() {  // Capture thread ID by value
                // Local batch storage to reduce lock contention - OPTIMIZED: 10000 instead of 100
                std::vector<std::pair<std::string, std::string>> localBatch; // hash -> file
                localBatch.reserve(appState.hashBatchSize); // Configurable batch size (default: 10000)
                long long localBytesProcessed = 0;
                
                for (size_t i = start; i < end && !stopScan; i++) {
                    const auto& file = sortedFiles[i];
                    std::string hash;
                    
                    // OPTIMIZATION: Update current file only in thread 0 - REDUCED: every statusUpdateInterval files
                    if (t == 0 && i % appState.statusUpdateInterval == 0) {
                        appState.currentHashingFile = file;
                    }
                    
                    // Check if FTP or local file
                    if (isFtpFile(file)) {
                        // FTP file - check minimum size filter
                        if (size < appState.ftpMinFileSize) {
                            // OPTIMIZATION: Skip very small FTP files (overhead too high)
                            // Mark as "skipped" by using a special hash
                            hash = "SKIPPED_TOO_SMALL_" + std::to_string(size);
                        } else {
                            // FTP file - already contains full URL (ftp://host:port/path)
                            if (appState.connectedPresetIndex >= 0 && appState.connectedPresetIndex < appState.ftpPresets.size()) {
                                const auto& preset = appState.ftpPresets[appState.connectedPresetIndex];
                                hash = calculateMD5FromFTP(file, preset.username, preset.password, size);
                            }
                        }
                    } else {
                        // Local file - use selected algorithm
                        hash = calculateHash(file, appState.hashAlgorithm);
                    }
                    
                    if (!hash.empty()) {
                        localBatch.push_back({hash, file});
                    } else {
                        // Hash-Berechnung fehlgeschlagen - Datei nicht mehr verfügbar?
                        // FTP-Dateien: Fehler wird bereits in calculateMD5FromFTP geloggt (thread-safe)
                        if (!isFtpFile(file)) {
                            struct stat st;
                            if (stat(file.c_str(), &st) != 0) {
                                std::cerr << "[Scanner] ERROR: File became inaccessible during hashing: " << file << " (errno: " << errno << ")" << std::endl;
                                {
                                    std::lock_guard<std::mutex> lock(appState.inaccessibleFilesMutex);
                                    appState.inaccessibleFiles.push_back(file);
                                    appState.totalInaccessibleFiles++;
                                    appState.showFileErrorDialog = true;
                                }
                            }
                        }
                        // Skip this file - continue with next
                    }
                    
                    hashedCount++;
                    appState.filesScanned++;  // Update progress counter
                    
                    // Track bytes for speed calculation
                    long long fileSize = 0;
                    if (isFtpFile(file)) {
                        // FTP-Dateien: Größe aus filesBySize Map holen
                        fileSize = size; // size ist bereits bekannt aus der Map
                    } else {
                        // Lokale Dateien: stat() verwenden
                        struct stat st;
                        if (stat(file.c_str(), &st) == 0) {
                            fileSize = st.st_size;
                        }
                    }
                    
                    localBytesProcessed += fileSize;
                    
                    // Flush batch every hashBatchSize files or at end - OPTIMIZED: 10000 instead of 100
                    if (localBatch.size() >= (size_t)appState.hashBatchSize || i == end - 1) {
                        std::lock_guard<std::mutex> lock(hashMapMutex);
                        for (const auto& entry : localBatch) {
                            filesByHash[entry.first].push_back(entry.second);
                        }
                        localBatch.clear();
                    }
                    
                    // OPTIMIZATION: Update progress every 20 files (reduced lock contention)
                    if (i % 20 == 0) {
                        std::lock_guard<std::mutex> lock(resultsMutex);
                        appState.scanProgress = 0.4f + 0.5f * ((float)hashedCount / totalToHash);
                        appState.bytesProcessed += localBytesProcessed;
                        localBytesProcessed = 0;
                    }
                    
                    // OPTIMIZATION: Calculate hash speed only in thread 0 to reduce overhead
                    if (t == 0 && i % 5 == 0) {
                        auto now = std::chrono::steady_clock::now();
                        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - hashSpeedStartTime).count();
                        
                        if (elapsed > 100) { // Update every 100ms (10x per second, less overhead)
                            double seconds = elapsed / 1000.0;
                            
                            // Thread-safe: Lock when reading bytesProcessed
                            long long currentBytesProcessed;
                            {
                                std::lock_guard<std::mutex> lock(resultsMutex);
                                currentBytesProcessed = appState.bytesProcessed;
                            }
                            
                            long long bytesDelta = currentBytesProcessed - hashSpeedLastBytes;
                            int countDelta = hashedCount.load() - hashSpeedLastCount;
                            
                            // ECHTZEIT Hash speed (MB/s)
                            if (seconds > 0.0 && bytesDelta > 0) {
                                float currentSpeed = (bytesDelta / seconds) / (1024.0 * 1024.0);
                                appState.hashSpeed = currentSpeed;
                                appState.scanSpeed = currentSpeed;
                            }
                            
                            // Files per second
                            if (seconds > 0.0) {
                                appState.filesPerSecond = countDelta / seconds;
                            }
                            
                            // Network bandwidth calculation (for FTP scans)
                            if (appState.ftpBytesTransferred > 0) {
                                auto ftpElapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                                    now - appState.ftpScanStartTime).count();
                                if (ftpElapsed > 0) {
                                    double ftpSeconds = ftpElapsed / 1000.0;
                                    appState.networkBandwidth = (appState.ftpBytesTransferred / ftpSeconds) / (1024.0 * 1024.0);
                                }
                            }
                            
                            // Update RAM usage
                            appState.ramUsageKB = getCurrentRAMUsageKB();
                            
                            hashSpeedLastBytes = currentBytesProcessed;
                            hashSpeedLastCount = hashedCount.load();
                            hashSpeedStartTime = now;
                            
                            // Update hardware monitoring
                            appState.cpuUsage = getCpuUsage();
                            appState.cpuTemp = getCpuTemperature();
                            if (appState.detectedHardware.find("GPU") != std::string::npos) {
                                appState.gpuUsage = getGpuUsage();
                                appState.gpuPower = getGpuPower();
                                appState.gpuMemBandwidth = getGpuMemBandwidth();
                            }
                        }
                    }
                }
                
                // Flush remaining batch and bytes at end of thread
                if (!localBatch.empty()) {
                    std::lock_guard<std::mutex> lock(hashMapMutex);
                    for (const auto& entry : localBatch) {
                        filesByHash[entry.first].push_back(entry.second);
                    }
                }
                if (localBytesProcessed > 0) {
                    std::lock_guard<std::mutex> lock(resultsMutex);
                    appState.bytesProcessed += localBytesProcessed;
                }
            });
        }
        
        // Wait for all threads to complete this size group
        for (auto& thread : threads) {
            if (thread.joinable()) thread.join();
        }
    }
    } // Ende Step 2: Hashing
    
    if (stopScan) {
        appState.scanning = false;
        appState.currentHashingFile = "";  // Clear current file display
        appState.scanStatus = "Abgebrochen";
        return;
    }
    
    // Step 3: Find duplicates
    {
        std::lock_guard<std::mutex> lock(resultsMutex);
        
        for (const auto& [hash, files] : filesByHash) {
            if (files.size() > 1) {
                DuplicateGroup group;
                group.hash = hash;
                group.files = files;
                
                // Get file size
                struct stat st;
                if (stat(files[0].c_str(), &st) == 0) {
                    group.size = st.st_size;
                    appState.duplicateSize += group.size * (files.size() - 1);
                }
                
                appState.duplicates.push_back(group);
                appState.duplicateGroups++;
                appState.duplicateFiles += files.size();
            }
        }
        
        if (appState.duplicateGroups == 0) {
            appState.scanStatus = "Keine Duplikate gefunden - alle Dateien sind unique!";
            std::cout << "[Scanner] Status: Keine Duplikate gefunden - alle Dateien sind unique! (100%)" << std::endl;
        } else {
            appState.scanStatus = "Fertig! " + std::to_string(appState.duplicateGroups) + " Duplikat-Gruppen";
            std::cout << "[Scanner] Status: Fertig! " << appState.duplicateGroups << " Duplikat-Gruppen (100%)" << std::endl;
        }
        appState.scanProgress = 1.0f;
        
        std::cout << "[Scanner] Found " << appState.duplicateGroups 
                 << " duplicate groups with " << appState.duplicateFiles 
                 << " files" << std::endl;
    }
    
    // OPTIMIZED: Removed 2-second blocking sleep - results show immediately!
    std::cout << "[Scanner] Done!" << std::endl;
    
    // CACHE: Save file cache to disk (automatic, transparent)
    std::cout << "[Cache] Saving file cache..." << std::endl;
    saveFileCache();
    
    {
        std::lock_guard<std::mutex> lock(resultsMutex);
        appState.scanning = false;
        appState.currentHashingFile = "";  // Clear current file display
    }
    
    // Execute post-scan action if enabled
    if (appState.postScanActionEnabled && appState.postScanAction > 0) {
        std::cout << "[Post-Scan] Action enabled, waiting " << appState.postScanDelay << " seconds..." << std::endl;
        appState.scanStatus = "Warte auf Post-Scan-Aktion...";
        std::this_thread::sleep_for(std::chrono::seconds(appState.postScanDelay));
        
        std::string actionName;
        std::string command;
        
        switch (appState.postScanAction) {
            case 1: // Herunterfahren
                actionName = "Herunterfahren";
                command = "systemctl poweroff";
                break;
            case 2: // Suspend
                actionName = "Suspend";
                command = "systemctl suspend";
                break;
            case 3: // Hibernate
                actionName = "Hibernate";
                command = "systemctl hibernate";
                break;
            case 4: // Benachrichtigung
                actionName = "Benachrichtigung";
                command = "notify-send 'FileDuper' 'Scan abgeschlossen!' -u critical";
                break;
            default:
                actionName = "Nichts";
                break;
        }
        
        if (!command.empty()) {
            std::cout << "[Post-Scan] Führe Aktion aus: " << actionName << std::endl;
            appState.scanStatus = "Post-Scan: " + actionName;
            system(command.c_str());
        }
    }
}

int main(int argc, char* argv[]) {
    // Auto-mount state (delayed until GUI is ready)
    bool autoMountDone = false;
    int frameCount = 0;
    
    // Load settings FIRST (before anything else!)
    std::cout << "[Startup] Loading settings..." << std::endl;
    loadSettings();
    
    // Auto-discover NFS mount points
    std::cout << "[Startup] Discovering NFS mount points..." << std::endl;
    autoDiscoverNFSMounts();
    
    // Load cached sudo password if available
    std::cout << "[Startup] Loading cached sudo password..." << std::endl;
    std::string cachedPwd = loadSudoPassword();
    if (!cachedPwd.empty()) {
        appState.sudoPassword = cachedPwd;
        appState.sudoPasswordAvailable = true;
        std::cout << "[SUDO] Cached password loaded" << std::endl;
    }
    

    // Init CURL Connection Pooling
    curl_global_init(CURL_GLOBAL_ALL);
    initCurlSharing();
    
    // Skip cache loading for now - it will be done lazily when needed
    // This prevents GUI blocking on startup
    std::cout << "[Startup] Cache loading deferred (lazy load)" << std::endl;
    
    // Init GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    // GL 3.3 + GLSL 130
    const char* glsl_version = "#version 130";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_DECORATED, GLFW_TRUE);  // Enable window decorations (close, maximize, minimize buttons)
    glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);  // Enable window resizing
    glfwWindowHint(GLFW_MAXIMIZED, GLFW_FALSE); // Don't start maximized
    glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE);    // Window is visible
    glfwWindowHint(GLFW_FLOATING, GLFW_FALSE);  // NOT always on top - allow Alt+Tab
    glfwWindowHint(GLFW_FOCUS_ON_SHOW, GLFW_FALSE); // Don't steal focus when shown
    glfwWindowHint(GLFW_AUTO_ICONIFY, GLFW_TRUE); // Minimize when focus lost (Alt+Tab away)

    // Create window (larger size: 2048x1440)
    GLFWwindow* window = glfwCreateWindow(2048, 1440, "FileDuper - Duplicate File Manager", NULL, NULL);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    
    // Set X11 WM_CLASS for proper GNOME integration
    Display* display = glfwGetX11Display();
    Window x11Window = glfwGetX11Window(window);
    if (display && x11Window) {
        XClassHint* classHint = XAllocClassHint();
        if (classHint) {
            classHint->res_name = (char*)"FileDuper";
            classHint->res_class = (char*)"FileDuper";
            XSetClassHint(display, x11Window, classHint);
            XFree(classHint);
        }
        
        // Set WM_NAME and WM_ICON_NAME
        XStoreName(display, x11Window, "FileDuper");
        XSetIconName(display, x11Window, "FileDuper");
        
        // Ensure window is NOT always on top and allows Alt+Tab
        Atom wmState = XInternAtom(display, "_NET_WM_STATE", False);
        Atom wmStateAbove = XInternAtom(display, "_NET_WM_STATE_ABOVE", False);
        Atom wmStateStaysOnTop = XInternAtom(display, "_NET_WM_STATE_STAYS_ON_TOP", False);
        
        // Remove any "always on top" properties
        XDeleteProperty(display, x11Window, wmStateAbove);
        XDeleteProperty(display, x11Window, wmStateStaysOnTop);
        
        // Set normal window type (not dialog, not notification)
        Atom wmWindowType = XInternAtom(display, "_NET_WM_WINDOW_TYPE", False);
        Atom wmWindowTypeNormal = XInternAtom(display, "_NET_WM_WINDOW_TYPE_NORMAL", False);
        Atom atomType = XInternAtom(display, "ATOM", False);
        XChangeProperty(display, x11Window, wmWindowType, atomType, 32, PropModeReplace,
                       (unsigned char*)&wmWindowTypeNormal, 1);
        
        XFlush(display);
    }
    
    // Explicitly set window attributes after creation
    glfwSetWindowAttrib(window, GLFW_RESIZABLE, GLFW_TRUE);
    glfwSetWindowAttrib(window, GLFW_DECORATED, GLFW_TRUE);
    glfwSetWindowAttrib(window, GLFW_FLOATING, GLFW_FALSE); // NOT always on top
    glfwSetWindowAttrib(window, GLFW_AUTO_ICONIFY, GLFW_TRUE); // Allow minimizing
    
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable vsync

    // Setup ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    
    // Load font with German umlauts and special characters
    ImFontConfig fontConfig;
    fontConfig.OversampleH = 2;
    fontConfig.OversampleV = 2;
    fontConfig.PixelSnapH = true;
    
    // Build glyph ranges with German umlauts
    static const ImWchar ranges[] = {
        0x0020, 0x00FF,  // Basic Latin + Latin Supplement (includes German umlauts)
        0x2000, 0x206F,  // General Punctuation
        0x2190, 0x21FF,  // Arrows
        0x2200, 0x22FF,  // Mathematical Operators
        0x2300, 0x23FF,  // Miscellaneous Technical
        0x2500, 0x257F,  // Box Drawing
        0x2580, 0x259F,  // Block Elements
        0x25A0, 0x25FF,  // Geometric Shapes
        0x2600, 0x26FF,  // Miscellaneous Symbols
        0x2700, 0x27BF,  // Dingbats
        0
    };
    
    // Add default font with extended glyph ranges
    io.Fonts->AddFontDefault(&fontConfig);
    io.Fonts->GetGlyphRangesDefault(); // This includes Latin + German umlauts
    
    // Try to load a system font if available (optional, falls back to default)
    if (FILE* f = fopen("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "r")) {
        fclose(f);
        io.Fonts->AddFontFromFileTTF("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16.0f, nullptr, ranges);
        std::cout << "[ImGui] Loaded DejaVu Sans font with extended Unicode support" << std::endl;
    } else {
        std::cout << "[ImGui] Using default font with extended Latin support" << std::endl;
    }
    
    // DON'T call io.Fonts->Build() - the backend will do it automatically!
    
    // Verhindere dass Fenster automatisch fokussiert werden
    io.ConfigWindowsMoveFromTitleBarOnly = false;
    
    // Enable clipboard support (GLFW provides this automatically)
    // Set clipboard callbacks for X11/Wayland compatibility
    io.SetClipboardTextFn = [](void* user_data, const char* text) {
        glfwSetClipboardString((GLFWwindow*)user_data, text);
    };
    io.GetClipboardTextFn = [](void* user_data) -> const char* {
        return glfwGetClipboardString((GLFWwindow*)user_data);
    };
    io.ClipboardUserData = window;
    
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init(glsl_version);

    // Detect hardware capabilities
    appState.detectedHardware = detectHardwareCapabilities();
    std::cout << "[Hardware] Detected: " << appState.detectedHardware << std::endl;
    
    // Create default config files if they don't exist
    createDefaultConfigs();
    
    // Load saved settings
    loadThemeSettings();
    loadScannerSettings(); // Lade Scanner-Einstellungen
    
    // ALWAYS create fresh config with all 45 settings after loading
    // This ensures the config file is complete even if it was created by old version
    saveScannerSettings();
    
    loadFtpPresets();
    loadSearchHistory(); // Lade Such-History
    applyTheme(appState.currentTheme);

    // Erkenne NPU beim Start
    appState.hasNPU = detectNPU();

    std::cout << "[FileDuper] [OK] Initialized" << std::endl;
    std::cout << "[Hash] Default algorithm: " << appState.hashAlgorithm << " (Preset: " << appState.hashPreset << ")" << std::endl;
    if (appState.hasNPU) {
        std::cout << "[Hardware] NPU detected and available" << std::endl;
    }
    
    // Auto-Mount will be done after GUI is ready (in main loop)
    std::cout << "[NFS/SMB/WebDAV] Auto-mount will be performed after GUI initialization..." << std::endl;

    // Main loop
    auto lastHwUpdate = std::chrono::steady_clock::now();
    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        
        // Auto-mount after a few frames (GUI is ready)
        frameCount++;
        if (!autoMountDone && frameCount == 4) {  // Only run once at frame 4
            // Try auto-mounting each preset only once at startup
            bool allMounted = true;
            
            // Auto-Mount NFS shares if configured (only once per startup)
            static std::set<std::string> nfsMountAttempted;
            for (auto& preset : appState.ftpPresets) {
                if (preset.serviceType == "NFS" && preset.nfsAutoMount && !preset.nfsMounted) {
                    if (nfsMountAttempted.find(preset.name) == nfsMountAttempted.end()) {
                        std::cout << "[NFS] Auto-mounting: " << preset.name << std::endl;
                        nfsMountAttempted.insert(preset.name);
                        if (mountNFS(preset)) {
                            // Just mount, DON'T auto-add to scan list
                            std::cout << "[NFS] ✅ Auto-mounted: " << preset.name << std::endl;
                        } else {
                            std::cout << "[NFS] Auto-mount failed: " << preset.name << " (may retry)" << std::endl;
                            allMounted = false;
                        }
                    } else {
                        allMounted = false;  // Still not mounted
                    }
                }
            }
            
            // Auto-Mount SMB/CIFS shares if configured (only once per startup)
            static std::set<std::string> smbMountAttempted;
            for (auto& preset : appState.ftpPresets) {
                if (preset.serviceType == "SMB" && preset.smbAutoMount && !preset.smbMounted) {
                    if (smbMountAttempted.find(preset.name) == smbMountAttempted.end()) {
                        std::cout << "[SMB] Auto-mounting: " << preset.name << std::endl;
                        smbMountAttempted.insert(preset.name);
                        if (mountSMB(preset)) {
                            // Just mount, DON'T auto-add to scan list
                            std::cout << "[SMB] ✅ Auto-mounted: " << preset.name << std::endl;
                        } else {
                            std::cout << "[SMB] Auto-mount failed: " << preset.name << " (may retry)" << std::endl;
                            allMounted = false;
                        }
                    } else {
                        allMounted = false;  // Still not mounted
                    }
                }
            }
            
            // Auto-Mount WebDAV shares if configured (only once per startup)
            static std::set<std::string> davMountAttempted;
            for (auto& preset : appState.ftpPresets) {
                if (preset.serviceType == "WebDAV" && preset.davAutoMount && !preset.davMounted) {
                    if (davMountAttempted.find(preset.name) == davMountAttempted.end()) {
                        std::cout << "[WebDAV] Auto-mounting: " << preset.name << std::endl;
                        davMountAttempted.insert(preset.name);
                        if (mountWebDAV(preset)) {
                            // Just mount, DON'T auto-add to scan list
                            std::cout << "[WebDAV] ✅ Auto-mounted: " << preset.name << std::endl;
                        } else {
                            std::cout << "[WebDAV] Auto-mount failed: " << preset.name << " (may retry)" << std::endl;
                            allMounted = false;
                        }
                    } else {
                        allMounted = false;  // Still not mounted
                    }
                }
            }
            
            // Mark as done - auto-mount only runs once at startup (frame 4)
            autoMountDone = true;
            if (!allMounted) {
                std::cout << "[Startup] Auto-mount attempted - some shares may have failed" << std::endl;
            } else {
                std::cout << "[Startup] Auto-mount complete" << std::endl;
            }
        }

        // Update hardware monitoring every second
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastHwUpdate).count();
        if (elapsed >= 1000) {
            appState.cpuUsage = getCpuUsage();
            appState.cpuTemp = getCpuTemperature();
            
            // Update GPU usage (multi-vendor support)
            appState.gpuUsage = getGpuUsage();
            appState.gpuPower = getGpuPower();
            appState.gpuMemBandwidth = getGpuMemBandwidth();
            
            // Estimate GPU hash speed based on GPU usage and typical performance
            if (appState.useGPU && appState.gpuUsage > 0.0f) {
                // Rough estimate: Modern iGPU can do ~0.5-2 GB/s for MD5
                appState.gpuHashSpeed = (appState.gpuUsage / 100.0f) * 1.5f;
            } else {
                appState.gpuHashSpeed = 0.0f;
            }
            
            // Update NPU usage (AI accelerator) - nur wenn vorhanden
            if (appState.hasNPU) {
                appState.npuUsage = getNpuUsage();
            }
            
            // Update RAM usage
            appState.ramUsageKB = getCurrentRAMUsageKB();
            
            // Update network bandwidth (kontinuierlich messen)
            appState.networkBandwidth = getNetworkBandwidth();
            
            lastHwUpdate = now;
        }

        // Start ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        // Main window FIRST (im Hintergrund)
        renderMainWindow();
        
        // DIALOGS LAST so they are always on top of main window!
        renderLocalBrowser();
        renderNfsDirectoryBrowser();
        renderLocalBrowserWindows();
        renderNetworkScanner();
        renderCredentialsDialog();
        renderServerBrowser();
        renderSmbMountDialog();
        renderSettings();
        renderSudoPasswordDialog();
        renderAbout();
        renderFileErrorDialog();
        renderDeleteSuccess();
        renderSaveStateDialog();
        renderLoadStateDialog();
        
        // Sudo password prompt (highest priority)
        if (showPasswordPrompt) {
            ImGui::OpenPopup("Sudo Password Required");
        }
        
        if (ImGui::BeginPopupModal("Sudo Password Required", &showPasswordPrompt, 
            ImGuiWindowFlags_AlwaysAutoResize)) {
            
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "🔒 Root-Rechte erforderlich");
            ImGui::Separator();
            ImGui::Spacing();
            
            ImGui::Text("FileDuper benötigt Root-Rechte zum Mounten von Netzwerk-Shares.");
            ImGui::Text("Bitte gib dein Passwort ein:");
            ImGui::Spacing();
            
            ImGui::SetNextItemWidth(300);
            bool enterPressed = ImGui::InputText("##SudoPassword", sudoPassword, 
                sizeof(sudoPassword), ImGuiInputTextFlags_Password | ImGuiInputTextFlags_EnterReturnsTrue);
            
            ImGui::Spacing();
            
            if (ImGui::Button("OK", ImVec2(120, 0)) || enterPressed) {
                passwordEntered = true;
                showPasswordPrompt = false;
                ImGui::CloseCurrentPopup();
            }
            
            ImGui::SameLine();
            
            if (ImGui::Button("Abbrechen", ImVec2(120, 0))) {
                passwordEntered = false;
                showPasswordPrompt = false;
                memset(sudoPassword, 0, sizeof(sudoPassword));
                ImGui::CloseCurrentPopup();
            }
            
            ImGui::Spacing();
            ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "Hinweis: Passwort wird verschlüsselt im RAM gespeichert (5 Min Cache)");
            
            ImGui::EndPopup();
        }

        // Status notification overlay (bottom-right corner)
        if (appState.statusNotificationTimer > 0.0f) {
            ImGuiIO& io = ImGui::GetIO();
            ImVec2 window_pos = ImVec2(io.DisplaySize.x - 10, io.DisplaySize.y - 10);
            ImVec2 window_pos_pivot = ImVec2(1.0f, 1.0f);
            ImGui::SetNextWindowPos(window_pos, ImGuiCond_Always, window_pos_pivot);
            ImGui::SetNextWindowBgAlpha(0.85f);
            
            ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | 
                                    ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | 
                                    ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove;
            
            if (ImGui::Begin("StatusNotification", nullptr, flags)) {
                ImGui::PushStyleColor(ImGuiCol_Text, appState.statusNotificationColor);
                ImGui::TextUnformatted(appState.statusNotification.c_str());
                ImGui::PopStyleColor();
            }
            ImGui::End();
            
            // Decrease timer
            appState.statusNotificationTimer -= ImGui::GetIO().DeltaTime;
        }

        // Rendering
        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    // Cleanup
    std::cout << "[Cleanup] Saving settings..." << std::endl;
    saveSettings();
    
    std::cout << "[Cleanup] Saving FTP directory cache..." << std::endl;
    saveFtpDirCache();
    
    // Unmount NFS shares if configured
    std::cout << "[Cleanup] Unmounting NFS shares..." << std::endl;
    for (auto& preset : appState.ftpPresets) {
        if (preset.serviceType == "NFS" && preset.nfsMounted) {
            std::cout << "[NFS] Unmounting: " << preset.name << std::endl;
            unmountNFS(preset);
        }
    }
    
    // Unmount SMB/CIFS shares if configured
    std::cout << "[Cleanup] Unmounting SMB shares..." << std::endl;
    for (auto& preset : appState.ftpPresets) {
        if (preset.serviceType == "SMB" && preset.smbMounted) {
            std::cout << "[SMB] Unmounting: " << preset.name << std::endl;
            unmountSMB(preset);
        }
    }
    
    // Unmount WebDAV shares if configured
    std::cout << "[Cleanup] Unmounting WebDAV shares..." << std::endl;
    for (auto& preset : appState.ftpPresets) {
        if (preset.serviceType == "WebDAV" && preset.davMounted) {
            std::cout << "[WebDAV] Unmounting: " << preset.name << std::endl;
            unmountWebDAV(preset);
        }
    }
    
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();
    
    // ============================================================================
    // RAM CLEANUP: Free all memory before exit
    // ============================================================================
    std::cout << "[Cleanup] Freeing all memory..." << std::endl;
    
    // Stop any running scan thread
    stopScan = true;
    if (scanThread.joinable()) {
        scanThread.join();
    }
    
    // Clear all caches
    {
        std::lock_guard<std::mutex> lock(hashCacheMutex);
        hashCache.clear();
        std::cout << "[Cleanup] Hash cache cleared" << std::endl;
    }
    
    {
        std::lock_guard<std::mutex> lock(fileCacheMutex);
        fileCache.clear();
        std::cout << "[Cleanup] File cache cleared" << std::endl;
    }
    
    // Clear all AppState data structures
    {
        std::lock_guard<std::mutex> lock(resultsMutex);
        appState.filesByHash.clear();
        appState.duplicates.clear();
        appState.markedForDeletion.clear();
        appState.selectedLocalDirs.clear();
        appState.selectedFtpDirs.clear();
        appState.discoveredHosts.clear();
        appState.inaccessibleFiles.clear();
        appState.searchHistory.clear();
        appState.ftpPresets.clear();
        std::cout << "[Cleanup] AppState data cleared" << std::endl;
    }
    
    // Cleanup CURL
    cleanupCurlSharing();
    curl_global_cleanup();
    
    std::cout << "[Cleanup] Memory cleanup complete!" << std::endl;

    return 0;
}
