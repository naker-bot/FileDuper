#ifndef SCANNER_H
#define SCANNER_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <QMutex>
#include <QQueue>
#include <QFileInfo>
#include <QDirIterator>
#include <QSet>
#include <QDateTime>  // ⏱️ REQUIRED: Fortschritts-Monitor für intelligenten Timeout
#include <atomic>
#include <map>
#include <memory>
#include <QMetaType>
#include <QFuture>
#include "npumanager.h"       // 🧠 NPU-INTEGRATION für Bildverarbeitung
#include "hardwarebenchmark.h" // ⚡ Hardware Auto-Detect & Optimization

class HashEngine;
class PresetManager;
class FtpClient;
class SftpClient;      // ✅ SFTP Client Forward Declaration
class SmbClient;       // ✅ SMB Client Forward Declaration  
class NfsClient;       // ✅ NFS Client Forward Declaration

struct FileInfo
{
    // Strings first (implicitly shared), then 64-bit integers, then small flags
    QString filePath;
    QString fileName;
    QString hash;
    QString preHash;  // 🚀 512-Byte rapid pre-hash für Early-Exit filtering
    QString networkType;        // "FTP", "SFTP", "SMB" etc. (leer für lokal)
    QString parentDirectory;    // 📁 Übergeordnetes Verzeichnis (für Hierarchie-Anzeige)
    QString topLevelDirectory;  // 📁 Root-Scan-Verzeichnis (für Parent/Child-Analyse)
    qint64 size = 0;
    qint64 lastModified = 0;
    bool isLocal = true;        // true = lokale Datei, false = Netzwerk-Datei
};

struct DuplicateGroup
{
    FileInfo original;          // Yellow background - keep this
    QList<FileInfo> duplicates; // Green background - delete candidates
    QString hash;
    QString preHash;  // 🚀 512-Byte rapid pre-hash für Early-Exit filtering
    qint64 size;
    QSet<QString> affectedDirectories;   // 📁 Alle betroffenen Verzeichnisse (Parent & Child)
    QMap<QString, int> directoryFileCounts; // 📊 Anzahl Dateien pro Verzeichnis in dieser Gruppe
    bool hasParentChildConflict = false;    // ⚠️ true wenn Parent & Child beide Duplikate haben
};

struct DuplicateGroups
{
    QList<DuplicateGroup> groups;
    int totalFiles = 0;
    int duplicateFiles = 0;
    qint64 duplicateSize = 0;
};

// 🎯 NPU-INTEGRATION: Erweiterte Strukturen für Feature-basierte Bildvergleiche
struct ImageDuplicateGroup
{
    NpuManager::ImageFeature originalImage;        // Bestes Qualitätsbild (behalten)
    QList<NpuManager::ImageFeature> duplicateImages; // Zu löschende ähnliche Bilder
    float averageSimilarity;                       // Durchschnittliche Ähnlichkeit in der Gruppe
    QString groupType;                             // "STRICT", "NEAR", "SIMILAR", "LOOSE"
};

struct CombinedDuplicateResult
{
    QList<DuplicateGroup> hashDuplicates;         // Traditionelle Hash-basierte Duplikate
    QList<ImageDuplicateGroup> imageDuplicates;   // NPU-basierte Bild-Ähnlichkeiten
    int totalGroups() const { return hashDuplicates.size() + imageDuplicates.size(); }
    int totalDuplicates() const;
};

// 🔐 Ensure custom types are known to Qt's meta-type system (for queued connections, etc.)
Q_DECLARE_METATYPE(FileInfo)
Q_DECLARE_METATYPE(DuplicateGroup)
Q_DECLARE_METATYPE(DuplicateGroups)
Q_DECLARE_METATYPE(ImageDuplicateGroup)
Q_DECLARE_METATYPE(CombinedDuplicateResult)
Q_DECLARE_METATYPE(NpuManager::ImageFeature)
Q_DECLARE_METATYPE(QList<NpuManager::ImageFeature>)

// ⚡ Performance-Hinweise für Qt-Container
// Markiere Value-Types als effizient relocatable/movable, damit Qt-Container
// (QList/QVector) schnelle Move/Memcpy-Operationen nutzen können.
#if defined(QT_VERSION) && QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
Q_DECLARE_TYPEINFO(FileInfo, Q_RELOCATABLE_TYPE);
Q_DECLARE_TYPEINFO(DuplicateGroup, Q_RELOCATABLE_TYPE);
Q_DECLARE_TYPEINFO(DuplicateGroups, Q_RELOCATABLE_TYPE);
Q_DECLARE_TYPEINFO(ImageDuplicateGroup, Q_RELOCATABLE_TYPE);
Q_DECLARE_TYPEINFO(CombinedDuplicateResult, Q_RELOCATABLE_TYPE);
#else
Q_DECLARE_TYPEINFO(FileInfo, Q_MOVABLE_TYPE);
Q_DECLARE_TYPEINFO(DuplicateGroup, Q_MOVABLE_TYPE);
Q_DECLARE_TYPEINFO(DuplicateGroups, Q_MOVABLE_TYPE);
Q_DECLARE_TYPEINFO(ImageDuplicateGroup, Q_MOVABLE_TYPE);
Q_DECLARE_TYPEINFO(CombinedDuplicateResult, Q_MOVABLE_TYPE);
#endif

class Scanner : public QObject
{
    Q_OBJECT

public:
    explicit Scanner(QObject *parent = nullptr);
    ~Scanner();

    // Scan control
    void startScan(const QStringList &directories, const QString &hashAlgorithm, const QString &fileFilter);
    void stopScan();
    void pauseScan();
    void resumeScan();
    void startProcessingCollectedFiles(); // 🔥 NEW: Start processing after file collection

    // Configuration
    void setHashEngine(HashEngine *engine);
    HashEngine* getHashEngine() const { return hashEngine; } // 🔥 NEW: Get HashEngine for signal connection
    void setPresetManager(PresetManager *manager);
    void setFtpClient(FtpClient *client);
    void setNpuManager(NpuManager *manager);    // 🧠 NPU-INTEGRATION
    // Toggle NPU usage at runtime (false = no NPU involvement in scan pipeline)
    void setNpuEnabled(bool enabled);

    // Status
    bool isScanning() const;
    bool isPaused() const;
    
    // 🔥 Getter für allFiles zum Debugging (const reference to avoid copying!)
    const QList<FileInfo>& getAllFiles() const { return allFiles; }
    
    // Cleanup
    void clearAllHashes();  // 🗑️ Lösche alle Hash-Indizes
    
    // 🔐 Hash-Cache Management (public für MainWindow)
    void saveHashCache();                      // Speichere Hash-Cache nach Scan
    void saveHashCacheOnlyDuplicates(const QList<DuplicateGroup> &duplicateGroups); // 🔥 Speichere nur Duplikate
    void removeFromHashCache(const QString &filePath); // Entferne nach Löschung

signals:
    void filesCollected(int totalFiles);
    void hashingStarted(int filesToHash);
    void comparingStarted();
    void scanCompleted(const DuplicateGroups &groups);
    void scanProgress(int percentage, int current, int total); // ✅ FIX: percentage zuerst!
    void scanProgressDetailed(int percentage, int current, int total, const QString &action); // ✅ NEU für enhanced display
    void scanStatusChanged(const QString &status);
    void error(const QString &message);
    
    // 🎯 LIVE-AKTIVITÄTS-SIGNALE für GUI
    void currentFileProcessing(const QString &fileName, const QString &processType, int fileNumber, int totalFiles);
    void processActivityUpdate(const QString &activity, const QString &details);
    void ftpProgressUpdate(int totalDirectories, int completedDirectories, int pendingScans);  // 📡 FTP-Verzeichnis-Fortschritt
    
    // 🚀 NEUE DETAILLIERTE PROGRESS-SIGNALE
    void fileComparisonProgress(const QString &file1, const QString &file2, int comparisonNumber, int totalComparisons);
    void pathProcessingUpdate(const QString &currentPath, const QString &action, int pathNumber, int totalPaths);
    void duplicateDetectionUpdate(int duplicatesFound, int groupsCreated, const QString &latestDuplicate);
    void hardwareUsageUpdate(const QString &processingUnit, int utilizationPercent, const QString &currentTask);
    
    // 🎯 NEUE SIGNALE: NPU-Bildverarbeitung
    void imageFeaturesExtracted(const QList<NpuManager::ImageFeature> &features);
    void imageDuplicatesFound(const QList<ImageDuplicateGroup> &imageGroups);
    void combinedScanCompleted(const CombinedDuplicateResult &result);
    void npuAnalysisProgress(const QString &status);
    void npuActivityUpdate(int imagesProcessed, int duplicateGroupsFound); // 🚀 NPU-AKTIVITÄTS-UPDATE
    
    // 🗑️ Lösch-Signale
    void deleteProgress(const QString &filePath, bool success, const QString &message);
    void deleteBatchFinished(int attempted, int succeeded);


    // ✅ HARDWARE STATUS SIGNALS
    void cpuStatusUpdated(int cores, int score);
    void gpuStatusUpdated(bool available, const QString &name, int score);
    void gpuMemoryUpdated(int usedMB, int totalMB);
    void gpuClockUpdated(int clockMHz);
    void gpuTemperatureUpdated(int tempC);
    void npuStatusUpdated(bool available, int score);
    void npuActivityUpdated(int activeUnits, int totalUnits, const QString &currentTask);
    void npuPowerUpdated(int powerW);
    void ioStatusUpdated(int score);
    void memoryStatusUpdated(int availableMB);
    
    // 🚀 HARDWARE ACCELERATION STATUS (SHA-NI, AVX2, AVX512)
    void hardwareStatusUpdate(bool hasSHANI, bool hasSHA512NI, bool hasAVX2, bool hasAVX512);

private slots:
    void processNextFile();
    void onHashCalculated(const QString &filePath, const QString &hash, bool isLocal);
    void onFtpFilesReceived(const QString &directory, const QStringList &files, bool success);
    void onNpuImageBatchProcessed(const QStringList &processedImages);  // 🧠 NPU-CALLBACK
    void onFtpRemoveFinished(const QString &remoteFile, bool ok);

private:
    void collectFiles();
    void collectFtpFiles(const QString &ftpDirectory, QSet<QString> &processedFiles, bool isFromQueue = false);
    void checkScanProgress();
    void filterBySize();
    // filterByEarlyExit() REMOVED - caused false "unique" for videos
    void startHashing();
    void startHashingPhase();  // ✅ NEU: Non-blocking transition to hashing
    void compareHashes();
    void generateResults();
    
    // 🗑️ Duplikat-Löschung
    void deleteDuplicateFiles(const QList<FileInfo> &filesToDelete);
    bool deleteLocalFile(const QString &path, QString &msg);
    void deleteFtpFile(const QString &ftpUrl);

    // Path optimization to prevent redundant comparisons
    QStringList deduplicateDirectories(const QStringList &directories);
    bool isDuplicateFile(const QString &filePath, const QList<FileInfo> &existingFiles);
    
    // ⚡ OPTIMIERUNG: Partielle Results für Anti-Hang
    DuplicateGroups buildPartialResults();
    void processCachedFtpFiles(const QString &ftpDirectory, const QStringList &files, QSet<QString> &processedFiles);
    FtpClient* getOrCreateFtpClient(const QString &host, int port = 21, const QString &parentFtpUrl = "");
    void useDefaultFtpCredentials(FtpClient *client, const QString &host);
    
    // 🧠 SMART HASH AUTO-DETECT
    QString selectOptimalHashAlgorithm(const QString &filePath);

    // 🛡️ NEUE FUNKTIONEN: Schutz vor Doppelbearbeitung
    void clearDeduplicationCaches();
    bool isFileAlreadyProcessed(const QString &filePath);
    void connectNpuManager(NpuManager *npuManager);
    
    // 🧠 MEMORY-SAFE: Batch-Verarbeitung für große FTP-Datensätze
    void processFtpFilesBatch(const QString &directory, const QStringList &files, bool success);
    void processSingleFtpBatch(const QString &directory, const QStringList &batchFiles);
    
    // ✅ Asynchrone Dateisammlung - GUI-responsive
    void startAsyncFileCollection();
    void processNextDirectoryChunk();
    void cleanupFileCollection();
    
    // 🌐 FTP 2-PHASEN-STRATEGIE: Discovery dann Scan
    void startFtpDiscovery(const QStringList &ftpRootDirectories);
    void discoverFtpDirectoriesRecursive(const QString &directory);
    void checkFtpDiscoveryCompletion();
    void onFtpDiscoveryCompleted();
    void scanFtpDirectoryForFiles(const QString &ftpDirectory); // 🔥 NEW: Scan FTP directory for actual files
    void startFtpScan();
    
    // 🚀 PARALLEL FTP PROCESSING mit QtConcurrent
    void startParallelFtpDiscovery(const QStringList &ftpRootDirectories);
    void processFtpDiscoveryBatch(const QStringList &ftpBatch);
    
    // �🎯 NPU-BILDVERARBEITUNG: Feature-basierte Ähnlichkeitsanalyse
    void startNpuImageAnalysis(const QStringList &imagePaths);
    void processImageFeatures(const QList<NpuManager::ImageFeature> &features);
    QStringList filterImageFiles(const QList<FileInfo> &allFiles);
    CombinedDuplicateResult combineHashAndImageResults();
    
    // NPU-Integration in Scanner-Pipeline
    void startAdvancedDuplicateDetection(); // Hash + NPU kombiniert
    bool isImageFile(const QString &filePath) const;
    
    // 🧠 FUZZY-NAME-MATCHING: Levenshtein-Distanz für ähnliche Dateinamen
    int calculateLevenshtein(const QString &s1, const QString &s2) const;
    
    // 📁 PARENT/CHILD DIRECTORY ANALYSIS
    QString extractTopLevelDirectory(const QString &filePath) const;
    bool isParentChildRelation(const QString &dir1, const QString &dir2) const;
    
    // ⚡ HARDWARE-OPTIMIERUNG: Intelligente Zuweisung nach Dateityp
    enum ProcessingUnit {
        USE_CPU,     // Text, Dokumente, kleine Dateien
        USE_GPU,     // Bilder, Videos, große Dateien
        USE_NPU      // KI-basierte Ähnlichkeit (Bilder)
    };
    ProcessingUnit selectOptimalHardware(const FileInfo &file) const;

private:
    HashEngine *hashEngine = nullptr;
    PresetManager *presetManager = nullptr;
    FtpClient *ftpClient = nullptr;
    SftpClient *sftpClient = nullptr;    // ✅ SFTP Client Instance
    SmbClient *smbClient = nullptr;      // ✅ SMB Client Instance
    NfsClient *nfsClient = nullptr;      // ✅ NFS Client Instance
    NpuManager *npuManager = nullptr;    // 🧠 NPU-MANAGER für Bildverarbeitung
    
    // ⚡ HARDWARE AUTO-OPTIMIZATION: Detected capabilities and optimal settings
    HardwareCapabilities hardwareCaps;   // Detected hardware and benchmark results

    QTimer *processTimer = nullptr;
    QTimer *fileCollectionTimer = nullptr;  // ✅ Neuer Timer für asynchrone Dateisammlung
    QTimer *ftpQueueDrainTimer = nullptr;  // 🚀 Periodischer Timer für FTP-Queue-Abarbeitung
    QStringList scanDirectories;
    QString currentHashAlgorithm;
    QString currentFileFilter;
    
    // ✅ Asynchrone Dateisammlung
    QQueue<QString> directoriesToProcess;    // Queue der zu verarbeitenden Verzeichnisse
    QDirIterator *currentDirIterator = nullptr;  // Aktueller Directory Iterator
    int currentDirectoryIndex = 0;           // Index des aktuellen Verzeichnisses
    int filesFoundInCurrentDir = 0;          // Dateien im aktuellen Verzeichnis gefunden
    QSet<QString> processedFiles;            // Verarbeitete Dateien in dieser Session
    QMutex processedFilesMutex;              // 🔒 SYNC: Protect processedFiles from race conditions

    QList<FileInfo> allFiles;
    QMutex allFilesMutex;                    // 🔒 CRITICAL: Protect allFiles from race conditions
    
    QHash<qint64, QList<FileInfo>> fileSizeGroups;
    QMutex m_fileSizeGroupsMutex;            // 🔒 SYNC: Protect fileSizeGroups from race conditions
    QHash<QString, QList<FileInfo>> hashGroups;
    
    // 🚀 CHUNK-PIPELINE Performance
    int chunkSize = 50;  // Verarbeite 50 Dateien parallel pro Chunk
    QMap<QString, QList<FileInfo>> dateSizeGroups;  // 🚀 Optimized groups (size+date filtered)
    
    // 📊 INTELLIGENTER FORTSCHRITTS-MONITOR (ersetzt festen Timeout)
    qint64 lastHashProgressTime = 0;  // Letzte Zeit mit Fortschritt (QDateTime::currentMSecsSinceEpoch)
    int lastHashCount = 0;            // Letzte Anzahl fertige Hashes
    std::atomic<int> currentHashCount{0};  // 🔧 Aktueller Hash-Counter (thread-safe)

    // 🛡️ NEUE MEMBER: Schutz vor Doppelbearbeitung
    QSet<QString> globalProcessedFiles; // Globaler Schutz vor Datei-Doppelbearbeitung
    QSet<QString> globalHashedFiles;    // Globaler Schutz vor Hash-Doppelberechnung
    int totalFilesForHashing = 0;       // 🎯 Gesamt-Dateien für Live-Progress-Anzeige
    
    // 🔥 GUARD FLAG: Verhindert mehrfache scanCompleted-Emissionen pro Scan-Zyklus
    std::atomic<bool> m_scanCompletedEmitted{false};
    
    // 🔥 TOTAL FILES: Speichert Anzahl gesammelter Dateien für scanCompleted
    int m_totalCollectedFiles = 0;
    
    // 🔐 PERSISTENTE SCAN-HISTORY: Verhindert mehrfaches Scannen über Sessions hinweg
    QSet<QString> scannedDirectoriesHistory;  // Alle jemals gescannten Verzeichnisse
    QSet<QString> scannedFilesHistory;        // Alle jemals gescannten Dateien
    QString scanHistoryFile;                   // Pfad zur History-Datei (~/.fileduper_scan_history.dat)
    
    // 🚀 SCAN-HISTORY MANAGEMENT
    void loadScanHistory();                    // Lade History beim Start
    void saveScanHistory();                    // Speichere History nach jedem Scan
    void clearScanHistory();                   // Lösche History (Menü-Option)
    bool isDirectoryInHistory(const QString &dir) const;
    bool isFileInHistory(const QString &filePath) const;
    void addToScanHistory(const QString &path, bool isDirectory);
    
    // 🔐 HASH-CACHE MANAGEMENT: Persistente Hash-Speicherung
    QString hashCacheFile;                     // Pfad zur Hash-Cache-Datei (~/.fileduper_hash_cache.dat)
    QMap<QString, QPair<QString, qint64>> hashCache; // filePath -> (hash, size)
    void loadHashCache();                      // Lade Hash-Cache beim Start
    void updateHashCache(const QString &filePath, const QString &hash, qint64 size); // Update einzelner Eintrag
    QString getCachedHash(const QString &filePath, qint64 size); // Hole Hash aus Cache
    
    // 🎯 NPU-BILDVERARBEITUNG: Feature-basierte Analyse
    QList<NpuManager::ImageFeature> extractedFeatures; // Extrahierte Bildfeatures
    QList<ImageDuplicateGroup> imageDuplicateGroups;   // NPU-erkannte Bild-Duplikate
    NpuManager::SimilarityMode currentSimilarityMode = NpuManager::SimilarityMode::STRICT_DUPLICATES;  // Sicherer Default
    int npuProcessedImages = 0;                        // 🚀 Anzahl NPU-verarbeiteter Bilder
    bool npuEnabled = false;                           // 🔒 Default: NPU aus, Hash-only Pipeline
    int deleteAttempted = 0;
    int deleteSucceeded = 0;
    
    // 🌐 2-PHASEN FTP-SCAN: Discovery dann File-Scan
    bool ftpDiscoveryPhase = false;                    // true = sammle nur Verzeichnisse, false = scanne Dateien
    bool m_ftpDiscoveryCompletedFlag = false;          // true = onFtpDiscoveryCompleted wurde ausgeführt (reset bei neuem Scan)
    QSet<QString> discoveredFtpDirectories;            // Alle entdeckten FTP-Verzeichnisse (Phase 1)
    QAtomicInt ftpDiscoveryPending{0};                 // Anzahl laufender Discovery-Requests
    QAtomicInt ftpDiscoveryCompleted{0};               // Anzahl abgeschlossener Discovery-Scans
    QAtomicInt ftpFileListingsPending{0};              // 🔥 Anzahl laufender File-Listing Callbacks
    QAtomicInt ftpFileListingsCompleted{0};            // 🔥 Anzahl abgeschlossener File-Listing Callbacks
    QStringList localDirectoriesForLaterScan;          // Lokale Verzeichnisse warten auf FTP-Discovery
    QMap<QString, QMetaObject::Connection> ftpDiscoveryConnections;  // Signal connections für Discovery cleanup
    QMap<QString, QMetaObject::Connection> m_ftpFileListConnections;  // 🔥 Track filesListFinished connections per directory

    // 🚀 PARALLEL PRE-COMPARISON: Vorvergleiche während Hash-Berechnung
    QMutex m_preComparisonMutex;                       // Schützt parallelen Zugriff auf Vorvergleich-Daten
    QMap<QString, QList<FileInfo>> m_hashToFilesMap;   // Hash → Liste von Dateien (für schnelle Duplikat-Erkennung)
    QSet<QString> m_potentialDuplicates;               // Dateien die potenzielle Duplikate sind
    void performPreComparison(const FileInfo &hashedFile);  // Vergleicht neue Datei mit bereits gehashten

    // FTP processing state
    QSet<QString> pendingFtpDirectories;        // 🔥 Changed to QSet for O(1) duplicate detection
    QSet<QString> processedFtpDirectories;      // 🔥 Track ALL scanned directories (never reset!)
    QSet<QString> completedFtpDirectories;  // 🔒 QSet verhindert Duplikate!
    QSet<QString> currentlyProcessingFtpDirectories; // 🔥 Track directories currently being processed
    int ftpDirectoriesProcessed = 0;
    QAtomicInt pendingFtpScans{0};  // 🔥 Counter für ausstehende FTP-Scans (inkl. rekursive)
    QSet<FtpClient*> m_recursiveClientsConnected;  // 🔥 Track welche FtpClients bereits subdirectoriesFound-Signal connected haben
    QMap<QString, int> ftpRecursionDepth;  // 🔥 Track recursion depth per FTP URL (max 10 levels)
    static constexpr int MAX_FTP_RECURSION_DEPTH = 10;  // 🔥 Limit to prevent infinite loops
    // Per-host FTP sequencing: parallel scanning with concurrency limit
    QHash<QString, QStringList> ftpQueuePerHost; // host -> queue of ftp://host/path entries
    QSet<QString> ftpActiveHosts;                // hosts currently running a listFiles
    int maxParallelFtpScans = 150;                // 🚀 ULTRA: 150 parallel FTP (Server unterstützt 300!)
    QHash<QString, int> activeFtpScansPerHost;   // Track active scans per host
    
    // 🚀 PARALLEL FTP PROCESSING mit Connection Pool
    QList<FtpClient*> ftpConnectionPool;         // Pool von wiederverwendbaren FTP-Verbindungen
    QMutex ftpConnectionPoolMutex;               // Schützt Zugriff auf Connection Pool
    int maxFtpConnections = 20;                   // Maximal 20 gleichzeitige FTP-Verbindungen
    int activeFtpConnections = 0;                 // Anzahl aktiver Verbindungen
    QSet<QString> activeFtpRequests;             // Set von aktuell laufenden FTP-Requests
    QMutex ftpRequestsMutex;                     // Schützt activeFtpRequests
    
    // 🚀 FTP CACHING: Vermeidet redundante LIST commands
    QHash<QString, QPair<QStringList, qint64>> ftpListCache;  // ftpUrl -> (files, timestamp)
    QMutex ftpCacheMutex;                        // Schützt ftpListCache
    qint64 ftpCacheExpiryMs = 300000;            // 5 Minuten Cache-Gültigkeit
    
    FtpClient* getFtpConnectionFromPool(const QString &host, int port);
    void returnFtpConnectionToPool(FtpClient* client);
    void clearFtpConnectionPool();               // Cleanup beim Beenden
    
    // 🚀 OPTIMIERUNG 2: Smart Pre-Filtering
    qint64 minFileSizeForHashing = 1024;  // Skip files < 1KB (meist keine Duplikate)
    bool enableSmartPreFiltering = true;
    
    // 🚀 OPTIMIERUNG 3: NPU/GPU Hash-Beschleunigung
    bool useNpuForHashing = false;
    bool useGpuForHashing = false;
    
    // NON-BLOCKING Directory Processing (GUI-responsive)
    QStringList pendingDirectories;
    std::map<QString, std::unique_ptr<QDirIterator>> currentDirIterators;
    
    // 🚀 ASYNC: Store watchers to prevent premature destruction
    QList<QFutureWatcher<void>*> activeFtpDiscoveryWatchers;  // Active FTP watchers
    QMutex ftpWatchersMutex;                                   // Protect watchers list
    
    // Processing state flags
    bool hasFtpDirectories = false;
    bool hasLocalDirectories = false;

    std::atomic<bool> scanning{false};
    std::atomic<bool> paused{false};

    enum ScanPhase
    {
        IDLE,
        COLLECTING,
        SIZE_FILTERING,
        HASHING,
        COMPARING,
        COMPLETED
    } currentPhase = IDLE;
};

#endif // SCANNER_H
