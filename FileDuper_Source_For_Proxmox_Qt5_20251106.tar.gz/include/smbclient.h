#ifndef SMBCLIENT_H
#define SMBCLIENT_H

#include <QObject>
#include <QProcess>
#include <QTimer>
#include <QStringList>
#include <QDateTime>

struct SmbShareInfo
{
    QString name;
    QString path;
    QString type;
    QString comment;
    qint64 size;
    QDateTime lastModified;
    bool isDirectory;
};

class SmbClient : public QObject
{
    Q_OBJECT

public:
    explicit SmbClient(QObject *parent = nullptr);
    ~SmbClient();

    // Connection management
    void setCredentials(const QString &host, int port, const QString &username, const QString &password);
    void connectToHost();
    void disconnectFromHost();
    bool isConnected() const;

    // Share and directory operations
    void listShares();
    void listDirectory(const QString &shareName, const QString &path = QString());
    QList<SmbShareInfo> getAvailableShares() const;
    QList<SmbShareInfo> getCurrentDirectoryListing() const;

    // File operations
    void downloadFile(const QString &shareName, const QString &remotePath, const QString &localPath);
    void uploadFile(const QString &localPath, const QString &shareName, const QString &remotePath);
    void deleteFile(const QString &shareName, const QString &filePath);

signals:
    void connected();
    void disconnected();
    void errorOccurred(const QString &message);
    void sharesListReceived(const QList<SmbShareInfo> &shares);
    void directoryListingReceived(const QList<SmbShareInfo> &files);
    void fileDownloaded(const QString &localPath);
    void fileUploaded(const QString &remotePath);

private slots:
    void onSmbProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);
    void onSmbProcessError(QProcess::ProcessError error);

private:
    void executeSmbCommand(const QStringList &arguments);
    void parseShareListing(const QString &output);
    void parseDirectoryListing(const QString &output);
    SmbShareInfo parseShareLine(const QString &line);
    SmbShareInfo parseDirectoryLine(const QString &line);

    QString hostname;
    int port;
    QString username;
    QString password;
    QString currentShare;
    QString currentDirectory;

    QList<SmbShareInfo> availableShares;
    QList<SmbShareInfo> currentListing;

    QProcess *smbProcess;
    bool isConnectedFlag;
    QString lastCommand;
    QTimer *connectionTimer;
};

#endif // SMBCLIENT_H
