#ifndef NFSCLIENT_H
#define NFSCLIENT_H

#include <QObject>
#include <QProcess>
#include <QTimer>
#include <QStringList>
#include <QDateTime>

struct NfsExportInfo
{
    QString name;
    QString path;
    QString mountPoint;
    QString options;
    qint64 size;
    QDateTime lastModified;
    bool isDirectory;
    bool isMounted;
};

class NfsClient : public QObject
{
    Q_OBJECT

public:
    explicit NfsClient(QObject *parent = nullptr);
    ~NfsClient();

    // Connection management
    void setCredentials(const QString &host, int port, const QString &username = QString(), const QString &password = QString());
    void connectToHost();
    void disconnectFromHost();
    bool isConnected() const;

    // Export and directory operations
    void listExports();
    void mountExport(const QString &exportPath, const QString &localMountPoint);
    void unmountExport(const QString &localMountPoint);
    void listDirectory(const QString &mountPoint, const QString &path = QString());

    QList<NfsExportInfo> getAvailableExports() const;
    QList<NfsExportInfo> getCurrentDirectoryListing() const;

    // File operations (through mounted filesystem)
    void copyFile(const QString &sourcePath, const QString &destinationPath);
    void deleteFile(const QString &filePath);

signals:
    void connected();
    void disconnected();
    void errorOccurred(const QString &message);
    void exportsListReceived(const QList<NfsExportInfo> &exports);
    void exportMounted(const QString &mountPoint);
    void exportUnmounted(const QString &mountPoint);
    void directoryListingReceived(const QList<NfsExportInfo> &files);

private slots:
    void onNfsProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);
    void onNfsProcessError(QProcess::ProcessError error);

private:
    void executeNfsCommand(const QString &command, const QStringList &arguments);
    void parseExportListing(const QString &output);
    void parseDirectoryListing(const QString &output, const QString &basePath);
    NfsExportInfo parseExportLine(const QString &line);
    NfsExportInfo parseDirectoryLine(const QString &line, const QString &basePath);

    QString hostname;
    int port;
    QString currentMountPoint;
    QString currentDirectory;

    QList<NfsExportInfo> availableExports;
    QList<NfsExportInfo> currentListing;
    QStringList mountedExports;

    QProcess *nfsProcess;
    bool isConnectedFlag;
    QString lastCommand;
    QTimer *connectionTimer;
};

#endif // NFSCLIENT_H
