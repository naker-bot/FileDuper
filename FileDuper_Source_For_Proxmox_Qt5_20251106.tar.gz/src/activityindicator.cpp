#include "activityindicator.h"
#include <QHBoxLayout>
#include <QDebug>
#include <QProcess>
#include <iostream>

ActivityIndicator::ActivityIndicator(QWidget *parent)
    : QWidget(parent), isActive(false), currentCpuLoad(0), currentGpuLoad(0), currentNpuLoad(0),
      gpuAvailable(false), npuAvailable(false), intelGpuAvailable(false),
      cpuLoad(0), gpuLoad(0), npuLoad(0),    // 🧠 NPU-Load-Tracking
      cpuVisible(true), gpuVisible(true), npuVisible(true),  // 🎨 Visibility flags
      realNpuActivity(0)  // 🚀 ECHTES NPU-Activity-Tracking
{
    setupUI();

    // Einfacher Timer für Updates alle 2 Sekunden
    updateTimer = new QTimer(this);
    updateTimer->setInterval(2000);
    connect(updateTimer, &QTimer::timeout, this, &ActivityIndicator::updateHardwareLoads);
    updateTimer->start();

    // Blink-Timer
    cpuBlinkTimer = new QTimer(this);
    gpuBlinkTimer = new QTimer(this);
    npuBlinkTimer = new QTimer(this);

    connect(cpuBlinkTimer, &QTimer::timeout, this, &ActivityIndicator::blinkCpu);
    connect(gpuBlinkTimer, &QTimer::timeout, this, &ActivityIndicator::blinkGpu);  
    connect(npuBlinkTimer, &QTimer::timeout, this, &ActivityIndicator::blinkNpu);
    
    // 🚀 NPU-Activity-Reset-Timer
    npuActivityTimer = new QTimer(this);
    npuActivityTimer->setSingleShot(true);
    connect(npuActivityTimer, &QTimer::timeout, [this]() {
        realNpuActivity = 0; // Reset nach Activity-Phase
        qDebug() << "[ActivityIndicator] 🧠 NPU-Activity beendet → 0%";
    });

    // Hardware-Erkennung
    detectHardwareCapabilities();
}

ActivityIndicator::~ActivityIndicator()
{
    qDebug() << "[ActivityIndicator] 🧹 Destructor";
    
    isActive = false;
    
    if (updateTimer) {
        updateTimer->stop();
        updateTimer = nullptr;
    }
    
    if (cpuBlinkTimer) {
        cpuBlinkTimer->stop();
        cpuBlinkTimer = nullptr;
    }
    
    if (gpuBlinkTimer) {
        gpuBlinkTimer->stop();
        gpuBlinkTimer = nullptr;
    }
    
    if (npuBlinkTimer) {
        npuBlinkTimer->stop();
        npuBlinkTimer = nullptr;
    }
}

void ActivityIndicator::setupUI()
{
    // ✅ STATISCHE MITTIGE ANORDNUNG - Zentriert auf GUI-Breite
    layout = new QHBoxLayout(this);
    layout->setSpacing(25);  // Mehr Abstand für bessere Optik
    layout->setContentsMargins(20, 8, 20, 8);
    layout->setAlignment(Qt::AlignCenter);  // Zentraler Alignment
    
    // ✅ Fixe Breite für konsistente Anordnung
    setFixedWidth(320);  // Feste Breite für statische Anordnung
    setFixedHeight(35);  // Etwas höher für bessere Sichtbarkeit

    // ✅ CPU Load Label - Feste Breite für statische Anordnung
    cpuLoadLabel = new QLabel("CPU: 0%", this);
    cpuLoadLabel->setFixedWidth(80);
    cpuLoadLabel->setAlignment(Qt::AlignCenter);
    cpuLoadLabel->setStyleSheet("QLabel { font-weight: bold; color: green; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    layout->addWidget(cpuLoadLabel);

    // ✅ GPU Load Label - Feste Breite für statische Anordnung
    gpuLoadLabel = new QLabel("GPU: 0%", this);
    gpuLoadLabel->setFixedWidth(80);
    gpuLoadLabel->setAlignment(Qt::AlignCenter);
    gpuLoadLabel->setStyleSheet("QLabel { font-weight: bold; color: orange; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    layout->addWidget(gpuLoadLabel);

    // ✅ NPU Load Label - Feste Breite für statische Anordnung
    npuLoadLabel = new QLabel("NPU: 0%", this);
    npuLoadLabel->setFixedWidth(80);
    npuLoadLabel->setAlignment(Qt::AlignCenter);
    npuLoadLabel->setStyleSheet("QLabel { font-weight: bold; color: blue; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    layout->addWidget(npuLoadLabel);

    setLayout(layout);
    
    isActive = true;
    setVisible(true);
    show();
}

void ActivityIndicator::updateLoadDisplay()
{
    // Vereinfachte Hardware-Load-Abfrage
    currentCpuLoad = getCurrentCpuLoad();
    currentGpuLoad = getCurrentGpuLoad();
    currentNpuLoad = getCurrentNpuLoad();

    // Label-Updates
    if (cpuLoadLabel) {
        updateLoadDisplay(cpuLoadLabel, currentCpuLoad, "CPU");
    }
    
    if (gpuLoadLabel) {
        updateLoadDisplay(gpuLoadLabel, currentGpuLoad, "GPU");
    }
    
    if (npuLoadLabel) {
        updateLoadDisplay(npuLoadLabel, currentNpuLoad, "NPU");
    }
}

void ActivityIndicator::updateLoadDisplay(QLabel *label, int load, const QString &type)
{
    if (!label) return;
    
    LoadLevel level = getLoadLevel(load);
    QColor color = getLoadColor(level);

    label->setText(QString("%1: %2%").arg(type).arg(load));
    
    QString colorStyle = QString("QLabel { color: %1; font-weight: bold; font-size: 12px; border: 1px solid %1; border-radius: 4px; padding: 2px; }").arg(color.name());
    label->setStyleSheet(colorStyle);

    // Blink-Effekt für hohe Last
    if (level == HIGH_LOAD) {
        if (type == "CPU" && cpuBlinkTimer && !cpuBlinkTimer->isActive()) {
            cpuBlinkTimer->start(500);
        } else if (type == "GPU" && gpuBlinkTimer && !gpuBlinkTimer->isActive()) {
            gpuBlinkTimer->start(500);
        } else if (type == "NPU" && npuBlinkTimer && !npuBlinkTimer->isActive()) {
            npuBlinkTimer->start(500);
        }
    } else {
        if (type == "CPU" && cpuBlinkTimer) cpuBlinkTimer->stop();
        else if (type == "GPU" && gpuBlinkTimer) gpuBlinkTimer->stop();
        else if (type == "NPU" && npuBlinkTimer) npuBlinkTimer->stop();
        
        label->setVisible(true);
    }
}

void ActivityIndicator::setActive(bool active)
{
    isActive = active;
    if (active) {
        updateTimer->start();
    } else {
        updateTimer->stop();
    }
}

void ActivityIndicator::blinkCpu()
{
    if (cpuLoadLabel) cpuLoadLabel->setVisible(!cpuLoadLabel->isVisible());
}

void ActivityIndicator::blinkGpu()
{
    if (gpuLoadLabel) gpuLoadLabel->setVisible(!gpuLoadLabel->isVisible());
}

void ActivityIndicator::blinkNpu()
{
    if (npuLoadLabel) npuLoadLabel->setVisible(!npuLoadLabel->isVisible());
}

// Vereinfachte Hardware-Monitoring-Funktionen
int ActivityIndicator::getCurrentCpuLoad()
{
    // Echte CPU-Load via /proc/stat
    static long long lastIdle = 0, lastTotal = 0;
    
    QFile file("/proc/stat");
    if (!file.open(QIODevice::ReadOnly)) return 0;
    
    QString line = file.readLine();
    file.close();
    
    QStringList parts = line.split(' ', Qt::SkipEmptyParts);
    if (parts.size() < 8) return 0;
    
    // CPU times: user, nice, system, idle, iowait, irq, softirq, steal
    long long user = parts[1].toLongLong();
    long long nice = parts[2].toLongLong();
    long long system = parts[3].toLongLong();
    long long idle = parts[4].toLongLong();
    long long iowait = parts[5].toLongLong();
    long long irq = parts[6].toLongLong();
    long long softirq = parts[7].toLongLong();
    
    long long totalIdle = idle + iowait;
    long long total = user + nice + system + idle + iowait + irq + softirq;
    
    // Erste Messung - Return 0
    if (lastTotal == 0) {
        lastIdle = totalIdle;
        lastTotal = total;
        return 0;
    }
    
    long long totald = total - lastTotal;
    long long idled = totalIdle - lastIdle;
    
    double cpuPercent = 0.0;
    if (totald > 0) {
        cpuPercent = ((double)(totald - idled) / totald) * 100.0;
    }
    
    lastIdle = totalIdle;
    lastTotal = total;
    
    return qMin(100, qMax(0, (int)cpuPercent));
}

int ActivityIndicator::getCurrentGpuLoad()
{
    if (!gpuAvailable && !intelGpuAvailable) return 0;
    
    // ⚡ ECHTE GPU-AUSLASTUNG: Intel GPU via sysfs
    if (intelGpuAvailable) {
        QProcess gpuQuery;
        gpuQuery.start("sh", QStringList() << "-c" << "cat /sys/class/drm/card0/gt_cur_freq_mhz 2>/dev/null");
        gpuQuery.waitForFinished(100);
        
        if (gpuQuery.exitCode() == 0) {
            QString output = gpuQuery.readAllStandardOutput().trimmed();
            int currentFreq = output.toInt();
            
            // Berechne Prozentsatz basierend auf max Frequenz (typisch 1200 MHz für Intel UHD)
            if (currentFreq > 0) {
                int maxFreq = 1200; // Intel UHD Graphics typical max
                int percentage = qMin(100, (currentFreq * 100) / maxFreq);
                return percentage;
            }
        }
    }
    
    // Fallback: NVIDIA/AMD GPUs (nvidia-smi, rocm-smi könnten hier verwendet werden)
    return 0;
}

int ActivityIndicator::getCurrentNpuLoad()
{
    if (!npuAvailable) return 0;
    
    // ⚡ ECHTE NPU-AUSLASTUNG: Intel NPU via Level Zero API oder sysfs
    // Option 1: Prüfe ob NPU-Treiber aktiv ist
    QProcess npuQuery;
    npuQuery.start("sh", QStringList() << "-c" << "lspci -v | grep -i 'neural\\|npu\\|vpu' | wc -l");
    npuQuery.waitForFinished(100);
    
    if (npuQuery.exitCode() == 0) {
        QString output = npuQuery.readAllStandardOutput().trimmed();
        int npuDevices = output.toInt();
        
        if (npuDevices > 0) {
            // NPU ist präsent - prüfe auf aktive Prozesse
            QProcess npuProcs;
            npuProcs.start("sh", QStringList() << "-c" << "ps aux | grep -i 'npu\\|openvino\\|level-zero' | wc -l");
            npuProcs.waitForFinished(100);
            
            if (npuProcs.exitCode() == 0) {
                int activeProcs = npuProcs.readAllStandardOutput().trimmed().toInt();
                // Einfache Heuristik: > 2 Prozesse = NPU aktiv
                if (activeProcs > 2) {
                    return qMin(50, activeProcs * 10); // Max 50% als Indikator
                }
            }
        }
    }
    
    return 0;
}

// 🚀 PUBLIC: NPU-Activity direkt setzen vom HashEngine
void ActivityIndicator::signalNpuActivity(int percentage)
{
    if (percentage <= 0) return;
    
    realNpuActivity = qMin(100, percentage);
    currentNpuLoad = realNpuActivity; // 🎯 Auch currentNpuLoad aktualisieren
    
    // 🚀 NPU-GUI SOFORT SICHTBAR MACHEN
    updateLoadDisplay(npuLoadLabel, realNpuActivity, "NPU");
    qDebug() << "[ActivityIndicator] 🎯 NPU-GUI SOFORT aktualisiert:" << realNpuActivity << "%";
    
    // 🚀 Activity für 8 Sekunden halten (länger sichtbar)
    npuActivityTimer->stop();
    npuActivityTimer->start(8000); // 8 Sekunden statt 3
    
    qDebug() << "[ActivityIndicator] 🚀 NPU-Activity signaled:" << realNpuActivity << "% für 8s";
}

void ActivityIndicator::updateHardwareLoads()
{
    int cpuLoad = getCurrentCpuLoad();
    int gpuLoad = getCurrentGpuLoad();
    int npuLoad = getCurrentNpuLoad();

    updateLoadDisplay(cpuLoadLabel, cpuLoad, "CPU");
    updateLoadDisplay(gpuLoadLabel, gpuLoad, "GPU");
    updateLoadDisplay(npuLoadLabel, npuLoad, "NPU");

    currentCpuLoad = cpuLoad;
    currentGpuLoad = gpuLoad;
    currentNpuLoad = npuLoad;
}

// ✅ Kompatibilität für MainWindow
void ActivityIndicator::setIdle()
{
    setActivity(false, 0, 0, 0);
}

void ActivityIndicator::startOperation(const QString &operationName)
{
    setActivity(true, 50, 30, 20); // Moderate Belastung während Operation
    qDebug() << "ActivityIndicator: Starte Operation:" << operationName;
}

void ActivityIndicator::finishOperation(const QString &operationName)
{
    setActivity(false, 10, 5, 2); // Idle-Zustand nach Operation
    qDebug() << "ActivityIndicator: Beende Operation:" << operationName;
}

void ActivityIndicator::setActivity(bool active, int cpuLoad, int gpuLoad, int npuLoad)
{
    isActive = active;
    currentCpuLoad = cpuLoad;
    currentGpuLoad = gpuLoad;  
    currentNpuLoad = npuLoad;
    
    if (!active) {
        if (cpuLoadLabel) cpuLoadLabel->setText("CPU: 0%");
        if (gpuLoadLabel) gpuLoadLabel->setText("GPU: 0%");
        if (npuLoadLabel) npuLoadLabel->setText("NPU: 0%");
        
        if (cpuLoadLabel) cpuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: bold; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
        if (gpuLoadLabel) gpuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: bold; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
        if (npuLoadLabel) npuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: bold; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    } else {
        updateTimer->start();
        updateLoadDisplay();
    }
}

ActivityIndicator::LoadLevel ActivityIndicator::getLoadLevel(int load)
{
    if (load >= 80) return HIGH_LOAD;
    if (load >= 50) return MEDIUM_LOAD;
    return LOW_LOAD;
}

QColor ActivityIndicator::getLoadColor(LoadLevel level)
{
    switch (level) {
        case LOW_LOAD: return QColor(0, 200, 0);    // Grün
        case MEDIUM_LOAD: return QColor(255, 165, 0); // Orange
        case HIGH_LOAD: return QColor(255, 0, 0);    // Rot
        default: return QColor(100, 100, 100);       // Grau
    }
}

void ActivityIndicator::detectHardwareCapabilities()
{
    qDebug() << "[ActivityIndicator] 🔍 Intel-optimierte Hardware-Erkennung gestartet (identisch zu HashEngine)...";
    
    // Hardware-Erkennung zurücksetzen
    gpuAvailable = false;
    intelGpuAvailable = false;
    npuAvailable = false;

    // Intel GPU detection (Arc, Xe, UHD Graphics) - identisch zu HashEngine
    QProcess intelGpuCheck;
    intelGpuCheck.start("lspci");
    // ✅ ANTI-HANG: 2-Sekunden Timeout für Intel GPU Check
    if (!intelGpuCheck.waitForFinished(2000)) {
        qWarning() << "[ActivityIndicator] ⚠️ Intel GPU lspci-Timeout - überspringe";
        intelGpuCheck.kill();
        intelGpuAvailable = false;
    } else {
        intelGpuAvailable = (intelGpuCheck.exitCode() == 0 && !intelGpuCheck.readAllStandardOutput().isEmpty());
    }

    // General GPU detection via lspci parsing - identisch zu HashEngine
    QProcess gpuCheck;
    gpuCheck.start("lspci");
    // ✅ ANTI-HANG: 2-Sekunden Timeout für Generic GPU Check
    if (!gpuCheck.waitForFinished(2000)) {
        qWarning() << "[ActivityIndicator] ⚠️ Generic GPU lspci-Timeout - überspringe";
        gpuCheck.kill();
        gpuAvailable = false;
    } else {
        gpuAvailable = (gpuCheck.exitCode() == 0 && !gpuCheck.readAllStandardOutput().isEmpty());
    }

    // Intel NPU detection for AI acceleration - identisch zu HashEngine
    QProcess npuCheck;
    npuCheck.start("lspci | grep -i 'Processing accelerators.*Intel.*Arrow Lake\\|neural\\|npu\\|intel.*ai\\|intel.*vpu'");
    // ✅ ANTI-HANG: 2-Sekunden Timeout für NPU Check
    if (!npuCheck.waitForFinished(2000)) {
        qWarning() << "[ActivityIndicator] ⚠️ NPU lspci-Timeout - überspringe";
        npuCheck.kill();
        npuAvailable = false;
    } else {
        QString npuOutput = npuCheck.readAllStandardOutput();
        npuAvailable = (npuCheck.exitCode() == 0 && !npuOutput.isEmpty());
    }
    
    // Intel Arrow Lake NPU support - verbesserte Erkennung mit TIMEOUT - identisch zu HashEngine
    if (!npuAvailable) {
        qDebug() << "[ActivityIndicator] 🧠 NPU nicht erkannt - prüfe Intel Arrow Lake NPU erweitert...";
        QProcess arrowLakeCheck;
        arrowLakeCheck.start("lspci");
        
        // ✅ ANTI-HANG: 3-Sekunden Timeout für lspci
        if (!arrowLakeCheck.waitForFinished(3000)) {
            qWarning() << "[ActivityIndicator] ⚠️ lspci-Timeout nach 3s - NPU-Erkennung übersprungen";
            arrowLakeCheck.kill();
        } else {
            QString allPciOutput = arrowLakeCheck.readAllStandardOutput();
            
            // Suche nach Arrow Lake NPU-spezifischen Strings
            if (allPciOutput.contains("Arrow Lake NPU", Qt::CaseInsensitive) ||
                allPciOutput.contains("Processing accelerators", Qt::CaseInsensitive) ||
                allPciOutput.contains("Intel Corporation", Qt::CaseInsensitive)) {
                npuAvailable = true;
                qDebug() << "[ActivityIndicator] 🚀 Intel Arrow Lake NPU über lspci-Vollscan erkannt!";
                qDebug() << "[ActivityIndicator] 📋 NPU gefunden in:" << allPciOutput.split('\n').filter("Arrow Lake", Qt::CaseInsensitive);
            }
        }
    }

    std::cout << "🔍 [ActivityIndicator] Hardware-Capabilities erkannt (identisch zu HashEngine):" << std::endl;
    std::cout << "   🎯 Intel GPU (Arc/Xe/UHD): " << (intelGpuAvailable ? "✅ Verfügbar" : "❌ Nicht gefunden") << std::endl;
    std::cout << "   🖥️  Generische GPU: " << (gpuAvailable ? "✅ Verfügbar" : "❌ Nicht gefunden") << std::endl;
    std::cout << "   🤖 Intel NPU/VPU: " << (npuAvailable ? "✅ Verfügbar" : "❌ Nicht gefunden") << std::endl;
    
    // Labels entsprechend anpassen
    if (!gpuAvailable && gpuLoadLabel) {
        gpuLoadLabel->setText("GPU: N/A");
        gpuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: normal; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    }
    
    if (!npuAvailable && npuLoadLabel) {
        npuLoadLabel->setText("NPU: N/A");
        npuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: normal; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    }
}

// 🧠 NPU-LOAD UPDATE METHODEN für NPU-Manager Integration
void ActivityIndicator::updateNpuLoad(int load)
{
    npuLoad = load;
    currentNpuLoad = load;  // Auch für Kompatibilität
    
    // ✅ NPU-LABEL DIREKT AKTUALISIEREN - GUI-FIX!
    if (npuLoadLabel) {
        npuLoadLabel->setText(QString("NPU: %1%").arg(load));
        QColor color = getLoadColor(getLoadLevel(load));
        npuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-weight: bold; }")
                                   .arg(color.name()));
        qDebug() << "[ActivityIndicator] 🎯 NPU-GUI aktualisiert:" << load << "%";
    }
    
    update(); // Trigger repaint
    
    // NPU-spezifisches Blinken bei hoher Last
    if (load > 80) {
        npuBlinkTimer->start(FAST);
    } else if (load > 50) {
        npuBlinkTimer->start(SLOW);
    } else {
        npuBlinkTimer->stop();
        npuVisible = true;
    }
    
    // Update NPU-Label direkt
    if (npuLoadLabel) {
        npuLoadLabel->setText(QString("NPU: %1%").arg(load));
    }
}

// 🚀 NPU-AKTIVITÄTS-SIGNALING für echte Verarbeitung
void ActivityIndicator::setNpuActive(bool active, int percentage)
{
    if (active) {
        updateNpuLoad(percentage);
        qDebug() << "[ActivityIndicator] 🧠 NPU aktiv gesetzt:" << percentage << "%";
    } else {
        updateNpuLoad(0);
        qDebug() << "[ActivityIndicator] 🧠 NPU inaktiv gesetzt";
    }
}

void ActivityIndicator::signalNpuProcessing(const QString &operation)
{
    setNpuActive(true, 87); // High activity when processing
    qDebug() << "[ActivityIndicator] 🚀 NPU-Verarbeitung signalisiert:" << operation;
    
    // Nach 2 Sekunden wieder reduzieren (simuliert Verarbeitung)
    QTimer::singleShot(2000, this, [this]() {
        setNpuActive(false);
    });
}

void ActivityIndicator::updateGpuLoad(int load)
{
    gpuLoad = load;
    currentGpuLoad = load;  // Auch für Kompatibilität
    update(); // Trigger repaint
    
    // GPU-spezifisches Blinken bei hoher Last
    if (load > 80) {
        gpuBlinkTimer->start(FAST);
    } else if (load > 50) {
        gpuBlinkTimer->start(SLOW);
    } else {
        gpuBlinkTimer->stop();
        gpuVisible = true;
    }
    
    // Update GPU-Label direkt
    if (gpuLoadLabel) {
        gpuLoadLabel->setText(QString("GPU: %1%").arg(load));
    }
}

void ActivityIndicator::updateCpuLoad(int load)
{
    cpuLoad = load;
    currentCpuLoad = load;  // Auch für Kompatibilität
    update(); // Trigger repaint
    
    // CPU-spezifisches Blinken bei hoher Last
    if (load > 80) {
        cpuBlinkTimer->start(FAST);
    } else if (load > 50) {
        cpuBlinkTimer->start(SLOW);
    } else {
        cpuBlinkTimer->stop();
        cpuVisible = true;
    }
    
    // Update CPU-Label direkt
    if (cpuLoadLabel) {
        cpuLoadLabel->setText(QString("CPU: %1%").arg(load));
    }
}
