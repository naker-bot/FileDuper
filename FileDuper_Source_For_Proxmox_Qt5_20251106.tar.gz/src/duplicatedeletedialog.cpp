#include "duplicatedeletedialog.h"
#include <QMessageBox>
#include <QFileInfo>
#include <QDir>
#include <QApplication>
#include <QDesktopServices>
#include <QUrl>
#include <QEventLoop>
#include <QDebug>
#include <QThreadPool>
#include "presetmanager.h"
#include "ftpclient.h"
#include "ftpdeleteworker.h"

DuplicateDeleteDialog::DuplicateDeleteDialog(QWidget *parent)
    : QDialog(parent), currentFileIndex(0), deletionInProgress(false), showDetailedLog(false)
{
    setupUI();
    
    deletionTimer = new QTimer(this);
    connect(deletionTimer, &QTimer::timeout, this, &DuplicateDeleteDialog::onDeleteNextFile);
    
    ftpDeletionTimer = new QTimer(this);
    ftpDeletionTimer->setInterval(50); // Check queue every 50ms
    connect(ftpDeletionTimer, &QTimer::timeout, this, &DuplicateDeleteDialog::processNextFtpDelete);
    
    setModal(true);
    setWindowTitle("🗑️ Duplikate entfernen - FileDuper");
    setMinimumSize(600, 500);
    resize(800, 600);
}

void DuplicateDeleteDialog::setupUI()
{
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    
    // Title
    titleLabel = new QLabel();
    titleLabel->setStyleSheet("QLabel { font-size: 16px; font-weight: bold; color: #2c5aa0; }");
    titleLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(titleLabel);
    
    // Info section
    infoLabel = new QLabel();
    infoLabel->setWordWrap(true);
    infoLabel->setStyleSheet("QLabel { color: #666; margin: 10px; }");
    mainLayout->addWidget(infoLabel);
    
    // Progress section
    progressLabel = new QLabel("Bereit zum Löschen...");
    progressLabel->setStyleSheet("QLabel { font-weight: bold; }");
    mainLayout->addWidget(progressLabel);
    
    progressBar = new QProgressBar();
    progressBar->setVisible(false);
    mainLayout->addWidget(progressBar);
    
    // File list display
    fileListDisplay = new QTextEdit();
    fileListDisplay->setMaximumHeight(200);
    fileListDisplay->setStyleSheet("QTextEdit { background-color: #f5f5f5; font-family: monospace; }");
    mainLayout->addWidget(fileListDisplay);
    
    // Buttons
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    
    confirmButton = new QPushButton("🗑️ Duplikate löschen");
    confirmButton->setStyleSheet("QPushButton { background-color: #e74c3c; color: white; font-weight: bold; padding: 8px 16px; }");
    connect(confirmButton, &QPushButton::clicked, this, &DuplicateDeleteDialog::onConfirmDeletion);
    
    cancelButton = new QPushButton("❌ Abbrechen");
    cancelButton->setStyleSheet("QPushButton { background-color: #95a5a6; color: white; padding: 8px 16px; }");
    connect(cancelButton, &QPushButton::clicked, this, &DuplicateDeleteDialog::onCancelDeletion);
    
    buttonLayout->addStretch();
    buttonLayout->addWidget(confirmButton);
    buttonLayout->addWidget(cancelButton);
    
    mainLayout->addLayout(buttonLayout);
}

void DuplicateDeleteDialog::setDeletionMode(const QString &mode)
{
    deletionMode = mode;
    
    if (mode == "Alle Duplikate") {
        titleLabel->setText("🗑️ Alle Duplikate entfernen");
        confirmButton->setText("🗑️ Alle Duplikate löschen");
    } else {
        titleLabel->setText("🗑️ Markierte Duplikate entfernen");  
        confirmButton->setText("🗑️ Markierte löschen");
    }
}

void DuplicateDeleteDialog::setFileList(const QStringList &duplicates, const QStringList &originals)
{
    duplicateFiles = duplicates;
    originalFiles = originals;
    filesToDelete.clear();
    
    // Calculate total size of duplicates
    qint64 totalSize = 0;
    int duplicateCount = 0;
    int originalCount = originalFiles.size();
    
    QString fileListText;
    
    for (const QString &filePath : duplicateFiles) {
        const bool isFtp = filePath.startsWith("ftp://", Qt::CaseInsensitive);
        QFileInfo fileInfo(filePath);
        const bool existsLocally = fileInfo.exists();

        // Determine display name and size string
        const QString displayName = isFtp ? QUrl(filePath).fileName() : fileInfo.fileName();
        const qint64 sizeBytes = (existsLocally && !isFtp) ? fileInfo.size() : 0;
        const QString sizeText = (existsLocally && !isFtp) ? formatFileSize(sizeBytes)
                                                           : QString("unbekannt");

        // Only count size for local files where it is known
        if (!isOriginalFile(filePath)) {
            duplicateCount++;
        }
        if (sizeBytes > 0) {
            totalSize += sizeBytes;
        }

        // Color code: Green for originals (protected), Red for duplicates
        if (isOriginalFile(filePath)) {
            fileListText += QString("🟢 ORIGINAL (GESCHÜTZT): %1 (%2)\n")
                                .arg(displayName)
                                .arg(sizeText);
        } else {
            fileListText += QString("🔴 DUPLIKAT: %1 (%2)\n")
                                .arg(displayName)
                                .arg(sizeText);
            // Important: For FTP URLs, QFileInfo.exists() is false. We still must schedule deletion.
            filesToDelete.append(filePath);
        }
    }
    
    fileListDisplay->setPlainText(fileListText);
    
    QString infoText = QString(
        "📊 <b>Lösch-Übersicht:</b><br>"
        "• 🔴 Zu löschende Duplikate: <b>%1 Dateien</b><br>"
        "• 🟢 Geschützte Original-Dateien: <b>%2 Dateien</b><br>"
        "• 💾 Freizugebender Speicherplatz (lokal ermittelt): <b>%3</b><br>"
        "• 🌐 Hinweis: Für entfernte Dateien (FTP) ist die Größe ggf. unbekannt\n"
        " und wird hier nicht eingerechnet.<br><br>"
        "⚠️ <b>WICHTIG:</b> Original-Dateien werden automatisch geschützt und niemals gelöscht!<br>"
        "📁 Dateien werden in den Papierkorb verschoben (nicht permanent gelöscht)."
    ).arg(filesToDelete.size())
     .arg(originalCount)
     .arg(formatFileSize(totalSize));
    
    infoLabel->setText(infoText);
}

void DuplicateDeleteDialog::startDeletion()
{
    if (filesToDelete.isEmpty()) {
        QMessageBox::information(this, "Keine Duplikate", 
            "Alle ausgewählten Dateien sind Original-Dateien und werden geschützt.\n"
            "Es gibt keine Duplikate zum Löschen.");
        return;
    }
    
    deletionInProgress = true;
    currentFileIndex = 0;
    
    progressBar->setVisible(true);
    progressBar->setMaximum(filesToDelete.size());
    progressBar->setValue(0);
    
    confirmButton->setEnabled(false);
    confirmButton->setText("🔄 Lösche...");
    
    result = DeletionResult(); // Reset results
    
    progressLabel->setText(QString("Lösche %1 Duplikate...").arg(filesToDelete.size()));
    
    // 🚀 PARALLEL DELETION: Separate FTP and local files
    QStringList localFiles;
    QStringList ftpFiles;
    
    for (const QString &filePath : filesToDelete) {
        if (isOriginalFile(filePath)) {
            qWarning() << "[DuplicateDeleteDialog] ⚠️ SCHUTZ: Original-Datei übersprungen:" << filePath;
            result.originalFilesProtected++;
            result.protectedFiles.append(filePath);
            continue;
        }
        
        if (filePath.startsWith("ftp://")) {
            ftpFiles.append(filePath);
        } else {
            localFiles.append(filePath);
        }
    }
    
    qDebug() << "[startDeletion] 📊 Lokale Dateien:" << localFiles.size() << "FTP-Dateien:" << ftpFiles.size();
    
    // Delete local files immediately (fast)
    if (!localFiles.isEmpty()) {
        deleteLocalFilesSync(localFiles);
    }
    
    // Delete FTP files in parallel (10 at once)
    if (!ftpFiles.isEmpty()) {
        qDebug() << "[startDeletion] 🚀 Starte parallele FTP-Löschung...";
        deleteFtpFilesParallel(ftpFiles);
    } else {
        // No FTP files, finish immediately
        qDebug() << "[startDeletion] ✅ Keine FTP-Dateien, zeige Ergebnis";
        deletionInProgress = false;
        showFinalResults();
    }
}

void DuplicateDeleteDialog::onDeleteNextFile()
{
    if (currentFileIndex >= filesToDelete.size()) {
        deletionTimer->stop();
        deletionInProgress = false;
        showFinalResults();
        return;
    }
    
    QString filePath = filesToDelete[currentFileIndex];
    
    // Double-check: Never delete original files
    if (isOriginalFile(filePath)) {
        qWarning() << "[DuplicateDeleteDialog] ⚠️ SCHUTZ: Original-Datei übersprungen:" << filePath;
        result.originalFilesProtected++;
        result.protectedFiles.append(filePath);
        currentFileIndex++;
        updateProgress();
        return;
    }
    
    // FTP vs Local handling
    bool deleted = false;
    qint64 fileSize = 0;
    QFileInfo fileInfo(filePath);
    
    if (filePath.startsWith("ftp://")) {
        // Parse URL and remove via FtpClient
        QUrl url(filePath);
        const QString host = url.host();
        const QString remote = url.path();
        if (!m_presetManager) {
            result.errors.append(QString("FTP-Löschung ohne PresetManager nicht möglich: %1").arg(filePath));
        } else {
            LoginData login = m_presetManager->getLogin(host, 21);
            if (!login.isValid()) {
                result.errors.append(QString("Keine FTP-Logindaten für %1").arg(host));
            } else {
                // Best-effort size (optional): unknown; skip size tally for FTP if not cached
                FtpClient ftp;
                ftp.setCredentials(host, 21, login.username, login.password);
                QEventLoop loop;
                QObject::connect(&ftp, &FtpClient::removeFinished, &loop, [&](const QString &path, bool ok){
                    deleted = ok;
                    if (!ok) {
                        result.errors.append(QString("FTP-Remove fehlgeschlagen: %1").arg(filePath));
                    }
                    loop.quit();
                });
                ftp.remove(remote);
                // Block until removeFinished arrives; UI stays responsive inside the nested loop
                loop.exec();
            }
        }
    } else {
        if (!fileInfo.exists()) {
            result.errors.append(QString("Datei existiert nicht: %1").arg(filePath));
        } else {
            fileSize = fileInfo.size();
            
            // Move to trash using QDesktopServices (safer than permanent deletion)
#ifdef Q_OS_LINUX
            // Linux: Use gio trash command for proper trash functionality
            QProcess trashProcess;
            trashProcess.start("gio", QStringList() << "trash" << filePath);
            bool finished = trashProcess.waitForFinished(10000); // 10 seconds timeout for large files
            
            if (!finished) {
                trashProcess.kill();
                qWarning() << "[DuplicateDeleteDialog] ⏱️ gio trash timeout für:" << fileInfo.fileName();
                result.errors.append(QString("⏱️ Timeout beim Löschen (>10s): %1").arg(fileInfo.fileName()));
                deleted = false;
            } else {
                deleted = (trashProcess.exitCode() == 0);
                
                if (deleted) {
                    qDebug() << "[DuplicateDeleteDialog] ✅ gio trash erfolgreich:" << fileInfo.fileName();
                } else {
                    QString gioError = trashProcess.readAllStandardError().trimmed();
                    QString gioOutput = trashProcess.readAllStandardOutput().trimmed();
                    qWarning() << "[DuplicateDeleteDialog] ❌ gio trash fehlgeschlagen:" 
                              << "Exit:" << trashProcess.exitCode()
                              << "Stderr:" << gioError 
                              << "Stdout:" << gioOutput;
                    
                    // Fallback: Try moving to user's trash directory
                    QString trashDir = QDir::home().filePath(".local/share/Trash/files");
                    QDir().mkpath(trashDir);
                    QString trashPath = trashDir + "/" + fileInfo.fileName();
                    deleted = QFile::rename(filePath, trashPath);
                    
                    if (!deleted) {
                        result.errors.append(QString("❌ Datei konnte nicht gelöscht werden: %1\n   gio trash Exit-Code: %2\n   Fehler: %3\n   Fallback fehlgeschlagen")
                                           .arg(fileInfo.fileName())
                                           .arg(trashProcess.exitCode())
                                           .arg(gioError.isEmpty() ? "Keine Fehlermeldung" : gioError));
                    } else {
                        qDebug() << "[DuplicateDeleteDialog] ✅ Fallback erfolgreich:" << fileInfo.fileName();
                    }
                }
            }
#else
            // Windows/macOS: Use QDesktopServices
            deleted = QDesktopServices::openUrl(QUrl::fromLocalFile(filePath));
#endif
        }
    }
    
    if (deleted) {
        result.totalFilesDeleted++;
        result.duplicateFilesDeleted++;
        if (fileSize > 0) result.totalBytesFreed += fileSize;
        result.deletedFiles.append(filePath);
        qDebug() << "[DuplicateDeleteDialog] ✅ Duplikat gelöscht:" << QFileInfo(filePath).fileName();
    } else if (!result.errors.isEmpty() && result.errors.last().contains(filePath)) {
        qWarning() << "[DuplicateDeleteDialog] ❌ Fehler beim Löschen:" << filePath;
    }
    
    currentFileIndex++;
    updateProgress();
}

void DuplicateDeleteDialog::updateProgress()
{
    // Calculate total progress (local + FTP)
    int totalCompleted = currentFileIndex + ftpCompletedCount;
    int totalFiles = filesToDelete.size();
    
    progressBar->setValue(totalCompleted);
    progressLabel->setText(QString("Lösche Datei %1 von %2...")
                          .arg(totalCompleted)
                          .arg(totalFiles));
    
    qDebug() << "[updateProgress] 📊" << totalCompleted << "/" << totalFiles 
             << "(local:" << currentFileIndex << "ftp:" << ftpCompletedCount << ")";
    
    QApplication::processEvents(); // Keep UI responsive
}

void DuplicateDeleteDialog::showFinalResults()
{
    // Prevent multiple result popups
    if (resultsShown) {
        qDebug() << "[showFinalResults] ⚠️ Ergebnisse bereits angezeigt, überspringe";
        return;
    }
    resultsShown = true;
    
    qDebug() << "[showFinalResults] 📊 Zeige Endergebnis:" << result.totalFilesDeleted << "gelöscht";
    
    QString resultTitle = "✅ Löschvorgang abgeschlossen";
    QString resultMessage = QString(
        "📊 <b>Lösch-Ergebnis:</b><br><br>"
        "✅ <b>Erfolgreich gelöschte Duplikate:</b> %1 Dateien<br>"
        "🛡️ <b>Geschützte Original-Dateien:</b> %2 Dateien<br>"
        "💾 <b>Freigewordener Speicherplatz:</b> %3<br>"
        "❌ <b>Fehler:</b> %4<br><br>"
        "🗑️ Die Dateien wurden sicher in den Papierkorb verschoben."
    ).arg(result.duplicateFilesDeleted)
     .arg(result.originalFilesProtected)
     .arg(formatFileSize(result.totalBytesFreed))
     .arg(result.errors.size());
    
    if (!result.errors.isEmpty()) {
        resultMessage += "\n\n❌ Fehlerdetails:\n" + result.errors.join("\n");
    }
    
    QMessageBox resultBox(this);
    resultBox.setWindowTitle(resultTitle);
    resultBox.setText(resultMessage);
    resultBox.setTextFormat(Qt::RichText);
    resultBox.setIcon(QMessageBox::Information);
    resultBox.setStandardButtons(QMessageBox::Ok);
    resultBox.exec();
    
    emit deletionCompleted(result);
    accept(); // Close dialog
}

void DuplicateDeleteDialog::onConfirmDeletion()
{
    if (deletionInProgress) return;
    
    int duplicateCount = filesToDelete.size();
    QString confirmMessage = QString(
        "🗑️ <b>Duplikate löschen bestätigen</b><br><br>"
        "Sie sind dabei, <b>%1 Duplikat-Dateien</b> zu löschen.<br>"
        "Freizugebender Speicherplatz: <b>%2</b><br><br>"
        "🛡️ <b>Original-Dateien werden automatisch geschützt</b><br>"
        "🗑️ Dateien werden in den Papierkorb verschoben<br><br>"
        "Möchten Sie fortfahren?"
    ).arg(duplicateCount).arg(formatFileSize(result.totalBytesFreed));
    
    QMessageBox::StandardButton reply = QMessageBox::question(this, "Löschen bestätigen", 
        confirmMessage, QMessageBox::Yes | QMessageBox::No);
    
    if (reply == QMessageBox::Yes) {
        startDeletion();
    }
}

void DuplicateDeleteDialog::onCancelDeletion()
{
    if (deletionInProgress) {
        deletionTimer->stop();
        deletionInProgress = false;
        emit deletionCancelled();
    }
    reject();
}

QString DuplicateDeleteDialog::formatFileSize(qint64 bytes) const
{
    if (bytes < 1024) return QString("%1 B").arg(bytes);
    if (bytes < 1024 * 1024) return QString("%1 KB").arg(bytes / 1024.0, 0, 'f', 1);
    if (bytes < 1024 * 1024 * 1024) return QString("%1 MB").arg(bytes / (1024.0 * 1024.0), 0, 'f', 1);
    return QString("%1 GB").arg(bytes / (1024.0 * 1024.0 * 1024.0), 0, 'f', 2);
}

bool DuplicateDeleteDialog::isOriginalFile(const QString &filePath) const
{
    return originalFiles.contains(filePath);
}

void DuplicateDeleteDialog::deleteLocalFilesSync(const QStringList &localFiles)
{
    qDebug() << "[deleteLocalFilesSync] 🚀 Starte Batch-Löschung von" << localFiles.size() << "lokalen Dateien";
    
    // Batch delete using gio trash with multiple files at once
    if (!localFiles.isEmpty()) {
#ifdef Q_OS_LINUX
        // Strategy: Delete in batches of 20 files for optimal performance
        const int batchSize = 20;
        int totalBatches = (localFiles.size() + batchSize - 1) / batchSize;
        
        for (int batchIndex = 0; batchIndex < totalBatches; ++batchIndex) {
            int startIdx = batchIndex * batchSize;
            int endIdx = qMin(startIdx + batchSize, localFiles.size());
            
            QStringList batch = localFiles.mid(startIdx, endIdx - startIdx);
            QStringList validFiles;
            
            // Filter out non-existent files
            for (const QString &filePath : batch) {
                QFileInfo fileInfo(filePath);
                if (fileInfo.exists()) {
                    validFiles.append(filePath);
                } else {
                    result.errors.append(QString("Datei existiert nicht: %1").arg(filePath));
                }
            }
            
            if (validFiles.isEmpty()) continue;
            
            // Delete entire batch with one gio trash call
            QProcess trashProcess;
            QStringList args;
            args << "trash";
            args.append(validFiles);
            
            trashProcess.start("gio", args);
            bool finished = trashProcess.waitForFinished(5000); // 5s for batch
            
            if (finished && trashProcess.exitCode() == 0) {
                // Batch successful - count all files
                for (const QString &filePath : validFiles) {
                    QFileInfo fileInfo(filePath);
                    qint64 fileSize = fileInfo.size();
                    result.totalFilesDeleted++;
                    result.duplicateFilesDeleted++;
                    result.totalBytesFreed += fileSize;
                    result.deletedFiles.append(filePath);
                    currentFileIndex++;
                }
                qDebug() << "[deleteLocalFilesSync] ✅ Batch" << (batchIndex+1) << "/" << totalBatches 
                         << "erfolgreich:" << validFiles.size() << "Dateien";
            } else {
                // Batch failed - try individual deletion
                qWarning() << "[deleteLocalFilesSync] ⚠️ Batch fehlgeschlagen, versuche einzeln...";
                
                for (const QString &filePath : validFiles) {
                    QFileInfo fileInfo(filePath);
                    qint64 fileSize = fileInfo.size();
                    
                    QProcess singleTrash;
                    singleTrash.start("gio", QStringList() << "trash" << filePath);
                    finished = singleTrash.waitForFinished(10000); // 10s for single file
                    
                    bool deleted = false;
                    if (finished && singleTrash.exitCode() == 0) {
                        deleted = true;
                        qDebug() << "[deleteLocalFilesSync] ✅ Einzeln gelöscht:" << fileInfo.fileName();
                    } else {
                        // Fallback: Manual move to trash
                        QString trashDir = QDir::home().filePath(".local/share/Trash/files");
                        QDir().mkpath(trashDir);
                        QString trashPath = trashDir + "/" + fileInfo.fileName();
                        deleted = QFile::rename(filePath, trashPath);
                        
                        if (deleted) {
                            qDebug() << "[deleteLocalFilesSync] ✅ Fallback erfolgreich:" << fileInfo.fileName();
                        } else {
                            QString gioError = singleTrash.readAllStandardError().trimmed();
                            result.errors.append(QString("❌ Löschen fehlgeschlagen: %1\n   Fehler: %2")
                                               .arg(fileInfo.fileName())
                                               .arg(gioError.isEmpty() ? "Unbekannt" : gioError));
                            qWarning() << "[deleteLocalFilesSync] ❌ Fehler:" << fileInfo.fileName();
                        }
                    }
                    
                    if (deleted) {
                        result.totalFilesDeleted++;
                        result.duplicateFilesDeleted++;
                        result.totalBytesFreed += fileSize;
                        result.deletedFiles.append(filePath);
                        currentFileIndex++;
                    }
                }
            }
            
            // Update progress after each batch
            updateProgress();
            QApplication::processEvents();
        }
#else
        // Windows/macOS: Individual deletion
        for (const QString &filePath : localFiles) {
            QFileInfo fileInfo(filePath);
            qint64 fileSize = fileInfo.size();
            bool deleted = QDesktopServices::openUrl(QUrl::fromLocalFile(filePath));
            
            if (deleted) {
                result.totalFilesDeleted++;
                result.duplicateFilesDeleted++;
                result.totalBytesFreed += fileSize;
                result.deletedFiles.append(filePath);
                currentFileIndex++;
            }
        }
#endif
    }
    
    qDebug() << "[deleteLocalFilesSync] ✅" << result.totalFilesDeleted << "lokale Dateien gelöscht";
}

void DuplicateDeleteDialog::deleteFtpFilesParallel(const QStringList &ftpFiles)
{
    qDebug() << "[DuplicateDeleteDialog] 🚀 deleteFtpFilesParallel:" << ftpFiles.size() << "Dateien";
    
    ftpDeleteQueue = ftpFiles;
    ftpCompletedCount = 0;
    ftpTotalCount = ftpFiles.size();
    ftpActiveDeletes = 0;
    
    // Start timer to process queue
    ftpDeletionTimer->start();
}

void DuplicateDeleteDialog::processNextFtpDelete()
{
    const int MAX_PARALLEL_DELETES = 10;
    
    // Start new deletes if queue not empty and under limit
    while (!ftpDeleteQueue.isEmpty() && ftpActiveDeletes < MAX_PARALLEL_DELETES) {
        QString ftpPath = ftpDeleteQueue.takeFirst();
        
        QUrl url(ftpPath);
        QString host = url.host();
        QString remotePath = url.path();
        
        // 🔧 FIX: Bereinige kaputte Pfade mit doppelten ///-Segmenten
        // Beispiel: /share/Jan/Jana/mix von t.g///share/Jan/naker/Musik/file.mp3
        // Lösung: Nimm nur den letzten Teil nach dem letzten ///
        if (remotePath.contains("///")) {
            QStringList parts = remotePath.split("///");
            remotePath = parts.last(); // Nur der echte Pfad
            qDebug() << "[processNextFtpDelete] 🔧 Bereinigter Pfad:" << remotePath;
        }
        
        if (!m_presetManager) {
            ftpCompletedCount++;
            continue;
        }
        
        LoginData login = m_presetManager->getLogin(host, 21);
        if (!login.isValid()) {
            qDebug() << "[DuplicateDeleteDialog] ❌ Keine Login-Daten für" << host;
            ftpCompletedCount++;
            continue;
        }
        
        ftpActiveDeletes++;
        
        qDebug() << "[processNextFtpDelete] 🚀 Starte Delete" << ftpActiveDeletes << "/" << MAX_PARALLEL_DELETES << ":" << remotePath;
        
        auto callback = [this, ftpPath](const QString &file, bool success) {
            ftpCompletedCount++;
            ftpActiveDeletes--;
            
            if (success) {
                result.totalFilesDeleted++;
                result.duplicateFilesDeleted++;
                result.deletedFiles.append(ftpPath);
                qDebug() << "[FTP-Callback] ✅ Gelöscht:" << file;
            } else {
                qDebug() << "[FTP-Callback] ❌ FEHLER beim Löschen:" << file;
            }
            
            // GUI-Update in main thread
            QMetaObject::invokeMethod(this, [this, ftpPath, success]() {
                updateProgress(); // Update after each file
                
                if (!success) {
                    qDebug() << "[DuplicateDeleteDialog] ❌ FTP-Fehler:" << ftpPath;
                }
                
                if (ftpCompletedCount >= ftpTotalCount && ftpActiveDeletes == 0) {
                    qDebug() << "[DuplicateDeleteDialog] ✅ Alle FTP-Dateien verarbeitet";
                    
                    // Stop timer FIRST to prevent more callbacks
                    if (ftpDeletionTimer->isActive()) {
                        ftpDeletionTimer->stop();
                        qDebug() << "[DuplicateDeleteDialog] ⏸️ Timer gestoppt";
                    }
                    
                    deletionInProgress = false;
                    
                    // Show results ONCE
                    if (!resultsShown) {
                        showFinalResults();
                    }
                }
            }, Qt::QueuedConnection);
        };
        
        FtpDeleteWorker *worker = new FtpDeleteWorker(host, 21, login.username, login.password, remotePath, callback);
        QThreadPool::globalInstance()->start(worker);
    }
    
    // Stop timer if done
    if (ftpDeleteQueue.isEmpty() && ftpActiveDeletes == 0 && ftpCompletedCount >= ftpTotalCount) {
        ftpDeletionTimer->stop();
        updateProgress();
    }
}
