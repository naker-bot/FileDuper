#include <QApplication>
#include <QStyleFactory>
#include <QDir>
#include <QDebug>
#include <QStandardPaths>
#include <QTimer>
#include <QFileInfo>
#include <iostream>
#include "mainwindow.h"
#include "hashengine.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Application properties
    app.setApplicationName("FileDuper");
    app.setApplicationVersion("1.0.0");
    app.setOrganizationName("FileDuper");
    app.setApplicationDisplayName("FileDuper - Duplicate File Scanner");

    // Create config directory if it doesn't exist
    QString configDir = QStandardPaths::writableLocation(QStandardPaths::ConfigLocation);
    QDir().mkpath(configDir);

    std::cout << "🚀 FileDuper wird gestartet..." << std::endl;
    std::cout << "📁 Konfiguration: " << configDir.toUtf8().constData() << std::endl;

    // Apply modern style
    app.setStyle(QStyleFactory::create("Fusion"));

    // Create and show main window
    MainWindow window;
    window.show();

    std::cout << "✅ FileDuper GUI gestartet!" << std::endl;

    // 🧪 FTP-NPU-TEST wird ERST nach Login/Doppelklick ausgeführt
    qDebug() << "[MAIN] � FTP-NPU-Test deaktiviert - wird nach manuellem FTP-Login gestartet";

    return app.exec();
}
