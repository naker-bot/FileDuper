#include <iostream>
#include "nfsclient.h"
#include <QDebug>
#include <QDir>
#include <QRegularExpression>

NfsClient::NfsClient(QObject *parent)
    : QObject(parent), port(2049), isConnectedFlag(false), currentDirectory("/")
{
    nfsProcess = new QProcess(this);
    connectionTimer = new QTimer(this);
    connectionTimer->setSingleShot(true);
    connectionTimer->setInterval(30000); // 30s timeout

    connect(nfsProcess, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &NfsClient::onNfsProcessFinished);
    connect(nfsProcess, &QProcess::errorOccurred, this, &NfsClient::onNfsProcessError);
    connect(connectionTimer, &QTimer::timeout, [this]()
            { emit errorOccurred("NFS connection timeout"); });
}

NfsClient::~NfsClient()
{
    disconnectFromHost();
}

void NfsClient::setCredentials(const QString &host, int portNum, const QString &user, const QString &pass)
{
    hostname = host;
    port = portNum;
    // NFS typically doesn't use username/password authentication

    std::cout << "[NfsClient] 🔐 Target set for " << host.toUtf8().constData()
              << ":" << port << " (NFS)" << std::endl;
}

void NfsClient::connectToHost()
{
    if (isConnectedFlag)
    {
        std::cout << "[NfsClient] ⚠️ Already connected" << std::endl;
        return;
    }

    std::cout << "[NfsClient] 🔗 Connecting to " << hostname.toUtf8().constData()
              << ":" << port << " via NFS..." << std::endl;

    // Start by listing available exports
    listExports();
}

void NfsClient::disconnectFromHost()
{
    // Unmount all mounted exports
    for (const QString &mountPoint : mountedExports)
    {
        unmountExport(mountPoint);
    }

    if (nfsProcess->state() == QProcess::Running)
    {
        std::cout << "[NfsClient] 📴 Disconnecting from " << hostname.toUtf8().constData() << std::endl;
        nfsProcess->kill();
        nfsProcess->waitForFinished(3000);
    }

    isConnectedFlag = false;
    connectionTimer->stop();
    emit disconnected();
}

bool NfsClient::isConnected() const
{
    return isConnectedFlag;
}

void NfsClient::listExports()
{
    std::cout << "[NfsClient] 🗂️ Listing exports on " << hostname.toUtf8().constData() << std::endl;

    QStringList arguments;
    arguments << hostname;

    lastCommand = "listExports";
    executeNfsCommand("showmount", arguments);
}

void NfsClient::mountExport(const QString &exportPath, const QString &localMountPoint)
{
    std::cout << "[NfsClient] 🔗 Mounting " << exportPath.toUtf8().constData()
              << " to " << localMountPoint.toUtf8().constData() << std::endl;

    // Create mount point directory if it doesn't exist
    QDir().mkpath(localMountPoint);

    QString nfsPath = QString("%1:%2").arg(hostname, exportPath);
    QStringList arguments;
    arguments << "-t" << "nfs" << nfsPath << localMountPoint;

    lastCommand = QString("mountExport:%1").arg(localMountPoint);
    executeNfsCommand("sudo mount", arguments);
}

void NfsClient::unmountExport(const QString &localMountPoint)
{
    std::cout << "[NfsClient] 📴 Unmounting " << localMountPoint.toUtf8().constData() << std::endl;

    QStringList arguments;
    arguments << localMountPoint;

    lastCommand = QString("unmountExport:%1").arg(localMountPoint);
    executeNfsCommand("sudo umount", arguments);
}

void NfsClient::listDirectory(const QString &mountPoint, const QString &path)
{
    currentMountPoint = mountPoint;
    currentDirectory = path.isEmpty() ? "/" : path;

    QString fullPath = mountPoint;
    if (!path.isEmpty() && path != "/")
    {
        fullPath += "/" + path;
    }

    std::cout << "[NfsClient] 📁 Listing directory " << fullPath.toUtf8().constData() << std::endl;

    QStringList arguments;
    arguments << "-la" << fullPath;

    lastCommand = "listDirectory";
    executeNfsCommand("ls", arguments);
}

QList<NfsExportInfo> NfsClient::getAvailableExports() const
{
    return availableExports;
}

QList<NfsExportInfo> NfsClient::getCurrentDirectoryListing() const
{
    return currentListing;
}

void NfsClient::copyFile(const QString &sourcePath, const QString &destinationPath)
{
    std::cout << "[NfsClient] 📋 Copying " << sourcePath.toUtf8().constData()
              << " to " << destinationPath.toUtf8().constData() << std::endl;

    QStringList arguments;
    arguments << "-r" << sourcePath << destinationPath;

    lastCommand = "copyFile";
    executeNfsCommand("cp", arguments);
}

void NfsClient::deleteFile(const QString &filePath)
{
    std::cout << "[NfsClient] 🗑️ Deleting " << filePath.toUtf8().constData() << std::endl;

    QStringList arguments;
    arguments << "-rf" << filePath;

    lastCommand = "deleteFile";
    executeNfsCommand("rm", arguments);
}

void NfsClient::executeNfsCommand(const QString &command, const QStringList &arguments)
{
    if (nfsProcess->state() == QProcess::Running)
    {
        nfsProcess->kill();
        nfsProcess->waitForFinished(1000);
    }

    connectionTimer->start();
    std::cout << "[NfsClient] 💻 Executing: " << command.toUtf8().constData()
              << " " << arguments.join(" ").toUtf8().constData() << std::endl;

    QStringList commandParts = command.split(' ');
    QString program = commandParts.takeFirst();
    QStringList allArgs = commandParts + arguments;

    nfsProcess->start(program, allArgs);
}

void NfsClient::onNfsProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    connectionTimer->stop();

    QString output = nfsProcess->readAllStandardOutput();
    QString errorOutput = nfsProcess->readAllStandardError();

    std::cout << "[NfsClient] 🏁 Process finished with code " << exitCode << std::endl;

    if (exitCode == 0 && !output.isEmpty())
    {
        std::cout << "[NfsClient] 📄 Output: " << output.left(200).toUtf8().constData() << "..." << std::endl;

        if (lastCommand == "listExports")
        {
            parseExportListing(output);
            if (!isConnectedFlag)
            {
                isConnectedFlag = true;
                std::cout << "[NfsClient] ✅ NFS connection established" << std::endl;
                emit connected();
            }
        }
        else if (lastCommand == "listDirectory")
        {
            parseDirectoryListing(output, currentMountPoint);
        }
        else if (lastCommand.startsWith("mountExport:"))
        {
            QString mountPoint = lastCommand.split(':').last();
            mountedExports.append(mountPoint);
            emit exportMounted(mountPoint);
        }
        else if (lastCommand.startsWith("unmountExport:"))
        {
            QString mountPoint = lastCommand.split(':').last();
            mountedExports.removeAll(mountPoint);
            emit exportUnmounted(mountPoint);
        }
    }
    else
    {
        std::cout << "[NfsClient] ❌ Error (code " << exitCode << "): " << errorOutput.toUtf8().constData() << std::endl;

        if (errorOutput.contains("Connection refused") ||
            errorOutput.contains("No route to host"))
        {
            emit errorOccurred("NFS Host unreachable or NFS service not running");
        }
        else if (errorOutput.contains("Permission denied"))
        {
            emit errorOccurred("NFS Permission denied - check export permissions");
        }
        else if (errorOutput.contains("Program not registered"))
        {
            emit errorOccurred("NFS service not available on target host");
        }
        else
        {
            emit errorOccurred(QString("NFS Error: %1").arg(errorOutput.isEmpty() ? "Unknown error" : errorOutput));
        }
    }
}

void NfsClient::onNfsProcessError(QProcess::ProcessError error)
{
    QString errorString;
    switch (error)
    {
    case QProcess::FailedToStart:
        errorString = "NFS process failed to start (showmount/mount tools not installed?)";
        break;
    case QProcess::Crashed:
        errorString = "NFS process crashed";
        break;
    case QProcess::Timedout:
        errorString = "NFS process timeout";
        break;
    default:
        errorString = "Unknown NFS process error";
    }

    std::cout << "[NfsClient] ❌ Process error: " << errorString.toUtf8().constData() << std::endl;
    isConnectedFlag = false;
    connectionTimer->stop();
    emit errorOccurred(errorString);
}

void NfsClient::parseExportListing(const QString &output)
{
    availableExports.clear();
    QStringList lines = output.split('\n', Qt::SkipEmptyParts);

    for (const QString &line : lines)
    {
        if (line.startsWith("/") || line.contains("Export list"))
        {
            if (line.contains("Export list"))
                continue;

            NfsExportInfo exportInfo = parseExportLine(line);
            if (!exportInfo.path.isEmpty())
            {
                availableExports.append(exportInfo);
            }
        }
    }

    std::cout << "[NfsClient] 📊 Found " << availableExports.size() << " exports" << std::endl;
    emit exportsListReceived(availableExports);
}

void NfsClient::parseDirectoryListing(const QString &output, const QString &basePath)
{
    currentListing.clear();
    QStringList lines = output.split('\n', Qt::SkipEmptyParts);

    for (const QString &line : lines)
    {
        if (line.startsWith("drw") || line.startsWith("-rw") || line.startsWith("lrw"))
        {
            NfsExportInfo info = parseDirectoryLine(line, basePath);
            if (!info.name.isEmpty() && info.name != "." && info.name != "..")
            {
                currentListing.append(info);
            }
        }
    }

    std::cout << "[NfsClient] 📊 Parsed " << currentListing.size() << " entries" << std::endl;
    emit directoryListingReceived(currentListing);
}

NfsExportInfo NfsClient::parseExportLine(const QString &line)
{
    NfsExportInfo exportInfo;

    // Parse: "/export/path hostname1,hostname2,..."
    QRegularExpression re(R"(^(/\S+)\s+(.*)$)");
    QRegularExpressionMatch match = re.match(line);

    if (match.hasMatch())
    {
        exportInfo.path = match.captured(1);
        exportInfo.name = exportInfo.path.split('/').last();
        if (exportInfo.name.isEmpty())
        {
            exportInfo.name = "root";
        }
        exportInfo.options = match.captured(2);
        exportInfo.isDirectory = true;
        exportInfo.isMounted = false;
    }

    return exportInfo;
}

NfsExportInfo NfsClient::parseDirectoryLine(const QString &line, const QString &basePath)
{
    NfsExportInfo info;

    // Parse Unix-style ls -la output: drwxr-xr-x 2 user group 4096 Jan 15 10:30 dirname
    QRegularExpression re(R"(^([d\-lrwx]+)\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\w+\s+\d+\s+[\d:]+)\s+(.+)$)");
    QRegularExpressionMatch match = re.match(line);

    if (match.hasMatch())
    {
        QString permissions = match.captured(1);
        info.size = match.captured(2).toLongLong();
        info.name = match.captured(4);
        info.isDirectory = permissions.startsWith('d');
        info.path = currentDirectory + "/" + info.name;
        info.isMounted = true; // It's accessible through mounted filesystem

        // ✅ ECHTE DATUM-PARSING für NFS ls Format (über mount)
        QString dateStr = match.captured(3);
        
        // Parse Unix ls date format: "Jul 13 10:30" oder "Jul 13  2024"
        QStringList dateParts = dateStr.split(' ', Qt::SkipEmptyParts);
        if (dateParts.size() >= 3) {
            QString month = dateParts[0];
            int day = dateParts[1].toInt();
            
            QDateTime dateTime;
            if (dateParts[2].contains(':')) {
                // Aktuelles Jahr mit Zeit
                dateTime = QDateTime::currentDateTime();
                QDate currentDate = dateTime.date();
                
                QMap<QString, int> monthMap = {
                    {"Jan", 1}, {"Feb", 2}, {"Mar", 3}, {"Apr", 4}, {"May", 5}, {"Jun", 6},
                    {"Jul", 7}, {"Aug", 8}, {"Sep", 9}, {"Oct", 10}, {"Nov", 11}, {"Dec", 12}
                };
                
                if (monthMap.contains(month)) {
                    QDate fileDate(currentDate.year(), monthMap[month], day);
                    QTime fileTime = QTime::fromString(dateParts[2], "hh:mm");
                    
                    if (fileTime.isValid()) {
                        dateTime = QDateTime(fileDate, fileTime);
                    }
                }
            } else {
                // Spezifisches Jahr
                int year = dateParts[2].toInt();
                QMap<QString, int> monthMap = {
                    {"Jan", 1}, {"Feb", 2}, {"Mar", 3}, {"Apr", 4}, {"May", 5}, {"Jun", 6},
                    {"Jul", 7}, {"Aug", 8}, {"Sep", 9}, {"Oct", 10}, {"Nov", 11}, {"Dec", 12}
                };
                
                if (monthMap.contains(month) && year > 1900) {
                    dateTime = QDateTime(QDate(year, monthMap[month], day), QTime(0, 0));
                }
            }
            
            info.lastModified = dateTime.isValid() ? dateTime : QDateTime::currentDateTime();
        } else {
            info.lastModified = QDateTime::currentDateTime();
        }
    }

    return info;
}
