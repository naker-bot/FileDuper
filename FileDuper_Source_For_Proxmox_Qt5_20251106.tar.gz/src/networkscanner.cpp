#include "networkscanner.h"
#include <QDebug>
#include <QRegularExpression>
#include <QPointer>
#include <QTimer>
#include <QTcpSocket>
#include <QNetworkInterface>
#include <QSettings>
#include <QDir>
#include <iostream>

const QList<int> NetworkScanner::DEFAULT_PORTS = {21, 22, 80, 139, 443, 445, 2049, 3306, 5432}; // Erweiterte Port-Liste

NetworkScanner::NetworkScanner(QObject *parent)
    : QObject(parent), currentTargetIndex(0), socketTimeout(200), scanning(false),
      completedChunks(0), totalChunks(30), scanFinishedReported(false) // 30-Chunk Ultra-Fast Scanning!
{
    scanPorts = DEFAULT_PORTS;
    ipRange = "192.168.1.0/24";
    m_presetConfigFile = QDir::homePath() + "/.fileduper_network_presets.ini";

    // Initialize port presets for file transfer services
    initializePortPresets();
    
    // Load saved network presets first
    loadNetworkPresets();
    
    // Auto-detect network ranges and merge with presets
    autoDetectNetworkRanges();

    std::cout << "[NetworkScanner] 🚀 Ultra-Fast 30-Chunk Parallel-Scanner initialisiert" << std::endl;
    std::cout << "[NetworkScanner] 📁 " << DEFAULT_PORTS.size() << " File-Transfer-Port-Presets geladen" << std::endl;
}

NetworkScanner::~NetworkScanner()
{
    stopScan();
}

void NetworkScanner::setIpRange(const QString &range)
{
    ipRange = range;
    parseIpRange(range);
    std::cout << "[NetworkScanner] 🌐 Reverse IP-Bereich: " << range.toUtf8().constData() << std::endl;
}

void NetworkScanner::setPorts(const QList<int> &ports)
{
    scanPorts = ports;
    std::cout << "[NetworkScanner] ⚡ " << ports.size() << " File-Transfer-Ports konfiguriert" << std::endl;
}

void NetworkScanner::startScan()
{
    if (scanning)
    {
        std::cout << "[NetworkScanner] ⚠️ 30-Chunk Parallel-Scan bereits aktiv" << std::endl;
        return;
    }

    // Auto-Netzwerk-Erkennung falls ipRange nicht gesetzt
    if (ipRange.isEmpty())
    {
        // Verwende auto-erkannte Netzwerk-Ranges
        QStringList detectedRanges = autoDetectNetworkRanges();
        if (!detectedRanges.isEmpty()) {
            ipRange = detectedRanges.first(); // Verwende ersten erkannten Range
            std::cout << "[NetworkScanner] 🌐 Auto-erkannter Range gewählt: " << ipRange.toUtf8().constData() << std::endl;
        } else {
            ipRange = "192.168.1.0/24"; // Fallback nur wenn keine Auto-Erkennung
            std::cout << "[NetworkScanner] ⚠️ Fallback zu Standard-Netzwerk: " << ipRange.toUtf8().constData() << std::endl;
        }
    }

    resetScan();
    parseIpRange(ipRange); // Stelle sicher, dass baseIps gefüllt wird
    generateTargets();

    if (scanTargets.isEmpty())
    {
        emit error("Keine Scan-Ziele generiert");
        return;
    }

    // Create smart parallel chunks balanced between performance and network discovery
    createScanChunks();

    scanning = true;
    completedChunks = 0;
    // 🔧 FIXED: Intelligent chunk balancing for Network Discovery Browser compatibility
    // For network discovery: Use moderate chunks to avoid UI overflow bugs
    // Balance: Performance + Browser Stability + Progress Counter Accuracy
    int maxNetworkChunks = qMin(MAX_CHUNKS / 10, 100); // Max 100 chunks for network discovery
    totalChunks = qMin(maxNetworkChunks, qMax(10, scanTargets.size() / 50)); // Min 10, optimal size

    std::cout << "[NetworkScanner] 🚀 SMART PARALLEL-SCAN GESTARTET: "
              << scanTargets.size() << " Ziele in " << totalChunks << " Chunks (Max: " << maxNetworkChunks << ")" << std::endl;

    // Start all chunks simultaneously with 5ms stagger for optimal performance
    for (int chunkId = 0; chunkId < totalChunks; ++chunkId)
    {
        // ✅ SICHERE Timer-Lösung mit QPointer für crash-freie Bereinigung
        QPointer<NetworkScanner> selfPtr(this);
        QTimer::singleShot(chunkId * 5, [selfPtr, chunkId]()
                           { 
                               if (selfPtr) {
                                   selfPtr->startChunkScan(chunkId); 
                               }
                           });
    }

    emit scanProgress(0, scanTargets.size());
}

void NetworkScanner::scanAllAvailableRanges()
{
    if (scanning) {
        std::cout << "[NetworkScanner] ⚠️ Scan bereits aktiv - warte auf Abschluss" << std::endl;
        return;
    }

    // Get all available ranges (auto-detected + custom)
    QList<NetworkRange> allRanges = getAvailableNetworkRanges();
    
    if (allRanges.isEmpty()) {
        std::cout << "[NetworkScanner] ❌ Keine Netzwerk-Ranges verfügbar" << std::endl;
        emit error("Keine Netzwerk-Ranges zum Scannen verfügbar");
        return;
    }

    std::cout << "[NetworkScanner] 🌐 Starte Multi-Range-Scan für " << allRanges.size() << " Bereiche:" << std::endl;
    
    // Clear previous results
    foundServices.clear();
    scanTargets.clear();
    
    // Generate targets for all ranges
    for (const NetworkRange &range : allRanges) {
        std::cout << "[NetworkScanner] 📍 Range: " << range.name.toUtf8().constData() 
                  << " (" << range.cidr.toUtf8().constData() << ")" << std::endl;
        
        // Temporarily set this range as active
        QString originalRange = ipRange;
        ipRange = range.cidr;
        
        // Parse and add targets for this range
        parseIpRange(range.cidr);
        generateTargets();
        
        // Restore original range
        ipRange = originalRange;
    }
    
    if (scanTargets.isEmpty()) {
        std::cout << "[NetworkScanner] ❌ Keine Scan-Targets für alle Ranges generiert" << std::endl;
        emit error("Keine Scan-Ziele für Multi-Range-Scan generiert");
        return;
    }

    std::cout << "[NetworkScanner] ⚡ Multi-Range-Scan: " << scanTargets.size() 
              << " Targets für " << allRanges.size() << " Ranges generiert" << std::endl;

    // Create 30 ultra-fast parallel chunks for all ranges
    createScanChunks();

    scanning = true;
    completedChunks = 0;
    // 🔧 FIXED: Smart multi-range chunk balancing 
    int maxNetworkChunks = qMin(MAX_CHUNKS / 10, 100); // Max 100 chunks for multi-range
    totalChunks = qMin(maxNetworkChunks, qMax(15, scanTargets.size() / 40)); // Min 15 for multi-range

    std::cout << "[NetworkScanner] 🚀 SMART MULTI-RANGE PARALLEL-SCAN GESTARTET: "
              << scanTargets.size() << " Ziele in " << totalChunks << " Chunks (Max: " << maxNetworkChunks << ")" << std::endl;

    // Start all chunks simultaneously
    for (int chunkId = 0; chunkId < totalChunks; ++chunkId) {
        QPointer<NetworkScanner> selfPtr(this);
        QTimer::singleShot(chunkId * 5, [selfPtr, chunkId]() { 
            if (selfPtr) {
                selfPtr->startChunkScan(chunkId); 
            }
        });
    }

    emit scanProgress(0, scanTargets.size());
}

void NetworkScanner::stopScan()
{
    if (!scanning)
        return;

    scanning = false;

    // Clean up all chunk resources
    cleanupChunkResources();

    std::cout << "[NetworkScanner] ⏹️ Parallel-Chunk-Scan gestoppt - "
              << foundServices.size() << " Services gefunden" << std::endl;
}

QList<NetworkService> NetworkScanner::getFoundServices() const
{
    return foundServices;
}

void NetworkScanner::parseIpRange(const QString &range)
{
    // Parse CIDR notation safely
    if (range.contains("/"))
    {
        QStringList parts = range.split("/");
        if (parts.size() == 2)
        {
            QString baseIp = parts[0];
            int subnetBits = parts[1].toInt();

            // For /24 networks, scan .254 to .1 (reverse for faster server detection)
            if (subnetBits == 24)
            {
                QStringList ipParts = baseIp.split(".");
                if (ipParts.size() == 4)
                {
                    QString networkBase = ipParts[0] + "." + ipParts[1] + "." + ipParts[2] + ".";

                    baseIps.clear();
                    // Reverse IP scanning: 254 → 1 (Server oft in höheren IP-Bereichen)
                    for (int i = 254; i >= 1; --i)
                    {
                        baseIps.append(networkBase + QString::number(i));
                    }

                    std::cout << "[NetworkScanner] 🔄 Reverse IP-Scanning aktiviert: "
                              << networkBase.toUtf8().constData() << "254 → 1" << std::endl;
                }
            }
        }
    }
    else
    {
        // Single IP (reverse scan not applicable)
        baseIps.clear();
        baseIps.append(range);
    }
}

void NetworkScanner::generateTargets()
{
    scanTargets.clear();

    // Generate all IP:Port combinations for /24 network (254 IPs × 9 ports = 2286 targets)
    for (const QString &ip : baseIps)
    {
        for (int port : scanPorts)
        {
            scanTargets.append(qMakePair(ip, port));
        }
    }

    std::cout << "[NetworkScanner] ⚡ " << scanTargets.size() << " Targets generiert für "
              << baseIps.size() << " IPs mit " << scanPorts.size() << " Ports" << std::endl;
    std::cout << "[NetworkScanner] 📊 Targets/Chunk: ~" << (scanTargets.size() / 30) << std::endl;
}

void NetworkScanner::resetScan()
{
    currentTargetIndex = 0;
    foundServices.clear();
    completedChunks = 0;
    scanFinishedReported = false;  // 🔒 Reset the flag for next scan

    // Clean up any existing chunk resources
    cleanupChunkResources();
}

QString NetworkScanner::detectService(const QString &ip, int port)
{
    Q_UNUSED(ip)

    // Enhanced service detection based on copilot-instructions.md
    switch (port)
    {
    case 21:
        return "FTP";
    case 22:
        return "SSH/SFTP";
    case 80:
        return "HTTP";
    case 139:
        return "SMB (NetBIOS)";
    case 443:
        return "HTTPS";
    case 445:
        return "SMB/CIFS";
    case 2049:
        return "NFS";
    case 3306:
        return "MySQL";
    case 5432:
        return "PostgreSQL";
    default:
        return QString("Port %1").arg(port);
    }
}

QString NetworkScanner::getServiceDescription(int port)
{
    switch (port)
    {
    case 21:
        return "📁 FTP - File Transfer Protocol (Parallel-Detection)";
    case 22:
        return "🔐 SSH/SFTP - Secure File Transfer (Parallel-Scan)";
    case 139:
        return "🖥️ SMB - NetBIOS Session Service (Parallel-Discovery)";
    case 445:
        return "🖥️ SMB/CIFS - Windows File Sharing (Parallel-Detection)";
    case 2049:
        return "🐧 NFS - Network File System (Parallel-Discovery)";
    default:
        return QString("❓ File-Transfer-Service auf Port %1").arg(port);
    }
}

bool NetworkScanner::isFileTransferService(int port)
{
    return (port == 21 || port == 22 || port == 139 || port == 445 || port == 2049);
}

QStringList NetworkScanner::getSupportedFileTransferProtocols()
{
    return {"FTP (Port 21)", "SFTP (Port 22)", "SMB (Port 445)", "NFS (Port 2049)"};
}

void NetworkScanner::performSafeServiceDetection(const QString &ip, int port)
{
    // Safe enhanced service detection with QPointer protection
    QTcpSocket *detectionSocket = new QTcpSocket(this);
    QPointer<QTcpSocket> socketPtr(detectionSocket); // Safe pointer

    connect(detectionSocket, &QTcpSocket::connected, [this, socketPtr, ip, port]()
            {
        std::cout << "[NetworkScanner] 🔍 Parallel Service-Analyse für " 
                  << ip.toUtf8().constData() << ":" << port << std::endl;
        
        // ✅ SICHERER Lightning banner read mit QPointer für crash-freie Bereinigung
        QPointer<NetworkScanner> selfPtr(this);
        QTimer::singleShot(200, [selfPtr, socketPtr, ip, port]() {  // ULTRA FAST: 200ms timeout
            if (!selfPtr || !socketPtr) {
                std::cout << "[NetworkScanner] ⚠️ Detection socket bereits freigegeben für " 
                         << ip.toUtf8().constData() << ":" << port << std::endl;
                return;
            }
            
            if (socketPtr->state() != QAbstractSocket::ConnectedState) {
                std::cout << "[NetworkScanner] ⚠️ Detection socket nicht verbunden für " 
                         << ip.toUtf8().constData() << ":" << port << std::endl;
                socketPtr->deleteLater();
                return;
            }
            
            QByteArray response = socketPtr->readAll();
            QString bannerText = QString::fromUtf8(response).trimmed();
            
            if (!bannerText.isEmpty()) {
                std::cout << "[NetworkScanner] ⚡ Ultra-Fast-Banner: " 
                         << ip.toUtf8().constData() << ":" << port 
                         << " - " << bannerText.left(60).toUtf8().constData() << std::endl;
                
                // ✅ SICHERE Banner-Analyse über selfPtr
                if (selfPtr) {
                    selfPtr->analyzeSafeServiceBanner(ip, port, bannerText);
                }
            }
            
            socketPtr->deleteLater();
        }); });

    connect(detectionSocket, &QTcpSocket::errorOccurred, [socketPtr](QAbstractSocket::SocketError)
            {
        if (socketPtr) {
            socketPtr->deleteLater();
        } });

    // Safe connection with reasonable timeout using QPointer
    socketPtr->connectToHost(ip, port);
    QTimer::singleShot(300, [socketPtr]()
                       { 
        if (socketPtr) {
            socketPtr->deleteLater();
        } }); // ULTRA FAST cleanup timeout
}

void NetworkScanner::analyzeSafeServiceBanner(const QString &ip, int port, const QString &banner)
{
    QString serviceInfo;

    // Safe banner analysis
    if (port == 21 && banner.contains("FTP", Qt::CaseInsensitive))
    {
        if (banner.contains("ProFTPD", Qt::CaseInsensitive))
        {
            serviceInfo = "ProFTPD Server";
        }
        else if (banner.contains("vsftpd", Qt::CaseInsensitive))
        {
            serviceInfo = "vsftpd Server";
        }
        else if (banner.contains("FileZilla", Qt::CaseInsensitive))
        {
            serviceInfo = "FileZilla Server";
        }
        else
        {
            serviceInfo = "FTP Server";
        }
    }
    else if (port == 22 && banner.contains("SSH", Qt::CaseInsensitive))
    {
        if (banner.contains("OpenSSH", Qt::CaseInsensitive))
        {
            serviceInfo = "OpenSSH Server";
        }
        else if (banner.contains("Dropbear", Qt::CaseInsensitive))
        {
            serviceInfo = "Dropbear SSH";
        }
        else
        {
            serviceInfo = "SSH Server";
        }
    }
    else if (port == 445)
    {
        serviceInfo = "SMB/CIFS Share";
    }
    else if (port == 2049)
    {
        serviceInfo = "NFS Export";
    }
    else
    {
        serviceInfo = "File-Transfer Service";
    }

    std::cout << "[NetworkScanner] ⚡ Parallel-Service: " << ip.toUtf8().constData() << ":" << port
              << " → " << serviceInfo.toUtf8().constData() << std::endl;
}

bool NetworkScanner::isScanning() const
{
    return scanning;
}

void NetworkScanner::initializePortPresets()
{
    // File Transfer Service Presets
    portPresets["File-Transfer (Standard)"] = {21, 22, 445, 2049}; // FTP, SFTP, SMB, NFS
    portPresets["FTP-Only"] = {21};                                // Nur FTP
    portPresets["SSH/SFTP-Only"] = {22};                           // Nur SFTP
    portPresets["SMB-Only"] = {445, 139};                          // SMB/CIFS
    portPresets["NFS-Only"] = {2049};                              // NFS
    portPresets["Windows-Shares"] = {139, 445};                    // Windows SMB
    portPresets["Unix-Services"] = {22, 2049};                     // SSH + NFS
    portPresets["Alle File-Transfer"] = {21, 22, 139, 445, 2049};  // Komplett
    portPresets["Benutzerdefiniert"] = {};                         // Wird vom User gesetzt

    std::cout << "[NetworkScanner] 📁 " << portPresets.size() << " File-Transfer-Port-Presets geladen" << std::endl;
}

QStringList NetworkScanner::getAvailablePresets() const
{
    return portPresets.keys();
}

void NetworkScanner::setPortPreset(const QString &presetName)
{
    if (portPresets.contains(presetName))
    {
        if (presetName == "Benutzerdefiniert")
        {
            std::cout << "[NetworkScanner] 🔧 Benutzerdefinierte Ports aktiv - verwende setPorts() zum setzen" << std::endl;
            return;
        }

        scanPorts = portPresets[presetName];
        std::cout << "[NetworkScanner] 📁 Port-Preset '" << presetName.toUtf8().constData()
                  << "' aktiviert: " << scanPorts.size() << " Ports" << std::endl;

        // Print selected ports for debugging
        QStringList portStrings;
        for (int port : scanPorts)
        {
            portStrings << QString::number(port);
        }
        std::cout << "[NetworkScanner] 🎯 Ports: " << portStrings.join(", ").toUtf8().constData() << std::endl;
    }
    else
    {
        std::cout << "[NetworkScanner] ⚠️ Port-Preset '" << presetName.toUtf8().constData() << "' nicht gefunden" << std::endl;
    }
}

QList<int> NetworkScanner::getPortsForPreset(const QString &presetName) const
{
    if (portPresets.contains(presetName))
    {
        return portPresets[presetName];
    }
    return DEFAULT_PORTS;
}

QString NetworkScanner::getCurrentPresetName() const
{
    // Find which preset matches current ports
    for (auto it = portPresets.constBegin(); it != portPresets.constEnd(); ++it)
    {
        if (it.value() == scanPorts)
        {
            return it.key();
        }
    }
    return "Benutzerdefiniert";
}

void NetworkScanner::createScanChunks()
{
    scanChunks.clear();
    chunkTimers.clear();
    chunkSockets.clear();

    // 🔒 FIX: Verwende totalChunks statt MAX_CHUNKS um nur so viele Chunks zu erstellen wie nötig
    // Teile Targets in totalChunks auf (z.B. 45 statt 1000)
    int targetsPerChunk = scanTargets.size() / totalChunks;
    int remainder = scanTargets.size() % totalChunks;

    int startIndex = 0;
    for (int chunk = 0; chunk < totalChunks; ++chunk)
    {
        int chunkSize = targetsPerChunk + (chunk < remainder ? 1 : 0);

        if (chunkSize > 0)
        {
            QList<QPair<QString, int>> chunkTargets;
            for (int i = 0; i < chunkSize; ++i)
            {
                chunkTargets.append(scanTargets[startIndex + i]);
            }
            scanChunks.append(chunkTargets);
            startIndex += chunkSize;
        }
    }

    std::cout << "[NetworkScanner] 📊 " << scanChunks.size() << " Parallel-Chunks erstellt (totalChunks=" << totalChunks << ")" << std::endl;
}

void NetworkScanner::startChunkScan(int chunkIndex)
{
    if (chunkIndex >= scanChunks.size())
        return;

    // Create timer for this chunk - ULTRA FAST!
    QTimer *chunkTimer = new QTimer(this);
    chunkTimer->setSingleShot(false);
    chunkTimer->setInterval(2); // 2ms between targets = LIGHTNING FAST!
    chunkTimer->setProperty("chunkIndex", chunkIndex);
    chunkTimer->setProperty("targetIndex", 0);

    connect(chunkTimer, &QTimer::timeout, [this, chunkIndex, chunkTimer]()
            {
        int targetIndex = chunkTimer->property("targetIndex").toInt();
        
        if (targetIndex >= scanChunks[chunkIndex].size()) {
            // Chunk completed
            chunkTimer->stop();
            onChunkCompleted(chunkIndex);
            return;
        }
        
        processChunkTarget(chunkIndex, targetIndex);
        chunkTimer->setProperty("targetIndex", targetIndex + 1); });

    chunkTimers.append(chunkTimer);
    chunkTimer->start();
}

void NetworkScanner::processChunkTarget(int chunkIndex, int targetIndex)
{
    if (chunkIndex >= scanChunks.size() || targetIndex >= scanChunks[chunkIndex].size())
    {
        return;
    }

    QPair<QString, int> target = scanChunks[chunkIndex][targetIndex];
    QString ip = target.first;
    int port = target.second;

    // Create socket for this specific target
    QTcpSocket *socket = new QTcpSocket(this);
    socket->setProperty("chunkIndex", chunkIndex);
    socket->setProperty("ip", ip);
    socket->setProperty("port", port);

    // Use QPointer for safe weak reference to both scanner and socket
    QPointer<QTcpSocket> socketPtr(socket);
    QPointer<NetworkScanner> scannerPtr(this);

    // Immediate result on connection
    connect(socket, &QTcpSocket::connected, [scannerPtr, socketPtr]()
            {
        if (!scannerPtr || !socketPtr) return; // Scanner or socket deleted
        
        QString ip = socketPtr->property("ip").toString();
        int port = socketPtr->property("port").toInt();
        
        // Create service entry immediately
        NetworkService service;
        service.ip = ip;
        service.port = port;
        service.service = scannerPtr->detectService(ip, port);
        service.status = "Active";
        service.responseTime = 400; // Ultra-fast estimate
        
        // 🔒 Check for duplicates before adding to foundServices
        bool isDuplicate = false;
        for (const NetworkService &existing : scannerPtr->foundServices) {
            if (existing.ip == service.ip && existing.port == service.port) {
                isDuplicate = true;
                break;
            }
        }
        
        if (!isDuplicate) {
            scannerPtr->foundServices.append(service);
            
            std::cout << "[NetworkScanner] 🎯 SOFORT-TREFFER: " << ip.toUtf8().constData() 
                      << ":" << port << " (" << service.service.toUtf8().constData() << ")" << std::endl;
            
            // Emit immediately for instant GUI update
            emit scannerPtr->serviceFound(service);
        }
        
        // Quick banner detection for file transfer services
        if (scannerPtr->isFileTransferService(port)) {
            scannerPtr->performSafeServiceDetection(ip, port);
        }
        
        // Safe socket cleanup
        socketPtr->setProperty("processed", true);
        QTimer::singleShot(50, socketPtr, &QTcpSocket::deleteLater); });

    connect(socket, &QTcpSocket::errorOccurred, [scannerPtr, socketPtr]()
            {
        if (!scannerPtr || !socketPtr) return; // Scanner or socket deleted
        socketPtr->setProperty("processed", true);
        socketPtr->abort();
        QTimer::singleShot(50, socketPtr, &QTcpSocket::deleteLater); });

    // Ultra-fast timeout for rapid scanning with safe cleanup
    QTimer::singleShot(400, [scannerPtr, socketPtr]()
                       {
        if (!scannerPtr || !socketPtr) return; // Scanner or socket deleted safely
        if (!socketPtr->property("processed").toBool()) {
            socketPtr->abort();
            socketPtr->setProperty("processed", true);
            QTimer::singleShot(50, socketPtr, &QTcpSocket::deleteLater);
        } });

    // Safe connection using QPointer
    if (socketPtr)
    {
        socketPtr->connectToHost(ip, port);
    }
}

void NetworkScanner::onChunkCompleted(int chunkIndex)
{
    completedChunks++;

    std::cout << "[NetworkScanner] ✅ Chunk " << (chunkIndex + 1) << "/" << totalChunks
              << " abgeschlossen (" << completedChunks << "/" << totalChunks << ")" << std::endl;

    if (completedChunks >= totalChunks)
    {
        // All chunks completed - delay cleanup to avoid memory issues
        scanning = false;

        // 🔒 Report scan finished ONLY ONCE
        if (!scanFinishedReported)
        {
            scanFinishedReported = true;
            std::cout << "[NetworkScanner] 🏁 PARALLEL-SCAN ABGESCHLOSSEN: "
                      << foundServices.size() << " File-Transfer-Services gefunden!" << std::endl;
        }

        // Emit finished first, then cleanup with delay
        emit scanFinished();

        // ✅ SICHERE Delayed cleanup mit QPointer für crash-freie Bereinigung
        QPointer<NetworkScanner> selfPtr(this);
        QTimer::singleShot(200, [selfPtr]() {
            if (selfPtr) {
                selfPtr->cleanupChunkResources();
            }
        });
        return;
    }

    // Update progress
    int totalProcessed = completedChunks * (scanTargets.size() / totalChunks);
    emit scanProgress(totalProcessed, scanTargets.size());
}

void NetworkScanner::cleanupChunkResources()
{
    // Stop and delete all chunk timers safely
    for (QTimer *timer : chunkTimers)
    {
        if (timer && timer->isActive())
        {
            timer->stop();
        }
        if (timer)
        {
            timer->deleteLater();
        }
    }
    chunkTimers.clear();

    // Clean up any remaining sockets safely
    QList<QTcpSocket *> allSockets = findChildren<QTcpSocket *>();
    for (QTcpSocket *socket : allSockets)
    {
        if (socket && socket->state() != QAbstractSocket::UnconnectedState)
        {
            socket->abort();
        }
        if (socket)
        {
            socket->deleteLater();
        }
    }

    scanChunks.clear();

    // ✅ SICHERER LAMBDA ohne 'this' Referenz für verzögertes Cleanup
    QTimer::singleShot(100, []()
                       {     std::cout << "[NetworkScanner] 🧹 Chunk-Resources sicher bereinigt" << std::endl;
                       });
}

// Network Range Management Implementation
QStringList NetworkScanner::autoDetectNetworkRanges()
{
    std::cout << "[NetworkScanner] 🔍 Auto-detecting network ranges..." << std::endl;
    
    QStringList detectedRanges;
    
    // Remove only auto-detected ranges, keep custom ones
    for (int i = m_networkRanges.size() - 1; i >= 0; --i) {
        if (m_networkRanges[i].isAutoDetected) {
            m_networkRanges.removeAt(i);
        }
    }
    
    // Get all network interfaces
    QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
    
    for (const QNetworkInterface &interface : interfaces) {
        // Skip loopback and inactive interfaces
        if (interface.flags() & QNetworkInterface::IsLoopBack || 
            !(interface.flags() & QNetworkInterface::IsUp) ||
            !(interface.flags() & QNetworkInterface::IsRunning)) {
            continue;
        }
        
        // Get all entries for this interface
        QList<QNetworkAddressEntry> entries = interface.addressEntries();
        
        for (const QNetworkAddressEntry &entry : entries) {
            QHostAddress ip = entry.ip();
            
            // Only process IPv4 addresses
            if (ip.protocol() != QAbstractSocket::IPv4Protocol) {
                continue;
            }
            
            // Skip private/local addresses for auto-detection
            if (ip == QHostAddress::LocalHost) {
                continue;
            }
            
            QString networkCidr = detectNetworkFromInterface(interface);
            if (!networkCidr.isEmpty()) {
                NetworkRange range;
                range.name = QString("Auto: %1").arg(interface.humanReadableName());
                range.cidr = networkCidr;
                range.description = QString("Auto-detected from %1 (%2)")
                    .arg(interface.humanReadableName())
                    .arg(ip.toString());
                range.isAutoDetected = true;
                range.interfaceName = interface.name();
                
                // Check if we already have this range
                bool exists = false;
                for (const NetworkRange &existing : m_networkRanges) {
                    if (existing.cidr == range.cidr) {
                        exists = true;
                        break;
                    }
                }
                
                if (!exists) {
                    m_networkRanges.append(range);
                    detectedRanges.append(range.cidr);  // 🌐 Add to return list
                    emit networkRangeDetected(range);
                    std::cout << "[NetworkScanner] 🌐 Detected network: " 
                              << range.cidr.toUtf8().constData() 
                              << " (" << range.name.toUtf8().constData() << ")" << std::endl;
                }
            }
        }
    }
    
    // Add common default ranges if none detected
    if (m_networkRanges.isEmpty()) {
        addCustomNetworkRange("Default Home", "192.168.1.0/24", "Common home router range");
        addCustomNetworkRange("Alternative Home", "192.168.0.0/24", "Alternative home router range");
        addCustomNetworkRange("Office Range 1", "192.168.30.0/24", "Common office range");
        addCustomNetworkRange("Office Range 2", "192.168.50.0/24", "Alternative office range");
        std::cout << "[NetworkScanner] 📋 Added default network ranges" << std::endl;
    }
    
    // Set first range as active if none set
    if (m_activeNetworkRange.isEmpty() && !m_networkRanges.isEmpty()) {
        m_activeNetworkRange = m_networkRanges.first().name;
        setIpRange(m_networkRanges.first().cidr);
    }
    
    return detectedRanges;  // 🌐 Return detected ranges
}

QString NetworkScanner::detectNetworkFromInterface(const QNetworkInterface &interface)
{
    QList<QNetworkAddressEntry> entries = interface.addressEntries();
    
    for (const QNetworkAddressEntry &entry : entries) {
        QHostAddress ip = entry.ip();
        QHostAddress netmask = entry.netmask();
        
        if (ip.protocol() != QAbstractSocket::IPv4Protocol) {
            continue;
        }
        
        // Calculate network address
        QHostAddress networkAddr = getNetworkAddress(ip, netmask);
        QString cidr = cidrFromNetmask(netmask);
        
        if (!networkAddr.isNull() && !cidr.isEmpty()) {
            return QString("%1/%2").arg(networkAddr.toString()).arg(cidr);
        }
    }
    
    return QString();
}

QHostAddress NetworkScanner::getNetworkAddress(const QHostAddress &ip, const QHostAddress &netmask)
{
    if (ip.protocol() != QAbstractSocket::IPv4Protocol || 
        netmask.protocol() != QAbstractSocket::IPv4Protocol) {
        return QHostAddress();
    }
    
    quint32 ipAddr = ip.toIPv4Address();
    quint32 maskAddr = netmask.toIPv4Address();
    quint32 networkAddr = ipAddr & maskAddr;
    
    return QHostAddress(networkAddr);
}

QString NetworkScanner::cidrFromNetmask(const QHostAddress &netmask)
{
    if (netmask.protocol() != QAbstractSocket::IPv4Protocol) {
        return QString();
    }
    
    quint32 mask = netmask.toIPv4Address();
    int cidr = 0;
    
    // Count consecutive bits from the left (MSB)
    // Standard netmask 255.255.255.0 = 0xFFFFFF00 should give /24
    quint32 testMask = 0x80000000; // Start with leftmost bit
    while (testMask && (mask & testMask)) {
        cidr++;
        testMask >>= 1;
    }
    
    // Debug output for troubleshooting
    std::cout << "[NetworkScanner] 🔍 Netmask: " << netmask.toString().toUtf8().constData() 
              << " (0x" << std::hex << mask << std::dec << ") → /" << cidr << std::endl;
    
    return QString::number(cidr);
}

QList<NetworkRange> NetworkScanner::getAvailableNetworkRanges() const
{
    std::cout << "[NetworkScanner] 🔍 getAvailableNetworkRanges() called - returning " 
              << m_networkRanges.size() << " ranges:" << std::endl;
    
    for (const NetworkRange &range : m_networkRanges) {
        std::cout << "[NetworkScanner] 📍 Range: " << range.name.toUtf8().constData() 
                  << " (" << range.cidr.toUtf8().constData() << ") Auto: " 
                  << (range.isAutoDetected ? "Yes" : "No") << std::endl;
    }
    
    return m_networkRanges;
}

void NetworkScanner::addCustomNetworkRange(const QString &name, const QString &cidr, const QString &description)
{
    if (!isValidCidr(cidr)) {
        std::cout << "[NetworkScanner] ❌ Invalid CIDR format: " << cidr.toUtf8().constData() << std::endl;
        return;
    }
    
    // Check for duplicates before adding
    for (const NetworkRange &existing : m_networkRanges) {
        if (existing.name == name || existing.cidr == cidr) {
            std::cout << "[NetworkScanner] ⚠️ Duplicate range ignored: " 
                      << name.toUtf8().constData() << " (" << cidr.toUtf8().constData() << ")" << std::endl;
            return;
        }
    }
    
    NetworkRange range;
    range.name = name;
    range.cidr = cidr;
    range.description = description.isEmpty() ? "Custom network range" : description;
    range.isAutoDetected = false;
    range.interfaceName = "";
    
    m_networkRanges.append(range);
    saveNetworkPresets();
    
    std::cout << "[NetworkScanner] ➕ Added custom range: " 
              << name.toUtf8().constData() << " (" << cidr.toUtf8().constData() << ")" << std::endl;
}

void NetworkScanner::removeNetworkRange(const QString &name)
{
    for (int i = 0; i < m_networkRanges.size(); ++i) {
        if (m_networkRanges[i].name == name) {
            m_networkRanges.removeAt(i);
            saveNetworkPresets();
            
            // If this was the active range, switch to first available
            if (m_activeNetworkRange == name && !m_networkRanges.isEmpty()) {
                setActiveNetworkRange(m_networkRanges.first().name);
            }
            
            std::cout << "[NetworkScanner] ➖ Removed range: " << name.toUtf8().constData() << std::endl;
            return;
        }
    }
}

void NetworkScanner::setActiveNetworkRange(const QString &name)
{
    for (const NetworkRange &range : m_networkRanges) {
        if (range.name == name) {
            m_activeNetworkRange = name;
            setIpRange(range.cidr);
            emit networkRangeChanged(name);
            
            std::cout << "[NetworkScanner] 🔄 Active range changed to: " 
                      << name.toUtf8().constData() << " (" << range.cidr.toUtf8().constData() << ")" << std::endl;
            return;
        }
    }
}

QString NetworkScanner::getActiveNetworkRange() const
{
    return m_activeNetworkRange;
}

void NetworkScanner::loadNetworkPresets()
{
    QSettings settings(m_presetConfigFile, QSettings::IniFormat);
    
    int size = settings.beginReadArray("NetworkRanges");
    for (int i = 0; i < size; ++i) {
        settings.setArrayIndex(i);
        
        NetworkRange range;
        range.name = settings.value("name").toString();
        range.cidr = settings.value("cidr").toString();
        range.description = settings.value("description").toString();
        range.isAutoDetected = false; // Loaded ranges are considered custom
        range.interfaceName = settings.value("interfaceName").toString();
        
        if (!range.name.isEmpty() && !range.cidr.isEmpty() && isValidCidr(range.cidr)) {
            // Check if we already have this range (avoid duplicates)
            bool exists = false;
            for (const NetworkRange &existing : m_networkRanges) {
                if (existing.name == range.name || existing.cidr == range.cidr) {
                    exists = true;
                    break;
                }
            }
            
            if (!exists) {
                m_networkRanges.append(range);
            }
        }
    }
    settings.endArray();
    
    // Load active range
    m_activeNetworkRange = settings.value("activeRange").toString();
    
    std::cout << "[NetworkScanner] 📋 Loaded " << size << " network presets" << std::endl;
}

void NetworkScanner::saveNetworkPresets()
{
    QSettings settings(m_presetConfigFile, QSettings::IniFormat);
    
    // Only save custom (non-auto-detected) ranges
    QList<NetworkRange> customRanges;
    for (const NetworkRange &range : m_networkRanges) {
        if (!range.isAutoDetected) {
            customRanges.append(range);
        }
    }
    
    settings.beginWriteArray("NetworkRanges");
    for (int i = 0; i < customRanges.size(); ++i) {
        settings.setArrayIndex(i);
        const NetworkRange &range = customRanges[i];
        
        settings.setValue("name", range.name);
        settings.setValue("cidr", range.cidr);
        settings.setValue("description", range.description);
        settings.setValue("interfaceName", range.interfaceName);
    }
    settings.endArray();
    
    settings.setValue("activeRange", m_activeNetworkRange);
    settings.sync();
}

QStringList NetworkScanner::getNetworkPresetNames() const
{
    QStringList names;
    for (const NetworkRange &range : m_networkRanges) {
        names.append(range.name);
    }
    return names;
}

QStringList NetworkScanner::generateIpRange(const QString &cidr)
{
    QStringList ips;
    
    // Parse CIDR notation (e.g., "192.168.1.0/24")
    QStringList parts = cidr.split('/');
    if (parts.size() != 2) {
        return ips;
    }
    
    QHostAddress network(parts[0]);
    int prefixLength = parts[1].toInt();
    
    if (network.protocol() != QAbstractSocket::IPv4Protocol || 
        prefixLength < 0 || prefixLength > 32) {
        return ips;
    }
    
    quint32 networkAddr = network.toIPv4Address();
    quint32 hostMask = (1U << (32 - prefixLength)) - 1;
    quint32 networkMask = ~hostMask;
    
    // Ensure we're working with the actual network address
    networkAddr &= networkMask;
    
    // Generate all host addresses (skip network and broadcast)
    for (quint32 host = 1; host < hostMask; ++host) {
        quint32 ip = networkAddr | host;
        ips.append(QHostAddress(ip).toString());
    }
    
    return ips;
}

bool NetworkScanner::isValidCidr(const QString &cidr)
{
    QRegularExpression cidrRegex(R"(^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$)");
    if (!cidrRegex.match(cidr).hasMatch()) {
        return false;
    }
    
    QStringList parts = cidr.split('/');
    QHostAddress ip(parts[0]);
    int prefix = parts[1].toInt();
    
    return ip.protocol() == QAbstractSocket::IPv4Protocol && 
           prefix >= 0 && prefix <= 32;
}
