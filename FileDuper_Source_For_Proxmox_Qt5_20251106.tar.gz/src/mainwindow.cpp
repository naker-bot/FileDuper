#include "mainwindow.h"
#include "presetmanager.h"
#include <algorithm>
#include "activityindicator.h"
#include "ftpclient.h"
#include "sftpclient.h"         // ✅ SFTP Client Include
#include "smbclient.h"          // ✅ SMB Client Include
#include "nfsclient.h"          // ✅ NFS Client Include
#include "networkdirectorydialog.h"
#include "simpletreedialog.h"
#include "logindialog.h"
#include "hashengine.h"
#include "duplicatedeletedialog.h"
#include "networkrangewidget.h"  // 🌐 Network Range Management Widget

#include <QApplication>
#include <QThread>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QSplitter>
#include <QGroupBox>
#include <QLabel>
#include <QPushButton>
#include <QTreeWidget>
#include <QTableWidget>
#include <QProgressBar>
#include <QComboBox>
#include <QFileDialog>
#include <QMessageBox>
#include <atomic>
#include <memory>
#include <QTimer>
#include <QTime>
#include <QShortcut>
#include <QThread>
#include <QDebug>
#include <QSettings>
#include <QStandardPaths>
#include <QMenu>
#include <QRegularExpression>
#include <QContextMenuEvent>
#include <QHeaderView>
#include <QPalette>
#include <QCloseEvent>
#include <QThreadPool>
#include <QAction>
#include <QClipboard>
#include <QHeaderView>
#include <iostream>
#include <QThread>

// PImpl structure for MainWindow
struct MainWindow::Impl
{
    Scanner *scanner = nullptr;
    NetworkScanner *networkScanner = nullptr;
    PresetManager *presetManager = nullptr;
    ActivityIndicator *activityIndicator = nullptr;

    QStringList scanDirectories;
    bool isScanning = false;
};

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      m_scanner(new Scanner(this)),
      m_networkScanner(new NetworkScanner(this)),
      m_presetManager(new PresetManager(this)),
      m_activityIndicator(new ActivityIndicator(this)),
      m_hashEngine(new HashEngine(this)),
      m_ftpClient(new FtpClient(this)),
      m_sftpClient(new SftpClient(this)),    // ✅ SFTP Client
      m_smbClient(new SmbClient(this)),      // ✅ SMB Client
      m_nfsClient(new NfsClient(this)),      // ✅ NFS Client
      m_networkRangeWidget(new NetworkRangeWidget(this)), // 🌐 Network Range Widget
      d(std::make_unique<Impl>()),
      m_isScanning(false),
      m_networkScanActive(false),      // Initialize network scan state
      m_multiRangeScanActive(false),   // Initialize multi-range scan state
      m_hashCalculationStarted(false), // Initialize hash calculation state
      m_filesCollectedHandled(false)   // Initialize filesCollected handling state
{
    setupProgrammaticGUI(); // Call the programmatic UI setup
    setupConnections();     // ✅ FRÜHER: Verbinde Signals VOR initializeComponents()
    initializeComponents();
    loadSettings();

    // Initial network scan after delay
    // ✅ PRODUCTION: Nur automatisches Netzwerk-Discovery
    QTimer::singleShot(1000, this, &MainWindow::startNetworkDiscovery);
    
    // Multi-Range-Scan ist jetzt in startNetworkDiscovery() integriert

    // ✅ PRODUCTION: Kein automatischer Demo-Scan - nur Benutzerauswahl
    std::cout << "[MainWindow] ✅ Produktions-Scanner bereit - warte auf Benutzerauswahl" << std::endl;

    // 🧪 DEBUG: Auto-Test-Scan für GUI-Update-Verifizierung
    // TEMP: Automatischer Test-Scan um zu prüfen ob GUI-Updates funktionieren
    if (qgetenv("FILEDUPER_GUI_TEST") == "1") {
        qDebug() << "[MainWindow] 🧪🧪🧪 GUI-TEST-MODUS AKTIVIERT!";
        std::cout << "[MainWindow] 🧪 Starte automatischen Test-Scan für GUI-Updates" << std::endl;
        
        // Füge Test-Verzeichnis hinzu (FTP oder lokal)
        QString testDir = "ftp://192.168.50.224/share/Jan/heiner/Musik/";
        m_selectedDirectories.append(testDir);
        updateDirectorySummary();
        
        qDebug() << "[MainWindow] 🧪 Test-Verzeichnis hinzugefügt:" << testDir;
        std::cout << "[MainWindow] 🧪 Starte Scan in 3 Sekunden..." << std::endl;
        
        // Starte Scan nach 3 Sekunden
        QTimer::singleShot(3000, this, [this]() {
            qDebug() << "[MainWindow] 🧪 AUTO-SCAN STARTET JETZT!";
            std::cout << "[MainWindow] 🚀🚀🚀 AUTO-TEST-SCAN GESTARTET!" << std::endl;
            startDuplicateScan();
        });
    }

    // 🔧 Production-Hook: Auto-Scan über Umgebungsvariable für Batch-Verarbeitung
    // Setzen Sie FILEDUPER_AUTOSCAN_DIRS="/pfad/zu/local;ftp://host/pfad/" um
    // direkt nach dem Start einen Scan mit diesen Verzeichnissen zu triggern.
    const QByteArray autoScanEnv = qgetenv("FILEDUPER_AUTOSCAN_DIRS");
    if (!autoScanEnv.isEmpty()) {
        QString raw = QString::fromUtf8(autoScanEnv);
        // Unterstütze Trennzeichen ';', ',' oder Zeilenumbruch
        QStringList dirs = raw.split(QRegularExpression("[\n;,]"), Qt::SkipEmptyParts);
        int added = 0;
        for (QString d : dirs) {
            d = d.trimmed();
            if (d.isEmpty()) continue;
            if (!m_selectedDirectories.contains(d)) {
                m_selectedDirectories.append(d);
                ++added;
            }
        }
        qDebug() << "[MainWindow] 🧪 AutoScan aktiviert via Env - Verzeichnisse hinzugefügt:" << added
                 << "→" << m_selectedDirectories;
        updateDirectorySummary();
        // Starte den Scan leicht verzögert, damit UI/Komponenten bereit sind
        QTimer::singleShot(1500, this, &MainWindow::startDuplicateScan);
    }
}

MainWindow::~MainWindow()
{
    // ✅ CRASH PREVENTION: Umfassender sicherer Destructor
    qDebug() << "[MainWindow] 🧹 Destructor gestartet - Sichere Bereinigung...";
    
    try {
        // ✅ 1. Scanner sicher stoppen
        if (m_scanner) {
            qDebug() << "[MainWindow] 🛑 Stoppe Scanner...";
            m_scanner->stopScan();
            m_scanner = nullptr;
        }
        
        // ✅ 2. NetworkScanner sicher stoppen  
        if (m_networkScanner) {
            qDebug() << "[MainWindow] 📡 Stoppe NetworkScanner...";
            // NetworkScanner hat automatische Bereinigung
            m_networkScanner = nullptr;
        }
        
        // ✅ 3. Timers sicher stoppen
        if (m_activityIndicator) {
            qDebug() << "[MainWindow] ⏰ Stoppe ActivityIndicator...";
            // ActivityIndicator stoppt seine eigenen Timer
            m_activityIndicator = nullptr;
        }
        
        // ✅ 4. Settings sicher speichern
        qDebug() << "[MainWindow] 💾 Speichere Settings...";
        saveSettings();
        
        // ✅ 5. Weitere Komponenten auf nullptr setzen
        m_presetManager = nullptr;
        m_hashEngine = nullptr;
        
        // ✅ 6. GUI-Komponenten sind durch Qt Parent-System automatisch bereinigt
        
        qDebug() << "[MainWindow] ✅ Destructor erfolgreich abgeschlossen";
        
    } catch (const std::exception& e) {
        qDebug() << "[MainWindow] ❌ Exception in Destruktor:" << e.what();
    } catch (...) {
        qDebug() << "[MainWindow] ❌ Unknown exception in Destruktor";
    }
}

void MainWindow::initializeComponents()
{
    d->scanner = m_scanner;
    d->networkScanner = m_networkScanner;
    d->presetManager = m_presetManager;
    d->activityIndicator = m_activityIndicator;

    // Configure HashEngine for Scanner
    m_scanner->setHashEngine(m_hashEngine);
    
    // 🔄 Verbinde HashEngine Status-Updates mit GUI
    connect(m_hashEngine, &HashEngine::statusUpdate, this, &MainWindow::onHashEngineStatusUpdate);
    
    // ✅ KRITISCH: Configure PresetManager for Scanner (für FTP-Credentials)
    m_scanner->setPresetManager(m_presetManager);
    
    // ✅ Configure FtpClient for Scanner
    m_scanner->setFtpClient(m_ftpClient);
    
    // 🌐 Initialize Network Range Widget connections
    if (m_networkRangeWidget) {
        // Connect the NetworkScanner to the NetworkRangeWidget
        m_networkRangeWidget->setNetworkScanner(m_networkScanner);
        
        connect(m_networkRangeWidget, &NetworkRangeWidget::customRangeAdded, 
                this, &MainWindow::onCustomNetworkRangeAdded);
        connect(m_networkRangeWidget, &NetworkRangeWidget::rangeSelected, 
                this, &MainWindow::onNetworkRangeSelected);
        connect(m_networkRangeWidget, &NetworkRangeWidget::rangesLoaded, 
                this, &MainWindow::onNetworkRangesLoaded);
        
        // Initial setup with auto-detected ranges
        updateNetworkRangeDisplay();
    }

    // 🧠 NPU enablement is configurable: env FILEDUPER_NPU or settings key npu/enabled (default: true)
    bool npuEnabled = true; // default
    const QByteArray npuEnv = qgetenv("FILEDUPER_NPU");
    if (!npuEnv.isEmpty()) {
        const QString v = QString::fromUtf8(npuEnv).trimmed().toLower();
        npuEnabled = (v == "1" || v == "true" || v == "yes" || v == "on");
    } else {
        QSettings s; // use application/org defaults
        npuEnabled = s.value("npu/enabled", true).toBool();
    }
    m_scanner->setNpuEnabled(npuEnabled);
    qDebug() << "[MainWindow] 🧠 NPU initial state =" << npuEnabled << "(env FILEDUPER_NPU overrides)";

    QThreadPool::globalInstance()->setMaxThreadCount(QThread::idealThreadCount());

    setWindowTitle("FileDuper - Advanced Duplicate Scanner");
    setMinimumSize(1200, 800);
}

void MainWindow::setupProgrammaticGUI()
{
    setWindowTitle(tr("FileDuper - Advanced Network Duplicate Scanner"));
    resize(1400, 900);

    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    mainLayout->addWidget(splitter);

    // Left Panel: Directory & Network Services
    QWidget *leftPanel = new QWidget();
    QVBoxLayout *leftLayout = new QVBoxLayout(leftPanel);
    
    // Local Directory Group with Multi-Selection
    QGroupBox *dirGroupBox = new QGroupBox(tr("📁 Lokale Verzeichnisse"));
    QVBoxLayout *dirLayout = new QVBoxLayout(dirGroupBox);
    
    // Directory selection buttons
    QHBoxLayout *dirButtonLayout = new QHBoxLayout();
    selectDirBtn = new QPushButton(tr("📂 Verzeichnisse auswählen"));
    scanSelectedBtn = new QPushButton(tr("🔍 Ausgewählte scannen"));
    scanSelectedBtn->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
    dirButtonLayout->addWidget(selectDirBtn);
    dirButtonLayout->addWidget(scanSelectedBtn);
    dirLayout->addLayout(dirButtonLayout);
    
    // ✅ Ersetzt direkten Tree durch Summary-Label mit DUNKLEREM Hintergrund
    QLabel *directorySummaryLabel = new QLabel(tr("📁 Keine Verzeichnisse ausgewählt"), this);
    directorySummaryLabel->setObjectName("directorySummaryLabel");
    directorySummaryLabel->setStyleSheet(
        "QLabel { "
        "   background-color: #2d3748; "  // Dunkelgrau statt hell
        "   color: #e2e8f0; "             // Helle Schrift
        "   border: 1px solid #4a5568; "  // Dunklerer Rand
        "   border-radius: 8px; "
        "   padding: 12px; "
        "   font-size: 13px; "
        "   font-family: 'Segoe UI', Arial, sans-serif; "
        "   min-height: 120px; "
        "}"
    );
    directorySummaryLabel->setWordWrap(true);
    directorySummaryLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    
    // ✅ Context Menu für Pfad-Entfernung aktivieren
    directorySummaryLabel->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(directorySummaryLabel, &QLabel::customContextMenuRequested, 
            this, &MainWindow::showDirectorySummaryContextMenu);
    
    dirLayout->addWidget(directorySummaryLabel);
    
    leftLayout->addWidget(dirGroupBox);

    // Network Services Group with Auto-Login
    QGroupBox *networkGroupBox = new QGroupBox(tr("🌐 Netzwerk-Services (Doppelklick für Auto-Login)"));
    QVBoxLayout *networkLayout = new QVBoxLayout(networkGroupBox);
    
    // Network scan status
    QHBoxLayout *networkStatusLayout = new QHBoxLayout();
    QLabel *networkStatusLabel = new QLabel(tr("📡 Netzwerk-Scan:"));
    networkProgressLabel = new QLabel(tr("Bereit"));
    networkStatusLayout->addWidget(networkStatusLabel);
    networkStatusLayout->addWidget(networkProgressLabel);
    networkStatusLayout->addStretch();
    networkLayout->addLayout(networkStatusLayout);
    
    networkTree = new QTreeWidget();
    networkTree->setColumnCount(5);
    networkTree->setHeaderLabels({tr("📡 Intelligente Server-Hierarchie"), tr("🔧 Service"), tr("🔐 Auth"), tr("📊 Status"), tr("🎯 Relevanz")});
    networkTree->header()->resizeSection(0, 280);
    networkTree->header()->resizeSection(1, 100);
    networkTree->header()->resizeSection(2, 70);
    networkTree->header()->resizeSection(3, 80);
    networkTree->header()->resizeSection(4, 90);
    networkTree->setSelectionMode(QAbstractItemView::ExtendedSelection);
    networkTree->setContextMenuPolicy(Qt::CustomContextMenu);
    networkTree->setRootIsDecorated(true);
    networkTree->setAnimated(true);
    networkTree->setIndentation(25);
    networkTree->setSortingEnabled(true);
    networkTree->setAlternatingRowColors(true);
    
    // ✅ VERBESSERTE Sichtbarkeit mit dunklerem Design
    networkTree->setStyleSheet(R"(
        QTreeWidget {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                      stop:0 #1e293b, stop:1 #0f172a);
            color: #e2e8f0;
            border: 2px solid #475569;
            border-radius: 12px;
            font-family: 'Segoe UI', 'SF Pro Display', Arial, sans-serif;
            font-size: 13px;
            alternate-background-color: rgba(71, 85, 105, 0.3);
        }
        QTreeWidget::item {
            padding: 8px 6px;
            border-bottom: 1px solid #334155;
            min-height: 28px;
        }
        QTreeWidget::item:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                      stop:0 #3b82f6, stop:1 #2563eb);
            color: white;
            border-radius: 6px;
            font-weight: 500;
        }
        QTreeWidget::item:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                      stop:0 #7c3aed, stop:1 #5b21b6);
            color: white;
            border-radius: 6px;
            font-weight: bold;
        }
        QTreeWidget::item:selected:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                      stop:0 #8b5cf6, stop:1 #7c3aed);
        }
        QTreeWidget::branch:has-children:!has-siblings:closed,
        QTreeWidget::branch:closed:has-children:has-siblings {
            image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIHZpZXdCb3g9IjAgMCAxMiAxMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTMgM0w5IDZMMyA5IiBzdHJva2U9IiNmMWY1ZjkiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+Cjwvc3ZnPgo=);
            width: 12px;
            height: 12px;
        }
        QTreeWidget::branch:open:has-children:!has-siblings,
        QTreeWidget::branch:open:has-children:has-siblings {
            image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIHZpZXdCb3g9IjAgMCAxMiAxMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTMgNEw2IDlMOSA0IiBzdHJva2U9IiNmMWY1ZjkiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+Cjwvc3ZnPgo=);
            width: 12px;
            height: 12px;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                      stop:0 #4338ca, stop:1 #3730a3);
            color: #f8fafc;
            border: 1px solid #312e81;
            padding: 10px 8px;
            font-weight: bold;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        QHeaderView::section:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                      stop:0 #5b21b6, stop:1 #581c87);
        }
        QScrollBar:vertical {
            background: #1e293b;
            width: 14px;
            border-radius: 7px;
            margin: 2px;
        }
        QScrollBar::handle:vertical {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                      stop:0 #64748b, stop:1 #475569);
            border-radius: 6px;
            min-height: 25px;
            margin: 1px;
        }
        QScrollBar::handle:vertical:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                      stop:0 #94a3b8, stop:1 #64748b);
        }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
            height: 0px;
        }
    )");
    
    networkLayout->addWidget(networkTree);
    
    // 🌐 Network Range Settings Button
    QHBoxLayout *networkRangeLayout = new QHBoxLayout();
    networkRangeBtn = new QPushButton(tr("🌐 IP-Bereiche verwalten"));
    networkRangeBtn->setStyleSheet("font-weight: bold; background-color: #2563eb; color: white; padding: 8px;");
    networkRangeBtn->setToolTip(tr("Netzwerk-IP-Bereiche konfigurieren und Auto-Erkennung verwalten"));
    networkRangeLayout->addWidget(networkRangeBtn);
    networkRangeLayout->addStretch();
    networkLayout->addLayout(networkRangeLayout);
    
    leftLayout->addWidget(networkGroupBox);
    splitter->addWidget(leftPanel);

    // Right Panel
    QWidget *rightPanel = new QWidget();
    QVBoxLayout *rightLayout = new QVBoxLayout(rightPanel);
    QGroupBox *scanGroupBox = new QGroupBox(tr("🔍 Duplikat-Scan"));
    QFormLayout *scanLayout = new QFormLayout(scanGroupBox);
    hashComboBox = new QComboBox();
    hashComboBox->addItems({
        "🧠 Smart Auto-Detect (Empfohlen)",
        "⚡ XXHash (Ultra-Fast, Video/Audio)",
        "🚀 MD5 (Fast, Dokumente)",
        "🔒 SHA-1 (Balance, Bilder)",
        "🛡️ SHA-256 (Secure, Archive)",
        "💎 SHA-512 (Maximum Security)",
        "🔥 BLAKE2 (Modern, schnell)",
        "💫 BLAKE3 (Ultra-Modern, parallel)",
        "🌊 SHA3 (Keccak, modern)",
        "🏎️ Murmur3 (Hash-Table optimiert)",
        "🏙️ CityHash (Google, sehr schnell)",
        "🚜 FarmHash (Google, Nachfolger)",
        "🛣️ HighwayHash (SIMD-optimiert)",
        "🚇 MetroHash (Extrem schnell)",
        "👻 SpookyHash (Gut verteilt)"
    });
    hashComboBox->setCurrentIndex(0); // Smart Auto-Detect als Standard
    hardwareComboBox = new QComboBox();
    hardwareComboBox->addItems({"Auto Detect", "CPU Only", "GPU Accelerated"});
    themeComboBox = new QComboBox();
    themeComboBox->addItems({
        "🌐 System Default",
        "☀️ Light Theme (High Contrast)",
        "🌙 Dark Theme (Blue Accent)",
        "🌑 Dark Theme (Green Accent)",
        "🎨 Dark Theme (Purple Accent)",
        "🔥 Dark Theme (Red/Orange)",
        "❄️ Ice Theme (Light Blue)",
        "🌲 Forest Theme (Dark Green)",
        "🎭 High Contrast (Black/White)",
        "🌸 Sakura Theme (Pink)"
    });
    
    // Connect theme change handler
    connect(themeComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onThemeChanged);
    
    scanLayout->addRow(tr("Hash-Algorithmus:"), hashComboBox);
    scanLayout->addRow(tr("Hardware:"), hardwareComboBox);
    scanLayout->addRow(tr("Theme:"), themeComboBox);
    
    // ✅ ERWEITERTE PROGRESS-ANZEIGE
    // Action-Label (was gerade passiert)
    actionLabel = new QLabel(tr("🔍 Bereit"));
    actionLabel->setStyleSheet("QLabel { font-weight: bold; color: #FF0000; background-color: #00FF00; font-size: 10pt; font-family: 'DejaVu Sans', 'Liberation Sans', Arial, sans-serif; }");
    scanLayout->addRow(tr("Aktion:"), actionLabel);
    
    // Progress-Bar mit deutlich sichtbarer Prozentzahl
    progressBar = new QProgressBar();
    progressBar->setTextVisible(true); // Zeige Prozent in der Mitte
    progressBar->setFormat("%p%"); // Format: "45%"
    progressBar->setAlignment(Qt::AlignCenter); // Zentrierte Anzeige
    
    // Styling mit weißer Schrift auf grünem Balken - OHNE Animation
    progressBar->setStyleSheet(
        "QProgressBar {"
        "    background-color: #E0E0E0;"
        "    border: 2px solid #CCCCCC;"
        "    border-radius: 5px;"
        "    text-align: center;"
        "    color: #000000;"  // Schwarze Schrift auf grauem Hintergrund
        "    font-weight: bold;"
        "    font-size: 14px;"
        "}"
        "QProgressBar::chunk {"
        "    background-color: #4CAF50;"
        "    border-radius: 3px;"
        "    width: 1px;"  // Verhindert doppelte Balken-Animation
        "}"
    );
    
    scanLayout->addRow(tr("Fortschritt:"), progressBar);
    
    // Datei X von Y Anzeige
    fileCountLabel = new QLabel(tr("Keine Dateien"));
    fileCountLabel->setStyleSheet("QLabel { color: #666; }");
    scanLayout->addRow(tr("Dateien:"), fileCountLabel);

    // 📡 FTP-Verzeichnis-Anzeige
    ftpDirectoryCountLabel = new QLabel(tr("FTP: 0 Verzeichnisse"));
    ftpDirectoryCountLabel->setStyleSheet("QLabel { color: #1976D2; font-weight: bold; }");
    scanLayout->addRow(tr("FTP Gesamt:"), ftpDirectoryCountLabel);

    ftpCompletedLabel = new QLabel(tr("FTP: 0 abgearbeitet"));
    ftpCompletedLabel->setStyleSheet("QLabel { color: #388E3C; font-weight: bold; }");
    scanLayout->addRow(tr("FTP Fertig:"), ftpCompletedLabel);
    
    // 🎯 NEUE DETAILLIERTE PROGRESS-LABELS
    currentFileLabel = new QLabel(tr("Bereit"));
    currentFileLabel->setStyleSheet("QLabel { color: #FF0000; background-color: #FFFF00; font-family: 'DejaVu Sans Mono', 'Liberation Mono', 'Courier New', monospace; font-size: 10pt; font-weight: bold; }");
    scanLayout->addRow(tr("Aktuelle Datei:"), currentFileLabel);
    
    fileComparisonLabel = new QLabel(tr("Bereit"));
    fileComparisonLabel->setStyleSheet("QLabel { color: #555; font-family: 'DejaVu Sans Mono', 'Liberation Mono', 'Courier New', monospace; font-size: 10pt; }");
    scanLayout->addRow(tr("Vergleiche:"), fileComparisonLabel);
    
    duplicateCountLabel = new QLabel(tr("0 Duplikate"));
    duplicateCountLabel->setStyleSheet("QLabel { color: #2E7D32; font-weight: bold; }");
    scanLayout->addRow(tr("Duplikate:"), duplicateCountLabel);
    
    // 🚀 ECHTZEIT HARDWARE-MONITORING
    hardwareStatusLabel = new QLabel(tr("Hardware bereit"));
    hardwareStatusLabel->setStyleSheet("QLabel { color: #555; }");
    scanLayout->addRow(tr("Hardware:"), hardwareStatusLabel);
    
    // CPU Echtzeit-Anzeige
    cpuLoadLabel = new QLabel(tr("CPU: 0%"));
    cpuLoadLabel->setStyleSheet("QLabel { color: #666; font-family: 'DejaVu Sans Mono', 'Liberation Mono', 'Courier New', monospace; font-weight: bold; font-size: 10pt; }");
    scanLayout->addRow(tr("🖥️ CPU:"), cpuLoadLabel);
    
    // GPU Echtzeit-Anzeige
    gpuLoadLabel = new QLabel(tr("GPU: Inaktiv"));
    gpuLoadLabel->setStyleSheet("QLabel { color: #666; font-family: 'DejaVu Sans Mono', 'Liberation Mono', 'Courier New', monospace; font-weight: bold; font-size: 10pt; }");
    scanLayout->addRow(tr("🎮 GPU:"), gpuLoadLabel);
    
    // NPU Echtzeit-Anzeige
    npuLoadLabel = new QLabel(tr("NPU: Inaktiv"));
    npuLoadLabel->setStyleSheet("QLabel { color: #666; font-family: monospace; font-weight: bold; font-size: 10pt; }");
    scanLayout->addRow(tr("🧠 NPU:"), npuLoadLabel);
    
    pathProcessingLabel = new QLabel(tr("Warten..."));
    pathProcessingLabel->setStyleSheet("QLabel { color: #777; font-size: 10pt; }");
    scanLayout->addRow(tr("Pfad:"), pathProcessingLabel);
    
    rightLayout->addWidget(scanGroupBox);

    QGroupBox *resultsGroupBox = new QGroupBox(tr("📊 Scan-Ergebnisse"));
    QVBoxLayout *resultsLayout = new QVBoxLayout(resultsGroupBox);
    resultsTable = new QTableWidget();
    resultsTable->setColumnCount(5);
    resultsTable->setHorizontalHeaderLabels({tr("Status"), tr("Dateiname"), tr("Pfad"), tr("Größe"), tr("Hash")});
    resultsTable->setColumnWidth(0, 120);  // Status
    resultsTable->setColumnWidth(1, 250);  // Dateiname
    resultsTable->setColumnWidth(2, 400);  // Pfad
    resultsTable->setColumnWidth(3, 100);  // Größe
    resultsTable->setColumnWidth(4, 350);  // Hash - 350px für vollständigen MD5 (32 Zeichen)
    resultsTable->setSelectionBehavior(QAbstractItemView::SelectItems); // Select einzelne Items
    resultsTable->setSelectionMode(QAbstractItemView::ExtendedSelection); // Mehrfachauswahl
    resultsTable->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked); // Edit bei Doppelklick
    resultsTable->setTextElideMode(Qt::ElideMiddle);
    resultsTable->setWordWrap(false);
    
    // Sortierung DEAKTIVIERT - Behalte Original → Duplikate Reihenfolge
    resultsTable->setSortingEnabled(false);
    
    for (int i = 0; i < resultsTable->columnCount(); ++i) {
        resultsTable->horizontalHeader()->setSectionResizeMode(i, QHeaderView::Interactive);
    }
    
    resultsTable->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(resultsTable, &QTableWidget::customContextMenuRequested, 
            this, &MainWindow::showResultsContextMenu);
    
    // 📋 DOUBLE-CLICK to copy cell text
    connect(resultsTable, &QTableWidget::cellDoubleClicked, this, [this](int row, int col) {
        QTableWidgetItem *item = resultsTable->item(row, col);
        if (!item) return;
        
        QString text = item->text();
        QApplication::clipboard()->setText(text);
        statusBar()->showMessage(tr("📋 Kopiert: %1").arg(text.length() > 50 ? text.left(50) + "..." : text), 2000);
    });
    
    // 📋 COPY & PASTE: Ctrl+C Shortcut für resultsTable
    QShortcut *copyShortcut = new QShortcut(QKeySequence::Copy, resultsTable);
    connect(copyShortcut, &QShortcut::activated, this, [this]() {
        // Copy selected rows as tab-separated values
        QSet<int> selectedRowSet;
        for (QTableWidgetItem *it : resultsTable->selectedItems()) {
            if (it) selectedRowSet.insert(it->row());
        }
        if (selectedRowSet.isEmpty()) return;
        
        QStringList rows;
        QList<int> sortedRows = selectedRowSet.values();
        std::sort(sortedRows.begin(), sortedRows.end());
        for (int row : sortedRows) {
            QStringList cells;
            for (int col = 0; col < resultsTable->columnCount(); ++col) {
                QTableWidgetItem *item = resultsTable->item(row, col);
                cells.append(item ? item->text() : "");
            }
            rows.append(cells.join("\t"));
        }
        QApplication::clipboard()->setText(rows.join("\n"));
        statusBar()->showMessage(tr("📋 %1 Zeilen kopiert (Ctrl+C)").arg(rows.size()), 2000);
    });
    
    resultsLayout->addWidget(resultsTable);
    rightLayout->addWidget(resultsGroupBox);

    // Standard 2-Panel Layout ohne Mitte
    splitter->addWidget(leftPanel);
    splitter->addWidget(rightPanel);
    splitter->setSizes({600, 800});
    splitter->setStretchFactor(0, 1);  // Links Panel
    splitter->setStretchFactor(1, 2);  // Rechts Panel mehr Platz
    
    // Widgets nutzen verfügbaren Platz
    networkTree->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    resultsTable->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    
    // Zentrales Widget Layout ändern von HBox zu VBox
    delete centralWidget->layout(); // Altes HBoxLayout entfernen
    QVBoxLayout *newMainLayout = new QVBoxLayout(centralWidget);
    newMainLayout->setContentsMargins(0, 0, 0, 0);  // Keine Ränder für maximalen Platz
    newMainLayout->addWidget(splitter, 1);  // Stretch factor 1 = nutzt ganzen Platz

    createActions();
    setupMenuBar();
    setupToolBar();
}

void MainWindow::setupMenuBar()
{
    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(m_addDirectoryAction);
    fileMenu->addAction(m_removeDirectoryAction);
    fileMenu->addSeparator();
    fileMenu->addAction(m_exitAction);

    QMenu *scanMenu = menuBar()->addMenu(tr("&Scan"));
    scanMenu->addAction(m_startScanAction);
    scanMenu->addAction(m_stopScanAction);
    scanMenu->addSeparator();
    scanMenu->addAction(m_networkScanAction);
    scanMenu->addAction(m_multiRangeScanAction);

    QMenu *toolsMenu = menuBar()->addMenu(tr("&Tools"));
    toolsMenu->addAction(m_settingsAction);
    toolsMenu->addAction(m_presetManagerAction);
    toolsMenu->addSeparator();
    toolsMenu->addAction(m_networkRangeAction);

    QMenu *helpMenu = menuBar()->addMenu(tr("&Help"));
    helpMenu->addAction(m_aboutAction);
    helpMenu->addAction(m_documentationAction);
}

void MainWindow::setupToolBar()
{
    QToolBar *mainToolBar = addToolBar(tr("Main Toolbar"));
    mainToolBar->setMovable(false);

    mainToolBar->addAction(m_addDirectoryAction);
    mainToolBar->addAction(m_removeDirectoryAction);
    mainToolBar->addSeparator();
    mainToolBar->addAction(m_startScanAction);
    mainToolBar->addAction(m_stopScanAction);
    mainToolBar->addSeparator();
    mainToolBar->addAction(m_networkScanAction);
    mainToolBar->addAction(m_multiRangeScanAction);
}

void MainWindow::createActions()
{
    m_addDirectoryAction = new QAction(QIcon(":/icons/add_folder.png"), tr("Add Directory"), this);
    m_removeDirectoryAction = new QAction(QIcon(":/icons/remove_folder.png"), tr("Remove Directory"), this);

    m_startScanAction = new QAction(QIcon(":/icons/start_scan.png"), tr("Start Scan"), this);
    m_stopScanAction = new QAction(QIcon(":/icons/stop_scan.png"), tr("Stop Scan"), this);
    m_networkScanAction = new QAction(QIcon(":/icons/network_scan.png"), tr("Network Scan"), this);
    m_multiRangeScanAction = new QAction(QIcon(":/icons/multi_range_scan.png"), tr("Alle Netzwerk-Bereiche scannen"), this);

    m_settingsAction = new QAction(QIcon(":/icons/settings.png"), tr("Settings"), this);
    m_presetManagerAction = new QAction(QIcon(":/icons/presets.png"), tr("Presets"), this);
    m_networkRangeAction = new QAction(QIcon(":/icons/network_range.png"), tr("Network Ranges"), this);

    m_aboutAction = new QAction(QIcon(":/icons/about.png"), tr("About"), this);
    m_documentationAction = new QAction(QIcon(":/icons/help.png"), tr("Documentation"), this);

    m_exitAction = new QAction(QIcon(":/icons/exit.png"), tr("Exit"), this);

    connect(m_addDirectoryAction, &QAction::triggered, this, &MainWindow::addDirectory);
    connect(m_removeDirectoryAction, &QAction::triggered, this, &MainWindow::removeSelectedDirectories);
    connect(m_startScanAction, &QAction::triggered, this, [this]()
            { startDuplicateScan(); });
    connect(m_stopScanAction, &QAction::triggered, this, &MainWindow::stopDuplicateScan);
    connect(m_networkScanAction, &QAction::triggered, this, &MainWindow::startNetworkDiscovery);
    connect(m_multiRangeScanAction, &QAction::triggered, this, &MainWindow::startMultiRangeScan);
    connect(m_settingsAction, &QAction::triggered, this, &MainWindow::showSettingsDialog);
    connect(m_presetManagerAction, &QAction::triggered, this, &MainWindow::showPresetManager);
    connect(m_networkRangeAction, &QAction::triggered, this, &MainWindow::showNetworkRangeSettings);
    connect(m_aboutAction, &QAction::triggered, this, &MainWindow::showAboutDialog);
    connect(m_exitAction, &QAction::triggered, this, &QMainWindow::close);
}

void MainWindow::setupConnections()
{
    // Directory Selection Buttons
    connect(selectDirBtn, &QPushButton::clicked, this, [this]() {
        QFileDialog dialog(this);
        dialog.setFileMode(QFileDialog::Directory);
        dialog.setOption(QFileDialog::ShowDirsOnly);
        dialog.setWindowTitle(tr("📂 Verzeichnisse für Duplikat-Scan auswählen"));
        
        if (dialog.exec() == QDialog::Accepted) {
            // 🛑 CRITICAL FIX: Leere alte Auswahl BEVOR neue Verzeichnisse hinzugefügt werden
            m_selectedDirectories.clear();
            qDebug() << "[MainWindow] 🧹 Alte Verzeichnisse geleert - starte mit neuer lokaler Auswahl";
            
            QStringList selectedPaths = dialog.selectedFiles();
            for (const QString &path : selectedPaths) {
                if (!m_selectedDirectories.contains(path)) {
                    m_selectedDirectories.append(path);
                }
            }
            updateDirectoryTree();
            statusBar()->showMessage(tr("📁 %1 Verzeichnisse ausgewählt").arg(m_selectedDirectories.size()), 3000);
        }
    });
    
    connect(scanSelectedBtn, &QPushButton::clicked, this, [this]() {
        if (m_isScanning) {
            // 🛑 STOP: Scan läuft, stoppe ihn
            stopDuplicateScan();
            scanSelectedBtn->setText(tr("🔍 Ausgewählte scannen"));
            scanSelectedBtn->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
        } else {
            // ▶️ START: Starte neuen Scan
            if (m_selectedDirectories.isEmpty()) {
                QMessageBox::information(this, tr("Keine Verzeichnisse"),
                                       tr("Bitte wählen Sie zuerst Verzeichnisse aus."));
                return;
            }
            startDuplicateScan();
            scanSelectedBtn->setText(tr("⏹️ Scan stoppen"));
            scanSelectedBtn->setStyleSheet("font-weight: bold; background-color: #f44336; color: white;");
        }
    });    // ✅ Directory Management - Summary Context Menu aktiviert statt directoryTree
    // connect(directoryTree, &QTreeWidget::customContextMenuRequested, this, &MainWindow::showDirectoryContextMenu);
    // connect(directoryTree, &QTreeWidget::itemExpanded, this, &MainWindow::onDirectoryItemExpanded);
    
    // Network Management
    connect(networkTree, &QTreeWidget::customContextMenuRequested, this, &MainWindow::showNetworkContextMenu);
    connect(networkTree, &QTreeWidget::itemDoubleClicked, this, &MainWindow::onNetworkServiceDoubleClicked);
    connect(networkTree, &QTreeWidget::itemChanged, this, &MainWindow::onNetworkTreeItemChanged);
    
    // 🌐 Network Range Management
    connect(networkRangeBtn, &QPushButton::clicked, this, &MainWindow::showNetworkRangeSettings);
    
    // Network Scanning
    std::cout << "\n[setupConnections] ================================================\n";
    std::cout << "[setupConnections] 🔗 Verbinde serviceFound Signal...\n";
    std::cout << "[setupConnections] m_networkScanner ist: " << (m_networkScanner ? "VALID ✅" : "NULL ❌") << "\n";
    std::cout.flush();
    
    if (!m_networkScanner) {
        std::cout << "[setupConnections] ❌ KRITISCH: m_networkScanner ist nullptr!\n";
        std::cout.flush();
        return;
    }
    
    bool connectSuccess = connect(m_networkScanner, &NetworkScanner::serviceFound, this, [this](const NetworkService &service) {
        std::cout << "\n[Lambda-serviceFound] 🎯🎯🎯 SIGNAL EMPFANGEN!!!\n";
        std::cout << "[Lambda] IP: " << service.ip.toUtf8().constData() << "\n";
        std::cout << "[Lambda] Port: " << service.port << "\n";
        std::cout << "[Lambda] Service: " << service.service.toUtf8().constData() << "\n";
        std::cout.flush();
        onNetworkServiceFound(service.ip, service.port, service.service);
    });
    
    std::cout << "[setupConnections] connect() Result: " << (connectSuccess ? "✅ SUCCESS" : "❌ FAILED") << "\n";
    std::cout << "[setupConnections] ================================================\n";
    std::cout.flush();
    
    // ✅ Reset network scan flags when scan completes
    connect(m_networkScanner, &NetworkScanner::scanFinished, this, [this]() {
        m_networkScanActive = false;
        m_multiRangeScanActive = false;
        statusBar()->showMessage(tr("✅ Network Discovery abgeschlossen - IPs bleiben sichtbar"), 5000);
    });

    // Duplicate Scanning
    connect(m_scanner, &Scanner::scanProgress, this, &MainWindow::onScanProgress);
    connect(m_scanner, &Scanner::filesCollected, this, &MainWindow::onFilesCollected); // 🔥 NEW: FTP Discovery completion
    connect(m_scanner, &Scanner::ftpProgressUpdate, this, [this](int total, int completed, int pending) {
        if (ftpDirectoryCountLabel) {
            ftpDirectoryCountLabel->setText(QString("📡 FTP Gesamt: %1 Verzeichnisse").arg(total));
            ftpDirectoryCountLabel->repaint();
        }
        if (ftpCompletedLabel) {
            ftpCompletedLabel->setText(QString("✅ FTP Fertig: %1 von %2 Verzeichnissen gescannt").arg(completed).arg(total));
            ftpCompletedLabel->repaint();
        }
    });
    connect(m_scanner, &Scanner::scanCompleted, this, [this](const DuplicateGroups &groups) {
        qDebug() << "[MainWindow] 📡 scanCompleted Signal empfangen mit" << groups.groups.size() << "Gruppen";
        // Persist groups for deletion actions
        m_currentDuplicateGroups = groups;
        
        // ✅ ALWAYS call onScanCompleted() to reset GUI state!
        qDebug() << "[MainWindow] ✅ Calling onScanCompleted() mit" << groups.groups.size() << "Gruppen";
        onScanCompleted(groups);
    }, Qt::QueuedConnection);

    // 🔧 NEU: HashEngine duplicatesFound Signal für vollständige Duplikat-Anzeige
    connect(m_hashEngine, &HashEngine::duplicatesFound, this, [this](const QHash<QString, QStringList> &hashGroups, int totalFiles) {
        qDebug() << "[MainWindow] 🔍 HashEngine duplicatesFound Signal empfangen mit" << hashGroups.size() << "Hash-Gruppen und" << totalFiles << "Dateien";
        
        // Convert HashEngine format to DuplicateGroups format
        DuplicateGroups engineGroups;
        for (auto it = hashGroups.begin(); it != hashGroups.end(); ++it) {
            const QStringList &files = it.value();
            if (files.size() > 1) {  // Only process actual duplicate groups
                DuplicateGroup group;
                QList<FileInfo> fileInfos;
                
                // Convert file paths to FileInfo objects
                for (const QString &filePath : files) {
                    FileInfo fileInfo;
                    fileInfo.filePath = filePath;
                    fileInfo.hash = it.key();
                    
                    QFileInfo info(filePath);
                    fileInfo.size = info.size();
                    fileInfo.lastModified = info.lastModified().toSecsSinceEpoch();
                    fileInfo.isLocal = !filePath.startsWith("ftp://");
                    
                    fileInfos.append(fileInfo);
                }
                
                // Sort by preference: local files first, then by modification time
                std::sort(fileInfos.begin(), fileInfos.end(), [](const FileInfo &a, const FileInfo &b) {
                    if (a.isLocal != b.isLocal) {
                        return a.isLocal > b.isLocal; // Local files first
                    }
                    return a.lastModified < b.lastModified; // Oldest first as original
                });
                
                group.original = fileInfos.takeFirst();
                group.duplicates = fileInfos;
                group.hash = it.key();
                group.size = group.original.size;
                
                engineGroups.groups.append(group);
                engineGroups.duplicateFiles += group.duplicates.size();
                engineGroups.duplicateSize += group.size * group.duplicates.size();
            }
        }
        
        // 🔥 CRITICAL FIX: Setze totalFiles auf gescannte Dateien von HashEngine
        engineGroups.totalFiles = totalFiles; // ✅ totalFiles kommt vom Signal-Parameter
        qDebug() << "[MainWindow] ✅ HashEngine-Ergebnisse: totalFiles =" << engineGroups.totalFiles;
        
        qDebug() << "[MainWindow] 🔍 HashEngine-Gruppen konvertiert:" << engineGroups.groups.size() << "Gruppen mit" << engineGroups.duplicateFiles << "Duplikaten";
        
        // ✅ ALWAYS use HashEngine results (they are the REAL duplicates based on full hash)
        qDebug() << "[MainWindow] ✅ Verwende HashEngine-Ergebnisse (echte Hash-basierte Duplikate)";
        m_currentDuplicateGroups = engineGroups;
        
        // Update GUI with real duplicate results
        qDebug() << "[MainWindow] 🎯 Aktualisiere GUI mit HashEngine-Ergebnissen:" << engineGroups.groups.size() << "Gruppen";
        onScanCompleted(engineGroups);
    }, Qt::QueuedConnection);
    
    // 🚀 ECHTZEIT-STATUS-UPDATES: Zeige Scan-Status in GUI
    connect(m_scanner, &Scanner::scanStatusChanged, this, [this](const QString &status) {
        // Zeige Status in StatusBar UND im actionLabel
        statusBar()->showMessage(status, 3000);
        if (actionLabel) {
            actionLabel->setText(status);
        }
        qDebug() << "[MainWindow] 📊 Status-Update:" << status;
    }, Qt::QueuedConnection);
    
    // 🚀 NEUE DETAILLIERTE PROGRESS-VERBINDUNGEN
    connect(m_scanner, &Scanner::currentFileProcessing, this, &MainWindow::onCurrentFileProcessing);
    connect(m_scanner, &Scanner::processActivityUpdate, this, &MainWindow::onProcessActivityUpdate);
    connect(m_scanner, &Scanner::fileComparisonProgress, this, &MainWindow::onFileComparisonProgress);
    connect(m_scanner, &Scanner::pathProcessingUpdate, this, &MainWindow::onPathProcessingUpdate);
    connect(m_scanner, &Scanner::duplicateDetectionUpdate, this, &MainWindow::onDuplicateDetectionUpdate);
    connect(m_scanner, &Scanner::hardwareUsageUpdate, this, &MainWindow::onHardwareUsageUpdate);

    // ✅ KRITISCH: Signal-Slot für thread-sichere FTP-GUI-Updates
    connect(this, &MainWindow::ftpDirectoriesReady, this, &MainWindow::handleFtpDirectoriesReady, Qt::QueuedConnection);
    
    // 🚀 ECHTZEIT HARDWARE-MONITORING: Update alle 250ms (4x pro Sekunde)
    QTimer *hardwareMonitorTimer = new QTimer(this);
    connect(hardwareMonitorTimer, &QTimer::timeout, this, &MainWindow::updateHardwareMonitoring);
    hardwareMonitorTimer->start(250); // 250ms = 4 FPS für Hardware-Anzeige

    // ✅ HARDWARE STATUS WIDGET INITIALIZATION & CONNECTIONS
    if (!m_hardwareStatusWidget) {
        m_hardwareStatusWidget = new HardwareStatusWidget(this);
        qDebug() << "[setupConnections] ✅ HardwareStatusWidget erstellt";
    }
    
    // Connect Scanner hardware status updates to widget
    connect(m_scanner, QOverload<int, int>::of(&Scanner::cpuStatusUpdated), 
            m_hardwareStatusWidget, &HardwareStatusWidget::updateCpuStatus);
    connect(m_scanner, QOverload<bool, const QString&, int>::of(&Scanner::gpuStatusUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateGpuStatus);
    connect(m_scanner, QOverload<int, int>::of(&Scanner::gpuMemoryUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateGpuMemory);
    connect(m_scanner, QOverload<int>::of(&Scanner::gpuClockUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateGpuClock);
    connect(m_scanner, QOverload<int>::of(&Scanner::gpuTemperatureUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateGpuTemperature);
    connect(m_scanner, QOverload<bool, int>::of(&Scanner::npuStatusUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateNpuStatus);
    connect(m_scanner, QOverload<int, int, const QString&>::of(&Scanner::npuActivityUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateNpuActivity);
    connect(m_scanner, QOverload<int>::of(&Scanner::npuPowerUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateNpuPower);
    connect(m_scanner, QOverload<int>::of(&Scanner::ioStatusUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateIoStatus);
    connect(m_scanner, QOverload<int>::of(&Scanner::memoryStatusUpdated),
            m_hardwareStatusWidget, &HardwareStatusWidget::updateMemoryStatus);
    
    // ✅ LIVE BENCHMARK MONITOR INITIALIZATION & CONNECTIONS
    if (!m_liveBenchmarkMonitor) {
        m_liveBenchmarkMonitor = new LiveBenchmarkMonitor(this);
        qDebug() << "[setupConnections] ✅ LiveBenchmarkMonitor erstellt";
    }
    
    connect(m_scanner, &Scanner::processActivityUpdate, m_liveBenchmarkMonitor, &LiveBenchmarkMonitor::onActivityLogged);
    connect(m_scanner, &Scanner::scanProgress, m_liveBenchmarkMonitor, &LiveBenchmarkMonitor::onScanProgress);
    connect(m_scanner, &Scanner::scanStatusChanged, m_liveBenchmarkMonitor, &LiveBenchmarkMonitor::onStatusChanged);
    
    // 🔐 HASH ENGINE PROGRESS CONNECTION
    if (m_scanner && m_scanner->getHashEngine()) {
        connect(m_scanner->getHashEngine(), &HashEngine::hashProgress, 
                this, &MainWindow::onHashProgress);
        qDebug() << "[setupConnections] ✅ HashEngine hashProgress Signal verbunden";
    }
    
    // ✅ SETTINGS DIALOG CONNECTIONS
    connect(m_settingsAction, &QAction::triggered, this, &MainWindow::showSettingsDialog);
    
    qDebug() << "[setupConnections] ✅ Alle Widget-Verbindungen hergestellt";

}

void MainWindow::onDirectoryDoubleClicked(QTreeWidgetItem *item, int column)
{
    Q_UNUSED(column)
    if (item)
    {
        QString path = item->text(0);
        QMessageBox::information(this, tr("Directory"), tr("Selected: %1").arg(path));
    }
}

void MainWindow::onNetworkServiceDoubleClicked(QTreeWidgetItem *item, int column)
{
    Q_UNUSED(column);
    if (!item) return;

    // 🔧 INTELLIGENTE DATENEXTRAKTION: Adaptiert für neue Metadaten-Struktur
    QString ip = item->data(0, Qt::UserRole).toString();
    int port = item->data(0, Qt::UserRole + 1).toInt();
    QString service = item->data(0, Qt::UserRole + 2).toString();
    
    if (ip.isEmpty() || port == 0) {
        qDebug() << "[MainWindow] ⚠️ Unvollständige Service-Daten - überspringe Doppelklick";
        return;
    }

    qDebug() << "[MainWindow] 🖱️ Network Service Doppelklick:" << ip << port << service;
    
    // ⚡ SOFORTIGES FEEDBACK: Zeige Status BEVOR irgendwas passiert
    statusBar()->showMessage(tr("🔍 Prüfe Verbindungsdaten für %1:%2...").arg(ip).arg(port), 2000);
    QApplication::processEvents(); // Sofortige GUI-Aktualisierung

    // ✅ KRITISCH: Prüfe Auto-Login zuerst
    if (m_presetManager) {
        LoginData existingLogin = m_presetManager->getLogin(ip, port);
        if (existingLogin.autoLogin && !existingLogin.username.isEmpty() && !existingLogin.password.isEmpty()) {
            qDebug() << "[MainWindow] 🚀✨ AUTO-LOGIN erkannt für" << ip << "- Direkte Verbindung ohne Dialog";
            statusBar()->showMessage(tr("🚀 Auto-Login: Verbinde mit %1:%2...").arg(ip).arg(port));
            QApplication::processEvents(); // Update anzeigen
            
            // Direkt verbinden ohne Dialog-Anzeige
            connectAndShowDirectoryTree(ip, port, service, 
                                       existingLogin.username, existingLogin.password);
            return;
        }
    }

    // Fallback: Login-Dialog anzeigen wenn kein Auto-Login
    statusBar()->showMessage(tr("💡 Zeige Login-Dialog für %1:%2").arg(ip).arg(port), 1000);
    showLoginDialog(ip, port, service);
}

void MainWindow::onNetworkServiceFound(const QString &ip, int port, const QString &service)
{
    qDebug() << "[MainWindow] onNetworkServiceFound() aufgerufen:" << ip << port << service;
    addNetworkService(ip, port, service);
}

void MainWindow::showLoginDialog(const QString &ip, int port, const QString &service)
{
    LoginDialog dialog(this);
    dialog.setServiceInfo(ip, port, service);

    // Load existing credentials if available
    if (m_presetManager) {
        dialog.setExistingLogin(m_presetManager->getLogin(ip, port));
    }

    if (dialog.exec() == QDialog::Accepted) {
        LoginData loginData = dialog.getLoginData();
        
        // Save credentials if saveCredentials is enabled
        if (loginData.saveCredentials && m_presetManager) {
            m_presetManager->saveLogin(ip, port, loginData);
            qDebug() << "[MainWindow] 💾 Login gespeichert für" << ip << ":" << port 
                     << "AutoLogin:" << loginData.autoLogin;
        }

        // Connect and show directory tree dialog
        connectAndShowDirectoryTree(ip, port, service, loginData.username, loginData.password);
    }
}

void MainWindow::connectAndShowDirectoryTree(const QString &ip, int port, const QString &service, const QString &username, const QString &password)
{
    qDebug() << "[MainWindow] 🔌 connectAndShowDirectoryTree:" << service << "auf Port" << port;
    
    // 🔍 EXPLICIT DEBUG für Service-Erkennung
    QString serviceLower = service.toLower();
    bool isSSH = serviceLower.contains("ssh");
    bool isSFTP = serviceLower.contains("sftp");
    bool isFTP = serviceLower.contains("ftp") && !serviceLower.contains("sftp");
    
    qDebug() << "[MainWindow] 🔍 Service-Analyse:";
    qDebug() << "  📝 Original Service:" << service;
    qDebug() << "  📝 Lowercase Service:" << serviceLower;
    qDebug() << "  🔐 Contains SSH:" << isSSH;
    qDebug() << "  🔐 Contains SFTP:" << isSFTP;
    qDebug() << "  📡 Contains FTP (pure):" << isFTP;
    
    // ✅ SSH/SFTP-Erkennung MUSS vor FTP-Erkennung stehen!
    if (isSSH || isSFTP) {
        qDebug() << "[MainWindow] 🔐 SSH/SFTP-Protokoll erkannt auf Port" << port;
        
        // ✅ SFTP-Unterstützung: Verwende externe Tools oder zeige Hinweis
        QString message = QString("SSH/SFTP-Verbindung zu %1:%2\n\n"
                                "Benutzer: %3\n"
                                "Protokoll: %4\n\n"
                                "SSH/SFTP wird derzeit über externe Tools unterstützt.\n"
                                "Sie können sich manuell verbinden mit:\n"
                                "sftp %3@%1")
                         .arg(ip).arg(port).arg(username).arg(service);
        
        QMessageBox::information(this, "SSH/SFTP Verbindung", message);
        
        // Markiere Service als "SSH erkannt" im Netzwerk-Tree
        QList<QTreeWidgetItem*> items = networkTree->findItems(ip, Qt::MatchContains | Qt::MatchRecursive, 0);
        if (!items.isEmpty()) {
            QTreeWidgetItem *serviceItem = items.first();
            serviceItem->setText(2, "🔐 SSH erkannt");
            serviceItem->setIcon(0, QIcon("🔐"));
        }
    }
    else if (isFTP) {
        qDebug() << "[MainWindow] 📡 FTP-Protokoll erkannt - verwende FtpClient";
        
        // ⚡ SOFORTIGES FEEDBACK für den Benutzer
        statusBar()->showMessage(tr("📡 Verbinde mit FTP-Server %1:%2...").arg(ip).arg(port));
        QApplication::processEvents(); // Zeige Nachricht sofort
        
        FtpClient *ftp = new FtpClient(this);
        ftp->setCredentials(ip, port, username, password);
        
        // Connect to signals BEFORE connecting to host
        connect(ftp, &FtpClient::connected, this, [this, ftp, ip](){
            qDebug() << "[MainWindow] ✅ FTP connected, starting directory list at root...";
            statusBar()->showMessage(tr("✅ FTP verbunden, lade Verzeichnisse von %1...").arg(ip));
            QApplication::processEvents(); // Update anzeigen
            // Start at server root – no hardcoded paths
            ftp->list("/");
        });
        
        connect(ftp, &FtpClient::listFinished, this, [this, ip, ftp](const QStringList &dirs, bool success){
            qDebug() << "[MainWindow] 📋 FTP listFinished:" << dirs.size() << "directories, success:" << success;
            if (success) {
                statusBar()->showMessage(tr("✅ %1 Verzeichnisse geladen von %2").arg(dirs.size()).arg(ip), 3000);
                emit ftpDirectoriesReady(ip, dirs);
            } else {
                statusBar()->showMessage(tr("❌ FTP-Fehler: Keine Verzeichnisse"), 5000);
                QMessageBox::warning(this, tr("FTP Fehler"), tr("Konnte echte Verzeichnisliste nicht abrufen. Bitte Berechtigungen prüfen oder anderes Startverzeichnis wählen."));
            }
            ftp->deleteLater(); // Clean up FTP client
        });
        
        connect(ftp, &FtpClient::error, this, [this, ip, ftp](const QString &error){
            qDebug() << "[MainWindow] ❌ FTP error:" << error;
            statusBar()->showMessage(tr("❌ FTP-Verbindungsfehler: %1").arg(error), 5000);
            QMessageBox::critical(this, "FTP Verbindungsfehler", 
                                QString("Verbindung zu %1 fehlgeschlagen:\n%2").arg(ip, error));
            ftp->deleteLater(); // Clean up FTP client
        });

        // NOW actually connect to the FTP server
        qDebug() << "[MainWindow] 🚀 Starting FTP connection to" << ip << ":" << port;
        statusBar()->showMessage(tr("🔄 FTP-Verbindung wird aufgebaut..."));
        QApplication::processEvents(); // Zeige "Verbinde..." sofort
        ftp->connectToHost();
    }
    else if (service.toLower().contains("smb") || service.toLower().contains("cifs")) {
        qDebug() << "[MainWindow] 🗂️ SMB/CIFS-Protokoll erkannt auf Port" << port;
        
        QString message = QString("SMB/CIFS-Verbindung zu %1:%2\n\n"
                                "Benutzer: %3\n"
                                "Protokoll: %4\n\n"
                                "SMB/CIFS wird derzeit über System-Mount unterstützt.\n"
                                "Sie können sich manuell verbinden mit:\n"
                                "smbclient //%1/share -U %3")
                         .arg(ip).arg(port).arg(username).arg(service);
        
        QMessageBox::information(this, "SMB/CIFS Verbindung", message);
    }
    else {
        qDebug() << "[MainWindow] ❓ Unbekanntes Protokoll:" << service << "- zeige generischen Hinweis";
        
        QString message = QString("Verbindung zu %1:%2\n\n"
                                "Benutzer: %3\n"
                                "Protokoll: %4\n\n"
                                "Dieses Protokoll wird derzeit nicht direkt unterstützt.\n"
                                "Bitte verwenden Sie externe Tools für die Verbindung.")
                         .arg(ip).arg(port).arg(username).arg(service);
        
        QMessageBox::information(this, "Protokoll nicht unterstützt", message);
    }
}

void MainWindow::handleFtpDirectoriesReady(const QString &ip, const QStringList &directories)
{
    // Ensure this runs on the main GUI thread
    if (QThread::currentThread() != this->thread()) {
        QMetaObject::invokeMethod(this, [this, ip, directories]() {
            handleFtpDirectoriesReady(ip, directories);
        }, Qt::QueuedConnection);
        return;
    }

    qDebug() << "[MainWindow] 📂 FTP-Verzeichnisse empfangen für" << ip << "mit" << directories.size() << "Verzeichnissen";
    
    // Update network tree to show connected status only
    QList<QTreeWidgetItem*> items = networkTree->findItems(ip, Qt::MatchContains | Qt::MatchRecursive, 0);
    if (!items.isEmpty()) {
        QTreeWidgetItem *serviceItem = items.first();
        serviceItem->setText(2, "🟢 Verbunden");
        serviceItem->setIcon(0, QIcon("📡"));
    }

    // ✅ KORREKTE LÖSUNG: SimpleTreeDialog statt NetworkDirectoryDialog verwenden
    qDebug() << "[MainWindow] 🚀 Öffne SimpleTreeDialog mit Verzeichnis-Hierarchie";
    
    SimpleTreeDialog *dialog = new SimpleTreeDialog(QString("%1 (FTP)").arg(ip), this);
    
    // ⚡ CRITICAL FIX: Signal verbinden VOR setDirectories(), da setDirectories() sofort Signale emittiert!
    connect(dialog, &SimpleTreeDialog::directoryExpanded, 
            this, [this, ip, dialog](const QString &path) {
        qDebug() << "[MainWindow] 📡 FTP-LIST-Anfrage für Unterverzeichnisse:" << path;
        requestFtpSubdirectoriesForDialog(ip, path, dialog);
    });
    
    // Jetzt erst Verzeichnisse setzen - triggert automatisch directoryExpanded für Root-Level
    dialog->setDirectories(directories);
    
    if (dialog->exec() == QDialog::Accepted) {
        QStringList selectedDirs = dialog->getSelectedDirectories();
        qDebug() << "[MainWindow] ✅ Benutzer hat" << selectedDirs.size() << "Verzeichnisse ausgewählt";
        qDebug() << "[MainWindow] 🔍 Debug: Ausgewählte Pfade:" << selectedDirs;
        
        // 🛑 CRITICAL FIX: Leere alte Verzeichnisse BEVOR neue hinzugefügt werden
        m_selectedDirectories.clear();
        qDebug() << "[MainWindow] 🧹 Alte Verzeichnisse geleert - starte mit neuer Auswahl";
        
        // Füge ausgewählte FTP-Verzeichnisse hinzu
        int addedCount = 0;
        for (const QString &dir : selectedDirs) {
            qDebug() << "[MainWindow] 🔍 Debug: Verarbeite Pfad:" << dir;
            // FTP-URL korrekt konstruieren - dir ist bereits vollständiger Pfad
            QString ftpUrl;
            if (dir.startsWith("ftp://")) {
                // Bereits vollständige FTP-URL
                ftpUrl = dir;
            } else {
                // Konstruiere FTP-URL aus Pfad
                QString cleanPath = dir;
                qDebug() << "[MainWindow] 🔍 Debug: Original-Pfad:" << dir;
                if (cleanPath.startsWith("/")) cleanPath = cleanPath.mid(1);
                qDebug() << "[MainWindow] 🔍 Debug: Clean-Pfad:" << cleanPath;
                ftpUrl = QString("ftp://%1/%2").arg(ip, cleanPath);
                qDebug() << "[MainWindow] 🔍 Debug: Konstruierte URL:" << ftpUrl;
            }
            
            // Bereinige nur echte doppelte Slashes (nicht ftp://)
            ftpUrl = ftpUrl.replace(QRegularExpression("([^:])//+"), "\\1/");
            
            if (!m_selectedDirectories.contains(ftpUrl)) {
                m_selectedDirectories.append(ftpUrl);
                addedCount++;
                qDebug() << "[MainWindow] ➕ FTP-URL hinzugefügt:" << ftpUrl;
            }
        }
        
        // ✅ SICHERE GUI-AKTUALISIERUNG: Verwende updateDirectorySummary statt updateDirectoryTree
        updateDirectorySummary();
        updateSelectedDirectoriesDisplay();
        statusBar()->showMessage(tr("✅ %1 FTP-Verzeichnisse hinzugefügt").arg(addedCount), 5000);
        
        qDebug() << "[MainWindow] 📁 FTP-Verzeichnisse vom Benutzer ausgewählt:" << addedCount;
    } else {
        qDebug() << "[MainWindow] ❌ Benutzer hat Dialog abgebrochen";
        statusBar()->showMessage("❌ Keine FTP-Verzeichnisse hinzugefügt", 3000);
    }
    
    dialog->deleteLater();
}

void MainWindow::requestFtpSubdirectories(const QString &ip, const QString &path)
{
    qDebug() << "[MainWindow] 🚀 Starte FTP-LIST für Unterverzeichnisse:" << ip << path;
    
    // Hole gespeicherte Login-Daten für diesen Server
    LoginData loginData = m_presetManager->getLogin(ip, 21);
    
    if (!loginData.isValid()) {
        qDebug() << "[MainWindow] ⚠️ Keine Login-Daten für" << ip << "gefunden";
        return;
    }
    
    // Erstelle neuen FTP-Client für Unterverzeichnis-Scan
    FtpClient *subdirClient = new FtpClient(this);
    subdirClient->setCredentials(ip, 21, loginData.username, loginData.password);
    
    // Verbinde das listFinished Signal
    connect(subdirClient, &FtpClient::listFinished, this, 
        [this, ip, path, subdirClient](const QStringList &subdirs, bool success) {
            if (success && !subdirs.isEmpty()) {
                qDebug() << "[MainWindow] ✅ Unterverzeichnisse für" << path << "empfangen:" << subdirs.size();
                
                // Finde den aktiven NetworkDirectoryDialog
                NetworkDirectoryDialog *activeDialog = findChild<NetworkDirectoryDialog*>();
                if (activeDialog) {
                    activeDialog->addSubdirectories(path, subdirs);
                } else {
                    qDebug() << "[MainWindow] ⚠️ Kein aktiver NetworkDirectoryDialog gefunden";
                }
            } else {
                qDebug() << "[MainWindow] ❌ FTP-LIST für Unterverzeichnisse fehlgeschlagen:" << path;
            }
            
            // Cleanup
            subdirClient->deleteLater();
        });
    
    // Starte FTP-Verbindung
    connect(subdirClient, &FtpClient::connected, subdirClient, [subdirClient, path]() {
        qDebug() << "[FtpClient] 🚀 Verbunden - starte LIST für:" << path;
        subdirClient->list(path);
    });
    
    subdirClient->connectToHost();
}

void MainWindow::requestFtpSubdirectoriesForDialog(const QString &ip, const QString &path, NetworkDirectoryDialog *dialog)
{
    qDebug() << "[MainWindow] 🚀 Starte FTP-LIST für Unterverzeichnisse mit Dialog-Referenz:" << ip << path;
    
    // Hole gespeicherte Login-Daten für diesen Server
    LoginData loginData = m_presetManager->getLogin(ip, 21);
    
    if (!loginData.isValid()) {
        qDebug() << "[MainWindow] ⚠️ Keine Login-Daten für" << ip << "gefunden";
        return;
    }
    
    // Erstelle neuen FTP-Client für Unterverzeichnis-Scan
    FtpClient *subdirClient = new FtpClient(this);
    subdirClient->setCredentials(ip, 21, loginData.username, loginData.password);
    
    // Verbinde das listFinished Signal direkt mit dem Dialog
    connect(subdirClient, &FtpClient::listFinished, this, 
        [this, ip, path, dialog, subdirClient](const QStringList &subdirs, bool success) {
            if (success && !subdirs.isEmpty()) {
                qDebug() << "[MainWindow] ✅ Unterverzeichnisse für" << path << "empfangen:" << subdirs.size() << "Einträge";
                
                if (dialog) {
                    dialog->addSubdirectories(path, subdirs);
                    qDebug() << "[MainWindow] 📋 Unterverzeichnisse an Dialog weitergegeben";
                } else {
                    qDebug() << "[MainWindow] ⚠️ Dialog-Referenz ungültig";
                }
            } else {
                qDebug() << "[MainWindow] ❌ FTP-LIST für Unterverzeichnisse fehlgeschlagen:" << path;
            }
            
            // Cleanup
            subdirClient->deleteLater();
        });
    
    // Starte FTP-Verbindung
    connect(subdirClient, &FtpClient::connected, subdirClient, [subdirClient, path]() {
        qDebug() << "[FtpClient] 🚀 Verbunden für Unterverzeichnisse - starte LIST für:" << path;
        subdirClient->list(path);
    });
    
    subdirClient->connectToHost();
}

// ✅ THREAD-SAFE FTP hierarchical tree building on main GUI thread
void MainWindow::buildHierarchicalFtpTree(const QString &ip, const QStringList &directories)
{
    // ❌ CRASH PREVENTION: Diese Funktion ist temporär deaktiviert
    // Die komplexe Tree-Manipulation verursacht Speicherzugriffsfehler
    
    qDebug() << "⚠️ buildHierarchicalFtpTree() DEAKTIVIERT für" << ip 
             << "mit" << directories.size() << "Verzeichnissen";
    qDebug() << "🔧 FTP-Tree-Integration erfordert separaten Dialog für sichere Mehrfachauswahl";
    
    // Temporäre Benachrichtigung ohne GUI-Manipulation
    statusBar()->showMessage(tr("📁 FTP-Verzeichnisbaum für %1 verfügbar (Dialog erforderlich)").arg(ip), 5000);
    
    // ❌ GESAMTE TREE-MANIPULATION DEAKTIVIERT
    return;
    
    // ❌ ALLE WEITEREN TREE-OPERATIONEN DEAKTIVIERT
    /*
    // Root-Element
    QTreeWidgetItem *rootItem = new QTreeWidgetItem();
    rootItem->setText(0, QString("📡 FTP %1").arg(ip));
    [... komplette Tree-Manipulation entfernt ...]
    */
}


void MainWindow::startDuplicateScan()
{
    // ✅ FIX: Stoppe vorherigen Scan statt zu blockieren
    if (m_isScanning) {
        qDebug() << "[MainWindow] ⏸️ Stoppe vorherigen Scan, starte neuen...";
        statusBar()->showMessage(tr("⏸️ Stoppe vorherigen Scan, starte neuen..."), 2000);
        if (m_scanner) {
            m_scanner->stopScan(); // Stoppe aktuellen Scan
        }
        m_isScanning = false; // Reset state
    }
    
    // 🔄 RESET: Hash-Berechnung und FileCollection Flags zurücksetzen
    m_hashCalculationStarted = false;
    m_filesCollectedHandled = false;
    qDebug() << "[MainWindow] 🔄 RESET: Hash- und FileCollection-Flags zurückgesetzt";

    // ✅ KORREKTUR: Verwende m_selectedDirectories statt Checkboxen aus directoryTree
    QStringList selectedDirs = m_selectedDirectories;

    qDebug() << "[MainWindow] 🔍 Starte Duplikat-Scan mit" << selectedDirs.size() << "Verzeichnissen:" << selectedDirs;

    if (selectedDirs.isEmpty()) {
        QMessageBox::information(this, tr("Keine Verzeichnisse"), 
                                tr("Bitte wählen Sie Verzeichnisse zum Scannen aus."));
        return;
    }

    resultsTable->setRowCount(0);
    
    // �️ HASH-SCHUTZ: Hash-Indizes NICHT vor Scan löschen - werden nach Duplikat-Löschung freigegeben!
    // Hash-Daten müssen erhalten bleiben für die Duplikatliste-Anzeige
    // Löschung erfolgt automatisch in onDeletionCompleted() NACH dem Löschen der Duplikate
    if (m_scanner) {
        qDebug() << "[MainWindow] �️ Hash-Indizes bleiben erhalten für aktuelle Duplikatliste";
        // m_scanner->clearAllHashes();  // ❌ DEAKTIVIERT - löscht Hashes für angezeigte Duplikate!
    }
    
    // ✅ ERWEITERTE PROGRESS-INITIALISIERUNG
    progressBar->setValue(0);
    actionLabel->setText(tr("🔍 Starte Duplikat-Scan..."));
    fileCountLabel->setText(tr("Bereite Scan vor..."));
    statusBar()->showMessage(tr("🔍 Duplikat-Scan wird gestartet..."));
    statusBar()->showMessage(tr("🚀 Starte Duplikat-Scan..."));

    // 🧠 SMART AUTO-DETECT: Wähle Hash basierend auf Dateityp
    QString selectedHashAlgo = hashComboBox->currentText();
    QString hashAlgorithm;
    
    if (selectedHashAlgo.startsWith("🧠")) {
        hashAlgorithm = "SMART"; // Auto-Detect aktiviert
        qDebug() << "[MainWindow] 🧠 Smart Auto-Detect aktiviert";
        statusBar()->showMessage(tr("🧠 Smart Auto-Detect: Optimaler Hash + Hardware pro Dateityp"), 3000);
    } else if (selectedHashAlgo.contains("XXHash")) {
        hashAlgorithm = "XXHASH";
    } else if (selectedHashAlgo.contains("MD5")) {
        hashAlgorithm = "MD5";
    } else if (selectedHashAlgo.contains("SHA-1")) {
        hashAlgorithm = "SHA1";
    } else if (selectedHashAlgo.contains("SHA-256")) {
        hashAlgorithm = "SHA256";
    } else if (selectedHashAlgo.contains("SHA-512")) {
        hashAlgorithm = "SHA512";
    } else if (selectedHashAlgo.contains("BLAKE2")) {
        hashAlgorithm = "BLAKE2";
    } else if (selectedHashAlgo.contains("BLAKE3")) {
        hashAlgorithm = "BLAKE3";
    } else if (selectedHashAlgo.contains("SHA3")) {
        hashAlgorithm = "SHA3";
    } else if (selectedHashAlgo.contains("Murmur3")) {
        hashAlgorithm = "MURMUR3";
    } else if (selectedHashAlgo.contains("CityHash")) {
        hashAlgorithm = "CITYHASH";
    } else if (selectedHashAlgo.contains("FarmHash")) {
        hashAlgorithm = "FARMHASH";
    } else if (selectedHashAlgo.contains("HighwayHash")) {
        hashAlgorithm = "HIGHWAY";
    } else if (selectedHashAlgo.contains("MetroHash")) {
        hashAlgorithm = "METROHASH";
    } else if (selectedHashAlgo.contains("SpookyHash")) {
        hashAlgorithm = "SPOOKY";
    } else {
        hashAlgorithm = "BLAKE2"; // Fallback zu modernem schnellen Algo
    }
    
    qDebug() << "[MainWindow] 🔐 Gewählter Hash-Algorithmus:" << hashAlgorithm;
    
    // ✅ FTP-INTEGRATION AKTIVIERT: Alle Pfade werden unterstützt
    QStringList safeDirs = selectedDirs; // Alle Pfade sind jetzt sicher
    
    qDebug() << "[MainWindow] 📁 Scan mit" << safeDirs.size() << "Verzeichnissen (lokal + FTP):" << safeDirs;
    
    // ✅ WICHTIG: FtpClient dem Scanner zur Verfügung stellen für FTP-Pfade
    // ✅ FTP-INTEGRATION AKTIVIERT: Credentials aus INI-Datei laden
    bool hasFtpPaths = false;
    for (const QString &dir : selectedDirs) {
        if (dir.startsWith("ftp://")) {
            hasFtpPaths = true;
            break;
        }
    }
    
    if (hasFtpPaths) {
        qDebug() << "[MainWindow] 🔐 FTP-Pfade erkannt - lade Credentials aus INI-Datei...";
        // Erstelle FtpClient mit den gespeicherten Credentials für diesen Scan
        for (const QString &dir : selectedDirs) {
            if (dir.startsWith("ftp://")) {
                QUrl ftpUrl(dir);
                QString host = ftpUrl.host();
                
                // Hole Login-Daten für diesen Host
                LoginData loginData = m_presetManager->getLogin(host, 21);
                if (loginData.isValid()) {
                    // Konfiguriere den bestehenden FtpClient
                    m_ftpClient->setCredentials(host, 21, loginData.username, loginData.password);
                    qDebug() << "[MainWindow] ✅ FtpClient-Credentials aus INI gesetzt für:" << host << "User:" << loginData.username;
                    break; // Ein FtpClient reicht für alle FTP-Pfade desselben Hosts
                } else {
                    qWarning() << "[MainWindow] ❌ Keine FTP-Credentials gefunden für Host:" << host;
                }
            }
        }
    }
    
    // ✅ Setze Scanning-Flag
    m_isScanning = true;
    m_hashCalculationStarted = false;  // 🔄 Reset hash calculation flag for new scan
    
    // 🔄 WICHTIG: Duplikat-Label zurücksetzen - NICHT "0 Duplikate" während Scan zeigen!
    if (duplicateCountLabel) {
        duplicateCountLabel->setText(tr("🔍 Scan läuft..."));
    }
    
    // 🔄 Tabelle leeren während Scan läuft
    if (resultsTable) {
        resultsTable->setRowCount(0);
    }
    
    qDebug() << "[MainWindow] 🧪 PRE: Scanner::startScan call";
    qDebug() << "[MainWindow] 🚀 Rufe Scanner::startScan auf mit sicheren Pfaden:" << safeDirs << "Hash:" << hashAlgorithm;
    if (!m_scanner) {
        qCritical() << "[MainWindow] ❌ Scanner ist nullptr – Abbruch";
        QMessageBox::critical(this, tr("Fehler"), tr("Scanner-Komponente nicht verfügbar."));
        return;
    }
    m_scanner->startScan(safeDirs, hashAlgorithm, "*");  // Verwende safeDirs statt selectedDirs
    qDebug() << "[MainWindow] ✅ POST: Scanner::startScan returned";
    statusBar()->showMessage(tr("🔍 Scan gestartet mit %1 lokalen Verzeichnissen...").arg(safeDirs.size()));
    m_activityIndicator->setActivity(true);
}

void MainWindow::stopDuplicateScan()
{
    qDebug() << "[MainWindow] 🛑 stopDuplicateScan() aufgerufen - m_isScanning:" << m_isScanning;
    
    if (m_scanner && m_isScanning) {
        qDebug() << "[MainWindow] 🛑 Rufe m_scanner->stopScan() auf";
        m_scanner->stopScan();
        m_isScanning = false;
        statusBar()->showMessage(tr("⏹️ Scan gestoppt!"), 3000);
        m_activityIndicator->setActivity(false);
        
        // Reset GUI
        if (progressBar) progressBar->setValue(0);
        if (actionLabel) actionLabel->setText(tr("Bereit"));
        if (currentFileLabel) currentFileLabel->setText(tr("---"));
        
        // 🛑 CRITICAL FIX: Button zurück auf "Start" setzen
        if (scanSelectedBtn) {
            scanSelectedBtn->setText(tr("🔍 Ausgewählte scannen"));
            scanSelectedBtn->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
        }
        
        qDebug() << "[MainWindow] ✅ Scan gestoppt - GUI zurückgesetzt";
    } else {
        qDebug() << "[MainWindow] ⚠️ Scan kann nicht gestoppt werden - nicht aktiv";
        statusBar()->showMessage(tr("⚠️ Kein aktiver Scan"), 2000);
    }
}

void MainWindow::initializeBackgroundServices()
{
    if (m_networkScanner)
    {
        QTimer::singleShot(2000, this, &MainWindow::startNetworkDiscovery);
    }
}

void MainWindow::loadSettings()
{
    QSettings settings;

    restoreGeometry(settings.value("Window/Geometry").toByteArray());
    restoreState(settings.value("Window/State").toByteArray());

    // Entfernt: Automatisches Laden der gespeicherten Verzeichnisse
    // QStringList dirs = settings.value("Directories/Recent").toStringList();
    // if (!dirs.isEmpty())
    // {
    //     m_selectedDirectories = dirs;
    //     updateDirectoryTree();
    // }

    hashComboBox->setCurrentText(settings.value("Settings/HashAlgorithm", "MD5 (Fast)").toString());
    hardwareComboBox->setCurrentText(settings.value("Settings/HardwareMode", "Auto Detect").toString());
    
    // 🎨 THEME LOADING: Restore saved theme
    QString savedTheme = loadThemeFromSettings();
    applyTheme(savedTheme);
    
    // Set ComboBox to match loaded theme
    QStringList themeNames = {
        "System Default", "Light High Contrast", "Dark Blue", "Dark Green",
        "Dark Purple", "Dark Red/Orange", "Ice Blue", "Forest Green",
        "High Contrast BW", "Sakura Pink"
    };
    int themeIndex = themeNames.indexOf(savedTheme);
    if (themeIndex >= 0) {
        themeComboBox->setCurrentIndex(themeIndex);
    }
}

void MainWindow::saveSettings()
{
    // ✅ CRASH PREVENTION: Sichere Settings-Speicherung
    qDebug() << "[MainWindow] 💾 saveSettings() gestartet...";
    
    try {
        QSettings settings;

        // ✅ Window-Einstellungen sicher speichern
        if (this && !this->isHidden()) {
            settings.setValue("Window/Geometry", saveGeometry());
            settings.setValue("Window/State", saveState());
            qDebug() << "[MainWindow] ✅ Window-Settings gespeichert";
        }

        // ✅ Directory-Liste sicher speichern
        settings.setValue("Directories/Recent", m_selectedDirectories);
        qDebug() << "[MainWindow] ✅ Directory-Settings gespeichert:" << m_selectedDirectories.size();

        // ✅ UI-Settings sicher speichern (mit Null-Checks)
        if (hashComboBox) {
            settings.setValue("Settings/HashAlgorithm", hashComboBox->currentText());
            qDebug() << "[MainWindow] ✅ Hash-Algorithm gespeichert";
        }
        
        if (hardwareComboBox) {
            settings.setValue("Settings/HardwareMode", hardwareComboBox->currentText());
            qDebug() << "[MainWindow] ✅ Hardware-Mode gespeichert";
        }
        
        if (themeComboBox) {
            settings.setValue("Settings/Theme", themeComboBox->currentIndex());
            qDebug() << "[MainWindow] ✅ Theme gespeichert";
        }
        
        qDebug() << "[MainWindow] ✅ saveSettings() erfolgreich abgeschlossen";
        
    } catch (const std::exception& e) {
        qDebug() << "[MainWindow] ❌ Exception in saveSettings:" << e.what();
    } catch (...) {
        qDebug() << "[MainWindow] ❌ Unknown exception in saveSettings";
    }
}

void MainWindow::addDirectory()
{
    // 🌳 VERBESSERTER DIALOG: Mit Unterverzeichnis-Auswahl
    QDialog *dialog = new QDialog(this);
    dialog->setWindowTitle(tr("Verzeichnis mit Unterverzeichnissen auswählen"));
    dialog->resize(700, 500);
    
    QVBoxLayout *layout = new QVBoxLayout(dialog);
    
    // Erklärungstext
    QLabel *infoLabel = new QLabel(tr("✅ Beim Anklicken eines Verzeichnisses werden automatisch alle Unterverzeichnisse mit ausgewählt."), dialog);
    infoLabel->setWordWrap(true);
    layout->addWidget(infoLabel);
    
    // Tree Widget für Verzeichnisstruktur
    QTreeWidget *dirTree = new QTreeWidget(dialog);
    dirTree->setHeaderLabel(tr("Verzeichnisstruktur"));
    dirTree->setSelectionMode(QAbstractItemView::NoSelection); // Keine Standard-Selection, nur Checkboxen
    layout->addWidget(dirTree);
    
    // Start-Verzeichnis auswählen
    QPushButton *selectRootBtn = new QPushButton(tr("📁 Basis-Verzeichnis wählen..."), dialog);
    layout->addWidget(selectRootBtn);
    
    // Buttons
    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, dialog);
    layout->addWidget(buttonBox);
    
    QString selectedRoot;
    
    // Funktion: Alle Unterverzeichnisse rekursiv auswählen
    auto checkAllChildren = [](QTreeWidgetItem *item, Qt::CheckState state) {
        std::function<void(QTreeWidgetItem*, Qt::CheckState)> checkRecursive;
        checkRecursive = [&checkRecursive](QTreeWidgetItem *current, Qt::CheckState newState) {
            current->setCheckState(0, newState);
            for (int i = 0; i < current->childCount(); ++i) {
                checkRecursive(current->child(i), newState);
            }
        };
        checkRecursive(item, state);
    };
    
    // Funktion: Verzeichnisbaum aufbauen
    auto buildTree = [&](const QString &rootPath) {
        dirTree->clear();
        QTreeWidgetItem *rootItem = new QTreeWidgetItem(dirTree);
        rootItem->setText(0, rootPath);
        rootItem->setData(0, Qt::UserRole, rootPath);
        rootItem->setCheckState(0, Qt::Unchecked);
        rootItem->setFlags(rootItem->flags() | Qt::ItemIsUserCheckable);
        
        // Rekursiv Unterverzeichnisse hinzufügen (max 3 Ebenen für Performance)
        std::function<void(QTreeWidgetItem*, const QString&, int)> addSubDirs;
        addSubDirs = [&](QTreeWidgetItem *parent, const QString &path, int depth) {
            if (depth > 3) return; // Max 3 Ebenen
            
            QDir dir(path);
            QStringList subDirs = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name);
            
            for (const QString &subDir : subDirs) {
                QString fullPath = dir.absoluteFilePath(subDir);
                QTreeWidgetItem *item = new QTreeWidgetItem(parent);
                item->setText(0, subDir);
                item->setData(0, Qt::UserRole, fullPath);
                item->setCheckState(0, Qt::Unchecked);
                item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
                
                // Rekursiv weitere Unterverzeichnisse
                addSubDirs(item, fullPath, depth + 1);
            }
        };
        
        addSubDirs(rootItem, rootPath, 1);
        dirTree->expandAll();
    };
    
    // Basis-Verzeichnis auswählen
    connect(selectRootBtn, &QPushButton::clicked, [&]() {
        QString dir = QFileDialog::getExistingDirectory(
            dialog, 
            tr("Basis-Verzeichnis auswählen"),
            QStandardPaths::writableLocation(QStandardPaths::HomeLocation),
            QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks
        );
        
        if (!dir.isEmpty()) {
            selectedRoot = dir;
            buildTree(dir);
        }
    });
    
    // ✅ AUTO-SELECT CHILDREN: Wenn Item angeklickt, alle Kinder auch anklicken
    connect(dirTree, &QTreeWidget::itemChanged, [&](QTreeWidgetItem *item, int column) {
        if (column == 0) {
            Qt::CheckState state = item->checkState(0);
            checkAllChildren(item, state);
        }
    });
    
    connect(buttonBox, &QDialogButtonBox::accepted, dialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, dialog, &QDialog::reject);
    
    if (dialog->exec() == QDialog::Accepted && !selectedRoot.isEmpty()) {
        // Sammle alle ausgewählten Verzeichnisse
        QStringList selectedDirs;
        
        std::function<void(QTreeWidgetItem*)> collectChecked;
        collectChecked = [&](QTreeWidgetItem *item) {
            if (item->checkState(0) == Qt::Checked) {
                QString path = item->data(0, Qt::UserRole).toString();
                if (!path.isEmpty() && !selectedDirs.contains(path)) {
                    selectedDirs.append(path);
                }
            }
            for (int i = 0; i < item->childCount(); ++i) {
                collectChecked(item->child(i));
            }
        };
        
        for (int i = 0; i < dirTree->topLevelItemCount(); ++i) {
            collectChecked(dirTree->topLevelItem(i));
        }
        
        // Füge ausgewählte Verzeichnisse hinzu
        int addedCount = 0;
        for (const QString &dir : selectedDirs) {
            if (!m_selectedDirectories.contains(dir)) {
                m_selectedDirectories.append(dir);
                addedCount++;
            }
        }
        
        if (addedCount > 0) {
            qDebug() << "[MainWindow] �" << addedCount << "Verzeichnisse hinzugefügt (inkl. Unterverzeichnisse)";
            updateDirectorySummary();
            saveSettings();
            statusBar()->showMessage(tr("📁 %1 neue Verzeichnisse hinzugefügt (gesamt: %2)").arg(addedCount).arg(m_selectedDirectories.size()), 5000);
        } else {
            statusBar()->showMessage(tr("⚠️ Keine neuen Verzeichnisse ausgewählt"), 3000);
        }
    }
    
    delete dialog;
}

void MainWindow::updateDirectoryTree()
{
    qDebug() << "[MainWindow] 📊 updateDirectoryTree: Zeige" << m_selectedDirectories.size() << "Verzeichnisse";
    
    // ✅ NEUES DESIGN: Verwende directorySummaryLabel statt directoryTree
    QLabel *directorySummaryLabel = findChild<QLabel*>("directorySummaryLabel");
    if (!directorySummaryLabel) {
        qWarning() << "[MainWindow] ⚠️ directorySummaryLabel nicht gefunden - überspringe Update";
        return;
    }
    
    // ✅ Aktualisiere Summary Label
    if (m_selectedDirectories.isEmpty()) {
        directorySummaryLabel->setText(tr("📁 Keine Verzeichnisse ausgewählt"));
    } else {
        QString summaryText = tr("📁 %1 Verzeichnisse ausgewählt:\n").arg(m_selectedDirectories.size());
        for (int i = 0; i < m_selectedDirectories.size() && i < 8; ++i) {
            summaryText += QString("• %1\n").arg(m_selectedDirectories[i]);
        }
        if (m_selectedDirectories.size() > 8) {
            summaryText += QString("... und %1 weitere").arg(m_selectedDirectories.size() - 8);
        }
        directorySummaryLabel->setText(summaryText);
    }
    
    // ✅ SICHERES Status-Update
    if (statusBar()) {
        statusBar()->showMessage(tr("📁 %1 Verzeichnisse aktiv").arg(m_selectedDirectories.size()), 3000);
    }
}

void MainWindow::updateDirectorySummary()
{
    // ✅ Aktualisiere Summary-Label mit ausgewählten Verzeichnissen
    QLabel *summaryLabel = findChild<QLabel*>("directorySummaryLabel");
    if (!summaryLabel) {
        qDebug() << "[MainWindow] ⚠️ directorySummaryLabel nicht gefunden!";
        return;
    }
    
    QString summaryText;
    
    if (m_selectedDirectories.isEmpty()) {
        summaryText = tr("📁 Keine Verzeichnisse ausgewählt\n\n"
                        "Klicken Sie auf '➕ Verzeichnis hinzufügen', um Ordner für den "
                        "Duplikat-Scan auszuwählen.");
    } else {
        summaryText = tr("📁 %1 Verzeichnisse ausgewählt:\n\n").arg(m_selectedDirectories.size());
        
        for (int i = 0; i < m_selectedDirectories.size() && i < 10; ++i) {
            QString dir = m_selectedDirectories.at(i);
            // Kürze sehr lange Pfade
            if (dir.length() > 50) {
                dir = "..." + dir.right(47);
            }
            summaryText += tr("• %1\n").arg(dir);
        }
        
        if (m_selectedDirectories.size() > 10) {
            summaryText += tr("• ... und %1 weitere Verzeichnisse\n").arg(m_selectedDirectories.size() - 10);
        }
        
        summaryText += tr("\n🔍 Klicken Sie auf 'Duplikate suchen', um den Scan zu starten.");
    }
    
    summaryLabel->setText(summaryText);
    
    qDebug() << "[MainWindow] ✅ Directory Summary aktualisiert:" << m_selectedDirectories.size() << "Verzeichnisse";
}

void MainWindow::updateSelectedDirectoriesDisplay()
{
    // ✅ SICHERE GUI-AKTUALISIERUNG ohne Tree-Manipulation
    qDebug() << "[MainWindow] 🔄 Aktualisiere Selected Directories Display...";
    
    // Update directory summary
    updateDirectorySummary();
    
    // Update network tree to show selected directories (if it exists and is safe)
    QTreeWidget *networkTree = findChild<QTreeWidget*>("networkTree");
    if (networkTree) {
        // Markiere ausgewählte FTP-Pfade visuell (ohne Crash-Risk)
        for (int i = 0; i < networkTree->topLevelItemCount(); ++i) {
            QTreeWidgetItem *item = networkTree->topLevelItem(i);
            updateItemSelectionState(item);
        }
    }
    
    // Update status
    if (!m_selectedDirectories.isEmpty()) {
        statusBar()->showMessage(tr("📁 %1 Verzeichnisse ausgewählt (bereit für Duplikat-Scan)")
                               .arg(m_selectedDirectories.size()), 2000);
    }
    
    qDebug() << "[MainWindow] ✅ Selected Directories Display aktualisiert:" << m_selectedDirectories.size() << "Einträge";
}

void MainWindow::updateItemSelectionState(QTreeWidgetItem *item)
{
    if (!item) return;
    
    // Prüfe, ob dieser Pfad in den ausgewählten Verzeichnissen ist
    QString itemPath = item->data(0, Qt::UserRole).toString();
    bool isSelected = false;
    
    for (const QString &selectedDir : m_selectedDirectories) {
        if (selectedDir.contains(itemPath) || itemPath.contains(selectedDir)) {
            isSelected = true;
            break;
        }
    }
    
    // Visuelles Feedback: Ausgewählte Elemente hervorheben
    if (isSelected) {
        QFont font = item->font(0);
        font.setBold(true);
        item->setFont(0, font);
        item->setBackground(0, QColor(144, 238, 144, 100)); // Light green background
        item->setIcon(0, QIcon(":/assets/icons/folder-selected.svg"));
    }
    
    // Rekursiv für Kinder
    for (int i = 0; i < item->childCount(); ++i) {
        updateItemSelectionState(item->child(i));
    }
}

void MainWindow::removeSelectedDirectories()
{
    // ✅ Dialog-basierte Verzeichnis-Entfernung
    if (m_selectedDirectories.isEmpty()) {
        QMessageBox::information(this, tr("Keine Verzeichnisse"), 
                               tr("Es sind keine Verzeichnisse zum Entfernen ausgewählt."));
        return;
    }
    
    // Zeige aktuell ausgewählte Verzeichnisse zum Entfernen
    DirectorySelectorDialog dialog(this);
    dialog.setWindowTitle(tr("🗑️ Verzeichnisse entfernen"));
    dialog.setSelectedDirectories(m_selectedDirectories);
    
    if (dialog.exec() == QDialog::Accepted) {
        QStringList remainingDirs = dialog.getSelectedDirectories();
        m_selectedDirectories = remainingDirs;
        updateDirectorySummary();
        saveSettings();
        
        statusBar()->showMessage(tr("📁 Verzeichnisse aktualisiert: %1 verbleibend").arg(remainingDirs.size()), 3000);
    }
}

void MainWindow::showDirectoryContextMenu(const QPoint &pos)
{
    // ✅ NEUES DESIGN: Context Menu für directorySummaryLabel
    QLabel *directorySummaryLabel = findChild<QLabel*>("directorySummaryLabel");
    if (!directorySummaryLabel) {
        qWarning() << "[MainWindow] ⚠️ directorySummaryLabel nicht gefunden";
        return;
    }

    QMenu contextMenu(this);

    // ✅ Deutsche Labels und Icons für bessere UX
    QAction *scanAction = contextMenu.addAction(tr("🔍 Alle Verzeichnisse scannen"));
    QAction *clearAction = contextMenu.addAction(tr("🗑️ Alle Pfade entfernen"));
    contextMenu.addSeparator();
    QAction *addAction = contextMenu.addAction(tr("➕ Verzeichnisse hinzufügen"));

    QAction *selectedAction = contextMenu.exec(directorySummaryLabel->mapToGlobal(pos));

    if (selectedAction == scanAction)
    {
        if (!m_selectedDirectories.isEmpty()) {
            startDuplicateScan();
        }
    }
    else if (selectedAction == clearAction)
    {
        m_selectedDirectories.clear();
        updateDirectoryTree();
    }
    else if (selectedAction == addAction)
    {
        addDirectory();
    }
}

// ✅ Context Menu für Directory Summary Label mit Pfad-Entfernung
void MainWindow::showDirectorySummaryContextMenu(const QPoint &pos)
{
    if (m_selectedDirectories.isEmpty()) {
        return; // Kein Menu, wenn keine Verzeichnisse ausgewählt
    }

    QMenu contextMenu(this);
    
    // ✅ Liste aller ausgewählten Verzeichnisse zum Entfernen
    contextMenu.addSection("🗑️ Pfad entfernen:");
    
    for (int i = 0; i < m_selectedDirectories.size(); ++i) {
        QString dirPath = m_selectedDirectories.at(i);
        
        // Kürze sehr lange Pfade für das Menu
        QString displayPath = dirPath;
        if (displayPath.length() > 50) {
            displayPath = "..." + displayPath.right(47);
        }
        
        QAction *removeAction = contextMenu.addAction(QString("🗑️ %1").arg(displayPath));
        removeAction->setData(i); // Index speichern für Entfernung
    }
    
    contextMenu.addSeparator();
    QAction *clearAllAction = contextMenu.addAction("🧹 Alle Pfade entfernen");
    
    // Context Menu anzeigen
    QAction *selectedAction = contextMenu.exec(mapToGlobal(pos));
    
    if (selectedAction == clearAllAction) {
        // Alle Pfade entfernen
        m_selectedDirectories.clear();
        updateDirectorySummary();
        statusBar()->showMessage("🧹 Alle Pfade entfernt", 2000);
        qDebug() << "[MainWindow] 🧹 Alle Verzeichnisse entfernt";
    }
    else if (selectedAction && selectedAction->data().isValid()) {
        // Einzelnen Pfad entfernen
        int index = selectedAction->data().toInt();
        if (index >= 0 && index < m_selectedDirectories.size()) {
            QString removedPath = m_selectedDirectories.takeAt(index);
            updateDirectorySummary();
            statusBar()->showMessage(QString("🗑️ Pfad entfernt: %1").arg(QFileInfo(removedPath).baseName()), 3000);
            qDebug() << "[MainWindow] 🗑️ Pfad entfernt:" << removedPath;
        }
    }
}

void MainWindow::showNetworkContextMenu(const QPoint &pos)
{
    QTreeWidgetItem *item = networkTree->itemAt(pos);
    if (!item)
        return;

    QMenu contextMenu(this);

    // Different actions based on item type
    if (item->parent()) {
        // This is a directory item under an FTP service
        QAction *addToScannerAction = contextMenu.addAction(tr("➕ Zu Scanner hinzufügen"));
        QAction *removeFromScannerAction = contextMenu.addAction(tr("➖ Aus Scanner entfernen"));
        contextMenu.addSeparator();
        QAction *scanDirectlyAction = contextMenu.addAction(tr("🚀 Sofort scannen"));
        
        QAction *selectedAction = contextMenu.exec(networkTree->mapToGlobal(pos));
        
        if (selectedAction == addToScannerAction) {
            // Add FTP directory to scanner list
            QString ftpPath = item->data(0, Qt::UserRole).toString();
            if (!ftpPath.isEmpty()) {
                addFtpDirectoryToScanner(item);
            }
        } else if (selectedAction == scanDirectlyAction) {
            // Start scan immediately with this FTP directory
            addFtpDirectoryToScanner(item);
            startDuplicateScan();
        }
    } else {
        // This is a service item (FTP server)
        // ✅ AUTO-BROWSE aktiviert - manuelle Verbindung nur für Refresh
        QAction *refreshAction = contextMenu.addAction(tr("🔄 Aktualisieren"));
        
        QAction *selectedAction = contextMenu.exec(networkTree->mapToGlobal(pos));
        
        if (selectedAction == refreshAction) {
            // Re-connect and refresh (works for both initial and re-connection)
            onNetworkServiceDoubleClicked(item, 0);
        }
    }
}

void MainWindow::addFtpDirectoryToScanner(QTreeWidgetItem *ftpDirItem)
{
    if (!ftpDirItem) return;
    
    QString ftpPath = ftpDirItem->data(0, Qt::UserRole).toString();
    if (ftpPath.isEmpty()) return;
    
    // Get the FTP server info from parent
    QTreeWidgetItem *parentItem = ftpDirItem->parent();
    if (!parentItem) return;
    
    // Extract IP and port from parent item
    QString serverInfo = parentItem->text(0);
    QString ip = serverInfo.split(':').first();
    
    // ✅ CRITICAL FIX: Ensure ftpPath starts with /
    if (!ftpPath.startsWith('/')) {
        ftpPath = "/" + ftpPath;
    }
    
    // Create a special FTP path identifier for the scanner
    QString scannerPath = QString("ftp://%1%2").arg(ip, ftpPath);
    
    if (!m_selectedDirectories.contains(scannerPath)) {
        m_selectedDirectories.append(scannerPath);
        // Neue GUI: aktualisiere Summary statt directoryTree zu verwenden
        updateDirectorySummary();
        qDebug() << "[MainWindow] ➕ FTP-Verzeichnis zum Scanner hinzugefügt:" << scannerPath;
        statusBar()->showMessage(tr("FTP-Verzeichnis %1 zum Scanner hinzugefügt").arg(ftpPath), 3000);
    } else {
        statusBar()->showMessage(tr("FTP-Verzeichnis %1 bereits im Scanner").arg(ftpPath), 3000);
    }
}

void MainWindow::onNetworkTreeItemChanged(QTreeWidgetItem *item, int column)
{
    if (!item || column != 0) return;  // Nur Spalte 0 (Checkbox-Spalte)
    
    // 🔒 Verhindere Rekursion während wir Kinder/Eltern aktualisieren
    static bool isUpdating = false;
    if (isUpdating) return;
    isUpdating = true;
    
    Qt::CheckState currentState = item->checkState(0);
    qDebug() << "[MainWindow] 🔘 Checkbox geändert:" << item->text(0) << "→" << (currentState == Qt::Checked ? "CHECKED" : "UNCHECKED");
    
    // 🌳 REKURSIVE CHILD-UPDATE: Wenn Parent gechecked/unchecked → ALLE Unterverzeichnisse gleich setzen
    std::function<void(QTreeWidgetItem*, Qt::CheckState)> updateChildrenRecursive;
    updateChildrenRecursive = [&](QTreeWidgetItem *parentItem, Qt::CheckState state) {
        for (int i = 0; i < parentItem->childCount(); ++i) {
            QTreeWidgetItem *child = parentItem->child(i);
            if (child->flags() & Qt::ItemIsUserCheckable) {
                child->setCheckState(0, state);
                qDebug() << "[MainWindow]   ↳ Unterverzeichnis aktualisiert:" << child->text(0) << "→" << (state == Qt::Checked ? "CHECKED" : "UNCHECKED");
                
                // 🔄 REKURSIV: Update auch die Kinder dieses Kindes
                if (child->childCount() > 0) {
                    updateChildrenRecursive(child, state);
                }
            }
        }
    };
    
    // Starte rekursives Update aller Unterverzeichnisse
    if (item->childCount() > 0) {
        updateChildrenRecursive(item, currentState);
    }
    
    // 🔼 PARENT-UPDATE: Wenn alle Geschwister checked → Parent checked, wenn keiner → Parent unchecked
    QTreeWidgetItem *parent = item->parent();
    if (parent && (parent->flags() & Qt::ItemIsUserCheckable)) {
        int checkedCount = 0;
        int totalChildren = parent->childCount();
        
        for (int i = 0; i < totalChildren; ++i) {
            if (parent->child(i)->checkState(0) == Qt::Checked) {
                checkedCount++;
            }
        }
        
        if (checkedCount == totalChildren) {
            parent->setCheckState(0, Qt::Checked);
            qDebug() << "[MainWindow]   ↑ Parent CHECKED:" << parent->text(0);
        } else if (checkedCount == 0) {
            parent->setCheckState(0, Qt::Unchecked);
            qDebug() << "[MainWindow]   ↑ Parent UNCHECKED:" << parent->text(0);
        } else {
            parent->setCheckState(0, Qt::PartiallyChecked);
            qDebug() << "[MainWindow]   ↑ Parent PARTIALLY:" << parent->text(0) << "(" << checkedCount << "/" << totalChildren << ")";
        }
    }
    
    // 📊 DATEI-ANZAHL UPDATE: Berechne Anzahl der ausgewählten Dateien
    updateNetworkTreeFileCounts();
    
    // ✅ Scanner-Liste aktualisieren
    collectSelectedNetworkDirectories();
    
    isUpdating = false;
}

void MainWindow::updateNetworkTreeFileCounts()
{
    // TODO: Implementiere Datei-Anzahl Berechnung für FTP-Verzeichnisse
    // Dies würde FTP LIST -R Kommandos erfordern für echte Counts
    qDebug() << "[MainWindow] 📊 updateNetworkTreeFileCounts() - TODO: FTP file counts";
}

void MainWindow::collectSelectedNetworkDirectories()
{
    qDebug() << "[MainWindow] 📂 collectSelectedNetworkDirectories() gestartet";
    qDebug() << "[MainWindow] 🔍 networkTree topLevelItemCount:" << (networkTree ? networkTree->topLevelItemCount() : -1);
    
    // Lösche alte Auswahl (nur FTP-Pfade)
    m_selectedDirectories.erase(
        std::remove_if(m_selectedDirectories.begin(), m_selectedDirectories.end(),
            [](const QString &path) { return path.startsWith("ftp://"); }),
        m_selectedDirectories.end()
    );
    
    // 🔍 Durchsuche Network Tree und sammle alle CHECKED Items
    QTreeWidgetItemIterator it(networkTree, QTreeWidgetItemIterator::Checked);
    int addedCount = 0;
    int totalChecked = 0;
    
    // Zähle erstmal ALLE gecheckte Items
    QTreeWidgetItemIterator countIt(networkTree, QTreeWidgetItemIterator::Checked);
    while (*countIt) {
        totalChecked++;
        qDebug() << "[MainWindow] 🔍 Gecheckt:" << (*countIt)->text(0) 
                 << "Parent:" << ((*countIt)->parent() ? (*countIt)->parent()->text(0) : "NONE")
                 << "UserRole:" << (*countIt)->data(0, Qt::UserRole).toString();
        ++countIt;
    }
    qDebug() << "[MainWindow] 📊 Total gecheckte Items:" << totalChecked;
    
    while (*it) {
        QTreeWidgetItem *item = *it;
        
        // Nur FTP-Verzeichnisse (haben Parent und UserRole-Daten)
        if (item->parent() && !item->data(0, Qt::UserRole).toString().isEmpty()) {
            QString ftpPath = item->data(0, Qt::UserRole).toString();
            QTreeWidgetItem *parentItem = item->parent();
            QString serverInfo = parentItem->text(0);
            QString ip = serverInfo.split(':').first();
            
            if (!ftpPath.startsWith('/')) {
                ftpPath = "/" + ftpPath;
            }
            
            QString scannerPath = QString("ftp://%1%2").arg(ip, ftpPath);
            
            if (!m_selectedDirectories.contains(scannerPath)) {
                m_selectedDirectories.append(scannerPath);
                addedCount++;
                qDebug() << "[MainWindow]   ✅ Hinzugefügt:" << scannerPath;
            }
        }
        
        ++it;
    }
    
    qDebug() << "[MainWindow] 📂 Gesamt ausgewählte FTP-Verzeichnisse:" << addedCount;
    
    // GUI aktualisieren
    updateDirectorySummary();
    updateSelectedDirectoriesDisplay();
    
    if (addedCount > 0) {
        statusBar()->showMessage(tr("✅ %1 FTP-Verzeichnisse ausgewählt").arg(addedCount), 3000);
    }
}

void MainWindow::addNetworkService(const QString &ip, int port, const QString &service)
{
    qDebug() << "[MainWindow] 🔍 addNetworkService() GESTARTET - ip:" << ip << "port:" << port << "service:" << service;
    qDebug() << "[MainWindow] 🔍 networkTree ist:" << (networkTree ? "VALID" : "INVALID");
    qDebug() << "[MainWindow] 🔍 networkTree topLevelItemCount:" << (networkTree ? networkTree->topLevelItemCount() : -1);
    
    if (!networkTree) {
        qDebug() << "[MainWindow] ❌ FEHLER: networkTree ist null!";
        return;
    }
    // 🛡️ DUPLIKAT-SCHUTZ: Prüfe ob Service bereits existiert
    QString serviceKey = QString("%1:%2").arg(ip).arg(port);
    
    // Durchsuche alle existierenden Services
    QTreeWidgetItemIterator it(networkTree);
    while (*it) {
        QString existingIp = (*it)->data(0, Qt::UserRole).toString();
        int existingPort = (*it)->data(0, Qt::UserRole + 1).toInt();
        
        if (existingIp == ip && existingPort == port) {
            qDebug() << "[MainWindow] ⚠️ Service bereits vorhanden, überspringe:" << serviceKey;
            return; // Service existiert bereits
        }
        ++it;
    }
    
    qDebug() << "[MainWindow] 📡 Network Service hinzugefügt:" << ip << port << service;
    
    // 🧠 INTELLIGENTE SERVICE-KATEGORISIERUNG
    QString category = categorizeIntelligentService(service, port);
    QString priority = calculateServicePriority(service, port, ip);
    QString icon = getServiceIcon(service, port);
    QString authStatus = getAuthenticationStatus(ip, port);
    
    // 🏗️ INTELLIGENTE HIERARCHIE-ERSTELLUNG
    QTreeWidgetItem *categoryItem = findOrCreateCategory(category);
    QTreeWidgetItem *serverItem = findOrCreateServer(categoryItem, ip);
    
    // 🎯 SERVICE-ITEM MIT ERWEITERTEN METADATEN
    QTreeWidgetItem *serviceItem = new QTreeWidgetItem(serverItem);
    serviceItem->setText(0, QString("%1 %2:%3").arg(icon, ip).arg(port));
    serviceItem->setText(1, service);
    serviceItem->setText(2, authStatus);
    serviceItem->setText(3, "🟢 Aktiv");
    serviceItem->setText(4, priority);
    
    // 🏷️ METADATEN FÜR INTELLIGENTE SORTIERUNG
    serviceItem->setData(0, Qt::UserRole, ip);
    serviceItem->setData(0, Qt::UserRole + 1, port);
    serviceItem->setData(0, Qt::UserRole + 2, service);
    serviceItem->setData(0, Qt::UserRole + 3, getPriorityScore(service, port));
    serviceItem->setData(0, Qt::UserRole + 4, QDateTime::currentDateTime());
    
    // 🎨 DYNAMISCHE STYLING BASIEREND AUF SERVICE-TYP
    applyIntelligentServiceStyling(serviceItem, service, port);
    
    // 📊 STATISTICS UPDATE
    updateNetworkStatistics();
    
    // 📂 AUTO-EXPANSION FÜR HOHE PRIORITÄT & FTP-SERVICES
    if (getPriorityScore(service, port) >= 8) {
        categoryItem->setExpanded(true);
        serverItem->setExpanded(true);
    }
    
    // 🌳 AUTO-EXPANSION für FTP-Services (nur Tree erweitern, keine Verbindung)
    if (port == 21 || service.toLower().contains("ftp")) {
        qDebug() << "[MainWindow] 🌳 FTP Service erkannt - erweitere Tree-Struktur automatisch";
        categoryItem->setExpanded(true);
        serverItem->setExpanded(true);
        serviceItem->setExpanded(true); // FTP-Item auch aufklappen
    }
    
    // 🔄 SOFORTIGE GUI-AKTUALISIERUNG ERZWINGEN
    networkTree->update();
    networkTree->repaint();
    // REMOVED: QApplication::processEvents(); // Sofortige Verarbeitung der GUI-Events
    
    qDebug() << "[MainWindow] ✅ GUI-Update erzwungen für Service:" << ip << port << service;
}

void MainWindow::startNetworkDiscovery()
{
    // ✅ FIX: NIEMALS clear() aufrufen - nur neue Services hinzufügen
    // networkTree->clear();  // ❌ DEAKTIVIERT - löscht gefundene IPs
    
    statusBar()->showMessage(tr("🚀 Starting 30-Chunk Network Discovery..."));

    if (m_networkScanner)
    {
        // Always perform multi-range scan to include all preset ranges
        QList<NetworkRange> ranges = m_networkScanner->getAvailableNetworkRanges();
        int customRangeCount = 0;
        int autoRangeCount = 0;
        
        for (const NetworkRange &range : ranges) {
            if (!range.isAutoDetected) {
                customRangeCount++;
                std::cout << "[MainWindow] � Custom Preset Range: " << range.name.toUtf8().constData() 
                          << " (" << range.cidr.toUtf8().constData() << ")" << std::endl;
            } else {
                autoRangeCount++;
            }
        }
        
        // Always use Multi-Range-Scan to ensure all preset ranges are scanned
        std::cout << "[MainWindow] 🌐 Auto-Scanning ALL ranges: " << customRangeCount 
                  << " Custom Presets + " << autoRangeCount << " Auto-Detected" << std::endl;
        m_networkScanner->scanAllAvailableRanges();
    }
}

void MainWindow::startMultiRangeScan()
{
    // ✅ FIX: NIEMALS clear() aufrufen - nur neue Services hinzufügen
    // networkTree->clear();  // ❌ DEAKTIVIERT - löscht gefundene IPs
    
    statusBar()->showMessage(tr("🌐 Starting Multi-Range Network Scan..."));

    if (m_networkScanner)
    {
        m_networkScanner->scanAllAvailableRanges();
    }
}

void MainWindow::onNetworkRangesLoaded(int customRangeCount)
{
    std::cout << "[MainWindow] 🌐 Network ranges loaded - " << customRangeCount 
              << " custom ranges available" << std::endl;
    
    // Trigger multi-range scan if custom ranges are available
    if (customRangeCount > 0) {
        std::cout << "[MainWindow] 🚀 Starting Multi-Range-Scan for " 
                  << customRangeCount << " custom ranges..." << std::endl;
        
        // Wait a moment for everything to settle, then start scan
        QTimer::singleShot(1000, this, &MainWindow::startMultiRangeScan);
    }
}

void MainWindow::checkAndStartMultiRangeScan()
{
    std::cout << "[MainWindow] 🔍 checkAndStartMultiRangeScan() called..." << std::endl;
    
    if (!m_networkScanner) {
        std::cout << "[MainWindow] ⚠️ NetworkScanner not available for multi-range check" << std::endl;
        return;
    }
    
    // Check if custom ranges are available
    QList<NetworkRange> ranges = m_networkScanner->getAvailableNetworkRanges();
    int customRangeCount = 0;
    
    std::cout << "[MainWindow] 🔍 Checking " << ranges.size() << " available network ranges..." << std::endl;
    
    for (const NetworkRange &range : ranges) {
        std::cout << "[MainWindow] 📍 Range: " << range.name.toUtf8().constData() 
                  << " (" << range.cidr.toUtf8().constData() << ") Auto: " 
                  << (range.isAutoDetected ? "Yes" : "No") << std::endl;
        
        if (!range.isAutoDetected) {
            customRangeCount++;
        }
    }
    
    if (customRangeCount > 0) {
        std::cout << "[MainWindow] 🌐 " << customRangeCount 
                  << " Custom Ranges detected - starting Multi-Range-Scan..." << std::endl;
        
        // Wait a bit for the first scan to complete, then start multi-range
        QTimer::singleShot(2000, this, &MainWindow::startMultiRangeScan);
    } else {
        std::cout << "[MainWindow] ℹ️ No custom ranges configured - using single range scan only" << std::endl;
    }
}

void MainWindow::onScanProgress(int percentage, int current, int total)
{
    qDebug() << "[MainWindow] 📊 onScanProgress aufgerufen:" << percentage << "% (" << current << "/" << total << ")";
    std::cout << "[MainWindow] 📊 Progress GUI-Update: " << percentage << "% (" << current << "/" << total << ")" << std::endl;
    
    // 🛡️ CRITICAL NULL-CHECKS: Verhindere GUI-Crashes
    if (!progressBar) {
        qWarning() << "[MainWindow] ❌ progressBar ist NULL!";
        std::cout << "[MainWindow] ❌❌❌ progressBar ist NULL!" << std::endl;
        return;
    }
    
    if (!actionLabel) {
        qWarning() << "[MainWindow] ❌ actionLabel ist NULL!";
        std::cout << "[MainWindow] ❌❌❌ actionLabel ist NULL!" << std::endl;
        return;
    }
    
    if (!fileCountLabel) {
        qWarning() << "[MainWindow] ❌ fileCountLabel ist NULL!";
        std::cout << "[MainWindow] ❌❌❌ fileCountLabel ist NULL!" << std::endl;
        return;
    }
    
    if (total > 0) {
        // 🚀 ECHTZEIT PROGRESS-ANZEIGE: Sofortige Updates ohne Verzögerung
        progressBar->setMaximum(100); // Immer 0-100 für Prozent
        progressBar->setValue(percentage); // Direkt Prozent setzen
        progressBar->repaint(); // 🚀 FORCE IMMEDIATE REPAINT!
        
        // ✅ FIX: Aktualisiere Action-Label basierend auf Fortschritt
        QString currentAction;
        if (percentage >= 90) {
            currentAction = "🔍 Identifiziere Duplikate...";
        } else if (percentage >= 50) {
            currentAction = "🔐 Hash-Berechnung läuft...";
        } else if (percentage >= 10) {
            currentAction = "📏 Analysiere Dateigrößen...";
        } else {
            currentAction = "🔍 Sammle Dateien...";
        }
        
        // 🚀 ECHTZEIT: Aktualisiere GUI Komponenten sofort
        actionLabel->setText(currentAction);
        actionLabel->repaint(); // 🚀 FORCE REPAINT!
        fileCountLabel->setText(QString("Datei %1 von %2").arg(current).arg(total));
        fileCountLabel->repaint(); // 🚀 FORCE REPAINT!
        
        // 🚀 ECHTZEIT: Status-Bar ohne Timeout für permanente Anzeige
        statusBar()->showMessage(QString("🔍 Hash-Berechnung: %1/%2 (%3%)").arg(current).arg(total).arg(percentage), 0); // 0 = kein Timeout!
        
        // 🔥 FORCE GUI UPDATE: Erzwinge sofortige Bildschirm-Aktualisierung
        // REMOVED: QCoreApplication::processEvents();
        update();
        repaint();
        
        // Logge nur alle 10% Fortschritt
        static int lastLoggedPercentage = -1;
        if (percentage % 10 == 0 && percentage != lastLoggedPercentage) {
            qDebug() << "[MainWindow] 📊 Progress:" << percentage << "% (" << current << "/" << total << ")";
            lastLoggedPercentage = percentage;
        }
    } else {
        // Unbestimmter Progress
        progressBar->setMaximum(0); // Indeterminate progress
        actionLabel->setText("🔍 Initialisiere Scan...");
        
        // 🔥 FORCE GUI UPDATE auch für unbestimmten Progress
        // REMOVED: QCoreApplication::processEvents();
        update();
        repaint();
        
        std::cout << "[MainWindow] 🔄 Unbestimmter Progress - Initialisierung" << std::endl;
    }
}

void MainWindow::onScanCompleted(const DuplicateGroups &results)
{
    qDebug() << "[MainWindow] ✅ onScanCompleted aufgerufen mit" << results.groups.size() << "Duplikat-Gruppen";
    std::cout << "[MainWindow] ✅ Scan abgeschlossen! Duplikat-Gruppen: " << results.groups.size() << std::endl;
    
    // 🔥 DEBUG: Zeige alle empfangenen Werte
    qDebug() << "[MainWindow] 🔥🔥🔥 onScanCompleted EMPFANGEN:";
    qDebug() << "    - results.totalFiles =" << results.totalFiles;
    qDebug() << "    - results.groups.size() =" << results.groups.size();
    qDebug() << "    - results.duplicateFiles =" << results.duplicateFiles;
    qDebug() << "    - results.duplicateSize =" << results.duplicateSize;
    std::cout << "🔥🔥🔥 totalFiles=" << results.totalFiles << " groups=" << results.groups.size() << std::endl;
    
    // 🔥 KRITISCH: Prüfe ob überhaupt Dateien gescannt wurden!
    if (results.totalFiles == 0) {
        qDebug() << "[MainWindow] ⚠️ scanCompleted mit 0 Dateien - Scan wurde nicht ausgeführt!";
        std::cout << "⚠️⚠️⚠️ PROBLEM: totalFiles == 0!" << std::endl;
        // Zeige "Keine Duplikate gefunden" auch wenn totalFiles == 0
        if (actionLabel) {
            actionLabel->setText(tr("✅ Keine Duplikate gefunden"));
        }
        
        // 🔥 FIX: duplicateCountLabel auch bei totalFiles == 0
        if (duplicateCountLabel) {
            duplicateCountLabel->setText(tr("✅ Keine Duplikate gefunden"));
            qDebug() << "[MainWindow] ✅ duplicateCountLabel: Keine Duplikate gefunden";
        }
        
        // �🛑 CRITICAL FIX: Button zurücksetzen auch bei abgebrochenem Scan
        if (scanSelectedBtn) {
            scanSelectedBtn->setText(tr("🔍 Ausgewählte scannen"));
            scanSelectedBtn->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
        }
        
        m_isScanning = false;
        return;
    }
    
    // 📊 Spezialfall: Scan wurde durchgeführt aber keine Duplikate gefunden
    if (results.groups.isEmpty() && results.totalFiles > 0) {
        qDebug() << "[MainWindow] ℹ️ Scan abgeschlossen:" << results.totalFiles << "Dateien geprüft, keine Duplikate";
        qDebug() << "[MainWindow] 🔧 GUI-Cleanup: actionLabel=" << (actionLabel ? "OK" : "NULL");
        qDebug() << "[MainWindow] 🔧 GUI-Cleanup: progressBar=" << (progressBar ? "OK" : "NULL");
        qDebug() << "[MainWindow] 🔧 GUI-Cleanup: scanSelectedBtn=" << (scanSelectedBtn ? "OK" : "NULL");
        
        if (actionLabel) {
            actionLabel->setText(tr("✅ Scan abgeschlossen - Keine Duplikate"));
            qDebug() << "[MainWindow] ✅ actionLabel updated";
        }
        if (progressBar) {
            progressBar->setValue(100);
            qDebug() << "[MainWindow] ✅ progressBar set to 100%";
        }
        
        // 🔥 FIX: duplicateCountLabel aktualisieren bei "Keine Duplikate"
        if (duplicateCountLabel) {
            duplicateCountLabel->setText(tr("✅ Keine Duplikate gefunden"));
            qDebug() << "[MainWindow] ✅ duplicateCountLabel updated";
        }
        
        // 🛑 CRITICAL FIX: Button zurücksetzen auch bei "keine Duplikate"
        if (scanSelectedBtn) {
            qDebug() << "[MainWindow] 🔧 Resetting scanSelectedBtn...";
            scanSelectedBtn->setText(tr("🔍 Ausgewählte scannen"));
            scanSelectedBtn->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
            qDebug() << "[MainWindow] ✅ scanSelectedBtn RESET to GREEN!";
        }
        
        qDebug() << "[MainWindow] 📢 Showing QMessageBox...";
        // Zeige Info-Meldung
        QMessageBox::information(this, 
            tr("Scan abgeschlossen"),
            tr("%1 Dateien wurden geprüft.\n\nKeine Duplikate gefunden.").arg(results.totalFiles)
        );
        qDebug() << "[MainWindow] ✅ QMessageBox closed";
        
        m_isScanning = false;
        qDebug() << "[MainWindow] ✅ m_isScanning = false";
        return;
    }
    
    // 🎯 NEU: Übergebe komplette DuplicateGroups Struktur (mit Hash!)
    qDebug() << "[MainWindow] 🔄 Zeige" << results.groups.size() << "Duplikat-Gruppen mit allen Infos";
    displayResultsGrouped(results);
    m_isScanning = false;
    
    // 🔄 KRITISCH: Button zurücksetzen nach Scan
    if (scanSelectedBtn) {
        scanSelectedBtn->setText(tr("🔍 Ausgewählte scannen"));
        scanSelectedBtn->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
    }
    
    // ✅ ERWEITERTE PROGRESS-FERTIGSTELLUNG mit speziellem Text für "keine Duplikate"
    progressBar->setValue(progressBar->maximum()); // 100%
    
    if (results.groups.isEmpty()) {
        // 🔥 KRITISCH: Unterscheide zwischen "keine Duplikate" und "Scan abgebrochen"
        if (results.totalFiles > 0) {
            // ✅ Scan wurde ausgeführt, aber keine Duplikate gefunden
            actionLabel->setText(tr("✅ Keine Duplikate gefunden!"));
            if (currentFileLabel) currentFileLabel->setText(tr("Alle Dateien sind einzigartig 🎉"));
            statusBar()->showMessage(tr("✅ Scan abgeschlossen - Keine Duplikate gefunden! Alle Dateien sind einzigartig."), 8000);
        } else {
            // ⏹️ Scan wurde abgebrochen (z.B. stopScan() aufgerufen)
            actionLabel->setText(tr("⏹️ Scan abgebrochen"));
            if (currentFileLabel) currentFileLabel->setText(tr("Scan wurde gestoppt"));
            statusBar()->showMessage(tr("⏹️ Scan wurde abgebrochen"), 3000);
        }
    } else {
        // Normale Anzeige wenn Duplikate gefunden wurden
        actionLabel->setText(tr("✅ Scan abgeschlossen"));
        if (currentFileLabel) currentFileLabel->setText(tr("%1 Duplikatgruppen gefunden").arg(results.groups.size()));
        statusBar()->showMessage(tr("Scan abgeschlossen. %1 Duplikatgruppen gefunden.").arg(results.groups.size()), 5000);
        
        // 🔔 MessageBox: Duplikate gefunden!
        QString message = tr("✅ Scan abgeschlossen!\n\n"
                           "📊 Gescannte Dateien: %1\n"
                           "📂 Duplikat-Gruppen: %2\n"
                           "📄 Duplikate gefunden: %3\n"
                           "💾 Potentiell freizugebender Speicher: %4 MB")
            .arg(results.totalFiles)
            .arg(results.groups.size())
            .arg(results.duplicateFiles)
            .arg(QString::number(results.duplicateSize / (1024.0 * 1024.0), 'f', 2));
        
        QMessageBox::information(this, tr("🎉 Duplikate gefunden!"), message);
    }
    
    std::cout << "[MainWindow] 🎉 GUI erfolgreich aktualisiert - " << results.groups.size() << " Gruppen angezeigt" << std::endl;
}

void MainWindow::onFilesCollected(int totalFiles)
{
    // 🛡️ CRITICAL: Ignore repeated calls - nur EINMAL verarbeiten!
    if (m_filesCollectedHandled) {
        qDebug() << "[MainWindow] ⏭️ onFilesCollected bereits verarbeitet, ignoriere Aufruf";
        return;
    }
    
    qDebug() << "[MainWindow] 🔥 onFilesCollected aufgerufen mit" << totalFiles << "Dateien";
    std::cout << "[MainWindow] 🔥 FTP Discovery abgeschlossen - " << totalFiles << " Dateien gesammelt!" << std::endl;
    
    m_filesCollectedHandled = true;  // 🔒 Lock - nur EINMAL verarbeiten
    
    // GUI-Updates für Discovery-Completion
    if (progressBar) {
        progressBar->setValue(50); // Discovery ist 50% des Scans
    }
    
    if (actionLabel) {
        actionLabel->setText(tr("📁 %1 Dateien gesammelt - Starte Analyse...").arg(totalFiles));
    }
    
    if (currentFileLabel) {
        currentFileLabel->setText(tr("🔍 Discovery abgeschlossen - Berechne Hashes..."));
    }
    
    statusBar()->showMessage(tr("✅ FTP Discovery abgeschlossen: %1 Dateien gefunden").arg(totalFiles), 3000);
    
    qDebug() << "[MainWindow] ✅ GUI für Discovery-Completion aktualisiert";
    
    // 🔥 CRITICAL FIX: STARTE HASH-BERECHNUNG SOFORT (parallel zur Sortierung)!
    qDebug() << "[MainWindow] 🚀 STARTE HASH-BERECHNUNG sofort nach File Collection!";
    if (m_scanner) {
        // ⚡ OPTIMIERUNG: Keine Wartezeit - starte Hash-Berechnung SOFORT!
        // Sortierung läuft parallel (ist Memory-Operation, ultra-schnell)
        QTimer::singleShot(0, this, &MainWindow::onHashCalculationStartNeeded);
    }
}

void MainWindow::onHashCalculationStartNeeded()
{
    qDebug() << "[MainWindow] 🔥 onHashCalculationStartNeeded - starte Hash-Berechnung!";
    
    // 🛡️ CRITICAL: Prevent multiple hash calculation starts
    if (m_hashCalculationStarted) {
        qDebug() << "[MainWindow] ⚠️ Hash calculation already started, ignoring duplicate call";
        return;
    }
    
    if (m_scanner) {
        int fileCount = m_scanner->getAllFiles().size();
        qDebug() << "[MainWindow] 📊 Total files in Scanner:" << fileCount;
        if (fileCount > 0) {
            qDebug() << "[MainWindow] ✅ Rufe startProcessingCollectedFiles() auf";
            m_hashCalculationStarted = true;  // 🔒 Lock to prevent re-entry
            m_scanner->startProcessingCollectedFiles();
        } else {
            qDebug() << "[MainWindow] ⚠️ KEINE FILES gefunden! Warte nochmal 10s...";
            QTimer::singleShot(10000, this, &MainWindow::onHashCalculationStartNeeded);
        }
    }
}

void MainWindow::onHashProgress(int current, int total)
{
    qDebug() << "[MainWindow] 🔐 onHashProgress:" << current << "/" << total;
    
    if (total > 0) {
        int percentage = (current * 100) / total;
        
        // 🔇 STOP BLINKING during hash (happens once at start)
        if (m_activityIndicator) {
            m_activityIndicator->setActivity(false);
        }
        
        // Update progress bar
        if (progressBar) {
            progressBar->setMaximum(total); // Set to determinate mode
            progressBar->setValue(current);
        }
        
        // Update labels
        if (actionLabel) {
            actionLabel->setText(tr("🔐 Hash-Berechnung: %1%").arg(percentage));
        }
        
        if (fileCountLabel) {
            fileCountLabel->setText(tr("Dateien: %1 / %2").arg(current).arg(total));
        }
        
        if (currentFileLabel) {
            currentFileLabel->setText(tr("Berechne Hashes... %1%").arg(percentage));
        }
        
        statusBar()->showMessage(tr("🔐 Hash-Berechnung: %1% (%2/%3 Dateien)").arg(percentage).arg(current).arg(total), 0);
        
        qDebug() << "[MainWindow] ✅ Hash-Progress GUI aktualisiert:" << percentage << "%";
    }
}

// 🚀 NEUE DETAILLIERTE PROGRESS-SLOT-IMPLEMENTIERUNGEN

void MainWindow::onCurrentFileProcessing(const QString &fileName, const QString &processType, int fileNumber, int totalFiles)
{
    qDebug() << "[MainWindow] 📄 onCurrentFileProcessing aufgerufen:" << processType << fileName << "(" << fileNumber << "/" << totalFiles << ")";
    qDebug() << "[MainWindow] 🔍 Labels: currentFileLabel=" << (currentFileLabel ? "OK" : "NULL") 
             << " actionLabel=" << (actionLabel ? "OK" : "NULL")
             << " pathProcessingLabel=" << (pathProcessingLabel ? "OK" : "NULL");
    // DEBUG DISABLED FOR PERFORMANCE
    
    // 🎯 FTP-QUEUE-MONITORING: Extrahiere Queue-Größe aus fileName wenn vorhanden
    QString displayFileName = fileName;
    QString queueInfo;
    
    // ⚡ RATE LIMITING: Verhindere Spam bei identischen Queue-Updates
    static QString lastQueueInfo;
    static QTime lastUpdateTime = QTime::currentTime();
    
    // Format: "ftp://host/path | Verbleibend: 3695"
    if (fileName.contains(" | Verbleibend: ")) {
        QStringList parts = fileName.split(" | Verbleibend: ");
        if (parts.size() == 2) {
            displayFileName = parts[0];
            queueInfo = QString(" | 🎯 Queue: %1").arg(parts[1]);
            
            // 🚨 ANTI-SPAM: Zeige nur bei Änderung oder alle 5 Sekunden
            QTime currentTime = QTime::currentTime();
            if (queueInfo != lastQueueInfo || lastUpdateTime.secsTo(currentTime) >= 5) {
                std::cout << "[MainWindow] 🎯 QUEUE UPDATE: " << parts[1].toUtf8().constData() << std::endl;
                lastQueueInfo = queueInfo;
                lastUpdateTime = currentTime;
            }
        }
    }
    
    // 🛡️ CRITICAL NULL-CHECKS für currentFileLabel
    if (!currentFileLabel) {
        qWarning() << "[MainWindow] ❌ currentFileLabel ist NULL!";
        std::cout << "[MainWindow] ❌❌❌ currentFileLabel ist NULL!" << std::endl;
        return;
    }
    
    if (currentFileLabel) {
        // Zeige Dateinamen + Zähler für bessere Übersicht
        QString displayText = displayFileName.isEmpty() ? processType : displayFileName;
        QString text = QString("📄 %1 (%2/%3)%4").arg(displayText).arg(fileNumber).arg(totalFiles).arg(queueInfo);
        currentFileLabel->setText(text);
        currentFileLabel->repaint(); // 🚀 FORCE IMMEDIATE REPAINT!
        
        // 🔥 FORCE GUI UPDATE: Erzwinge sofortige Anzeige
        // REMOVED: QCoreApplication::processEvents();
        
        // DEBUG DISABLED FOR PERFORMANCE
    } else {
        qWarning() << "[MainWindow] ❌ currentFileLabel ist NULL!";
        std::cout << "[MainWindow] ❌❌❌ currentFileLabel ist NULL!" << std::endl;
    }
    
    if (actionLabel) {
        actionLabel->setText(QString("🔍 %1 (%2/%3)").arg(processType).arg(fileNumber).arg(totalFiles));
        actionLabel->repaint();
    } else {
        qWarning() << "[MainWindow] ❌ actionLabel ist NULL!";
    }
    
    // 🚀 ECHTZEIT-UPDATE: Statusbar zeigt nur wichtigste Info (ProgressBar zeigt Zahlen bereits!)
    QString statusMsg = QString("%1: %2%3").arg(processType, displayFileName, queueInfo);
    statusBar()->showMessage(statusMsg, 0);
    
    // Force GUI update
    // REMOVED: QCoreApplication::processEvents();
}

void MainWindow::onProcessActivityUpdate(const QString &activity, const QString &details)
{
    qDebug() << "[MainWindow] 🔄 onProcessActivityUpdate:" << activity << "-" << details;
    std::cout << "[MainWindow] 🔄 Activity: " << activity.toUtf8().constData() << " | " << details.toUtf8().constData() << std::endl;
    
    // 🎯 FTP-STATISTIKEN: Parse "Files: X Success: Y" aus details
    QString displayActivity = activity;
    QString displayDetails = details;
    
    if (details.contains("Files:") && details.contains("Success:")) {
        // Format: "Files: 19 Success: true"
        QRegularExpression re(R"(Files:\s*(\d+)\s*Success:\s*(\w+))");
        QRegularExpressionMatch match = re.match(details);
        
        if (match.hasMatch()) {
            QString filesCount = match.captured(1);
            QString successStr = match.captured(2);
            QString successIcon = (successStr == "true") ? "✅" : "❌";
            
            displayDetails = QString("%1 %2 Dateien gefunden").arg(successIcon, filesCount);
            std::cout << "[MainWindow] 📊📊📊 FTP-STATISTIK: " << displayDetails.toUtf8().constData() << std::endl;
        }
    }
    
    if (actionLabel) {
        actionLabel->setText(displayActivity);
        qDebug() << "[MainWindow] ✅ actionLabel aktualisiert (Activity):" << displayActivity;
    } else {
        qWarning() << "[MainWindow] ❌ actionLabel ist NULL (Activity)!";
    }
    
    // Details in Status-Bar anzeigen mit besserer Formatierung
    if (!displayDetails.isEmpty()) {
        statusBar()->showMessage(QString("%1 - %2").arg(displayActivity, displayDetails), 0); // 0 = kein Timeout!
        qDebug() << "[MainWindow] ✅ StatusBar:" << displayActivity << "-" << displayDetails;
    } else {
        statusBar()->showMessage(displayActivity, 0);
    }
    
    // 🚀 Aktualisiere auch pathProcessingLabel wenn vorhanden
    if (pathProcessingLabel) {
        if (activity.contains("FTP") || !displayDetails.isEmpty()) {
            pathProcessingLabel->setText(displayDetails);
            pathProcessingLabel->repaint(); // 🚀 FORCE IMMEDIATE REPAINT!
            qDebug() << "[MainWindow] ✅ pathProcessingLabel aktualisiert:" << displayDetails;
            std::cout << "[MainWindow] ✅✅✅ PATH LABEL: " << displayDetails.toUtf8().constData() << std::endl;
        }
    } else {
        qWarning() << "[MainWindow] ❌ pathProcessingLabel ist NULL!";
    }
    
    // Force GUI update
    // REMOVED: QCoreApplication::processEvents();
}

void MainWindow::onFileComparisonProgress(const QString &file1, const QString &file2, int comparisonNumber, int totalComparisons)
{
    if (fileComparisonLabel) {
        QString shortFile1 = QFileInfo(file1).fileName();
        QString shortFile2 = QFileInfo(file2).fileName();
        fileComparisonLabel->setText(QString("🔍 %1 ↔ %2 (%3/%4)").arg(shortFile1, shortFile2, QString::number(comparisonNumber), QString::number(totalComparisons)));
    }
    
    // Berechne Prozent für Progress-Bar
    if (totalComparisons > 0) {
        int percentage = (comparisonNumber * 100) / totalComparisons;
        progressBar->setValue(percentage);
    }
}

void MainWindow::onPathProcessingUpdate(const QString &currentPath, const QString &action, int pathNumber, int totalPaths)
{
    if (pathProcessingLabel) {
        QString shortPath = currentPath.length() > 50 ? "..." + currentPath.right(47) : currentPath;
        pathProcessingLabel->setText(QString("📂 %1: %2 (%3/%4)").arg(action, shortPath, QString::number(pathNumber), QString::number(totalPaths)));
    }
}

void MainWindow::onDuplicateDetectionUpdate(int duplicatesFound, int groupsCreated, const QString &latestDuplicate)
{
    // 🔥 WICHTIG: NICHT "0 Duplikate" während Scan anzeigen!
    if (duplicatesFound == 0) {
        // Zeige "Scan läuft..." statt "0 Duplikate"
        if (duplicateCountLabel) {
            duplicateCountLabel->setText(tr("🔍 Suche Duplikate..."));
        }
        return; // Kein Update bei 0 Duplikaten
    }
    
    // ✅ Nur bei echten Duplikaten anzeigen
    if (duplicateCountLabel) {
        duplicateCountLabel->setText(QString("🔄 %1 Duplikate in %2 Gruppen").arg(duplicatesFound).arg(groupsCreated));
    }
    
    // Zeige letztes gefundenes Duplikat kurz in Status-Bar
    if (!latestDuplicate.isEmpty()) {
        statusBar()->showMessage(QString("🔍 Duplikat: %1").arg(latestDuplicate), 500);
    }
}

void MainWindow::onHardwareUsageUpdate(const QString &processingUnit, int utilizationPercent, const QString &currentTask)
{
    if (hardwareStatusLabel) {
        // Color-coding basierend auf Auslastung
        QString colorClass;
        if (utilizationPercent >= 90) {
            colorClass = "color: red; font-weight: bold;"; // 🔴 Kritisch
        } else if (utilizationPercent >= 70) {
            colorClass = "color: orange; font-weight: bold;"; // 🟠 Hoch
        } else if (utilizationPercent >= 30) {
            colorClass = "color: green;"; // 🟢 Normal
        } else {
            colorClass = "color: gray;"; // Niedrig
        }
        
        hardwareStatusLabel->setStyleSheet(QString("QLabel { %1 }").arg(colorClass));
        hardwareStatusLabel->setText(QString("⚡ %1: %2% - %3").arg(processingUnit, QString::number(utilizationPercent), currentTask));
    }
}

// +++ NEUE FUNKTIONEN FÜR VERZEICHNISBAUM MIT CHECKBOXEN +++

void MainWindow::loadLocalDirectoryTreeWithCheckboxes()
{
    // ✅ NEUES DESIGN: Kompatibel mit directorySummaryLabel
    qDebug() << "[MainWindow] 📁 loadLocalDirectoryTreeWithCheckboxes: Nicht mehr verwendet in neuer GUI";
    
    // Backup: Lade Standard-Verzeichnisse in m_selectedDirectories wenn leer
    if (m_selectedDirectories.isEmpty()) {
        QStringList systemPaths = {
            QStandardPaths::writableLocation(QStandardPaths::HomeLocation),
            QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation),
            QStandardPaths::writableLocation(QStandardPaths::DownloadLocation),
            QStandardPaths::writableLocation(QStandardPaths::PicturesLocation),
            QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
            QStandardPaths::writableLocation(QStandardPaths::MoviesLocation)
        };
        
        for (const QString &path : systemPaths) {
            if (QDir(path).exists() && !m_selectedDirectories.contains(path)) {
                m_selectedDirectories.append(path);
            }
        }
        updateDirectoryTree();
        qDebug() << "[MainWindow] 📁 Standard-Verzeichnisse geladen:" << m_selectedDirectories.size();
    }
}


void MainWindow::onDirectoryItemExpanded(QTreeWidgetItem *item)
{
    // ✅ ECHTES LAZY-LOADING: Kinder nur bei erster Expansion laden
    if (item && item->childCount() == 1 && item->child(0)->text(0) == "Lade...") {
        item->takeChild(0); // Loading-Platzhalter entfernen
        loadSubDirectories(item, item->data(0, Qt::UserRole).toString());
    }
}

void MainWindow::loadSubDirectories(QTreeWidgetItem *parentItem, const QString &path)
{
    QDir dir(path);
    QFileInfoList entries = dir.entryInfoList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot, QDir::Name);

    for (const QFileInfo &info : entries) {
        QTreeWidgetItem *childItem = new QTreeWidgetItem(parentItem);
        QString icon = info.isDir() ? "📁" : "📄";
        childItem->setText(0, icon + " " + info.fileName());
        childItem->setText(1, formatFileSize(info.isDir() ? getDirSize(info.filePath()) : info.size()));
        childItem->setText(2, info.lastModified().toString("dd.MM.yyyy hh:mm"));
        childItem->setData(0, Qt::UserRole, info.filePath());
        childItem->setFlags(childItem->flags() | Qt::ItemIsUserCheckable);
        childItem->setCheckState(0, Qt::Unchecked);

        // For directories, check if they have subdirectories to show expander
        if (info.isDir()) {
            QDir subDir(info.filePath());
            if (subDir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot).count() > 0) {
                new QTreeWidgetItem(childItem, QStringList("Lade..."));
            }
        }
    }
}

QString MainWindow::formatFileSize(qint64 size) const
{
    if (size < 1024) return QString::number(size) + " B";
    if (size < 1024 * 1024) return QString::number(size / 1024.0, 'f', 1) + " KB";
    if (size < 1024 * 1024 * 1024) return QString::number(size / (1024.0 * 1024.0), 'f', 1) + " MB";
    return QString::number(size / (1024.0 * 1024.0 * 1024.0), 'f', 1) + " GB";
}

qint64 MainWindow::getDirSize(const QString &path)
{
    // Quick approximation - in real app you'd do this async
    QDir dir(path);
    qint64 size = 0;
    QFileInfoList files = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot);
    for (const QFileInfo &file : files) {
        size += file.size();
        if (size > 1024 * 1024 * 100) break; // Stop at 100MB for performance
    }
    return size;
}

// 🔐 HASH-CACHE: Lade Hash aus Cache-Datei mit Größen-Verifikation
QString MainWindow::loadHashFromCacheFile(const QString &filePath, qint64 size)
{
    QString hashCacheFile = QDir::homePath() + "/.fileduper_hash_cache.dat";
    QFile file(hashCacheFile);
    
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return QString(); // Cache-Datei nicht vorhanden
    }
    
    QString canonical = QFileInfo(filePath).canonicalFilePath();
    if (canonical.isEmpty()) {
        canonical = filePath; // Fallback für Netzwerk-Pfade
    }
    
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty() || line.startsWith("#")) continue;
        
        // Format: hash|size|filepath
        QStringList parts = line.split("|");
        if (parts.size() >= 3) {
            QString cachedHash = parts[0];
            qint64 cachedSize = parts[1].toLongLong();
            QString cachedPath = parts.mid(2).join("|"); // Falls Pfad | enthält
            
            // Prüfe ob Pfad übereinstimmt
            if (cachedPath == canonical || cachedPath == filePath) {
                // Prüfe Größe zur Verifikation
                if (cachedSize == size) {
                    file.close();
                    return cachedHash; // ✅ Hash gefunden und Größe stimmt überein
                } else {
                    qWarning() << "[MainWindow] ⚠️ Cache-Größe stimmt nicht überein:" 
                              << filePath << "Cache:" << cachedSize << "Aktuell:" << size;
                    file.close();
                    return QString(); // ❌ Größe stimmt nicht → Datei wurde geändert
                }
            }
        }
    }
    
    file.close();
    return QString(); // Kein Hash im Cache gefunden
}

// --- ENDE NEUE FUNKTIONEN ---

void MainWindow::displayResults(const QList<QStringList> &duplicateGroups)
{
    resultsTable->setRowCount(0);

    if (duplicateGroups.isEmpty()) {
        // 🎉 WICHTIG: Nur "Keine Duplikate" zeigen wenn Scan ABGESCHLOSSEN ist!
        if (!m_isScanning) {
            resultsTable->setRowCount(1);
            resultsTable->setColumnCount(3);
            
            QTableWidgetItem *messageItem = new QTableWidgetItem("🎉 Keine Duplikate gefunden!");
            messageItem->setTextAlignment(Qt::AlignCenter);
            messageItem->setBackground(QColor(144, 238, 144));
            messageItem->setFont(QFont("Arial", 12, QFont::Bold));
            resultsTable->setItem(0, 0, messageItem);
            
            QTableWidgetItem *detailItem = new QTableWidgetItem("Alle Dateien sind einzigartig");
            detailItem->setTextAlignment(Qt::AlignCenter);
            detailItem->setBackground(QColor(144, 238, 144));
            resultsTable->setItem(0, 1, detailItem);
            
            QTableWidgetItem *statusItem = new QTableWidgetItem("✅ Scan erfolgreich");
            statusItem->setTextAlignment(Qt::AlignCenter);
            statusItem->setBackground(QColor(144, 238, 144));
            resultsTable->setItem(0, 2, statusItem);
            
            resultsTable->resizeColumnsToContents();
        }
        return;
    }

    // 🎯 GRUPPIERTE ANZEIGE: Jede Gruppe mit Trenner und visueller Hierarchie
    int groupNumber = 1;
    for (const QStringList &group : duplicateGroups)
    {
        if (group.size() < 2) continue; // Skip Gruppen mit nur 1 Datei
        
        // 📊 GRUPPEN-HEADER: Zeige Gruppen-Nummer und Anzahl Duplikate
        int headerRow = resultsTable->rowCount();
        resultsTable->insertRow(headerRow);
        
        QTableWidgetItem *groupHeaderItem = new QTableWidgetItem(
            QString("══════ 🗂️ GRUPPE %1 ══════ (%2 Dateien) ══════").arg(groupNumber).arg(group.size())
        );
        groupHeaderItem->setTextAlignment(Qt::AlignCenter);
        groupHeaderItem->setBackground(QColor(70, 130, 180, 100)); // Steel Blue
        groupHeaderItem->setForeground(Qt::white);
        groupHeaderItem->setFont(QFont("Arial", 11, QFont::Bold));
        groupHeaderItem->setFlags(Qt::ItemIsEnabled); // Nicht selektierbar
        resultsTable->setItem(headerRow, 0, groupHeaderItem);
        
        // Merge alle Spalten für Header
        resultsTable->setSpan(headerRow, 0, 1, resultsTable->columnCount());
        
        // 🟢 ORIGINAL (erste Datei in Gruppe)
        addResultRow(group.first(), true);
        
        // 🔴 DUPLIKATE (Rest der Gruppe)
        for (int i = 1; i < group.size(); ++i) {
            addResultRow(group.at(i), false);
        }
        
        // 📏 LEERZEILE als visuelle Trennung zwischen Gruppen
        int separatorRow = resultsTable->rowCount();
        resultsTable->insertRow(separatorRow);
        QTableWidgetItem *separatorItem = new QTableWidgetItem("");
        separatorItem->setBackground(QColor(240, 240, 240)); // Light gray
        separatorItem->setFlags(Qt::ItemIsEnabled); // Nicht selektierbar
        resultsTable->setItem(separatorRow, 0, separatorItem);
        resultsTable->setSpan(separatorRow, 0, 1, resultsTable->columnCount());
        resultsTable->setRowHeight(separatorRow, 5); // Dünne Trennlinie
        
        groupNumber++;
    }

    resultsTable->resizeColumnsToContents();
    
    qDebug() << "[MainWindow] 🎨 Gruppierte Anzeige:" << groupNumber - 1 << "Gruppen mit visuellen Trennern";
}

// 🎯 NEUE GRUPPIERTE ANZEIGE mit FileInfo (inkl. Hash!)
void MainWindow::displayResultsGrouped(const DuplicateGroups &results)
{
    resultsTable->setRowCount(0);

    if (results.groups.isEmpty()) {
        if (!m_isScanning) {
            resultsTable->setRowCount(1);
            resultsTable->setColumnCount(3);
            
            QTableWidgetItem *messageItem = new QTableWidgetItem("🎉 Keine Duplikate gefunden!");
            messageItem->setTextAlignment(Qt::AlignCenter);
            messageItem->setBackground(QColor(144, 238, 144));
            messageItem->setFont(QFont("Arial", 12, QFont::Bold));
            resultsTable->setItem(0, 0, messageItem);
            
            QTableWidgetItem *detailItem = new QTableWidgetItem("Alle Dateien sind einzigartig");
            detailItem->setTextAlignment(Qt::AlignCenter);
            detailItem->setBackground(QColor(144, 238, 144));
            resultsTable->setItem(0, 1, detailItem);
            
            QTableWidgetItem *statusItem = new QTableWidgetItem("✅ Scan erfolgreich");
            statusItem->setTextAlignment(Qt::AlignCenter);
            statusItem->setBackground(QColor(144, 238, 144));
            resultsTable->setItem(0, 2, statusItem);
            
            resultsTable->resizeColumnsToContents();
        }
        return;
    }

    // 🎯 Tabellen-Konfiguration: Status | Hash | Name | Pfad | Größe
    resultsTable->setSortingEnabled(false); // Deaktiviere Sortierung während Befüllen
    resultsTable->setColumnCount(5);
    resultsTable->setHorizontalHeaderLabels({"Status", "Hash", "Dateiname", "Pfad", "Größe"});
    resultsTable->horizontalHeader()->setStretchLastSection(false);
    resultsTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    resultsTable->setColumnWidth(1, 280); // Hash-Spalte auf 280px
    // 🔐 Hash-Cache laden für schnellen Zugriff
    QMap<QString, QPair<QString, qint64>> hashCacheMap;
    QString hashCacheFile = QDir::homePath() + "/.fileduper_hash_cache.dat";
    QFile cacheFile(hashCacheFile);
    if (cacheFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&cacheFile);
        while (!in.atEnd()) {
            QString line = in.readLine().trimmed();
            if (line.isEmpty() || line.startsWith("#")) continue;
            
            QStringList parts = line.split("|");
            if (parts.size() >= 3) {
                QString hash = parts[0];
                qint64 size = parts[1].toLongLong();
                QString filePath = parts.mid(2).join("|");
                hashCacheMap[filePath] = qMakePair(hash, size);
            }
        }
        cacheFile.close();
    }
    
    int groupNumber = 1;
    for (const DuplicateGroup &group : results.groups)
    {
        if (group.duplicates.isEmpty()) continue; // Skip Gruppen ohne Duplikate
        
        // Original mit Hash aus Cache falls nötig
        FileInfo originalWithHash = group.original;
        if (originalWithHash.hash.isEmpty()) {
            QString canonical = QFileInfo(originalWithHash.filePath).canonicalFilePath();
            QString rawPath = originalWithHash.filePath;
            
            // Versuche canonical lookup zuerst, dann raw
            if (!canonical.isEmpty() && hashCacheMap.contains(canonical)) {
                auto cached = hashCacheMap[canonical];
                if (cached.second == originalWithHash.size) {
                    originalWithHash.hash = cached.first;
                }
            } else if (hashCacheMap.contains(rawPath)) {
                auto cached = hashCacheMap[rawPath];
                if (cached.second == originalWithHash.size) {
                    originalWithHash.hash = cached.first;
                }
            }
        }
        addResultRowWithInfo(originalWithHash, true);
        
        // Duplikate mit Hash aus Cache falls nötig
        for (const FileInfo &duplicate : group.duplicates) {
            FileInfo duplicateWithHash = duplicate;
            if (duplicateWithHash.hash.isEmpty()) {
                QString canonical = QFileInfo(duplicateWithHash.filePath).canonicalFilePath();
                QString rawPath = duplicateWithHash.filePath;
                
                if (!canonical.isEmpty() && hashCacheMap.contains(canonical)) {
                    auto cached = hashCacheMap[canonical];
                    if (cached.second == duplicateWithHash.size) {
                        duplicateWithHash.hash = cached.first;
                    }
                } else if (hashCacheMap.contains(rawPath)) {
                    auto cached = hashCacheMap[rawPath];
                    if (cached.second == duplicateWithHash.size) {
                        duplicateWithHash.hash = cached.first;
                    }
                }
            }
            addResultRowWithInfo(duplicateWithHash, false);
        }
        
        groupNumber++;
    }
    resultsTable->resizeColumnsToContents();
    // Keine Sortierung aktivieren - Reihenfolge bleibt wie eingefügt
}

void MainWindow::addResultRowWithInfo(const FileInfo &fileInfo, bool isOriginal)
{
    int row = resultsTable->rowCount();
    resultsTable->insertRow(row);

    QString filePath = fileInfo.filePath;
    bool isNetworkFile = filePath.startsWith("ftp://") || filePath.startsWith("sftp://") || filePath.startsWith("smb://");
    QString networkType = "";
    QString displayPath = filePath;
    
    // Extrahiere Dateinamen IMMER aus dem Pfad (nicht aus fileInfo.fileName!)
    QString fileName;
    if (isNetworkFile) {
        QUrl url(filePath);
        fileName = url.fileName();  // Dateiname aus URL
        if (filePath.startsWith("ftp://")) networkType = "FTP";
        else if (filePath.startsWith("sftp://")) networkType = "SFTP";
        else if (filePath.startsWith("smb://")) networkType = "SMB";
        displayPath = QString("%1://%2%3").arg(networkType.toLower()).arg(url.host()).arg(url.path());
    } else {
        QFileInfo pathInfo(filePath);
        fileName = pathInfo.fileName();  // Dateiname aus lokalem Pfad
        displayPath = filePath;
    }

    auto createSelectableItem = [](const QString &text) -> QTableWidgetItem* {
        QTableWidgetItem *item = new QTableWidgetItem(text);
        item->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled | Qt::ItemIsEditable);
        item->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        return item;
    };

    QTableWidgetItem *statusItem = createSelectableItem("");
    QTableWidgetItem *nameItem = createSelectableItem(
        isNetworkFile ? QString("📡 %1").arg(fileName) : QString("📂 %1").arg(fileName)
    );
    QTableWidgetItem *pathItem = createSelectableItem(displayPath);
    QTableWidgetItem *sizeItem = createSelectableItem(formatFileSize(fileInfo.size));
    
    // Hash-Display vorbereiten
    QString hashDisplay;
    QString cacheSource = "";
    
    if (!fileInfo.hash.isEmpty()) {
        hashDisplay = fileInfo.hash;
        cacheSource = "✅ Scan";
    } else {
        // Versuche Hash aus Cache zu laden
        QString cachedHashFromFile = loadHashFromCacheFile(filePath, fileInfo.size);
        if (!cachedHashFromFile.isEmpty()) {
            hashDisplay = cachedHashFromFile;
            cacheSource = "🔐 Cache";
        } else {
            hashDisplay = "⏳ Berechnung...";
            cacheSource = "❌ Fehlt";
        }
    }
    
    QTableWidgetItem *hashItem = createSelectableItem(hashDisplay);
    hashItem->setToolTip(QString("Quelle: %1 | Größe: %2")
                        .arg(cacheSource)
                        .arg(formatFileSize(fileInfo.size)));
    hashItem->setForeground(Qt::black);
    hashItem->setFont(QFont("Monospace", 9));

    if (isOriginal) {
        statusItem->setText("🟢 ORIGINAL");
        statusItem->setToolTip(tr("Originaldatei - Diese behalten"));
        statusItem->setBackground(QColor(100, 200, 100));
        statusItem->setForeground(Qt::white);
        statusItem->setFont(QFont("Arial", 10, QFont::Bold));
        
        nameItem->setBackground(QColor(230, 255, 230));
        pathItem->setBackground(QColor(230, 255, 230));
        sizeItem->setBackground(QColor(230, 255, 230));
        hashItem->setBackground(QColor(230, 255, 230));
    } else {
        statusItem->setText("🔴 DUPLIKAT");
        statusItem->setToolTip(tr("Duplikat - Kann gelöscht werden"));
        statusItem->setBackground(QColor(255, 100, 100));
        statusItem->setForeground(Qt::white);
        statusItem->setFont(QFont("Arial", 10, QFont::Bold));
        
        nameItem->setBackground(QColor(255, 240, 240));
        pathItem->setBackground(QColor(255, 240, 240));
        sizeItem->setBackground(QColor(255, 240, 240));
        hashItem->setBackground(QColor(255, 240, 240));
    }

    statusItem->setData(Qt::UserRole + 1, isOriginal);
    pathItem->setData(Qt::UserRole, filePath);

    // Spalten-Reihenfolge: Status, Hash, Name, Pfad, Größe
    resultsTable->setItem(row, 0, statusItem);
    resultsTable->setItem(row, 1, hashItem);
    resultsTable->setItem(row, 2, nameItem);
    resultsTable->setItem(row, 3, pathItem);
    resultsTable->setItem(row, 4, sizeItem);
}

void MainWindow::addResultRow(const QString &filePath, bool isOriginal, int row)
{
    if (row == -1)
    {
        row = resultsTable->rowCount();
        resultsTable->insertRow(row);
    }

    QFileInfo fileInfo(filePath);
    
    // ✅ NEU: Erkenne ob es sich um eine Netzwerk-Datei handelt
    bool isNetworkFile = filePath.startsWith("ftp://") || filePath.startsWith("sftp://") || filePath.startsWith("smb://");
    QString networkType = "";
    QString displayPath = filePath;
    
    if (isNetworkFile) {
        if (filePath.startsWith("ftp://")) networkType = "FTP";
        else if (filePath.startsWith("sftp://")) networkType = "SFTP";
        else if (filePath.startsWith("smb://")) networkType = "SMB";
        
        // Für Netzwerk-Dateien: Zeige kompakteren Pfad an
        QUrl url(filePath);
        displayPath = QString("%1://%2%3").arg(networkType.toLower()).arg(url.host()).arg(url.path());
    } else {
        displayPath = fileInfo.absoluteFilePath();
    }

    // 📋 CREATE SELECTABLE TABLE ITEMS (text can be selected with mouse)
    auto createSelectableItem = [](const QString &text) -> QTableWidgetItem* {
        QTableWidgetItem *item = new QTableWidgetItem(text);
        item->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled | Qt::ItemIsEditable);
        item->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        return item;
    };

    QTableWidgetItem *statusItem = createSelectableItem("");
    QTableWidgetItem *nameItem = createSelectableItem(isNetworkFile ? 
                                                      QString("📡 %1").arg(fileInfo.fileName()) : 
                                                      QString("📂 %1").arg(fileInfo.fileName()));
    QTableWidgetItem *pathItem = createSelectableItem(displayPath);
    QTableWidgetItem *sizeItem = createSelectableItem(isNetworkFile ? 
                                                      "Netzwerk" : 
                                                      QString::number(fileInfo.size()));
    QTableWidgetItem *hashItem = createSelectableItem(""); // Hash wird später gesetzt

    if (isOriginal)
    {
        statusItem->setIcon(QIcon(":/icons/original.png"));
        statusItem->setText("🟢 ORIGINAL");
        statusItem->setToolTip(isNetworkFile ? 
                               tr("Original file (Netzwerk: %1)").arg(networkType) : 
                               tr("Original file (Lokal)"));
        statusItem->setBackground(QColor(255, 255, 150, 50));
        
        // ✅ NEU: Verschiedene Farben für lokale vs. Netzwerk-Originale
        if (isNetworkFile) {
            statusItem->setBackground(QColor(255, 200, 150, 70)); // Orange für Netzwerk-Original
        }
    }
    else
    {
        statusItem->setIcon(QIcon(":/icons/duplicate.png"));
        statusItem->setText("🔴 DUPLIKAT");
        statusItem->setToolTip(isNetworkFile ? 
                               tr("Duplicate file (Netzwerk: %1)").arg(networkType) : 
                               tr("Duplicate file (Lokal)"));
        statusItem->setBackground(QColor(150, 255, 150, 50));
        
        // ✅ NEU: Verschiedene Farben für lokale vs. Netzwerk-Duplikate
        if (isNetworkFile) {
            statusItem->setBackground(QColor(150, 200, 255, 70)); // Blau für Netzwerk-Duplikat
        }
    }

    // Hidden flag for robust original/duplicate classification
    statusItem->setData(Qt::UserRole + 1, isOriginal);

    // Hash berechnen und setzen (nur für lokale Dateien)
    if (!isNetworkFile) {
        QThreadPool::globalInstance()->start([this, filePath, row]()
        {
            HashEngine hashEngine;
            hashEngine.setAlgorithm(HashEngine::MD5);
            QString hash = hashEngine.calculateFileHash(filePath);
            QMetaObject::invokeMethod(this, "setHashForRow", Qt::QueuedConnection, Q_ARG(int, row), Q_ARG(QString, hash));
        });
    } else {
        // Für Netzwerk-Dateien: Hash wird vom Scanner bereitgestellt
        hashItem->setText("FTP-Hash");
    }

    // Always store the canonical/original full path for deletion
    pathItem->setData(Qt::UserRole, isNetworkFile ? filePath : fileInfo.absoluteFilePath());

    resultsTable->setItem(row, 0, statusItem);
    resultsTable->setItem(row, 1, nameItem);
    resultsTable->setItem(row, 2, pathItem);
    resultsTable->setItem(row, 3, sizeItem);
    resultsTable->setItem(row, 4, hashItem);
}

void MainWindow::setHashForRow(int row, const QString &hash)
{
    if (row >= 0 && row < resultsTable->rowCount())
    {
        QTableWidgetItem *hashItem = resultsTable->item(row, 4);
        if (hashItem)
        {
            hashItem->setText(hash); // ✅ VOLLSTÄNDIGER Hash (32 Zeichen für MD5)
        }
    }
}

void MainWindow::handleScanError(const QString &error)
{
    m_activityIndicator->setActivity(false);
    QMessageBox::critical(this, tr("Scan Error"), error);
}

void MainWindow::showSettingsDialog()
{
    QMessageBox::information(this, tr("Settings"), tr("Settings dialog will be implemented here"));
}

void MainWindow::showPresetManager()
{
    QMessageBox::information(this, tr("Presets"), tr("Preset manager will be implemented here"));
}

void MainWindow::showAboutDialog()
{
    QMessageBox::about(this, tr("About FileDuper"),
                       tr("<h2>FileDuper v5.0</h2>"
                          "<p>Advanced duplicate file finder with network support</p>"
                          "<p><b>Features:</b></p>"
                          "<ul>"
                          "<li>Multi-protocol network scanning</li>"
                          "<li>Hardware-accelerated hashing</li>"
                          "<li>Smart duplicate detection</li>"
                          "<li>Customizable interface</li>"
                          "</ul>"
                          "<p>Copyright © 2025 FileDuper Team</p>"));
}

// 🌐 Network Range Management Implementation
void MainWindow::showNetworkRangeSettings()
{
    if (!m_networkRangeWidget) {
        qWarning() << "NetworkRangeWidget not initialized!";
        return;
    }
    
    // Create dialog to show network range settings
    QDialog dialog(this);
    dialog.setWindowTitle(tr("🌐 Netzwerk-IP-Bereiche verwalten"));
    dialog.setModal(true);
    dialog.resize(800, 600);
    
    QVBoxLayout *layout = new QVBoxLayout(&dialog);
    
    // Temporarily reparent widget to dialog (fix segfault)
    QWidget *oldParent = m_networkRangeWidget->parentWidget();
    m_networkRangeWidget->setParent(&dialog);
    layout->addWidget(m_networkRangeWidget);
    
    // Dialog buttons
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    QPushButton *applyBtn = new QPushButton(tr("✅ Anwenden"));
    QPushButton *cancelBtn = new QPushButton(tr("❌ Abbrechen"));
    
    applyBtn->setStyleSheet("font-weight: bold; background-color: #22c55e; color: white; padding: 8px 16px;");
    cancelBtn->setStyleSheet("background-color: #ef4444; color: white; padding: 8px 16px;");
    
    buttonLayout->addStretch();
    buttonLayout->addWidget(applyBtn);
    buttonLayout->addWidget(cancelBtn);
    layout->addLayout(buttonLayout);
    
    // Connect buttons
    connect(applyBtn, &QPushButton::clicked, [&dialog, this]() {
        updateNetworkRangeDisplay();
        dialog.accept();
    });
    connect(cancelBtn, &QPushButton::clicked, &dialog, &QDialog::reject);
    
    // Show dialog
    if (dialog.exec() == QDialog::Accepted) {
        statusBar()->showMessage(tr("🌐 Netzwerk-Bereiche aktualisiert"), 3000);
        
        // NetworkRangeWidget handles all range management internally
        // No need to call addCustomNetworkRange here
    }
    
    // Restore widget to original parent after dialog closes
    m_networkRangeWidget->setParent(oldParent);
}

void MainWindow::onCustomNetworkRangeAdded(const QString &range, const QString &description)
{
    if (m_networkScanner) {
        m_networkScanner->addCustomNetworkRange(range, description);
        statusBar()->showMessage(tr("🌐 Neuer IP-Bereich hinzugefügt: %1").arg(range), 3000);
    }
}

void MainWindow::onNetworkRangeSelected(const QString &range)
{
    if (m_networkScanner) {
        // Set the selected range as active
        m_networkScanner->setActiveNetworkRange(range);
        
        // 🧹 SMART CLEAR: Remove only IP items, keep credential structure
        qDebug() << "[MainWindow] 🧹 Clearing IP items (keeping credentials) for new range:" << range;
        
        // Remove all top-level items (these are the IPs)
        // This keeps the credential manager intact but clears old scan results
        while (networkTree->topLevelItemCount() > 0) {
            delete networkTree->takeTopLevelItem(0);
        }
        
        // Trigger scan for specific range
        statusBar()->showMessage(tr("🔍 Starte Scan für Netzwerk-Bereich: %1").arg(range), 3000);
        
        // Stop any running scan first
        if (m_networkScanner->isScanning()) {
            m_networkScanner->stopScan();
        }
        
        // Start scanning the selected range
        m_networkScanner->startScan();
    }
}

void MainWindow::updateNetworkRangeDisplay()
{
    if (m_networkRangeWidget && m_networkScanner) {
        // Get auto-detected ranges from scanner
        QStringList autoRanges = m_networkScanner->autoDetectNetworkRanges();
        
        // Update widget with current ranges
        m_networkRangeWidget->setAutoDetectedRanges(autoRanges);
        
        // Update status
        int totalRanges = autoRanges.size() + m_networkRangeWidget->getCustomRanges().size();
        networkProgressLabel->setText(tr("📡 %1 IP-Bereiche verfügbar").arg(totalRanges));
    }
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    // ✅ CRASH PREVENTION: Sicheres Beenden der Anwendung
    qDebug() << "[MainWindow] 🚪 closeEvent gestartet - Sichere Anwendungsbeendigung...";
    
    try {
        // ✅ 1. Scanner-Check und sicherer Stop
        if (m_scanner && m_scanner->isScanning())
        {
            qDebug() << "[MainWindow] ⏸️ Scanner läuft noch - Benutzer fragen...";
            
            QMessageBox::StandardButton reply = QMessageBox::question(
                this,
                tr("Scan in Progress"),
                tr("A scan is currently running. Do you want to stop it and exit?"),
                QMessageBox::Yes | QMessageBox::No);

            if (reply == QMessageBox::No)
            {
                qDebug() << "[MainWindow] ❌ Benutzer hat Beenden abgebrochen";
                event->ignore();
                return;
            }

            qDebug() << "[MainWindow] 🛑 Stoppe Scanner vor Beenden...";
            m_scanner->stopScan();
        }
        
        // ✅ 2. NetworkScanner sicher stoppen
        if (m_networkScanner) {
            qDebug() << "[MainWindow] 📡 Stoppe NetworkScanner vor Beenden...";
            // NetworkScanner hat automatische Timer-Bereinigung
        }
        
        // ✅ 3. ActivityIndicator sicher stoppen
        if (m_activityIndicator) {
            qDebug() << "[MainWindow] ⏰ Stoppe ActivityIndicator vor Beenden...";
            // ActivityIndicator hat automatische Timer-Bereinigung
        }

        // ✅ 4. Settings sicher speichern
        qDebug() << "[MainWindow] 💾 Speichere Settings vor Beenden...";
        saveSettings();
        
        qDebug() << "[MainWindow] ✅ closeEvent erfolgreich - Anwendung kann sicher beendet werden";
        event->accept();
        
    } catch (const std::exception& e) {
        qDebug() << "[MainWindow] ❌ Exception in closeEvent:" << e.what();
        // Trotz Fehler sicher beenden
        event->accept();
    } catch (...) {
        qDebug() << "[MainWindow] ❌ Unknown exception in closeEvent";
        // Trotz Fehler sicher beenden
        event->accept();
    }
}

void MainWindow::startProductionScan()
{
    // ✅ PRODUCTION: Start real duplicate scan with user-selected directories
    if (m_selectedDirectories.isEmpty())
    {
        statusBar()->showMessage("⚠️ Keine Verzeichnisse ausgewählt - bitte wählen Sie Scan-Pfade");
        std::cout << "[MainWindow] ⚠️ Keine Verzeichnisse für Scan ausgewählt" << std::endl;
        return;
    }

    // Starte echten Duplicate Scan mit ausgewählten Verzeichnissen
    if (m_scanner)
    {
        m_scanner->startScan(m_selectedDirectories, "SHA256", "All Files");
        statusBar()->showMessage(QString("🔍 Produktions-Scan gestartet für %1 Verzeichnisse").arg(m_selectedDirectories.size()));
        std::cout << "[MainWindow] 🎯 PRODUKTIONS Duplicate Scan gestartet für " << m_selectedDirectories.size() << " Verzeichnisse" << std::endl;
        
        for (const QString &dir : m_selectedDirectories) {
            std::cout << "  📂 " << dir.toUtf8().constData() << std::endl;
        }
    }
    else
    {
        std::cout << "[MainWindow] ❌ Scanner nicht initialisiert!" << std::endl;
        statusBar()->showMessage("❌ Scanner-Fehler: Nicht initialisiert");
    }
}

void MainWindow::createProductionWorkspace()
{
    // ✅ PRODUCTION: Setup working directories for real scanning
    QString workDir = QDir::currentPath() + "/scanner_workspace";
    QDir().mkpath(workDir);
    
    // Create cache directories for hash storage and FTP temp files
    QDir().mkpath(workDir + "/hash_cache");
    QDir().mkpath(workDir + "/ftp_temp");
    QDir().mkpath(workDir + "/results");
    
    std::cout << "[MainWindow] ✅ Produktions-Workspace erstellt: " << workDir.toUtf8().constData() << std::endl;
    statusBar()->showMessage("✅ Produktions-Workspace bereit für echte Scans");
}

// ✅ ECHTE HILFSFUNKTION: Prüft ob Verzeichnis Unterverzeichnisse hat
bool MainWindow::hasSubdirectories(const QString &path)
{
    QDir dir(path);
    if (!dir.exists() || !dir.isReadable()) {
        return false;
    }
    
    // Schnelle Prüfung: Mindestens ein Unterverzeichnis vorhanden?
    QFileInfoList entries = dir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name);
    return !entries.isEmpty();
}

// ✅ Hardware Monitor Setup (private method implementation)
void MainWindow::setupBottomHardwareMonitor()
{
    qDebug() << "[MainWindow] ✅ setupBottomHardwareMonitor() - Legacy compatibility method";
    // This method exists for MOC compatibility but actual setup is done inline in setupProgrammaticGUI()
}

// ✅ Results Table Context Menu Implementation
void MainWindow::showResultsContextMenu(const QPoint &pos)
{
    // Öffne Kontextmenü auch wenn auf leere Fläche geklickt wurde
    // (früher: nur auf Items → wir erlauben jetzt globale Aktionen wie "Alle Duplikate entfernen")
    QMenu contextMenu(this);

    // Auto-select row under cursor on right-click if it's not already selected
    QModelIndex idx = resultsTable->indexAt(pos);
    int rowUnderCursor = idx.isValid() ? idx.row() : -1;

    // Collect current selection
    QSet<int> selectedRowSet;
    for (QTableWidgetItem *it : resultsTable->selectedItems()) {
        if (it) selectedRowSet.insert(it->row());
    }

    if (rowUnderCursor >= 0 && !selectedRowSet.contains(rowUnderCursor)) {
        resultsTable->clearSelection();
        resultsTable->selectRow(rowUnderCursor);
        selectedRowSet.clear();
        selectedRowSet.insert(rowUnderCursor);
    }

    // Count duplicates vs originals in current results using hidden flag
    int totalDuplicates = 0;
    int totalOriginals = 0;
    for (int row = 0; row < resultsTable->rowCount(); ++row) {
        QTableWidgetItem *statusItem = resultsTable->item(row, 0); // Status column
        if (!statusItem) continue;
        bool isOriginal = statusItem->data(Qt::UserRole + 1).toBool();
        if (isOriginal) totalOriginals++; else totalDuplicates++;
    }

    // Count how many of the selection are duplicates (not originals)
    int selectedDuplicateCount = 0;
    for (int row : selectedRowSet) {
        QTableWidgetItem *statusItem = resultsTable->item(row, 0);
        if (!statusItem) continue;
        bool isOriginal = statusItem->data(Qt::UserRole + 1).toBool();
        if (!isOriginal) selectedDuplicateCount++;
    }

    // Context menu actions - COPY FIRST!
    QAction *copyPathAction = contextMenu.addAction("📋 Pfad kopieren");
    QAction *copyAllPathsAction = contextMenu.addAction("📋 Alle Pfade kopieren");
    QAction *copyRowAction = contextMenu.addAction("📋 Zeile kopieren");
    QAction *copyAllAction = contextMenu.addAction("📋 Alles kopieren");
    
    contextMenu.addSeparator();
    
    QAction *deleteAllAction = contextMenu.addAction("🗑️ Alle Duplikate entfernen");
    QAction *deleteSelectedAction = contextMenu.addAction("🗑️ Markierte entfernen");

    contextMenu.addSeparator();

    QAction *infoAction = contextMenu.addAction(QString("📊 Info: %1 Duplikate, %2 Originale")
                                               .arg(totalDuplicates).arg(totalOriginals));
    infoAction->setEnabled(false); // Info only

    // Enable/disable actions based on content
    copyPathAction->setEnabled(!selectedRowSet.isEmpty());
    copyAllPathsAction->setEnabled(resultsTable->rowCount() > 0);
    copyRowAction->setEnabled(!selectedRowSet.isEmpty());
    copyAllAction->setEnabled(resultsTable->rowCount() > 0);
    deleteAllAction->setEnabled(totalDuplicates > 0);
    deleteSelectedAction->setEnabled(selectedDuplicateCount > 0);

    // Execute selected action
    QAction *selectedAction = contextMenu.exec(resultsTable->mapToGlobal(pos));

    if (selectedAction == copyPathAction) {
        // Copy selected paths to clipboard
        QStringList paths;
        for (int row : selectedRowSet) {
            QTableWidgetItem *pathItem = resultsTable->item(row, 2); // Path column
            if (pathItem) paths.append(pathItem->text());
        }
        QApplication::clipboard()->setText(paths.join("\n"));
        statusBar()->showMessage(tr("📋 %1 Pfade kopiert").arg(paths.size()), 2000);
        
    } else if (selectedAction == copyAllPathsAction) {
        // Copy all paths to clipboard
        QStringList paths;
        for (int row = 0; row < resultsTable->rowCount(); ++row) {
            QTableWidgetItem *pathItem = resultsTable->item(row, 2);
            if (pathItem) paths.append(pathItem->text());
        }
        QApplication::clipboard()->setText(paths.join("\n"));
        statusBar()->showMessage(tr("📋 %1 Pfade kopiert").arg(paths.size()), 2000);
        
    } else if (selectedAction == copyRowAction) {
        // Copy selected rows as tab-separated values
        QStringList rows;
        QList<int> sortedRows = selectedRowSet.values();
        std::sort(sortedRows.begin(), sortedRows.end());
        for (int row : sortedRows) {
            QStringList cells;
            for (int col = 0; col < resultsTable->columnCount(); ++col) {
                QTableWidgetItem *item = resultsTable->item(row, col);
                cells.append(item ? item->text() : "");
            }
            rows.append(cells.join("\t"));
        }
        QApplication::clipboard()->setText(rows.join("\n"));
        statusBar()->showMessage(tr("📋 %1 Zeilen kopiert").arg(rows.size()), 2000);
        
    } else if (selectedAction == copyAllAction) {
        // Copy entire table with headers
        QStringList output;
        // Headers
        QStringList headers;
        for (int col = 0; col < resultsTable->columnCount(); ++col) {
            headers.append(resultsTable->horizontalHeaderItem(col)->text());
        }
        output.append(headers.join("\t"));
        // All rows
        for (int row = 0; row < resultsTable->rowCount(); ++row) {
            QStringList cells;
            for (int col = 0; col < resultsTable->columnCount(); ++col) {
                QTableWidgetItem *item = resultsTable->item(row, col);
                cells.append(item ? item->text() : "");
            }
            output.append(cells.join("\t"));
        }
        QApplication::clipboard()->setText(output.join("\n"));
        statusBar()->showMessage(tr("📋 Komplette Tabelle kopiert (%1 Zeilen)").arg(resultsTable->rowCount()), 2000);
        
    } else if (selectedAction == deleteAllAction) {
        deleteAllDuplicates();
    } else if (selectedAction == deleteSelectedAction) {
        deleteSelectedDuplicates();
    }
}

void MainWindow::deleteAllDuplicates()
{
    if (m_currentDuplicateGroups.groups.isEmpty()) {
        QMessageBox::information(this, "Keine Duplikate", 
            "Es wurden noch keine Duplikate gefunden.\n"
            "Führen Sie zuerst einen Scan durch.");
        return;
    }
    
    // Collect all duplicate and original files
    QStringList duplicateFiles;
    QStringList originalFiles;
    
    for (const auto &group : m_currentDuplicateGroups.groups) {
        // Add original file to protected list
        originalFiles.append(group.original.filePath);
        
        // Add all duplicates to deletion list
        for (const auto &duplicate : group.duplicates) {
            duplicateFiles.append(duplicate.filePath);
        }
    }
    
    // 🛑 PAUSE Scanner to prevent race condition during deletion
    if (m_scanner && m_scanner->isScanning()) {
        qDebug() << "[MainWindow] ⏸️ Pausiere Scanner für sichere Deletion";
        m_scanner->pauseScan();
    }
    
    // Show deletion dialog
    DuplicateDeleteDialog *dialog = new DuplicateDeleteDialog(this);
    dialog->setPresetManager(m_presetManager);
    dialog->setDeletionMode("Alle Duplikate");
    dialog->setFileList(duplicateFiles, originalFiles);
    
    connect(dialog, &DuplicateDeleteDialog::deletionCompleted,
            this, &MainWindow::onDeletionCompleted);
    
    dialog->exec();
    dialog->deleteLater();
    
    // 🔄 RESUME Scanner after dialog closed
    if (m_scanner && !m_scanner->isScanning()) {
        qDebug() << "[MainWindow] ▶️ Setze Scanner fort nach Deletion";
        m_scanner->resumeScan();
    }
}

void MainWindow::deleteSelectedDuplicates()
{
    QList<QTableWidgetItem*> selectedItems = resultsTable->selectedItems();
    if (selectedItems.isEmpty()) {
        QMessageBox::information(this, "Keine Auswahl", 
            "Bitte wählen Sie die zu löschenden Dateien aus.");
        return;
    }
    
    // Get selected file paths
    QStringList selectedFiles;
    QStringList originalFiles;
    QSet<int> selectedRows;
    
    for (QTableWidgetItem *item : selectedItems) {
        selectedRows.insert(item->row());
    }
    
    for (int row : selectedRows) {
        QTableWidgetItem *pathItem = resultsTable->item(row, 2); // Path column
        QTableWidgetItem *statusItem = resultsTable->item(row, 0); // Status column
        if (pathItem && statusItem) {
            QString filePath = pathItem->data(Qt::UserRole).toString();
            if (filePath.isEmpty()) {
                // Fallback to visible text if no stored path
                filePath = pathItem->text();
            }
            selectedFiles.append(filePath);
            bool isOriginal = statusItem->data(Qt::UserRole + 1).toBool();
            if (isOriginal) {
                originalFiles.append(filePath);
            }
        }
    }
    
    if (selectedFiles.isEmpty()) {
        QMessageBox::information(this, "Keine gültigen Dateien", 
            "Die ausgewählten Zeilen enthalten keine gültigen Dateipfade.");
        return;
    }
    
    // 🛑 PAUSE Scanner to prevent race condition during deletion
    if (m_scanner && m_scanner->isScanning()) {
        qDebug() << "[MainWindow] ⏸️ Pausiere Scanner für sichere Deletion (selected)";
        m_scanner->pauseScan();
    }
    
    // Show deletion dialog
    DuplicateDeleteDialog *dialog = new DuplicateDeleteDialog(this);
    dialog->setPresetManager(m_presetManager);
    dialog->setDeletionMode("Markierte Dateien");
    dialog->setFileList(selectedFiles, originalFiles);
    
    connect(dialog, &DuplicateDeleteDialog::deletionCompleted,
            this, &MainWindow::onDeletionCompleted);
    
    dialog->exec();
    dialog->deleteLater();
    
    // 🔄 RESUME Scanner after dialog closed
    if (m_scanner && !m_scanner->isScanning()) {
        qDebug() << "[MainWindow] ▶️ Setze Scanner fort nach Deletion (selected)";
        m_scanner->resumeScan();
    }
}

void MainWindow::onDeletionCompleted(const DeletionResult &result)
{
    // Update status bar with deletion results
    QString statusMessage = QString("✅ %1 Duplikate gelöscht, %2 freigeworden - %3 Originale geschützt")
                           .arg(result.duplicateFilesDeleted)
                           .arg(formatFileSize(result.totalBytesFreed))
                           .arg(result.originalFilesProtected);
    
    statusBar()->showMessage(statusMessage, 10000); // Show for 10 seconds
    
    // Refresh the results table by removing deleted files
    for (const QString &deletedFile : result.deletedFiles) {
        // 🔐 Entferne gelöschte Datei aus Hash-Cache
        if (m_scanner) {
            m_scanner->removeFromHashCache(deletedFile);
        }
        
        for (int row = resultsTable->rowCount() - 1; row >= 0; --row) {
            QTableWidgetItem *pathItem = resultsTable->item(row, 2);
            if (!pathItem) continue;
            const QString storedFullPath = pathItem->data(Qt::UserRole).toString();
            const QString visiblePath = pathItem->text();
            if (deletedFile == storedFullPath || deletedFile == visiblePath) {
                resultsTable->removeRow(row);
                qDebug() << "[MainWindow] 🗑️ Entfernte Zeile für gelöschte Datei:" << deletedFile;
            }
        }
    }
    
    // Update duplicate groups to remove deleted files
    for (auto &group : m_currentDuplicateGroups.groups) {
        for (const QString &deletedFile : result.deletedFiles) {
            auto it = std::remove_if(group.duplicates.begin(), group.duplicates.end(),
                [&deletedFile](const FileInfo &file) {
                    return file.filePath == deletedFile;
                });
            group.duplicates.erase(it, group.duplicates.end());
        }
    }
    
    qDebug() << "[MainWindow] ✅ Duplikat-Löschung abgeschlossen:"
             << result.duplicateFilesDeleted << "gelöscht,"
             << result.originalFilesProtected << "geschützt";
    
    // 🗑️ JETZT Hash-Indizes löschen - Duplikate wurden gelöscht, Hashes nicht mehr benötigt
    if (m_scanner && result.duplicateFilesDeleted > 0) {
        qDebug() << "[MainWindow] 🗑️ Lösche Hash-Indizes nach Duplikat-Löschung...";
        m_scanner->clearAllHashes();
        
        // 💾 Hash-Cache nach Löschung aktualisieren
        qDebug() << "[MainWindow] 💾 Speichere aktuellen Hash-Cache nach Löschung...";
        m_scanner->saveHashCache();
        
        qDebug() << "[MainWindow] ✅ Hash-Indizes freigegeben + Cache aktualisiert - Memory bereinigt";
    }
}

// ✅ ECHTE IMPLEMENTIERUNGEN FÜR FEHLENDE FUNKTIONEN

void MainWindow::deleteDuplicateFiles(const QStringList &filePaths)
{
    qDebug() << "[MainWindow] 🗑️ deleteDuplicateFiles gestartet mit" << filePaths.size() << "Dateien";
    
    if (filePaths.isEmpty()) {
        statusBar()->showMessage("Keine Dateien zum Löschen ausgewählt", 3000);
        return;
    }
    
    // Bestätigungsdialog
    int result = QMessageBox::question(this, 
        tr("Dateien löschen"), 
        tr("Möchten Sie wirklich %1 Dateien löschen?").arg(filePaths.size()),
        QMessageBox::Yes | QMessageBox::No,
        QMessageBox::No);
    
    if (result != QMessageBox::Yes) {
        statusBar()->showMessage("Löschvorgang abgebrochen", 3000);
        return;
    }
    
    // 🚀 PARALLEL DELETE: Trennung von lokalen und FTP-Dateien
    QStringList localFiles;
    QStringList ftpFiles;
    
    for (const QString &filePath : filePaths) {
        if (filePath.startsWith("ftp://")) {
            ftpFiles.append(filePath);
        } else {
            localFiles.append(filePath);
        }
    }
    
    // Lokale Dateien sofort löschen (schnell)
    int deletedCount = 0;
    for (const QString &filePath : localFiles) {
        QFile file(filePath);
        if (file.remove()) {
            deletedCount++;
            qDebug() << "[MainWindow] ✅ Lokale Datei gelöscht:" << filePath;
        } else {
            qDebug() << "[MainWindow] ❌ Fehler beim Löschen:" << filePath;
        }
    }
    
    // FTP-Dateien parallel löschen (50 gleichzeitig)
    if (!ftpFiles.isEmpty()) {
        deleteFtpFilesParallel(ftpFiles);
        statusBar()->showMessage(tr("🚀 Lösche %1 lokale + %2 FTP-Dateien parallel...").arg(deletedCount).arg(ftpFiles.size()), 5000);
    } else {
        statusBar()->showMessage(tr("✅ %1 lokale Dateien gelöscht").arg(deletedCount), 5000);
    }
}

bool MainWindow::deleteFtpFileSync(const QString &ftpPath)
{
    qDebug() << "[MainWindow] 📡 deleteFtpFileSync:" << ftpPath;
    
    QUrl url(ftpPath);
    QString host = url.host();
    QString remotePath = url.path();
    
    // Hole Login-Daten
    if (m_presetManager) {
        LoginData login = m_presetManager->getLogin(host, 21);
        if (login.isValid()) {
            FtpClient *ftpClient = new FtpClient(this);
            ftpClient->setCredentials(host, 21, login.username, login.password);
            
            bool success = false;
            connect(ftpClient, &FtpClient::removeFinished, this, 
                [this, ftpPath, ftpClient, &success](const QString &file, bool result) {
                    success = result;
                    if (result) {
                        qDebug() << "[MainWindow] ✅ FTP-Datei gelöscht:" << ftpPath;
                        statusBar()->showMessage(tr("FTP-Datei gelöscht: %1").arg(file), 3000);
                    } else {
                        qDebug() << "[MainWindow] ❌ FTP-Löschen fehlgeschlagen:" << ftpPath;
                        statusBar()->showMessage(tr("FTP-Löschen fehlgeschlagen: %1").arg(file), 5000);
                    }
                    ftpClient->deleteLater();
                });
            
            ftpClient->remove(remotePath);
            return success;
        } else {
            qDebug() << "[MainWindow] ❌ Keine FTP-Login-Daten für" << host;
            statusBar()->showMessage(tr("Keine FTP-Login-Daten für %1").arg(host), 5000);
            return false;
        }
    }
    return false;
}

void MainWindow::deleteFtpFilesParallel(const QStringList &ftpPaths)
{
    qDebug() << "[MainWindow] 🚀 deleteFtpFilesParallel:" << ftpPaths.size() << "Dateien";
    
    if (ftpPaths.isEmpty()) {
        statusBar()->showMessage("Keine FTP-Dateien zum Löschen", 3000);
        return;
    }
    
    // ThreadPool auf 50 setzen (wie beim Scannen)
    QThreadPool *pool = QThreadPool::globalInstance();
    if (pool->maxThreadCount() < 50) {
        pool->setMaxThreadCount(50);
        qDebug() << "[MainWindow] 🚀 ThreadPool erhöht auf 50 parallele Löschvorgänge";
    }
    
    int totalFiles = ftpPaths.size();
    // Use shared_ptr for thread-safe counter access
    auto completedFiles = std::make_shared<std::atomic<int>>(0);
    auto successCount = std::make_shared<std::atomic<int>>(0);
    
    for (const QString &ftpPath : ftpPaths) {
        QUrl url(ftpPath);
        QString host = url.host();
        QString remotePath = url.path();
        
        qDebug() << "[MainWindow] 📡 Lösche FTP-Datei:" << remotePath << "auf" << host;
        
        if (m_presetManager) {
            LoginData login = m_presetManager->getLogin(host, 21);
            if (login.isValid()) {
                // Callback für Completion
                auto callback = [this, totalFiles, completedFiles, successCount, ftpPath](const QString &/*file*/, bool success) {
                    int completed = ++(*completedFiles);
                    if (success) {
                        ++(*successCount);
                        qDebug() << "[MainWindow] ✅ FTP-Datei gelöscht:" << ftpPath;
                    } else {
                        qDebug() << "[MainWindow] ❌ FTP-Löschen fehlgeschlagen:" << ftpPath;
                    }
                    
                    // Progress-Update im GUI-Thread
                    QMetaObject::invokeMethod(this, [this, completed, totalFiles, successCount]() {
                        statusBar()->showMessage(tr("🗑️ Löschen: %1/%2 (%3 erfolgreich)").arg(completed).arg(totalFiles).arg(successCount->load()), 2000);
                        
                        // Fertig?
                        if (completed >= totalFiles) {
                            statusBar()->showMessage(tr("✅ %1 von %2 FTP-Dateien gelöscht").arg(successCount->load()).arg(totalFiles), 5000);
                        }
                    }, Qt::QueuedConnection);
                };
                
                FtpDeleteWorker *worker = new FtpDeleteWorker(host, 21, login.username, login.password, remotePath, callback);
                pool->start(worker);
            } else {
                qWarning() << "[MainWindow] ❌ Keine Login-Daten für" << host;
            }
        }
    }
}

void MainWindow::selectAllDuplicatesInTable()
{
    qDebug() << "[MainWindow] 📋 selectAllDuplicatesInTable gestartet";
    
    if (!resultsTable) {
        qDebug() << "[MainWindow] ⚠️ resultsTable ist null";
        return;
    }
    
    int selectedCount = 0;
    for (int row = 0; row < resultsTable->rowCount(); ++row) {
        QTableWidgetItem *statusItem = resultsTable->item(row, 0);
        if (statusItem && statusItem->toolTip().contains("Duplicate")) {
            resultsTable->selectRow(row);
            selectedCount++;
        }
    }
    
    statusBar()->showMessage(tr("📋 %1 Duplikate ausgewählt").arg(selectedCount), 3000);
    qDebug() << "[MainWindow] ✅ selectAllDuplicatesInTable:" << selectedCount << "Duplikate ausgewählt";
}

void MainWindow::updateDuplicateResults(int totalFiles, int duplicateGroups)
{
    qDebug() << "[MainWindow] 📊 updateDuplicateResults:" << totalFiles << "Dateien," << duplicateGroups << "Gruppen";
    
    QString resultText = tr("📊 Scan-Ergebnisse: %1 Dateien analysiert, %2 Duplikatgruppen gefunden")
                        .arg(totalFiles).arg(duplicateGroups);
    
    if (statusBar()) {
        statusBar()->showMessage(resultText, 10000);
    }
    
    // Update GUI-Labels wenn vorhanden
    QLabel *resultLabel = findChild<QLabel*>("resultSummaryLabel");
    if (resultLabel) {
        resultLabel->setText(resultText);
    }
}

void MainWindow::startFtpNpuTest()
{
    qDebug() << "[MainWindow] 🧪 startFtpNpuTest gestartet - FTP + NPU Integration Test";
    
    if (!m_npuManager) {
        qDebug() << "[MainWindow] ⚠️ NPU Manager nicht verfügbar";
        statusBar()->showMessage("NPU Manager nicht verfügbar für Test", 5000);
        return;
    }
    
    statusBar()->showMessage("🧪 Starte FTP-NPU-Integrations-Test...", 3000);
    
    // Filtere FTP-Pfade aus den ausgewählten Verzeichnissen
    QStringList ftpPaths;
    for (const QString &dir : m_selectedDirectories) {
        if (dir.startsWith("ftp://")) {
            ftpPaths.append(dir);
        }
    }
    
    if (ftpPaths.isEmpty()) {
        statusBar()->showMessage("Keine FTP-Pfade für NPU-Test verfügbar", 5000);
        return;
    }
    
    qDebug() << "[MainWindow] 🧪 FTP-NPU-Test mit" << ftpPaths.size() << "FTP-Pfaden:" << ftpPaths;
    
    // Starte NPU-basierten Duplikat-Scan mit FTP-Integration
    if (m_scanner) {
        m_scanner->startScan(ftpPaths, "SHA256", "*.jpg,*.png,*.bmp,*.gif");
        statusBar()->showMessage("🧪 FTP-NPU-Test läuft...", 5000);
    }
}

void MainWindow::showCriticalErrorDialog(const QString &title, const QString &message)
{
    qDebug() << "[MainWindow] ❌ showCriticalErrorDialog:" << title << "-" << message;
    
    QMessageBox::critical(this, title, message);
    
    // Log kritischen Fehler
    qCritical() << "[MainWindow] CRITICAL ERROR:" << title << message;
}

void MainWindow::showFtpCredentialDialog(const QString &host, int port, const QString &service)
{
    qDebug() << "[MainWindow] 🔐 showFtpCredentialDialog für" << host << ":" << port << service;
    
    LoginDialog dialog(this);
    dialog.setServiceInfo(host, port, service);
    dialog.setWindowTitle(tr("FTP-Anmeldung erforderlich"));
    
    if (dialog.exec() == QDialog::Accepted) {
        LoginData loginData = dialog.getLoginData();
        
        if (loginData.saveCredentials && m_presetManager) {
            m_presetManager->saveLogin(host, port, loginData);
            qDebug() << "[MainWindow] 💾 FTP-Credentials gespeichert für" << host;
        }
        
        statusBar()->showMessage(tr("FTP-Anmeldung für %1 erfolgreich").arg(host), 3000);
    } else {
        statusBar()->showMessage(tr("FTP-Anmeldung für %1 abgebrochen").arg(host), 3000);
    }
}

void MainWindow::updateDownloadProgress(int current, int total, bool isComplete)
{
    if (!progressBar) return;
    
    if (isComplete) {
        progressBar->setValue(progressBar->maximum());
        statusBar()->showMessage(tr("✅ Download abgeschlossen: %1 Dateien").arg(total), 5000);
        qDebug() << "[MainWindow] ✅ Download abgeschlossen:" << total << "Dateien";
    } else {
        int percentage = (total > 0) ? (current * 100 / total) : 0;
        progressBar->setValue(percentage);
        statusBar()->showMessage(tr("📥 Download: %1/%2 (%3%)").arg(current).arg(total).arg(percentage));
        
        // Update File Count Label wenn vorhanden
        if (fileCountLabel) {
            fileCountLabel->setText(tr("📥 %1/%2 Dateien").arg(current).arg(total));
        }
    }
}

void MainWindow::requestFtpSubdirectoriesForDialog(const QString &host, const QString &path, SimpleTreeDialog *dialog)
{
    qDebug() << "[MainWindow] 🚀 requestFtpSubdirectoriesForDialog:" << host << path;
    
    if (!dialog || !m_presetManager) {
        qDebug() << "[MainWindow] ⚠️ Dialog oder PresetManager null";
        return;
    }
    
    LoginData loginData = m_presetManager->getLogin(host, 21);
    if (!loginData.isValid()) {
        qDebug() << "[MainWindow] ❌ Keine Login-Daten für" << host;
        return;
    }
    
    FtpClient *ftpClient = new FtpClient(this);
    ftpClient->setCredentials(host, 21, loginData.username, loginData.password);
    
    connect(ftpClient, &FtpClient::listFinished, this, 
        [this, host, path, dialog, ftpClient](const QStringList &subdirs, bool success) {
            if (success && dialog) {
                qDebug() << "[MainWindow] ✅ FTP-Unterverzeichnisse empfangen:" << subdirs.size();
                dialog->addSubdirectories(path, subdirs);
            } else {
                qDebug() << "[MainWindow] ❌ FTP-LIST fehlgeschlagen für" << path;
            }
            ftpClient->deleteLater();
        });
    
    connect(ftpClient, &FtpClient::connected, ftpClient, [ftpClient, path]() {
        qDebug() << "[FtpClient] 🚀 Verbunden - starte LIST für:" << path;
        ftpClient->list(path);
    });
    
    ftpClient->connectToHost();
}

// 📊 HashEngine Status-Updates in GUI anzeigen
void MainWindow::onHashEngineStatusUpdate(const QString &operation, const QString &details)
{
    // Aktualisiere StatusBar mit HashEngine-Aktivität
    QString statusMessage = QString("🔧 %1: %2").arg(operation, details);
    
    // Für Hardware-Tests länger anzeigen, für andere kurz
    int displayTime = 10000;  // 10 Sekunden Standard
    if (operation.contains("Hardware") || operation.contains("GPU") || operation.contains("NPU") || 
        operation.contains("Test") || operation.contains("Erkenn") || operation.contains("Load")) {
        displayTime = 15000;  // 15 Sekunden für Hardware-Tests
    }
    
    // StatusBar aktualisieren
    statusBar()->showMessage(statusMessage, displayTime);
    
    // ZUSÄTZLICH: Auch das Hauptfenster-Title aktualisieren für bessere Sichtbarkeit
    QString windowTitle = QString("FileDuper - %1").arg(statusMessage);
    setWindowTitle(windowTitle);
    
    // Optional: Ausgabe für Debug
    qDebug() << "[GUI] HashEngine Status:" << operation << "-" << details;
    
    // GUI mehrfach aktualisieren für bessere Sichtbarkeit
    // REMOVED: QApplication::processEvents();
    update();
    repaint();
    
    // Kurze Pause für GUI-Update
    QThread::msleep(100);
}

// 🧠 INTELLIGENTE SERVICE-KATEGORISIERUNG
QString MainWindow::categorizeIntelligentService(const QString &service, int port)
{
    if (service.contains("FTP") || port == 21) return "🗂️ File Transfer (FTP/SFTP)";
    if (service.contains("SSH") || service.contains("SFTP") || port == 22) return "🗂️ File Transfer (FTP/SFTP)";
    if (service.contains("SMB") || service.contains("CIFS") || port == 445 || port == 139) return "🗂️ File Transfer (FTP/SFTP)";
    if (service.contains("NFS") || port == 2049) return "🗂️ File Transfer (FTP/SFTP)";
    if (service.contains("HTTP") || port == 80 || port == 443) return "🌐 Web Services";
    if (service.contains("Telnet") || port == 23) return "🔧 Management Services";
    if (service.contains("SNMP") || port == 161) return "🔧 Management Services";
    if (service.contains("Database") || port == 3306 || port == 5432) return "🗄️ Database Services";
    return "🔍 Other Services";
}

QString MainWindow::calculateServicePriority(const QString &service, int port, const QString &/*ip*/)
{
    int score = getPriorityScore(service, port);
    if (score >= 9) return "🔥 Sehr Hoch";
    if (score >= 7) return "⚡ Hoch";
    if (score >= 5) return "📊 Mittel";
    if (score >= 3) return "📝 Niedrig";
    return "⏸️ Info";
}

int MainWindow::getPriorityScore(const QString &service, int port)
{
    // FTP/SFTP = Höchste Priorität für File Duper
    if (service.contains("FTP") || port == 21) return 10;
    if (service.contains("SFTP") || port == 22) return 9;
    if (service.contains("SMB") || service.contains("CIFS")) return 8;
    if (service.contains("NFS")) return 7;
    if (service.contains("HTTP") && port == 80) return 4;
    if (service.contains("HTTPS") && port == 443) return 5;
    return 2;
}

QString MainWindow::getServiceIcon(const QString &service, int port)
{
    if (service.contains("FTP") || port == 21) return "📁";
    if (service.contains("SSH") || service.contains("SFTP") || port == 22) return "🔐";
    if (service.contains("SMB") || service.contains("CIFS")) return "🗂️";
    if (service.contains("NFS")) return "📂";
    if (service.contains("HTTP") || port == 80) return "🌐";
    if (service.contains("HTTPS") || port == 443) return "🔒";
    return "🔧";
}

QString MainWindow::getAuthenticationStatus(const QString &ip, int port)
{
    if (m_presetManager) {
        auto login = m_presetManager->getLogin(ip, port);
        if (!login.username.isEmpty()) {
            return QString("✅ %1").arg(login.username);
        }
    }
    return "❌ Kein Login";
}

QTreeWidgetItem* MainWindow::findOrCreateCategory(const QString &category)
{
    // Suche existierende Kategorie
    for (int i = 0; i < networkTree->topLevelItemCount(); ++i) {
        QTreeWidgetItem *item = networkTree->topLevelItem(i);
        if (item->text(0) == category) {
            return item;
        }
    }
    
    // Erstelle neue Kategorie
    QTreeWidgetItem *categoryItem = new QTreeWidgetItem(networkTree);
    categoryItem->setText(0, category);
    categoryItem->setText(1, "Kategorie");
    categoryItem->setText(4, "🏷️ Gruppe");
    categoryItem->setExpanded(false);
    
    // Styling für Kategorie
    QFont categoryFont = categoryItem->font(0);
    categoryFont.setBold(true);
    categoryFont.setPointSize(14);
    categoryItem->setFont(0, categoryFont);
    categoryItem->setBackground(0, QColor(75, 85, 105, 100));
    
    return categoryItem;
}

QTreeWidgetItem* MainWindow::findOrCreateServer(QTreeWidgetItem *categoryItem, const QString &ip)
{
    // Suche existierenden Server in der Kategorie
    for (int i = 0; i < categoryItem->childCount(); ++i) {
        QTreeWidgetItem *child = categoryItem->child(i);
        if (child->data(0, Qt::UserRole).toString() == ip) {
            return child;
        }
    }
    
    // Erstelle neuen Server
    QTreeWidgetItem *serverItem = new QTreeWidgetItem(categoryItem);
    serverItem->setText(0, QString("🖥️ %1").arg(ip));
    serverItem->setText(1, "Server");
    serverItem->setText(4, "🏠 Host");
    serverItem->setData(0, Qt::UserRole, ip);
    serverItem->setExpanded(false);
    
    // Server-Styling
    QFont serverFont = serverItem->font(0);
    serverFont.setBold(true);
    serverItem->setFont(0, serverFont);
    serverItem->setBackground(0, QColor(59, 130, 246, 50));
    
    return serverItem;
}

void MainWindow::applyIntelligentServiceStyling(QTreeWidgetItem *serviceItem, const QString &service, int port)
{
    // Prioritäts-basierte Styling
    int priority = getPriorityScore(service, port);
    
    if (priority >= 9) {
        serviceItem->setBackground(0, QColor(239, 68, 68, 80));  // Rot für höchste Priorität
        serviceItem->setForeground(0, QColor(255, 255, 255));
    } else if (priority >= 7) {
        serviceItem->setBackground(0, QColor(245, 158, 11, 80)); // Orange für hohe Priorität
        serviceItem->setForeground(0, QColor(255, 255, 255));
    } else if (priority >= 5) {
        serviceItem->setBackground(0, QColor(59, 130, 246, 80)); // Blau für mittlere Priorität
    } else {
        serviceItem->setBackground(0, QColor(107, 114, 128, 50)); // Grau für niedrige Priorität
    }
}

void MainWindow::updateNetworkStatistics()
{
    int totalServices = 0;
    int fileTransferServices = 0;
    int authenticatedServices = 0;
    
    for (int i = 0; i < networkTree->topLevelItemCount(); ++i) {
        QTreeWidgetItem *category = networkTree->topLevelItem(i);
        for (int j = 0; j < category->childCount(); ++j) {
            QTreeWidgetItem *server = category->child(j);
            for (int k = 0; k < server->childCount(); ++k) {
                QTreeWidgetItem *service = server->child(k);
                totalServices++;
                
                QString serviceName = service->text(1);
                if (serviceName.contains("FTP") || serviceName.contains("SFTP") || 
                    serviceName.contains("SMB") || serviceName.contains("NFS")) {
                    fileTransferServices++;
                }
                
                if (service->text(2).contains("✅")) {
                    authenticatedServices++;
                }
            }
        }
    }
    
    // Update Status in der ersten Kategorie
    if (networkTree->topLevelItemCount() > 0) {
        QTreeWidgetItem *firstCategory = networkTree->topLevelItem(0);
        firstCategory->setText(3, QString("📊 %1 Services").arg(totalServices));
    }
}

// 🚀 ECHTZEIT HARDWARE-MONITORING IMPLEMENTATION
void MainWindow::updateHardwareMonitoring()
{
    // CPU Load auslesen
    int cpuLoad = getCurrentCpuLoad();
    updateCpuDisplay(cpuLoad);
    
    // GPU Load auslesen (wenn aktiv)
    int gpuLoad = getCurrentGpuLoad();
    updateGpuDisplay(gpuLoad);
    
    // NPU Load auslesen (wenn aktiv)
    int npuLoad = getCurrentNpuLoad();
    updateNpuDisplay(npuLoad);
}

int MainWindow::getCurrentCpuLoad()
{
    // Linux: /proc/stat auslesen
    static qint64 lastTotalTime = 0;
    static qint64 lastIdleTime = 0;
    
    QFile file("/proc/stat");
    if (!file.open(QIODevice::ReadOnly)) {
        return 0;
    }
    
    QString line = file.readLine();
    file.close();
    
    // Parse "cpu" line: cpu user nice system idle iowait irq softirq
    QStringList parts = line.split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);
    if (parts.size() < 5) return 0;
    
    qint64 user = parts[1].toLongLong();
    qint64 nice = parts[2].toLongLong();
    qint64 system = parts[3].toLongLong();
    qint64 idle = parts[4].toLongLong();
    
    qint64 totalTime = user + nice + system + idle;
    qint64 idleTime = idle;
    
    if (lastTotalTime == 0) {
        lastTotalTime = totalTime;
        lastIdleTime = idleTime;
        return 0;
    }
    
    qint64 totalDelta = totalTime - lastTotalTime;
    qint64 idleDelta = idleTime - lastIdleTime;
    
    lastTotalTime = totalTime;
    lastIdleTime = idleTime;
    
    if (totalDelta == 0) return 0;
    
    int cpuUsage = 100 - (idleDelta * 100 / totalDelta);
    return qBound(0, cpuUsage, 100);
}

int MainWindow::getCurrentGpuLoad()
{
    // 🎮 ECHTZEIT GPU-AUSLASTUNG: Intel Arrow Lake-S Graphics
    static int minFreq = -1;
    static int maxFreq = -1;
    static QString cardPath;
    
    // Auto-Detect GPU card beim ersten Aufruf (card0 oder card1)
    if (maxFreq == -1) {
        // Probiere card1 (Arrow Lake-S), dann card0 (ältere Intel GPUs)
        QStringList cardPaths = {"/sys/class/drm/card1", "/sys/class/drm/card0"};
        
        for (const QString &testPath : cardPaths) {
            QFile maxFile(testPath + "/gt_max_freq_mhz");
            QFile minFile(testPath + "/gt_min_freq_mhz");
            
            if (maxFile.exists() && minFile.exists()) {
                cardPath = testPath;
                
                if (maxFile.open(QIODevice::ReadOnly)) {
                    maxFreq = maxFile.readAll().trimmed().toInt();
                    maxFile.close();
                }
                
                if (minFile.open(QIODevice::ReadOnly)) {
                    minFreq = minFile.readAll().trimmed().toInt();
                    minFile.close();
                }
                
                qDebug() << "[GPU] ✅ Intel GPU gefunden:" << cardPath;
                qDebug() << "[GPU] 🎮 Min:" << minFreq << "MHz, Max:" << maxFreq << "MHz";
                break;
            }
        }
        
        if (cardPath.isEmpty()) {
            qDebug() << "[GPU] ❌ Keine Intel GPU gefunden (card0/card1)";
            return 0;
        }
    }
    
    // Lese aktuelle Frequenz
    QFile curFile(cardPath + "/gt_cur_freq_mhz");
    if (curFile.open(QIODevice::ReadOnly)) {
        int curFreq = curFile.readAll().trimmed().toInt();
        curFile.close();
        
        if (maxFreq > 0 && minFreq >= 0 && curFreq > 0) {
            // Berechne Prozent basierend auf Frequenz-Range
            int load = ((curFreq - minFreq) * 100) / (maxFreq - minFreq);
            load = qBound(0, load, 100);
            
            // Debug nur bei Änderung > 5%
            static int lastLoad = -1;
            if (abs(load - lastLoad) > 5) {
                qDebug() << "[GPU] 🎮 ECHTZEIT:" << curFreq << "MHz →" << load << "%";
                lastLoad = load;
            }
            
            return load;
        }
    }
    
    return 0; // GPU nicht verfügbar oder idle
}

int MainWindow::getCurrentNpuLoad()
{
    // 🧠 ECHTZEIT NPU-AUSLASTUNG: Intel VPU Detection
    
    // Intel NPU/VPU: /sys/class/misc/intel_vpu0/device/power_state
    static bool npuChecked = false;
    static bool npuAvailable = false;
    static QString npuPath;
    
    // Einmalige NPU-Detection beim Start
    if (!npuChecked) {
        QDir vpu("/sys/class/misc");
        QStringList vpuDevices = vpu.entryList(QStringList() << "intel_vpu*", QDir::Dirs);
        
        if (!vpuDevices.isEmpty()) {
            npuPath = QString("/sys/class/misc/%1/device/power_state").arg(vpuDevices.first());
            npuAvailable = QFile::exists(npuPath);
            qDebug() << "[NPU] 🧠 Intel VPU gefunden:" << vpuDevices.first() << "→" << npuPath;
        }
        
        npuChecked = true;
    }
    
    // Prüfe NPU Power State
    if (npuAvailable) {
        QFile powerFile(npuPath);
        if (powerFile.open(QIODevice::ReadOnly)) {
            QString state = powerFile.readAll().trimmed();
            powerFile.close();
            
            // Debug bei State-Änderung
            static QString lastState;
            if (state != lastState) {
                qDebug() << "[NPU] 🧠 Power State:" << state;
                lastState = state;
            }
            
            // D0/D1/D2 = Aktiv, D3 = Suspend
            if (state.startsWith("D0") || state.startsWith("D1") || state.startsWith("D2")) {
                return 80; // NPU aktiv
            } else if (state == "D3" || state == "off") {
                return 0; // NPU suspended
            }
        }
    }
    
    // Fallback: CPU-basierte Detection (wenn CPU niedrig aber Scanner läuft)
    if (m_scanner && m_scanner->isScanning()) {
        int cpuLoad = getCurrentCpuLoad();
        if (cpuLoad < 40) {
            // Scanner läuft aber CPU niedrig → NPU könnte arbeiten
            return 50;
        }
    }
    
    return 0; // Inaktiv oder nicht verfügbar
}

void MainWindow::updateCpuDisplay(int load)
{
    if (!cpuLoadLabel) return;
    
    QString text = QString("CPU: %1%").arg(load);
    cpuLoadLabel->setText(text);
    
    // Farb-Coding basierend auf Last
    QString color;
    if (load >= 90) {
        color = "#DC2626"; // Rot - KRITISCH (blinkend)
        cpuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-family: monospace; font-weight: bold; animation: blink 0.5s infinite; }").arg(color));
    } else if (load >= 70) {
        color = "#F59E0B"; // Orange - HOCH
        cpuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-family: monospace; font-weight: bold; }").arg(color));
    } else if (load >= 30) {
        color = "#FBBF24"; // Gelb - MODERAT
        cpuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-family: monospace; font-weight: bold; }").arg(color));
    } else {
        color = "#10B981"; // Grün - IDLE
        cpuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-family: monospace; font-weight: bold; }").arg(color));
    }
}

void MainWindow::updateGpuDisplay(int load)
{
    if (!gpuLoadLabel) return;
    
    if (load == 0) {
        gpuLoadLabel->setText("GPU: Inaktiv");
        gpuLoadLabel->setStyleSheet("QLabel { color: #6B7280; font-family: monospace; font-weight: bold; }");
    } else {
        QString text = QString("GPU: %1%").arg(load);
        gpuLoadLabel->setText(text);
        
        QString color;
        if (load >= 90) {
            color = "#DC2626"; // Rot
        } else if (load >= 70) {
            color = "#F59E0B"; // Orange
        } else {
            color = "#3B82F6"; // Blau (GPU aktiv)
        }
        gpuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-family: monospace; font-weight: bold; }").arg(color));
    }
}

void MainWindow::updateNpuDisplay(int load)
{
    if (!npuLoadLabel) return;
    
    if (load == 0) {
        npuLoadLabel->setText("NPU: Inaktiv");
        npuLoadLabel->setStyleSheet("QLabel { color: #6B7280; font-family: monospace; font-weight: bold; }");
    } else {
        QString text = QString("NPU: %1%").arg(load);
        npuLoadLabel->setText(text);
        
        QString color = "#8B5CF6"; // Lila für NPU (AI-Acceleration)
        npuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-family: monospace; font-weight: bold; }").arg(color));
    }
}

// ✅ HARDWARE STATUS SLOTS IMPLEMENTATION
void MainWindow::onHardwareStatusUpdate(bool hasSHANI, bool hasSHA512NI, bool hasAVX2, bool hasAVX512)
{
    m_hasShaNI = hasSHANI;
    m_hasSha512NI = hasSHA512NI;
    m_hasAVX2 = hasAVX2;
    m_hasAVX512 = hasAVX512;
    qDebug() << "[MainWindow] Hardware Update: SHA-NI=" << hasSHANI << "SHA512-NI=" << hasSHA512NI 
             << "AVX2=" << hasAVX2 << "AVX512=" << hasAVX512;
}

void MainWindow::onCpuStatusUpdated(int cores, int score) 
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateCpuStatus(cores, score);
    }
}

void MainWindow::onGpuStatusUpdated(bool available, const QString &name, int score)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateGpuStatus(available, name, score);
    }
}

void MainWindow::onGpuMemoryUpdated(int usedMB, int totalMB)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateGpuMemory(usedMB, totalMB);
    }
}

void MainWindow::onGpuClockUpdated(int clockMHz)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateGpuClock(clockMHz);
    }
}

void MainWindow::onGpuTemperatureUpdated(int tempC)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateGpuTemperature(tempC);
    }
}

void MainWindow::onNpuStatusUpdated(bool available, int score)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateNpuStatus(available, score);
    }
}

void MainWindow::onNpuActivityUpdated(int activeUnits, int totalUnits, const QString &currentTask)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateNpuActivity(activeUnits, totalUnits, currentTask);
    }
}

void MainWindow::onNpuPowerUpdated(int powerW)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateNpuPower(powerW);
    }
}

void MainWindow::onIoStatusUpdated(int score)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateIoStatus(score);
    }
}

void MainWindow::onMemoryStatusUpdated(int availableMB)
{
    if (m_hardwareStatusWidget) {
        m_hardwareStatusWidget->updateMemoryStatus(availableMB);
    }
}

// ✅ BENCHMARK MONITOR SLOTS
void MainWindow::onBenchmarkActivityLogged(const QString &activity, const QString &details)
{
    if (m_liveBenchmarkMonitor) {
        m_liveBenchmarkMonitor->onActivityLogged(activity, details);
    }
}

void MainWindow::onBenchmarkProgressUpdated(int filesProcessed, int filesHashed, int duplicatesFound)
{
    if (m_liveBenchmarkMonitor) {
        m_liveBenchmarkMonitor->onScanProgress(filesProcessed, filesHashed, duplicatesFound);
    }
}

void MainWindow::onBenchmarkSpeedUpdated(double /*filesPerSecond*/)
{
    // Speed calculation can be added here
}

void MainWindow::onBenchmarkTimeElapsedUpdated(int /*seconds*/)
{
    // Time tracking can be added here
}

// ✅ SETTINGS DIALOG
void MainWindow::onSettingsApplied(const QVariantMap &settings)
{
    qDebug() << "[MainWindow] Settings applied:" << settings;
    // Apply settings to scanner and other components
}


// 🎨 THEME MANAGEMENT: Handle theme selection changes
void MainWindow::onThemeChanged(int index)
{
    QStringList themes = {
        "System Default",
        "Light High Contrast",
        "Dark Blue",
        "Dark Green",
        "Dark Purple",
        "Dark Red/Orange",
        "Ice Blue",
        "Forest Green",
        "High Contrast BW",
        "Sakura Pink"
    };
    
    if (index >= 0 && index < themes.size()) {
        QString themeName = themes[index];
        qDebug() << "[MainWindow] 🎨 Theme gewechselt zu:" << themeName;
        applyTheme(themeName);
        saveThemeToSettings(themeName);
    }
}

// 🎨 APPLY THEME: Set application-wide stylesheet
void MainWindow::applyTheme(const QString &themeName)
{
    QString styleSheet;
    
    if (themeName == "System Default") {
        qApp->setStyleSheet(""); // Reset to default
        return;
    }
    else if (themeName == "Light High Contrast") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #FFFFFF; color: #000000; }
            QGroupBox { border: 3px solid #000000; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #F5F5F5; }
            QGroupBox::title { color: #000000; font-size: 14pt; }
            QPushButton { background-color: #E0E0E0; color: #000000; border: 2px solid #000000; padding: 8px; font-weight: bold; }
            QPushButton:hover { background-color: #2196F3; color: #FFFFFF; }
            QLineEdit, QComboBox { background-color: #FFFFFF; color: #000000; border: 2px solid #000000; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #FFFFFF; color: #000000; border: 2px solid #000000; }
            QLabel { color: #000000; }
            QProgressBar { border: 2px solid #000000; background-color: #E0E0E0; }
            QProgressBar::chunk { background-color: #2196F3; }
        )";
    }
    else if (themeName == "Dark Blue") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #1E1E2E; color: #CDD6F4; }
            QGroupBox { border: 2px solid #89B4FA; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #181825; }
            QGroupBox::title { color: #89B4FA; font-size: 13pt; }
            QPushButton { background-color: #313244; color: #CDD6F4; border: 2px solid #89B4FA; padding: 8px; }
            QPushButton:hover { background-color: #89B4FA; color: #1E1E2E; }
            QLineEdit, QComboBox { background-color: #313244; color: #CDD6F4; border: 2px solid #89B4FA; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #181825; color: #CDD6F4; border: 2px solid #89B4FA; }
            QHeaderView::section { background-color: #313244; color: #89B4FA; border: 1px solid #89B4FA; }
            QLabel { color: #CDD6F4; }
            QProgressBar { border: 2px solid #89B4FA; background-color: #313244; color: #FFFFFF; }
            QProgressBar::chunk { background-color: #89B4FA; }
        )";
    }
    else if (themeName == "Dark Green") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #1A1D1A; color: #A6E3A1; }
            QGroupBox { border: 2px solid #A6E3A1; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #11140F; }
            QGroupBox::title { color: #A6E3A1; font-size: 13pt; }
            QPushButton { background-color: #2D3A2E; color: #A6E3A1; border: 2px solid #A6E3A1; padding: 8px; }
            QPushButton:hover { background-color: #A6E3A1; color: #1A1D1A; }
            QLineEdit, QComboBox { background-color: #2D3A2E; color: #A6E3A1; border: 2px solid #A6E3A1; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #11140F; color: #A6E3A1; border: 2px solid #A6E3A1; }
            QHeaderView::section { background-color: #2D3A2E; color: #A6E3A1; border: 1px solid #A6E3A1; }
            QProgressBar { border: 2px solid #A6E3A1; background-color: #2D3A2E; color: #FFFFFF; }
            QProgressBar::chunk { background-color: #A6E3A1; }
        )";
    }
    else if (themeName == "Dark Purple") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #1E1E2E; color: #CBA6F7; }
            QGroupBox { border: 2px solid #CBA6F7; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #181825; }
            QGroupBox::title { color: #CBA6F7; font-size: 13pt; }
            QPushButton { background-color: #313244; color: #CBA6F7; border: 2px solid #CBA6F7; padding: 8px; }
            QPushButton:hover { background-color: #CBA6F7; color: #1E1E2E; }
            QLineEdit, QComboBox { background-color: #313244; color: #CBA6F7; border: 2px solid #CBA6F7; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #181825; color: #CBA6F7; border: 2px solid #CBA6F7; }
            QHeaderView::section { background-color: #313244; color: #CBA6F7; border: 1px solid #CBA6F7; }
            QProgressBar { border: 2px solid #CBA6F7; background-color: #313244; color: #FFFFFF; }
            QProgressBar::chunk { background-color: #CBA6F7; }
        )";
    }
    else if (themeName == "Dark Red/Orange") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #1E1616; color: #FAB387; }
            QGroupBox { border: 2px solid #F38BA8; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #181111; }
            QGroupBox::title { color: #F38BA8; font-size: 13pt; }
            QPushButton { background-color: #3A2626; color: #FAB387; border: 2px solid #F38BA8; padding: 8px; }
            QPushButton:hover { background-color: #F38BA8; color: #1E1616; }
            QLineEdit, QComboBox { background-color: #3A2626; color: #FAB387; border: 2px solid #F38BA8; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #181111; color: #FAB387; border: 2px solid #F38BA8; }
            QHeaderView::section { background-color: #3A2626; color: #F38BA8; border: 1px solid #F38BA8; }
            QProgressBar { border: 2px solid #F38BA8; background-color: #3A2626; color: #FFFFFF; }
            QProgressBar::chunk { background-color: #F38BA8; }
        )";
    }
    else if (themeName == "Ice Blue") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #E8F4F8; color: #0D47A1; }
            QGroupBox { border: 2px solid: #0277BD; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #B3E5FC; }
            QGroupBox::title { color: #0277BD; font-size: 13pt; }
            QPushButton { background-color: #B3E5FC; color: #0D47A1; border: 2px solid #0277BD; padding: 8px; }
            QPushButton:hover { background-color: #0277BD; color: #FFFFFF; }
            QLineEdit, QComboBox { background-color: #FFFFFF; color: #0D47A1; border: 2px solid #0277BD; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #FFFFFF; color: #0D47A1; border: 2px solid #0277BD; }
            QHeaderView::section { background-color: #B3E5FC; color: #0D47A1; border: 1px solid #0277BD; }
            QProgressBar { border: 2px solid #0277BD; background-color: #E0F7FA; color: #000000; }
            QProgressBar::chunk { background-color: #0277BD; }
        )";
    }
    else if (themeName == "Forest Green") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #0D1F0D; color: #76FF03; }
            QGroupBox { border: 2px solid #76FF03; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #1B5E20; }
            QGroupBox::title { color: #76FF03; font-size: 13pt; }
            QPushButton { background-color: #1B5E20; color: #76FF03; border: 2px solid #76FF03; padding: 8px; }
            QPushButton:hover { background-color: #76FF03; color: #0D1F0D; }
            QLineEdit, QComboBox { background-color: #1B5E20; color: #76FF03; border: 2px solid #76FF03; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #0D1F0D; color: #76FF03; border: 2px solid #76FF03; }
            QHeaderView::section { background-color: #1B5E20; color: #76FF03; border: 1px solid #76FF03; }
            QProgressBar { border: 2px solid #76FF03; background-color: #1B5E20; color: #FFFFFF; }
            QProgressBar::chunk { background-color: #76FF03; }
        )";
    }
    else if (themeName == "High Contrast BW") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #000000; color: #FFFFFF; }
            QGroupBox { border: 3px solid #FFFFFF; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #000000; }
            QGroupBox::title { color: #FFFFFF; font-size: 14pt; }
            QPushButton { background-color: #FFFFFF; color: #000000; border: 3px solid #FFFFFF; padding: 8px; font-weight: bold; }
            QPushButton:hover { background-color: #FFFF00; color: #000000; }
            QLineEdit, QComboBox { background-color: #000000; color: #FFFFFF; border: 3px solid #FFFFFF; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #000000; color: #FFFFFF; border: 3px solid #FFFFFF; }
            QHeaderView::section { background-color: #000000; color: #FFFFFF; border: 2px solid #FFFFFF; }
            QLabel { color: #FFFFFF; }
            QProgressBar { border: 3px solid #FFFFFF; background-color: #000000; color: #FFFFFF; }
            QProgressBar::chunk { background-color: #FFFFFF; }
        )";
    }
    else if (themeName == "Sakura Pink") {
        styleSheet = R"(
            QMainWindow, QWidget { background-color: #FFF0F5; color: #880E4F; }
            QGroupBox { border: 2px solid #E91E63; font-weight: bold; padding: 10px; margin-top: 10px; background-color: #FCE4EC; }
            QGroupBox::title { color: #C2185B; font-size: 13pt; }
            QPushButton { background-color: #F8BBD0; color: #880E4F; border: 2px solid #E91E63; padding: 8px; }
            QPushButton:hover { background-color: #E91E63; color: #FFFFFF; }
            QLineEdit, QComboBox { background-color: #FFFFFF; color: #880E4F; border: 2px solid #E91E63; padding: 5px; }
            QTreeWidget, QTableWidget { background-color: #FFFFFF; color: #880E4F; border: 2px solid #E91E63; }
            QHeaderView::section { background-color: #F8BBD0; color: #880E4F; border: 1px solid #E91E63; }
            QProgressBar { border: 2px solid #E91E63; background-color: #FCE4EC; color: #000000; }
            QProgressBar::chunk { background-color: #E91E63; }
        )";
    }
    
    qApp->setStyleSheet(styleSheet);
    qDebug() << "[MainWindow] 🎨 Theme angewendet:" << themeName;
}

// 💾 SAVE THEME: Persist theme selection to INI file
void MainWindow::saveThemeToSettings(const QString &themeName)
{
    QSettings settings("FileDuper", "Settings");
    settings.setValue("theme/selected", themeName);
    settings.sync();
    qDebug() << "[MainWindow] 💾 Theme gespeichert in INI:" << themeName;
}

// 📂 LOAD THEME: Restore theme from INI file
QString MainWindow::loadThemeFromSettings()
{
    QSettings settings("FileDuper", "Settings");
    QString savedTheme = settings.value("theme/selected", "System Default").toString();
    qDebug() << "[MainWindow] 📂 Theme geladen aus INI:" << savedTheme;
    return savedTheme;
}
