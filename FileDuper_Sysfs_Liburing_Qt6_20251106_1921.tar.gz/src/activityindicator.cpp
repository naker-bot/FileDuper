#include "activityindicator.h"
#include <QHBoxLayout>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <iostream>

ActivityIndicator::ActivityIndicator(QWidget *parent)
    : QWidget(parent), isActive(false), currentCpuLoad(0), currentGpuLoad(0), currentNpuLoad(0),
      gpuAvailable(false), npuAvailable(false), intelGpuAvailable(false),
      cpuLoad(0), gpuLoad(0), npuLoad(0),    // 🧠 NPU-Load-Tracking
      cpuVisible(true), gpuVisible(true), npuVisible(true),  // 🎨 Visibility flags
      realNpuActivity(0)  // 🚀 ECHTES NPU-Activity-Tracking
{
    setupUI();

    // Einfacher Timer für Updates alle 2 Sekunden
    updateTimer = new QTimer(this);
    updateTimer->setInterval(2000);
    connect(updateTimer, &QTimer::timeout, this, &ActivityIndicator::updateHardwareLoads);
    updateTimer->start();

    // Blink-Timer
    cpuBlinkTimer = new QTimer(this);
    gpuBlinkTimer = new QTimer(this);
    npuBlinkTimer = new QTimer(this);

    connect(cpuBlinkTimer, &QTimer::timeout, this, &ActivityIndicator::blinkCpu);
    connect(gpuBlinkTimer, &QTimer::timeout, this, &ActivityIndicator::blinkGpu);  
    connect(npuBlinkTimer, &QTimer::timeout, this, &ActivityIndicator::blinkNpu);
    
    // 🚀 NPU-Activity-Reset-Timer
    npuActivityTimer = new QTimer(this);
    npuActivityTimer->setSingleShot(true);
    connect(npuActivityTimer, &QTimer::timeout, [this]() {
        realNpuActivity = 0; // Reset nach Activity-Phase
        qDebug() << "[ActivityIndicator] 🧠 NPU-Activity beendet → 0%";
    });

    // Hardware-Erkennung
    detectHardwareCapabilities();
}

ActivityIndicator::~ActivityIndicator()
{
    qDebug() << "[ActivityIndicator] 🧹 Destructor";
    
    isActive = false;
    
    if (updateTimer) {
        updateTimer->stop();
        updateTimer = nullptr;
    }
    
    if (cpuBlinkTimer) {
        cpuBlinkTimer->stop();
        cpuBlinkTimer = nullptr;
    }
    
    if (gpuBlinkTimer) {
        gpuBlinkTimer->stop();
        gpuBlinkTimer = nullptr;
    }
    
    if (npuBlinkTimer) {
        npuBlinkTimer->stop();
        npuBlinkTimer = nullptr;
    }
}

void ActivityIndicator::setupUI()
{
    // ✅ STATISCHE MITTIGE ANORDNUNG - Zentriert auf GUI-Breite
    layout = new QHBoxLayout(this);
    layout->setSpacing(25);  // Mehr Abstand für bessere Optik
    layout->setContentsMargins(20, 8, 20, 8);
    layout->setAlignment(Qt::AlignCenter);  // Zentraler Alignment
    
    // ✅ Fixe Breite für konsistente Anordnung
    setFixedWidth(320);  // Feste Breite für statische Anordnung
    setFixedHeight(35);  // Etwas höher für bessere Sichtbarkeit

    // ✅ CPU Load Label - Feste Breite für statische Anordnung
    cpuLoadLabel = new QLabel("CPU: 0%", this);
    cpuLoadLabel->setFixedWidth(80);
    cpuLoadLabel->setAlignment(Qt::AlignCenter);
    cpuLoadLabel->setStyleSheet("QLabel { font-weight: bold; color: green; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    layout->addWidget(cpuLoadLabel);

    // ✅ GPU Load Label - Feste Breite für statische Anordnung
    gpuLoadLabel = new QLabel("GPU: 0%", this);
    gpuLoadLabel->setFixedWidth(80);
    gpuLoadLabel->setAlignment(Qt::AlignCenter);
    gpuLoadLabel->setStyleSheet("QLabel { font-weight: bold; color: orange; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    layout->addWidget(gpuLoadLabel);

    // ✅ NPU Load Label - Feste Breite für statische Anordnung
    npuLoadLabel = new QLabel("NPU: 0%", this);
    npuLoadLabel->setFixedWidth(80);
    npuLoadLabel->setAlignment(Qt::AlignCenter);
    npuLoadLabel->setStyleSheet("QLabel { font-weight: bold; color: blue; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    layout->addWidget(npuLoadLabel);

    setLayout(layout);
    
    isActive = true;
    setVisible(true);
    show();
}

void ActivityIndicator::updateLoadDisplay()
{
    // Vereinfachte Hardware-Load-Abfrage
    currentCpuLoad = getCurrentCpuLoad();
    currentGpuLoad = getCurrentGpuLoad();
    currentNpuLoad = getCurrentNpuLoad();

    // Label-Updates
    if (cpuLoadLabel) {
        updateLoadDisplay(cpuLoadLabel, currentCpuLoad, "CPU");
    }
    
    if (gpuLoadLabel) {
        updateLoadDisplay(gpuLoadLabel, currentGpuLoad, "GPU");
    }
    
    if (npuLoadLabel) {
        updateLoadDisplay(npuLoadLabel, currentNpuLoad, "NPU");
    }
}

void ActivityIndicator::updateLoadDisplay(QLabel *label, int load, const QString &type)
{
    if (!label) return;
    
    LoadLevel level = getLoadLevel(load);
    QColor color = getLoadColor(level);

    label->setText(QString("%1: %2%").arg(type).arg(load));
    
    QString colorStyle = QString("QLabel { color: %1; font-weight: bold; font-size: 12px; border: 1px solid %1; border-radius: 4px; padding: 2px; }").arg(color.name());
    label->setStyleSheet(colorStyle);

    // Blink-Effekt für hohe Last
    if (level == HIGH_LOAD) {
        if (type == "CPU" && cpuBlinkTimer && !cpuBlinkTimer->isActive()) {
            cpuBlinkTimer->start(500);
        } else if (type == "GPU" && gpuBlinkTimer && !gpuBlinkTimer->isActive()) {
            gpuBlinkTimer->start(500);
        } else if (type == "NPU" && npuBlinkTimer && !npuBlinkTimer->isActive()) {
            npuBlinkTimer->start(500);
        }
    } else {
        if (type == "CPU" && cpuBlinkTimer) cpuBlinkTimer->stop();
        else if (type == "GPU" && gpuBlinkTimer) gpuBlinkTimer->stop();
        else if (type == "NPU" && npuBlinkTimer) npuBlinkTimer->stop();
        
        label->setVisible(true);
    }
}

void ActivityIndicator::setActive(bool active)
{
    isActive = active;
    if (active) {
        updateTimer->start();
    } else {
        updateTimer->stop();
    }
}

void ActivityIndicator::blinkCpu()
{
    if (cpuLoadLabel) cpuLoadLabel->setVisible(!cpuLoadLabel->isVisible());
}

void ActivityIndicator::blinkGpu()
{
    if (gpuLoadLabel) gpuLoadLabel->setVisible(!gpuLoadLabel->isVisible());
}

void ActivityIndicator::blinkNpu()
{
    if (npuLoadLabel) npuLoadLabel->setVisible(!npuLoadLabel->isVisible());
}

// Vereinfachte Hardware-Monitoring-Funktionen
int ActivityIndicator::getCurrentCpuLoad()
{
    // Echte CPU-Load via /proc/stat
    static long long lastIdle = 0, lastTotal = 0;
    
    QFile file("/proc/stat");
    if (!file.open(QIODevice::ReadOnly)) return 0;
    
    QString line = file.readLine();
    file.close();
    
    QStringList parts = line.split(' ', Qt::SkipEmptyParts);
    if (parts.size() < 8) return 0;
    
    // CPU times: user, nice, system, idle, iowait, irq, softirq, steal
    long long user = parts[1].toLongLong();
    long long nice = parts[2].toLongLong();
    long long system = parts[3].toLongLong();
    long long idle = parts[4].toLongLong();
    long long iowait = parts[5].toLongLong();
    long long irq = parts[6].toLongLong();
    long long softirq = parts[7].toLongLong();
    
    long long totalIdle = idle + iowait;
    long long total = user + nice + system + idle + iowait + irq + softirq;
    
    // Erste Messung - Return 0
    if (lastTotal == 0) {
        lastIdle = totalIdle;
        lastTotal = total;
        return 0;
    }
    
    long long totald = total - lastTotal;
    long long idled = totalIdle - lastIdle;
    
    double cpuPercent = 0.0;
    if (totald > 0) {
        cpuPercent = ((double)(totald - idled) / totald) * 100.0;
    }
    
    lastIdle = totalIdle;
    lastTotal = total;
    
    return qMin(100, qMax(0, (int)cpuPercent));
}

int ActivityIndicator::getCurrentGpuLoad()
{
    if (!gpuAvailable && !intelGpuAvailable) return 0;
    
    // ⚡ ECHTE GPU-AUSLASTUNG: Intel GPU via sysfs (NICHT-BLOCKIEREND)
    if (intelGpuAvailable) {
        // Methode 1: Direkte GPU-Auslastung (gpu_busy_percent) - Bevorzugt für moderne Intel GPUs
        QFile busyFile("/sys/class/drm/card0/device/gpu_busy_percent");
        if (busyFile.open(QIODevice::ReadOnly)) {
            QString content = busyFile.readAll().trimmed();
            busyFile.close();
            int busyPercent = content.toInt();
            if (busyPercent >= 0 && busyPercent <= 100) {
                return busyPercent;
            }
        }
        
        // Methode 2: Frequenz-basierte Auslastung (Fallback für ältere Systeme)
        QFile currentFreqFile("/sys/class/drm/card0/gt_cur_freq_mhz");
        QFile maxFreqFile("/sys/class/drm/card0/gt_max_freq_mhz");
        
        if (currentFreqFile.open(QIODevice::ReadOnly) && maxFreqFile.open(QIODevice::ReadOnly)) {
            int currentFreq = currentFreqFile.readAll().trimmed().toInt();
            int maxFreq = maxFreqFile.readAll().trimmed().toInt();
            currentFreqFile.close();
            maxFreqFile.close();
            
            if (currentFreq > 0 && maxFreq > 0) {
                int percentage = qMin(100, (currentFreq * 100) / maxFreq);
                return percentage;
            }
        }
    }
    
    // Fallback: NVIDIA GPUs via sysfs (nicht-blockierend)
    QFile nvidiaUtilFile("/sys/class/hwmon/hwmon0/device/gpu_busy_percent");
    if (nvidiaUtilFile.open(QIODevice::ReadOnly)) {
        int utilPercent = nvidiaUtilFile.readAll().trimmed().toInt();
        nvidiaUtilFile.close();
        if (utilPercent >= 0 && utilPercent <= 100) {
            return utilPercent;
        }
    }
    
    // Fallback: AMD GPUs via sysfs
    QFile amdUtilFile("/sys/class/drm/card0/device/gpu_busy_percent");
    if (amdUtilFile.open(QIODevice::ReadOnly)) {
        int utilPercent = amdUtilFile.readAll().trimmed().toInt();
        amdUtilFile.close();
        if (utilPercent >= 0 && utilPercent <= 100) {
            return utilPercent;
        }
    }
    
    return 0; // Keine GPU-Auslastung verfügbar
}

int ActivityIndicator::getCurrentNpuLoad()
{
    if (!npuAvailable) return 0;
    
    // ⚡ ECHTE NPU-AUSLASTUNG: Intel NPU via sysfs (NICHT-BLOCKIEREND)
    // Methode 1: Intel NPU über accel device
    QFile npuUtilFile("/sys/class/accel/accel0/device/utilization");
    if (npuUtilFile.open(QIODevice::ReadOnly)) {
        int utilPercent = npuUtilFile.readAll().trimmed().toInt();
        npuUtilFile.close();
        if (utilPercent >= 0 && utilPercent <= 100) {
            return utilPercent;
        }
    }
    
    // Methode 2: Intel NPU über DRM-Subsystem (neuere Kernel)
    QFile npuBusyFile("/sys/class/drm/renderD128/device/npu_busy_percent");
    if (npuBusyFile.open(QIODevice::ReadOnly)) {
        int busyPercent = npuBusyFile.readAll().trimmed().toInt();
        npuBusyFile.close();
        if (busyPercent >= 0 && busyPercent <= 100) {
            return busyPercent;
        }
    }
    
    // Methode 3: Intel VPU (Video Processing Unit) als NPU
    QFile vpuUtilFile("/sys/class/misc/intel_vpu0/utilization");
    if (vpuUtilFile.open(QIODevice::ReadOnly)) {
        int utilPercent = vpuUtilFile.readAll().trimmed().toInt();
        vpuUtilFile.close();
        if (utilPercent >= 0 && utilPercent <= 100) {
            return utilPercent;
        }
    }
    
    // Methode 4: Frequenz-basierte NPU-Auslastung (Fallback)
    QFile npuCurFreqFile("/sys/class/accel/accel0/device/cur_freq");
    QFile npuMaxFreqFile("/sys/class/accel/accel0/device/max_freq");
    if (npuCurFreqFile.open(QIODevice::ReadOnly) && npuMaxFreqFile.open(QIODevice::ReadOnly)) {
        int currentFreq = npuCurFreqFile.readAll().trimmed().toInt();
        int maxFreq = npuMaxFreqFile.readAll().trimmed().toInt();
        npuCurFreqFile.close();
        npuMaxFreqFile.close();
        
        if (currentFreq > 0 && maxFreq > 0) {
            int percentage = qMin(100, (currentFreq * 100) / maxFreq);
            return percentage;
        }
    }
    
    // Fallback: Verwende realNpuActivity falls direkt vom HashEngine gesetzt
    if (realNpuActivity > 0) {
        return realNpuActivity;
    }
    
    return 0; // Keine NPU-Auslastung verfügbar
}

// 🚀 PUBLIC: NPU-Activity direkt setzen vom HashEngine
void ActivityIndicator::signalNpuActivity(int percentage)
{
    if (percentage <= 0) return;
    
    realNpuActivity = qMin(100, percentage);
    currentNpuLoad = realNpuActivity; // 🎯 Auch currentNpuLoad aktualisieren
    
    // 🚀 NPU-GUI SOFORT SICHTBAR MACHEN
    updateLoadDisplay(npuLoadLabel, realNpuActivity, "NPU");
    qDebug() << "[ActivityIndicator] 🎯 NPU-GUI SOFORT aktualisiert:" << realNpuActivity << "%";
    
    // 🚀 Activity für 8 Sekunden halten (länger sichtbar)
    npuActivityTimer->stop();
    npuActivityTimer->start(8000); // 8 Sekunden statt 3
    
    qDebug() << "[ActivityIndicator] 🚀 NPU-Activity signaled:" << realNpuActivity << "% für 8s";
}

void ActivityIndicator::updateHardwareLoads()
{
    int cpuLoad = getCurrentCpuLoad();
    int gpuLoad = getCurrentGpuLoad();
    int npuLoad = getCurrentNpuLoad();

    updateLoadDisplay(cpuLoadLabel, cpuLoad, "CPU");
    updateLoadDisplay(gpuLoadLabel, gpuLoad, "GPU");
    updateLoadDisplay(npuLoadLabel, npuLoad, "NPU");

    currentCpuLoad = cpuLoad;
    currentGpuLoad = gpuLoad;
    currentNpuLoad = npuLoad;
}

// ✅ Kompatibilität für MainWindow
void ActivityIndicator::setIdle()
{
    setActivity(false, 0, 0, 0);
}

void ActivityIndicator::startOperation(const QString &operationName)
{
    setActivity(true, 50, 30, 20); // Moderate Belastung während Operation
    qDebug() << "ActivityIndicator: Starte Operation:" << operationName;
}

void ActivityIndicator::finishOperation(const QString &operationName)
{
    setActivity(false, 10, 5, 2); // Idle-Zustand nach Operation
    qDebug() << "ActivityIndicator: Beende Operation:" << operationName;
}

void ActivityIndicator::setActivity(bool active, int cpuLoad, int gpuLoad, int npuLoad)
{
    isActive = active;
    currentCpuLoad = cpuLoad;
    currentGpuLoad = gpuLoad;  
    currentNpuLoad = npuLoad;
    
    if (!active) {
        if (cpuLoadLabel) cpuLoadLabel->setText("CPU: 0%");
        if (gpuLoadLabel) gpuLoadLabel->setText("GPU: 0%");
        if (npuLoadLabel) npuLoadLabel->setText("NPU: 0%");
        
        if (cpuLoadLabel) cpuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: bold; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
        if (gpuLoadLabel) gpuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: bold; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
        if (npuLoadLabel) npuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: bold; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    } else {
        updateTimer->start();
        updateLoadDisplay();
    }
}

ActivityIndicator::LoadLevel ActivityIndicator::getLoadLevel(int load)
{
    if (load >= 80) return HIGH_LOAD;
    if (load >= 50) return MEDIUM_LOAD;
    return LOW_LOAD;
}

QColor ActivityIndicator::getLoadColor(LoadLevel level)
{
    switch (level) {
        case LOW_LOAD: return QColor(0, 200, 0);    // Grün
        case MEDIUM_LOAD: return QColor(255, 165, 0); // Orange
        case HIGH_LOAD: return QColor(255, 0, 0);    // Rot
        default: return QColor(100, 100, 100);       // Grau
    }
}

void ActivityIndicator::detectHardwareCapabilities()
{
    qDebug() << "[ActivityIndicator] 🔍 Intel-optimierte Hardware-Erkennung gestartet (identisch zu HashEngine)...";
    
    // Hardware-Erkennung zurücksetzen
    gpuAvailable = false;
    intelGpuAvailable = false;
    npuAvailable = false;

    // 🚀 Intel GPU detection via sysfs (NICHT-BLOCKIEREND, SCHNELL)
    // Prüfe ob Intel DRM-Device existiert
    QDir drmDir("/sys/class/drm");
    QStringList drmCards = drmDir.entryList(QStringList() << "card*", QDir::Dirs);
    
    for (const QString &card : drmCards) {
        QFile vendorFile(QString("/sys/class/drm/%1/device/vendor").arg(card));
        if (vendorFile.open(QIODevice::ReadOnly)) {
            QString vendorId = vendorFile.readAll().trimmed();
            vendorFile.close();
            
            // Intel GPU: Vendor-ID 0x8086
            if (vendorId.contains("0x8086")) {
                intelGpuAvailable = true;
                qDebug() << "[ActivityIndicator] ✅ Intel GPU erkannt:" << card;
                break;
            }
            
            // Generische GPU-Erkennung (NVIDIA, AMD, etc.)
            if (vendorId.contains("0x10de") || // NVIDIA
                vendorId.contains("0x1002")) {  // AMD
                gpuAvailable = true;
                qDebug() << "[ActivityIndicator] ✅ GPU erkannt:" << card;
            }
        }
    }

    // 🚀 Intel NPU detection via sysfs (NICHT-BLOCKIEREND)
    // Methode 1: Prüfe accel devices (neuere Kernel für Intel NPU)
    QDir accelDir("/sys/class/accel");
    if (accelDir.exists()) {
        QStringList accelDevices = accelDir.entryList(QStringList() << "accel*", QDir::Dirs);
        if (!accelDevices.isEmpty()) {
            npuAvailable = true;
            qDebug() << "[ActivityIndicator] ✅ Intel NPU erkannt via /sys/class/accel:" << accelDevices;
        }
    }
    
    // Methode 2: Prüfe Intel VPU (Video Processing Unit als NPU)
    if (!npuAvailable) {
        QDir miscDir("/sys/class/misc");
        QStringList vpuDevices = miscDir.entryList(QStringList() << "intel_vpu*", QDir::Dirs);
        if (!vpuDevices.isEmpty()) {
            npuAvailable = true;
            qDebug() << "[ActivityIndicator] ✅ Intel VPU (NPU) erkannt via /sys/class/misc:" << vpuDevices;
        }
    }
    
    // Methode 3: Prüfe PCI devices für NPU (fallback via sysfs, NICHT lspci)
    if (!npuAvailable) {
        QDir pciDir("/sys/bus/pci/devices");
        QStringList pciDevices = pciDir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        
        for (const QString &pciDev : pciDevices) {
            QFile classFile(QString("/sys/bus/pci/devices/%1/class").arg(pciDev));
            if (classFile.open(QIODevice::ReadOnly)) {
                QString classCode = classFile.readAll().trimmed();
                classFile.close();
                
                // PCI Class 0x120000: Processing accelerators (NPU)
                if (classCode.startsWith("0x12")) {
                    QFile vendorFile(QString("/sys/bus/pci/devices/%1/vendor").arg(pciDev));
                    if (vendorFile.open(QIODevice::ReadOnly)) {
                        QString vendorId = vendorFile.readAll().trimmed();
                        vendorFile.close();
                        
                        // Intel Vendor-ID 0x8086
                        if (vendorId.contains("0x8086")) {
                            npuAvailable = true;
                            qDebug() << "[ActivityIndicator] ✅ Intel NPU erkannt via PCI class:" << pciDev;
                            break;
                        }
                    }
                }
            }
        }
    }

    std::cout << "🔍 [ActivityIndicator] Hardware-Capabilities erkannt (sysfs-basiert, nicht-blockierend):" << std::endl;
    std::cout << "   🎯 Intel GPU (Arc/Xe/UHD): " << (intelGpuAvailable ? "✅ Verfügbar" : "❌ Nicht gefunden") << std::endl;
    std::cout << "   🖥️  Generische GPU: " << (gpuAvailable ? "✅ Verfügbar" : "❌ Nicht gefunden") << std::endl;
    std::cout << "   🤖 Intel NPU/VPU: " << (npuAvailable ? "✅ Verfügbar" : "❌ Nicht gefunden") << std::endl;
    
    // Labels entsprechend anpassen
    if (!gpuAvailable && gpuLoadLabel) {
        gpuLoadLabel->setText("GPU: N/A");
        gpuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: normal; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    }
    
    if (!npuAvailable && npuLoadLabel) {
        npuLoadLabel->setText("NPU: N/A");
        npuLoadLabel->setStyleSheet("QLabel { color: gray; font-weight: normal; font-size: 12px; border: 1px solid gray; border-radius: 4px; padding: 2px; }");
    }
}

// 🧠 NPU-LOAD UPDATE METHODEN für NPU-Manager Integration
void ActivityIndicator::updateNpuLoad(int load)
{
    npuLoad = load;
    currentNpuLoad = load;  // Auch für Kompatibilität
    
    // ✅ NPU-LABEL DIREKT AKTUALISIEREN - GUI-FIX!
    if (npuLoadLabel) {
        npuLoadLabel->setText(QString("NPU: %1%").arg(load));
        QColor color = getLoadColor(getLoadLevel(load));
        npuLoadLabel->setStyleSheet(QString("QLabel { color: %1; font-weight: bold; }")
                                   .arg(color.name()));
        qDebug() << "[ActivityIndicator] 🎯 NPU-GUI aktualisiert:" << load << "%";
    }
    
    update(); // Trigger repaint
    
    // NPU-spezifisches Blinken bei hoher Last
    if (load > 80) {
        npuBlinkTimer->start(FAST);
    } else if (load > 50) {
        npuBlinkTimer->start(SLOW);
    } else {
        npuBlinkTimer->stop();
        npuVisible = true;
    }
    
    // Update NPU-Label direkt
    if (npuLoadLabel) {
        npuLoadLabel->setText(QString("NPU: %1%").arg(load));
    }
}

// 🚀 NPU-AKTIVITÄTS-SIGNALING für echte Verarbeitung
void ActivityIndicator::setNpuActive(bool active, int percentage)
{
    if (active) {
        updateNpuLoad(percentage);
        qDebug() << "[ActivityIndicator] 🧠 NPU aktiv gesetzt:" << percentage << "%";
    } else {
        updateNpuLoad(0);
        qDebug() << "[ActivityIndicator] 🧠 NPU inaktiv gesetzt";
    }
}

void ActivityIndicator::signalNpuProcessing(const QString &operation)
{
    setNpuActive(true, 87); // High activity when processing
    qDebug() << "[ActivityIndicator] 🚀 NPU-Verarbeitung signalisiert:" << operation;
    
    // Nach 2 Sekunden wieder reduzieren (simuliert Verarbeitung)
    QTimer::singleShot(2000, this, [this]() {
        setNpuActive(false);
    });
}

void ActivityIndicator::updateGpuLoad(int load)
{
    gpuLoad = load;
    currentGpuLoad = load;  // Auch für Kompatibilität
    update(); // Trigger repaint
    
    // GPU-spezifisches Blinken bei hoher Last
    if (load > 80) {
        gpuBlinkTimer->start(FAST);
    } else if (load > 50) {
        gpuBlinkTimer->start(SLOW);
    } else {
        gpuBlinkTimer->stop();
        gpuVisible = true;
    }
    
    // Update GPU-Label direkt
    if (gpuLoadLabel) {
        gpuLoadLabel->setText(QString("GPU: %1%").arg(load));
    }
}

void ActivityIndicator::updateCpuLoad(int load)
{
    cpuLoad = load;
    currentCpuLoad = load;  // Auch für Kompatibilität
    update(); // Trigger repaint
    
    // CPU-spezifisches Blinken bei hoher Last
    if (load > 80) {
        cpuBlinkTimer->start(FAST);
    } else if (load > 50) {
        cpuBlinkTimer->start(SLOW);
    } else {
        cpuBlinkTimer->stop();
        cpuVisible = true;
    }
    
    // Update CPU-Label direkt
    if (cpuLoadLabel) {
        cpuLoadLabel->setText(QString("CPU: %1%").arg(load));
    }
}
