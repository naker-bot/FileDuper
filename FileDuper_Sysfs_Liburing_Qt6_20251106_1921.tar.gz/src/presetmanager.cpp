#include "presetmanager.h"
#include <QStandardPaths>
#include <QCoreApplication>
#include <QDebug>
#include <iostream>

PresetManager::PresetManager(QObject *parent)
    : QObject(parent)
{
    qDebug() << "[PresetManager] 📋 Initialisierung gestartet...";

    // Auto-save timer
    autoSaveTimer = new QTimer(this);
    autoSaveTimer->setSingleShot(true);
    autoSaveTimer->setInterval(5000); // 5 Sekunden nach Änderung speichern
    connect(autoSaveTimer, &QTimer::timeout, this, &PresetManager::autoSaveSettings);

    // Settings initialisieren
    QString configDir = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);

    mainSettings = new QSettings(configDir + "/.fileduper_settings.ini", QSettings::IniFormat, this);
    loginSettings = new QSettings(configDir + "/.fileduper_login.ini", QSettings::IniFormat, this);

    // Standard-Konfiguration
    initializeDefaultSettings();
    initializeDefaultFileTypes();
    initializeSystemExcludes();

    // Einstellungen laden
    loadSettings();

    std::cout << "📋 PresetManager initialisiert" << std::endl;
    std::cout << "   Settings: " << mainSettings->fileName().toUtf8().constData() << std::endl;
    std::cout << "   Logins: " << loginSettings->fileName().toUtf8().constData() << std::endl;
}

PresetManager::~PresetManager()
{
    saveSettings();
}

void PresetManager::initializeDefaultFileTypes()
{
    // Standard Dateitype-Kategorien mit Hardware-optimierter Verarbeitung
    defaultCategories["Media"] = QStringList{"mp4", "avi", "mkv", "mp3", "wav", "flac", "jpg", "png", "gif", "webm", "mov", "m4v"};
    defaultCategories["Backups"] = QStringList{"iso", "img", "bak", "backup", "tar", "gz", "zip", "7z", "rar", "xz"};
    defaultCategories["3D Design"] = QStringList{"blend", "fbx", "obj", "3ds", "max", "c4d", "dae", "x3d"};
    defaultCategories["Office"] = QStringList{"csv", "xlsx", "docx", "pptx", "pdf", "txt", "odt", "ods", "odp"};
    defaultCategories["Code"] = QStringList{"cpp", "h", "py", "js", "html", "css", "java", "c", "ts", "json", "xml"};
    
    // Hardware-optimierte Hash-Algorithmus-Zuordnung
    hashPreferences["Media"] = "xxHash";      // Schnell für große Video-Dateien
    hashPreferences["Backups"] = "SHA256";    // Sicher für kritische Backups
    hashPreferences["3D Design"] = "MD5";     // Balanciert für 3D-Dateien
    hashPreferences["Office"] = "SHA1";       // Standard für Dokumente
    hashPreferences["Code"] = "MD5";          // Schnell für kleine Dateien
    
    // NPU-optimierte Kategorien (AI-basierte Ähnlichkeitserkennung)
    npuCategories["Images"] = QStringList{"jpg", "jpeg", "png", "bmp", "tiff", "webp"};
    npuCategories["Documents"] = QStringList{"pdf", "doc", "docx", "txt", "rtf"};
    // VIDEOS NICHT HIER! Videos verwenden xxHash auf CPU/GPU
    
    std::cout << "📁 " << defaultCategories.size() << " Standard-Kategorien initialisiert" << std::endl;
    std::cout << "🎯 " << hashPreferences.size() << " Hardware-optimierte Hash-Zuordnungen geladen" << std::endl;
    std::cout << "🤖 " << npuCategories.size() << " NPU-optimierte Kategorien konfiguriert" << std::endl;
}

void PresetManager::initializeSystemExcludes()
{
    systemExcludePaths = QStringList{
        "/proc", "/sys", "/dev", "/run", "/tmp",
        "/var/cache", "/var/tmp", "/var/run",
        "/.cache", "/.local/share/Trash",
        "/snap", "/flatpak"};

    std::cout << "🚫 " << systemExcludePaths.size() << " System-Pfade ausgeschlossen" << std::endl;
}

void PresetManager::initializeDefaultSettings()
{
    // Standard-Werte setzen falls nicht vorhanden
    if (!mainSettings->contains("General/Version"))
    {
        mainSettings->setValue("General/Version", "1.0.0");
        mainSettings->setValue("General/AutoSave", true);
        mainSettings->setValue("General/AutoDetectFileTypes", true);
    }
}

void PresetManager::saveSettings()
{
    QMutexLocker locker(&settingsMutex);

    // File type mappings speichern
    mainSettings->beginWriteArray("FileTypes");
    int index = 0;
    for (auto it = fileTypeMappings.begin(); it != fileTypeMappings.end(); ++it, ++index)
    {
        mainSettings->setArrayIndex(index);
        mainSettings->setValue("extension", it.key());
        mainSettings->setValue("category", it->category);
        mainSettings->setValue("autoAdd", it->autoAdd);
        mainSettings->setValue("frequency", it->frequency);
    }
    mainSettings->endArray();

    // Directory presets speichern
    mainSettings->beginWriteArray("DirectoryPresets");
    index = 0;
    for (auto it = directoryPresets.begin(); it != directoryPresets.end(); ++it, ++index)
    {
        mainSettings->setArrayIndex(index);
        mainSettings->setValue("name", it.key());
        mainSettings->setValue("description", it->description);
        mainSettings->setValue("paths", it->paths);
        mainSettings->setValue("fileTypes", it->fileTypes);
        mainSettings->setValue("lastUsed", it->lastUsed);
        mainSettings->setValue("usageCount", it->usageCount);
    }
    mainSettings->endArray();

    mainSettings->sync();
    emit settingsSaved();

    qDebug() << "[PresetManager] 💾 Einstellungen gespeichert";
}

void PresetManager::loadSettings()
{
    QMutexLocker locker(&settingsMutex);

    // File type mappings laden
    int size = mainSettings->beginReadArray("FileTypes");
    for (int i = 0; i < size; ++i)
    {
        mainSettings->setArrayIndex(i);
        FileTypeMapping mapping;
        mapping.extension = mainSettings->value("extension").toString();
        mapping.category = mainSettings->value("category").toString();
        mapping.autoAdd = mainSettings->value("autoAdd").toBool();
        mapping.frequency = mainSettings->value("frequency").toInt();

        fileTypeMappings[mapping.extension] = mapping;
    }
    mainSettings->endArray();

    // ✅ LOGIN-DATEN LADEN (war fehlend!)
    loadLoginData();

    qDebug() << "[PresetManager] 📂" << fileTypeMappings.size() << "Dateitype-Mappings geladen";
}

void PresetManager::saveLogin(const QString &host, int port, const LoginData &login)
{
    QString key = QString("%1:%2").arg(host).arg(port);
    loginData[key] = login;

    // In Datei speichern
    loginSettings->beginGroup(key);
    loginSettings->setValue("username", login.username);
    if (login.saveCredentials)
    {
        // Einfache Verschleierung - in Produktion richtige Verschlüsselung verwenden
        loginSettings->setValue("password", QString::fromUtf8(login.password.toUtf8().toBase64()));
    }
    loginSettings->setValue("service", login.service);
    loginSettings->setValue("lastUsed", login.lastUsed);
    loginSettings->setValue("saveCredentials", login.saveCredentials);
    loginSettings->setValue("autoLogin", login.autoLogin); // ✅ AUTO-LOGIN SPEICHERN
    loginSettings->endGroup();

    loginSettings->sync();

    std::cout << "🔐 Login für " << host.toUtf8().constData() << ":" << port << " gespeichert" << std::endl;
}

LoginData PresetManager::getLogin(const QString &host, int port) const
{
    QString key = QString("%1:%2").arg(host).arg(port);
    
    // Erst im Memory-Cache prüfen
    if (loginData.contains(key)) {
        return loginData.value(key);
    }
    
    // Dann direkt aus INI-Datei laden (für bereits gespeicherte Credentials)
    if (loginSettings->childGroups().contains(key)) {
        qDebug() << "[PresetManager] 🔐 Lade Login-Daten aus INI für" << key;
        
        const_cast<QSettings*>(loginSettings)->beginGroup(key);
        
        LoginData login;
        login.username = loginSettings->value("username").toString();
        QString encodedPassword = loginSettings->value("password").toString();
        login.service = loginSettings->value("service").toString();
        login.lastUsed = loginSettings->value("lastUsed").toInt();
        login.saveCredentials = loginSettings->value("saveCredentials").toBool();
        login.autoLogin = loginSettings->value("autoLogin").toBool();
        
        // Passwort dekodieren (Base64)
        if (!encodedPassword.isEmpty()) {
            login.password = QString::fromUtf8(QByteArray::fromBase64(encodedPassword.toUtf8()));
        }
        
        const_cast<QSettings*>(loginSettings)->endGroup();
        
        qDebug() << "[PresetManager] ✅ Login-Daten geladen für" << login.username << "@" << host << ":" << port;
        
        // Im Memory-Cache speichern für nächsten Zugriff
        const_cast<QHash<QString, LoginData>&>(loginData)[key] = login;
        
        return login;
    }
    
    qDebug() << "[PresetManager] ❌ Keine Login-Daten gefunden für" << host << ":" << port;
    return LoginData();
}

QStringList PresetManager::getSystemExcludePaths() const
{
    return systemExcludePaths;
}

bool PresetManager::shouldExcludePath(const QString &path) const
{
    for (const QString &excludePath : systemExcludePaths)
    {
        if (path.startsWith(excludePath))
        {
            return true;
        }
    }
    return false;
}

QString PresetManager::suggestCategoryForExtension(const QString &extension) const
{
    // Suche in bekannten Kategorien
    for (auto it = defaultCategories.begin(); it != defaultCategories.end(); ++it)
    {
        if (it.value().contains(extension.toLower()))
        {
            return it.key();
        }
    }
    return "Sonstige";
}

void PresetManager::autoSaveSettings()
{
    saveSettings();
}

// ✅ ECHTE IMPLEMENTIERUNGEN ALLER PRESET-FUNKTIONEN
void PresetManager::addDirectoryPreset(const DirectoryPreset &preset) {
    mainSettings->beginGroup("DirectoryPresets");
    mainSettings->beginGroup(preset.name);
    mainSettings->setValue("description", preset.description);
    mainSettings->setValue("paths", preset.paths);
    mainSettings->setValue("fileTypes", preset.fileTypes);
    mainSettings->setValue("usageCount", preset.usageCount);
    mainSettings->setValue("lastUsed", preset.lastUsed);
    mainSettings->setValue("category", preset.category);
    mainSettings->endGroup();
    mainSettings->endGroup();
    mainSettings->sync();
    qDebug() << "[PresetManager] ➕ Directory preset added:" << preset.name;
}

void PresetManager::removeDirectoryPreset(const QString &name) {
    mainSettings->beginGroup("DirectoryPresets");
    mainSettings->remove(name);
    mainSettings->endGroup();
    mainSettings->sync();
    qDebug() << "[PresetManager] ➖ Directory preset removed:" << name;
}

QList<DirectoryPreset> PresetManager::getDirectoryPresets() const {
    QList<DirectoryPreset> presets;
    mainSettings->beginGroup("DirectoryPresets");
    QStringList presetNames = mainSettings->childGroups();
    
    for (const QString &name : presetNames) {
        mainSettings->beginGroup(name);
        DirectoryPreset preset;
        preset.name = name;
        preset.description = mainSettings->value("description").toString();
        preset.paths = mainSettings->value("paths").toStringList();
        preset.fileTypes = mainSettings->value("fileTypes").toStringList();
        preset.usageCount = mainSettings->value("usageCount", 0).toInt();
        preset.lastUsed = mainSettings->value("lastUsed", 0).toLongLong();
        preset.category = mainSettings->value("category", "Sonstige").toString();
        presets.append(preset);
        mainSettings->endGroup();
    }
    
    mainSettings->endGroup();
    return presets;
}

DirectoryPreset PresetManager::getPreset(const QString &name) const {
    mainSettings->beginGroup("DirectoryPresets");
    mainSettings->beginGroup(name);
    
    DirectoryPreset preset;
    if (mainSettings->contains("description")) {
        preset.name = name;
        preset.description = mainSettings->value("description").toString();
        preset.paths = mainSettings->value("paths").toStringList();
        preset.fileTypes = mainSettings->value("fileTypes").toStringList();
        preset.usageCount = mainSettings->value("usageCount", 0).toInt();
        preset.lastUsed = mainSettings->value("lastUsed", 0).toLongLong();
        preset.category = mainSettings->value("category", "Sonstige").toString();
    }
    
    mainSettings->endGroup();
    mainSettings->endGroup();
    return preset;
}

void PresetManager::analyzeNewFileTypes(const QStringList &filePaths) {
    QSet<QString> newExtensions;
    
    for (const QString &filePath : filePaths) {
        QString extension = getFileExtension(filePath).toLower();
        if (!extension.isEmpty() && !fileTypeMappings.contains(extension)) {
            newExtensions.insert(extension);
        }
    }
    
    if (!newExtensions.isEmpty()) {
        detectNewFileTypes(newExtensions.values());
    }
}

void PresetManager::addFileTypeMapping(const QString &extension, const QString &category, bool permanent) {
    FileTypeMapping mapping;
    mapping.extension = extension.toLower();
    mapping.category = category;
    mapping.autoAdd = permanent;
    mapping.frequency = 1;
    
    fileTypeMappings[extension.toLower()] = mapping;
    
    if (permanent) {
        mainSettings->beginGroup("FileTypeMappings");
        mainSettings->setValue(extension.toLower(), category);
        mainSettings->endGroup();
        mainSettings->sync();
    }
    
    qDebug() << "[PresetManager] 📁 File type mapping added:" << extension << "→" << category;
}

void PresetManager::removeFileTypeMapping(const QString &extension) {
    fileTypeMappings.remove(extension.toLower());
    
    mainSettings->beginGroup("FileTypeMappings");
    mainSettings->remove(extension.toLower());
    mainSettings->endGroup();
    mainSettings->sync();
    
    qDebug() << "[PresetManager] 🗑️ File type mapping removed:" << extension;
}

QStringList PresetManager::getFileTypesForCategory(const QString &category) const {
    QStringList extensions;
    for (auto it = fileTypeMappings.constBegin(); it != fileTypeMappings.constEnd(); ++it) {
        if (it.value().category == category) {
            extensions.append(it.key());
        }
    }
    return extensions;
}

QStringList PresetManager::getAllCategories() const { 
    QSet<QString> categories = QSet<QString>(defaultCategories.keys().begin(), defaultCategories.keys().end());
    for (const FileTypeMapping &mapping : fileTypeMappings.values()) {
        categories.insert(mapping.category);
    }
    return categories.values();
}

void PresetManager::removeLogin(const QString &host, int port) {
    QString key = QString("%1:%2").arg(host).arg(port);
    loginData.remove(key);
    
    loginSettings->remove(key);
    loginSettings->sync();
    
    qDebug() << "[PresetManager] 🔐 Login removed:" << key;
}

QList<QPair<QString, LoginData>> PresetManager::getAllLogins() const {
    QList<QPair<QString, LoginData>> allLogins;
    for (auto it = loginData.constBegin(); it != loginData.constEnd(); ++it) {
        allLogins.append(qMakePair(it.key(), it.value()));
    }
    return allLogins;
}

bool PresetManager::shouldShowAutoAddDialog(const QString &extension) const {
    QString ext = extension.toLower();
    return !fileTypeMappings.contains(ext) && 
           !ignoredExtensions.contains(ext) && 
           !uninterestingExtensions.contains(ext);
}

void PresetManager::markExtensionAsIgnored(const QString &extension) {
    if (!ignoredExtensions.contains(extension.toLower())) {
        ignoredExtensions.append(extension.toLower());
    }
    
    mainSettings->beginGroup("IgnoredExtensions");
    QStringList ignored = mainSettings->value("extensions").toStringList();
    ignored.append(extension.toLower());
    ignored.removeDuplicates();
    mainSettings->setValue("extensions", ignored);
    mainSettings->endGroup();
    mainSettings->sync();
    
    qDebug() << "[PresetManager] 🚫 Extension marked as ignored:" << extension;
}

void PresetManager::markExtensionAsUninteresting(const QString &extension) {
    if (!uninterestingExtensions.contains(extension.toLower())) {
        uninterestingExtensions.append(extension.toLower());
    }
    
    mainSettings->beginGroup("UninterestingExtensions");
    QStringList uninteresting = mainSettings->value("extensions").toStringList();
    uninteresting.append(extension.toLower());
    uninteresting.removeDuplicates();
    mainSettings->setValue("extensions", uninteresting);
    mainSettings->endGroup();
    mainSettings->sync();
    
    qDebug() << "[PresetManager] 💤 Extension marked as uninteresting:" << extension;
}

void PresetManager::recordPresetUsage(const QString &presetName) {
    mainSettings->beginGroup("PresetUsage");
    int currentUsage = mainSettings->value(presetName, 0).toInt();
    mainSettings->setValue(presetName, currentUsage + 1);
    mainSettings->endGroup();
    mainSettings->sync();
}

void PresetManager::recordFileTypeUsage(const QString &extension) {
    mainSettings->beginGroup("FileTypeUsage");
    int currentUsage = mainSettings->value(extension.toLower(), 0).toInt();
    mainSettings->setValue(extension.toLower(), currentUsage + 1);
    mainSettings->endGroup();
    mainSettings->sync();
}

QStringList PresetManager::getMostUsedPresets(int count) const {
    QMultiMap<int, QString> usageMap;
    
    mainSettings->beginGroup("PresetUsage");
    QStringList keys = mainSettings->allKeys();
    for (const QString &key : keys) {
        int usage = mainSettings->value(key, 0).toInt();
        usageMap.insert(usage, key);
    }
    mainSettings->endGroup();
    
    QStringList result;
    auto it = usageMap.constEnd();
    while (it != usageMap.constBegin() && result.size() < count) {
        --it;
        result.append(it.value());
    }
    
    return result;
}

QStringList PresetManager::getMostUsedFileTypes(int count) const {
    QMultiMap<int, QString> usageMap;
    
    mainSettings->beginGroup("FileTypeUsage");
    QStringList keys = mainSettings->allKeys();
    for (const QString &key : keys) {
        int usage = mainSettings->value(key, 0).toInt();
        usageMap.insert(usage, key);
    }
    mainSettings->endGroup();
    
    QStringList result;
    auto it = usageMap.constEnd();
    while (it != usageMap.constBegin() && result.size() < count) {
        --it;
        result.append(it.value());
    }
    
    return result;
}

void PresetManager::analyzeFileTypes() {
    // Analysiere alle gemappten Dateitypen und kategorisiere sie neu
    qDebug() << "[PresetManager] 🔍 Analyzing file types...";
    
    mainSettings->beginGroup("FileTypeUsage");
    QStringList usedExtensions = mainSettings->allKeys();
    mainSettings->endGroup();
    
    detectNewFileTypes(usedExtensions);
}

void PresetManager::detectNewFileTypes(const QStringList &extensions) {
    for (const QString &extension : extensions) {
        QString ext = extension.toLower();
        
        if (fileTypeMappings.contains(ext) || ignoredExtensions.contains(ext) || uninterestingExtensions.contains(ext)) {
            continue;
        }
        
        // Automatische Kategorisierung basierend auf Extension
        QString suggestedCategory = "Sonstige";
        
        // Medien-Dateien
        if (QStringList({"mp4", "avi", "mkv", "mov", "wmv", "flv", "webm", "m4v"}).contains(ext)) {
            suggestedCategory = "Videos";
        } else if (QStringList({"mp3", "wav", "flac", "ogg", "aac", "m4a", "wma"}).contains(ext)) {
            suggestedCategory = "Audio";
        } else if (QStringList({"jpg", "jpeg", "png", "gif", "bmp", "tiff", "svg", "webp"}).contains(ext)) {
            suggestedCategory = "Bilder";
        }
        // Dokumente
        else if (QStringList({"pdf", "doc", "docx", "txt", "rtf", "odt"}).contains(ext)) {
            suggestedCategory = "Dokumente";
        } else if (QStringList({"xls", "xlsx", "csv", "ods"}).contains(ext)) {
            suggestedCategory = "Tabellen";
        } else if (QStringList({"ppt", "pptx", "odp"}).contains(ext)) {
            suggestedCategory = "Präsentationen";
        }
        // Archive
        else if (QStringList({"zip", "rar", "7z", "tar", "gz", "bz2", "xz"}).contains(ext)) {
            suggestedCategory = "Archive";
        }
        // Code
        else if (QStringList({"cpp", "h", "py", "js", "html", "css", "java", "c"}).contains(ext)) {
            suggestedCategory = "Quellcode";
        }
        // Sicherungen
        else if (QStringList({"bak", "backup", "old", "tmp"}).contains(ext)) {
            suggestedCategory = "Backups";
        }
        
        // Automatisch hinzufügen ohne Dialog für bekannte Typen
        if (suggestedCategory != "Sonstige") {
            addFileTypeMapping(ext, suggestedCategory, true);
            qDebug() << "[PresetManager] 🤖 Auto-categorized:" << ext << "→" << suggestedCategory;
        }
    }
}

QString PresetManager::getFileExtension(const QString &filePath) const { 
    return QFileInfo(filePath).suffix().toLower(); 
}

QString PresetManager::getCategoryForExtension(const QString &extension) const {
    QString ext = extension.toLower();
    if (fileTypeMappings.contains(ext)) {
        return fileTypeMappings.value(ext).category;
    }
    return "Sonstige";
}QString PresetManager::getSettingsFilePath() const { 
    return mainSettings->fileName(); 
}

QString PresetManager::getLoginFilePath() const { 
    return loginSettings->fileName(); 
}

void PresetManager::setupDefaultMappings() {
    // Standard-Dateityp-Mappings einrichten
    QMap<QString, QStringList> defaultMappings = {
        {"Videos", {"mp4", "avi", "mkv", "mov", "wmv", "flv", "webm", "m4v", "3gp", "asf"}},
        {"Audio", {"mp3", "wav", "flac", "ogg", "aac", "m4a", "wma", "opus", "ape"}},
        {"Bilder", {"jpg", "jpeg", "png", "gif", "bmp", "tiff", "svg", "webp", "ico", "psd"}},
        {"Dokumente", {"pdf", "doc", "docx", "txt", "rtf", "odt", "pages", "epub", "mobi"}},
        {"Tabellen", {"xls", "xlsx", "csv", "ods", "numbers", "tsv"}},
        {"Präsentationen", {"ppt", "pptx", "odp", "key"}},
        {"Archive", {"zip", "rar", "7z", "tar", "gz", "bz2", "xz", "lzma", "dmg", "iso"}},
        {"Quellcode", {"cpp", "h", "py", "js", "html", "css", "java", "c", "php", "rb", "go", "rs"}},
        {"Backups", {"bak", "backup", "old", "tmp", "swp", "orig"}}
    };
    
    for (auto it = defaultMappings.constBegin(); it != defaultMappings.constEnd(); ++it) {
        const QString &category = it.key();
        const QStringList &extensions = it.value();
        
        for (const QString &ext : extensions) {
            if (!fileTypeMappings.contains(ext)) {
                FileTypeMapping mapping;
                mapping.extension = ext;
                mapping.category = category;
                mapping.autoAdd = false;
                mapping.frequency = 0;
                fileTypeMappings[ext] = mapping;
            }
        }
    }
    
    std::cout << "[PresetManager] 📋" << fileTypeMappings.size() << "default file type mappings loaded" << std::endl;
}

// Hardware-optimierte Funktionen
QString PresetManager::getOptimalHashAlgorithm(const QString &fileExtension) const
{
    QString extension = fileExtension.toLower();
    if (extension.startsWith(".")) extension = extension.mid(1);
    
    // Kategorie bestimmen
    QString category = getCategoryForExtension(extension);
    
    // Hardware-optimierten Hash-Algorithmus zurückgeben
    return hashPreferences.value(category, "MD5"); // MD5 als Fallback
}

QString PresetManager::getOptimalHashAlgorithm(const QString &category, const QString &fileExtension) const
{
    Q_UNUSED(fileExtension)
    return hashPreferences.value(category, "MD5");
}

bool PresetManager::shouldUseNpuProcessing(const QString &fileExtension) const
{
    QString extension = fileExtension.toLower();
    if (extension.startsWith(".")) extension = extension.mid(1);
    
    // Prüfe ob Extension in NPU-optimierten Kategorien ist
    for (auto it = npuCategories.constBegin(); it != npuCategories.constEnd(); ++it) {
        if (it.value().contains(extension)) {
            return true;
        }
    }
    return false;
}

bool PresetManager::shouldUseCpuProcessing(const QString &fileExtension) const
{
    QString extension = fileExtension.toLower();
    if (extension.startsWith(".")) extension = extension.mid(1);
    
    // Kleine Dateien oder Text-basierte Formate: CPU optimal
    QStringList cpuOptimalExtensions = QStringList{"txt", "csv", "json", "xml", "cpp", "h", "py", "js", "html", "css"};
    return cpuOptimalExtensions.contains(extension);
}

void PresetManager::loadLoginData()
{
    // ✅ ECHTE LOGIN-DATEN LADEN
    loginData.clear();
    
    // Alle gespeicherten Login-Gruppen durchgehen
    QStringList groups = loginSettings->childGroups();
    for (const QString &key : groups) {
        loginSettings->beginGroup(key);
        
        LoginData login;
        login.username = loginSettings->value("username").toString();
        login.service = loginSettings->value("service").toString();
        login.lastUsed = loginSettings->value("lastUsed").toLongLong();
        login.saveCredentials = loginSettings->value("saveCredentials").toBool();
        login.autoLogin = loginSettings->value("autoLogin").toBool();
        
        // Passwort dekodieren falls gespeichert
        if (login.saveCredentials) {
            QString encodedPassword = loginSettings->value("password").toString();
            login.password = QString::fromUtf8(QByteArray::fromBase64(encodedPassword.toUtf8()));
        }
        
        loginSettings->endGroup();
        
        if (login.isValid()) {
            loginData[key] = login;
            std::cout << "🔐 Login geladen: " << key.toUtf8().constData() 
                      << " User: " << login.username.toUtf8().constData() 
                      << " AutoLogin: " << (login.autoLogin ? "YES" : "NO") << std::endl;
        }
    }
    
    std::cout << "📋 " << loginData.size() << " Login-Einträge geladen" << std::endl;
}
