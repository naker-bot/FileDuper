#include "ftplistworker.h"
#include <QUrl>
#include <QDebug>

FtpListWorker::FtpListWorker(const QString &host, int port, const QString &user, const QString &pass, const QString &dir)
    : m_host(host), m_port(port), m_user(user), m_pass(pass), m_dir(dir)
{
    setAutoDelete(true);  // Auto-delete after run()
}

FtpListWorker::~FtpListWorker()
{
}

size_t FtpListWorker::writeToString(void *ptr, size_t size, size_t nmemb, void *stream)
{
    QString *str = static_cast<QString*>(stream);
    str->append(QString::fromUtf8(static_cast<const char*>(ptr), int(size * nmemb)));
    return size * nmemb;
}

void FtpListWorker::run()
{
    QStringList lines;
    bool success = false;

    CURL *curl = curl_easy_init();
    if (!curl) {
        emit listCompleted(m_dir, lines, false);
        return;
    }

    // Prepare URL
    QString cleanDir = m_dir;
    if (!cleanDir.endsWith('/')) {
        cleanDir += '/';
    }

    QUrl ftpUrl;
    ftpUrl.setScheme("ftp");
    ftpUrl.setHost(m_host);
    ftpUrl.setPort(m_port);
    ftpUrl.setPath(cleanDir);
    QString url = ftpUrl.toString(QUrl::FullyEncoded);

    // Configure libcurl
    curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
    curl_easy_setopt(curl, CURLOPT_USERNAME, m_user.toUtf8().constData());
    curl_easy_setopt(curl, CURLOPT_PASSWORD, m_pass.toUtf8().constData());
    curl_easy_setopt(curl, CURLOPT_FTP_USE_EPSV, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);

    QString listing;
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeToString);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &listing);

    // PERFORM (blocks this worker thread, not main thread!)
    CURLcode res = curl_easy_perform(curl);

    if (res == CURLE_OK) {
        // Parse lines
        QTextStream ts(&listing);
        while (!ts.atEnd()) {
            QString line = ts.readLine().trimmed();
            if (!line.isEmpty()) {
                lines << line;
            }
        }
        success = true;
    }

    curl_easy_cleanup(curl);

    // Emit result (thread-safe signal)
    emit listCompleted(m_dir, lines, success);
}
