#include <iostream>
#include "smbclient.h"
#include <QDebug>
#include <QRegularExpression>

SmbClient::SmbClient(QObject *parent)
    : QObject(parent), port(445), isConnectedFlag(false), currentDirectory("/")
{
    smbProcess = new QProcess(this);
    connectionTimer = new QTimer(this);
    connectionTimer->setSingleShot(true);
    connectionTimer->setInterval(30000); // 30s timeout

    connect(smbProcess, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &SmbClient::onSmbProcessFinished);
    connect(smbProcess, &QProcess::errorOccurred, this, &SmbClient::onSmbProcessError);
    connect(connectionTimer, &QTimer::timeout, [this]()
            { emit errorOccurred("SMB connection timeout"); });
}

SmbClient::~SmbClient()
{
    disconnectFromHost();
}

void SmbClient::setCredentials(const QString &host, int portNum, const QString &user, const QString &pass)
{
    hostname = host;
    port = portNum;
    username = user;
    password = pass;

    std::cout << "[SmbClient] 🔐 Credentials set for " << host.toUtf8().constData()
              << ":" << port << " user: " << user.toUtf8().constData() << std::endl;
}

void SmbClient::connectToHost()
{
    if (isConnectedFlag)
    {
        std::cout << "[SmbClient] ⚠️ Already connected" << std::endl;
        return;
    }

    std::cout << "[SmbClient] 🔗 Connecting to " << hostname.toUtf8().constData()
              << ":" << port << " via SMB..." << std::endl;

    // Start by listing available shares
    listShares();
}

void SmbClient::disconnectFromHost()
{
    if (smbProcess->state() == QProcess::Running)
    {
        std::cout << "[SmbClient] 📴 Disconnecting from " << hostname.toUtf8().constData() << std::endl;
        smbProcess->kill();
        smbProcess->waitForFinished(3000);
    }
    isConnectedFlag = false;
    connectionTimer->stop();
    emit disconnected();
}

bool SmbClient::isConnected() const
{
    return isConnectedFlag;
}

void SmbClient::listShares()
{
    std::cout << "[SmbClient] 🗂️ Listing shares on " << hostname.toUtf8().constData() << std::endl;

    QStringList arguments;
    arguments << "-L" << hostname;

    if (!username.isEmpty())
    {
        arguments << "-U" << QString("%1%%%2").arg(username, password.isEmpty() ? "" : password);
    }
    else
    {
        arguments << "-N"; // No password
    }

    arguments << "--option=client min protocol=NT1"; // Compatibility
    lastCommand = "listShares";
    executeSmbCommand(arguments);
}

void SmbClient::listDirectory(const QString &shareName, const QString &path)
{
    if (shareName.isEmpty())
    {
        emit errorOccurred("Share name cannot be empty");
        return;
    }

    currentShare = shareName;
    currentDirectory = path.isEmpty() ? "/" : path;

    std::cout << "[SmbClient] 📁 Listing directory " << currentDirectory.toUtf8().constData()
              << " in share " << shareName.toUtf8().constData() << std::endl;

    QString smbPath = QString("//%1/%2").arg(hostname, shareName);
    if (!path.isEmpty() && path != "/")
    {
        smbPath += "/" + path;
    }

    QStringList arguments;
    arguments << smbPath << "-c" << "ls";

    if (!username.isEmpty())
    {
        arguments << "-U" << QString("%1%%%2").arg(username, password.isEmpty() ? "" : password);
    }
    else
    {
        arguments << "-N";
    }

    arguments << "--option=client min protocol=NT1";
    lastCommand = "listDirectory";
    executeSmbCommand(arguments);
}

QList<SmbShareInfo> SmbClient::getAvailableShares() const
{
    return availableShares;
}

QList<SmbShareInfo> SmbClient::getCurrentDirectoryListing() const
{
    return currentListing;
}

void SmbClient::downloadFile(const QString &shareName, const QString &remotePath, const QString &localPath)
{
    std::cout << "[SmbClient] ⬇️ Downloading " << remotePath.toUtf8().constData()
              << " from share " << shareName.toUtf8().constData()
              << " to " << localPath.toUtf8().constData() << std::endl;

    QString smbPath = QString("//%1/%2/%3").arg(hostname, shareName, remotePath);

    QStringList arguments;
    arguments << smbPath << "-c" << QString("get %1 %2").arg(remotePath, localPath);

    if (!username.isEmpty())
    {
        arguments << "-U" << QString("%1%%%2").arg(username, password.isEmpty() ? "" : password);
    }
    else
    {
        arguments << "-N";
    }

    lastCommand = "downloadFile";
    executeSmbCommand(arguments);
}

void SmbClient::uploadFile(const QString &localPath, const QString &shareName, const QString &remotePath)
{
    std::cout << "[SmbClient] ⬆️ Uploading " << localPath.toUtf8().constData()
              << " to share " << shareName.toUtf8().constData()
              << " as " << remotePath.toUtf8().constData() << std::endl;

    QString smbPath = QString("//%1/%2").arg(hostname, shareName);

    QStringList arguments;
    arguments << smbPath << "-c" << QString("put %1 %2").arg(localPath, remotePath);

    if (!username.isEmpty())
    {
        arguments << "-U" << QString("%1%%%2").arg(username, password.isEmpty() ? "" : password);
    }
    else
    {
        arguments << "-N";
    }

    lastCommand = "uploadFile";
    executeSmbCommand(arguments);
}

void SmbClient::deleteFile(const QString &shareName, const QString &filePath)
{
    std::cout << "[SmbClient] 🗑️ Deleting " << filePath.toUtf8().constData()
              << " from share " << shareName.toUtf8().constData() << std::endl;

    QString smbPath = QString("//%1/%2").arg(hostname, shareName);

    QStringList arguments;
    arguments << smbPath << "-c" << QString("rm %1").arg(filePath);

    if (!username.isEmpty())
    {
        arguments << "-U" << QString("%1%%%2").arg(username, password.isEmpty() ? "" : password);
    }
    else
    {
        arguments << "-N";
    }

    lastCommand = "deleteFile";
    executeSmbCommand(arguments);
}

void SmbClient::executeSmbCommand(const QStringList &arguments)
{
    if (smbProcess->state() == QProcess::Running)
    {
        smbProcess->kill();
        smbProcess->waitForFinished(1000);
    }

    connectionTimer->start();
    std::cout << "[SmbClient] 💻 Executing: smbclient " << arguments.join(" ").toUtf8().constData() << std::endl;
    smbProcess->start("smbclient", arguments);
}

void SmbClient::onSmbProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    connectionTimer->stop();

    QString output = smbProcess->readAllStandardOutput();
    QString errorOutput = smbProcess->readAllStandardError();

    std::cout << "[SmbClient] 🏁 Process finished with code " << exitCode << std::endl;

    if (exitCode == 0 && !output.isEmpty())
    {
        std::cout << "[SmbClient] 📄 Output: " << output.left(200).toUtf8().constData() << "..." << std::endl;

        if (lastCommand == "listShares")
        {
            parseShareListing(output);
            if (!isConnectedFlag)
            {
                isConnectedFlag = true;
                std::cout << "[SmbClient] ✅ SMB connection established" << std::endl;
                emit connected();
            }
        }
        else if (lastCommand == "listDirectory")
        {
            parseDirectoryListing(output);
        }
    }
    else
    {
        std::cout << "[SmbClient] ❌ Error (code " << exitCode << "): " << errorOutput.toUtf8().constData() << std::endl;

        if (errorOutput.contains("NT_STATUS_LOGON_FAILURE") ||
            errorOutput.contains("NT_STATUS_ACCESS_DENIED"))
        {
            emit errorOccurred("SMB Authentication failed - invalid credentials");
        }
        else if (errorOutput.contains("NT_STATUS_HOST_UNREACHABLE") ||
                 errorOutput.contains("Connection refused"))
        {
            emit errorOccurred("SMB Host unreachable or SMB service not running");
        }
        else
        {
            emit errorOccurred(QString("SMB Error: %1").arg(errorOutput.isEmpty() ? "Unknown error" : errorOutput));
        }
    }
}

void SmbClient::onSmbProcessError(QProcess::ProcessError error)
{
    QString errorString;
    switch (error)
    {
    case QProcess::FailedToStart:
        errorString = "SMB process failed to start (smbclient not installed?)";
        break;
    case QProcess::Crashed:
        errorString = "SMB process crashed";
        break;
    case QProcess::Timedout:
        errorString = "SMB process timeout";
        break;
    default:
        errorString = "Unknown SMB process error";
    }

    std::cout << "[SmbClient] ❌ Process error: " << errorString.toUtf8().constData() << std::endl;
    isConnectedFlag = false;
    connectionTimer->stop();
    emit errorOccurred(errorString);
}

void SmbClient::parseShareListing(const QString &output)
{
    availableShares.clear();
    QStringList lines = output.split('\n', Qt::SkipEmptyParts);

    bool inShareSection = false;
    for (const QString &line : lines)
    {
        if (line.contains("Sharename") && line.contains("Type"))
        {
            inShareSection = true;
            continue;
        }

        if (inShareSection && (line.contains("-----") || line.contains("=====")))
        {
            continue;
        }

        if (inShareSection && !line.trimmed().isEmpty())
        {
            SmbShareInfo share = parseShareLine(line);
            if (!share.name.isEmpty() && !share.name.endsWith("$"))
            { // Skip administrative shares
                availableShares.append(share);
            }
        }

        // Stop parsing after shares section
        if (inShareSection && (line.contains("Domain=") || line.contains("OS=")))
        {
            break;
        }
    }

    std::cout << "[SmbClient] 📊 Found " << availableShares.size() << " shares" << std::endl;
    emit sharesListReceived(availableShares);
}

void SmbClient::parseDirectoryListing(const QString &output)
{
    currentListing.clear();
    QStringList lines = output.split('\n', Qt::SkipEmptyParts);

    for (const QString &line : lines)
    {
        if (line.contains("  D  ") || line.contains("  A  ") || line.contains("  H  "))
        {
            SmbShareInfo info = parseDirectoryLine(line);
            if (!info.name.isEmpty() && info.name != "." && info.name != "..")
            {
                currentListing.append(info);
            }
        }
    }

    std::cout << "[SmbClient] 📊 Parsed " << currentListing.size() << " entries" << std::endl;
    emit directoryListingReceived(currentListing);
}

SmbShareInfo SmbClient::parseShareLine(const QString &line)
{
    SmbShareInfo share;

    // Parse: "  ShareName     Type     Comment"
    QRegularExpression re(R"(\s*(\S+)\s+(Disk|IPC|Printer)\s*(.*)$)");
    QRegularExpressionMatch match = re.match(line);

    if (match.hasMatch())
    {
        share.name = match.captured(1);
        share.type = match.captured(2);
        share.comment = match.captured(3).trimmed();
        share.isDirectory = (share.type == "Disk");
        share.path = QString("//%1/%2").arg(hostname, share.name);
    }

    return share;
}

SmbShareInfo SmbClient::parseDirectoryLine(const QString &line)
{
    SmbShareInfo info;

    // Parse: "  filename.txt    A     1234 Mon Jan 15 10:30:00 2024"
    QRegularExpression re(R"(\s*(.+?)\s+([DAH]+)\s+(\d+)\s+(.+)$)");
    QRegularExpressionMatch match = re.match(line);

    if (match.hasMatch())
    {
        info.name = match.captured(1).trimmed();
        QString attributes = match.captured(2);
        info.size = match.captured(3).toLongLong();
        info.isDirectory = attributes.contains('D');
        info.path = currentDirectory + "/" + info.name;

        // ✅ ECHTE DATUM-PARSING für SMB smbclient Format
        QString dateStr = match.captured(4);
        
        // Parse SMB date format: "Wed Jul 13 10:30:15 2024"
        QDateTime parsedDate = QDateTime::fromString(dateStr, "ddd MMM d hh:mm:ss yyyy");
        if (!parsedDate.isValid()) {
            // Alternative format: "Jul 13 10:30 2024"  
            parsedDate = QDateTime::fromString(dateStr, "MMM d hh:mm yyyy");
        }
        if (!parsedDate.isValid()) {
            // Fallback format: "2024-07-13 10:30"
            parsedDate = QDateTime::fromString(dateStr, "yyyy-MM-dd hh:mm");
        }
        
        info.lastModified = parsedDate.isValid() ? parsedDate : QDateTime::currentDateTime();
    }

    return info;
}
