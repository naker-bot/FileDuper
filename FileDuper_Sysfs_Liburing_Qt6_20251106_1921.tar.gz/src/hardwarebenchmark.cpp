#include "hardwarebenchmark.h"
#include <QTimer>
#include <QSettings>
#include <QDebug>

HardwareBenchmark::HardwareBenchmark(QObject *parent)
    : QObject(parent)
{
    qDebug() << "[HardwareBenchmark] ✅ Konstruktor - ultraschnelle Hardware-Erkennung aktiviert";
}

HardwareCapabilities HardwareBenchmark::detectAndBenchmark()
{
    qDebug() << "[HardwareBenchmark] 🚀 detectAndBenchmark() - sofortige Rückkehr für GUI-Blockade-Vermeidung";
    
    HardwareCapabilities caps;
    
    // ✅ ULTRASCHNELLE MOCK-HARDWARE-ERKENNUNG
    // Keine echten Benchmarks - nur Cache-basierte Werte
    QSettings cache;
    
    // CPU Mock-Werte aus Cache oder Standard-Defaults
    caps.cpuCores = cache.value("hardware/cpu_cores", 8).toInt();
    caps.recommendedThreads = caps.cpuCores;
    caps.maxParallelFtpScans = qMax(1, caps.cpuCores / 2);
    caps.maxParallelHashing = caps.cpuCores;
    caps.availableRamMB = cache.value("hardware/total_ram", 16384).toLongLong();
    
    // CPU instruction sets
    caps.hasSHANI = cache.value("hardware/has_shani", false).toBool();
    caps.hasSHA512NI = cache.value("hardware/has_sha512ni", false).toBool();
    caps.hasAVX2 = cache.value("hardware/has_avx2", true).toBool();
    caps.hasAVX512 = cache.value("hardware/has_avx512", false).toBool();
    
    // GPU Mock-Werte
    caps.hasGPU = cache.value("hardware/gpu_available", true).toBool();
    caps.gpuName = cache.value("hardware/gpu_name", "Mock GPU").toString();
    
    // NPU Mock-Werte  
    caps.hasNPU = cache.value("hardware/npu_available", false).toBool();
    
    // Performance scores
    caps.cpuScore = cache.value("hardware/cpu_score", 85).toInt();
    caps.ioScore = cache.value("hardware/io_score", 85).toInt();
    caps.networkScore = cache.value("hardware/network_score", 90).toInt();
    
    qDebug() << "[HardwareBenchmark] 💾 Cache-Werte geladen:";
    qDebug() << "  🖥️ CPU:" << caps.cpuCores << "Kerne, Threads:" << caps.recommendedThreads;
    qDebug() << "  🎮 GPU:" << (caps.hasGPU ? "verfügbar" : "nicht verfügbar") << caps.gpuName;
    qDebug() << "  🧠 NPU:" << (caps.hasNPU ? "verfügbar" : "nicht verfügbar");
    qDebug() << "  📊 Scores: CPU" << caps.cpuScore << "IO" << caps.ioScore << "Network" << caps.networkScore;
    
    // ✅ SOFORTIGE SIGNAL-EMISSION (keine Delays!)
    emit benchmarkProgress("CPU erkannt", 50);
    emit benchmarkProgress("GPU erkannt", 100);
    emit benchmarkComplete(caps);
    
    qDebug() << "[HardwareBenchmark] ✅ Alle Signale emittiert - detectAndBenchmark() abgeschlossen";
    
    return caps;
}

// Static methods implementation
bool HardwareBenchmark::loadBenchmarkFromINI(HardwareCapabilities &caps)
{
    QSettings settings;
    if (!settings.contains("hardware/cpu_cores")) {
        return false;
    }
    
    caps.cpuCores = settings.value("hardware/cpu_cores", 4).toInt();
    caps.recommendedThreads = settings.value("hardware/recommended_threads", caps.cpuCores).toInt();
    caps.maxParallelFtpScans = settings.value("hardware/max_parallel_ftp", 4).toInt();
    caps.maxParallelHashing = settings.value("hardware/max_parallel_hash", caps.cpuCores).toInt();
    caps.availableRamMB = settings.value("hardware/available_ram", 8192).toLongLong();
    caps.hasNPU = settings.value("hardware/has_npu", false).toBool();
    caps.hasGPU = settings.value("hardware/has_gpu", false).toBool();
    caps.gpuName = settings.value("hardware/gpu_name", "").toString();
    
    // CPU instruction sets
    caps.hasSHANI = settings.value("hardware/has_shani", false).toBool();
    caps.hasSHA512NI = settings.value("hardware/has_sha512ni", false).toBool();
    caps.hasAVX2 = settings.value("hardware/has_avx2", false).toBool();
    caps.hasAVX512 = settings.value("hardware/has_avx512", false).toBool();
    
    // Performance scores
    caps.cpuScore = settings.value("hardware/cpu_score", 50).toInt();
    caps.ioScore = settings.value("hardware/io_score", 50).toInt();
    caps.networkScore = settings.value("hardware/network_score", 50).toInt();
    
    return true;
}

void HardwareBenchmark::saveBenchmarkToINI(const HardwareCapabilities &caps)
{
    QSettings settings;
    settings.setValue("hardware/cpu_cores", caps.cpuCores);
    settings.setValue("hardware/recommended_threads", caps.recommendedThreads);
    settings.setValue("hardware/max_parallel_ftp", caps.maxParallelFtpScans);
    settings.setValue("hardware/max_parallel_hash", caps.maxParallelHashing);
    settings.setValue("hardware/available_ram", caps.availableRamMB);
    settings.setValue("hardware/has_npu", caps.hasNPU);
    settings.setValue("hardware/has_gpu", caps.hasGPU);
    settings.setValue("hardware/gpu_name", caps.gpuName);
    
    // CPU instruction sets
    settings.setValue("hardware/has_shani", caps.hasSHANI);
    settings.setValue("hardware/has_sha512ni", caps.hasSHA512NI);
    settings.setValue("hardware/has_avx2", caps.hasAVX2);
    settings.setValue("hardware/has_avx512", caps.hasAVX512);
    
    // Performance scores
    settings.setValue("hardware/cpu_score", caps.cpuScore);
    settings.setValue("hardware/io_score", caps.ioScore);
    settings.setValue("hardware/network_score", caps.networkScore);
}

bool HardwareBenchmark::hasSavedBenchmark()
{
    QSettings settings;
    return settings.contains("hardware/cpu_cores");
}

// Stub implementations for other methods
int HardwareBenchmark::detectCpuCores()
{
    return QThread::idealThreadCount();
}

qint64 HardwareBenchmark::detectAvailableRAM()
{
    return 16384; // 16GB mock
}

bool HardwareBenchmark::detectNPU()
{
    return false; // NPU detection not implemented
}

bool HardwareBenchmark::detectGPU(QString &gpuName)
{
    gpuName = "Mock GPU";
    return true;
}

int HardwareBenchmark::benchmarkCpuSpeed()
{
    return 85; // Mock score
}

int HardwareBenchmark::benchmarkDiskIO()
{
    return 75; // Mock score
}

int HardwareBenchmark::benchmarkNetworkSpeed()
{
    return 90; // Mock score
}

int HardwareBenchmark::recommendThreadCount(int cpuCores, int cpuScore)
{
    return qMax(1, cpuCores * cpuScore / 100);
}

int HardwareBenchmark::recommendFtpParallel(int cpuCores, int networkScore)
{
    return qMax(1, qMin(8, cpuCores * networkScore / 200));
}

int HardwareBenchmark::recommendHashParallel(int cpuCores, int ioScore)
{
    return qMax(1, cpuCores * ioScore / 150);
}

void HardwareBenchmark::detectCpuFeatures(HardwareCapabilities &caps)
{
    // Mock implementation
    caps.hasSHANI = false;    // SHA hardware acceleration usually not available
    caps.hasSHA512NI = false; // SHA-512 hardware acceleration rare
    caps.hasAVX2 = true;      // AVX2 common on modern CPUs
    caps.hasAVX512 = false;   // AVX-512 mainly on server/workstation CPUs
}