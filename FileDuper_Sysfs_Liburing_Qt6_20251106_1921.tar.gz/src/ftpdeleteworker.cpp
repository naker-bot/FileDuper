#include "ftpdeleteworker.h"
#include <QDebug>
#include <curl/curl.h>

FtpDeleteWorker::FtpDeleteWorker(const QString &host, int port, const QString &user, const QString &pass, 
                                 const QString &remotePath, CompletionCallback callback)
    : m_host(host), m_port(port), m_user(user), m_pass(pass), m_remotePath(remotePath), m_callback(callback)
{
    setAutoDelete(true);
}

FtpDeleteWorker::~FtpDeleteWorker()
{
}

void FtpDeleteWorker::run()
{
    bool success = false;
    
    CURL *curl = curl_easy_init();
    if (!curl) {
        qWarning() << "[FtpDeleteWorker] libcurl init failed for:" << m_remotePath;
        if (m_callback) m_callback(m_remotePath, false);
        return;
    }
    
    // FTP DELE command
    QString baseUrl = QString("ftp://%1:%2/").arg(m_host).arg(m_port);
    
    curl_easy_setopt(curl, CURLOPT_URL, baseUrl.toUtf8().constData());
    curl_easy_setopt(curl, CURLOPT_USERNAME, m_user.toUtf8().constData());
    curl_easy_setopt(curl, CURLOPT_PASSWORD, m_pass.toUtf8().constData());
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    
    // DELE command via QUOTE
    struct curl_slist *commands = nullptr;
    commands = curl_slist_append(commands, ("DELE " + m_remotePath).toUtf8().constData());
    curl_easy_setopt(curl, CURLOPT_QUOTE, commands);
    
    CURLcode res = curl_easy_perform(curl);
    success = (res == CURLE_OK);
    
    if (success) {
        qDebug() << "[FtpDeleteWorker] ✅ DELE success:" << m_remotePath;
    } else {
        qWarning() << "[FtpDeleteWorker] ❌ DELE failed:" << m_remotePath << "-" << curl_easy_strerror(res);
    }
    
    if (m_callback) {
        m_callback(m_remotePath, success);
    }
    
    curl_slist_free_all(commands);
    curl_easy_cleanup(curl);
}
