#include "duplicateresultswidget.h"
#include "scanner.h" // For FileInfo and DuplicateGroups structs
#include <QApplication>
#include <QMessageBox>
#include <QIcon>
#include <QDesktopServices>
#include <QUrl>
#include <QProcess>
#include <QFile>
#include <iostream>

// Color constants for visual distinction
const QColor DuplicateResultsWidget::ORIGINAL_COLOR(255, 255, 0, 128); // Yellow background
const QColor DuplicateResultsWidget::DUPLICATE_COLOR(0, 255, 0, 128);  // Light green background
const QColor DuplicateResultsWidget::SELECTED_COLOR(0, 120, 215, 50);  // Blue tint

DuplicateResultsWidget::DuplicateResultsWidget(QWidget *parent)
    : QWidget(parent), currentRule(KEEP_NEWEST), autoSelectDuplicates(true), colorCodingEnabled(true), selectedDuplicateCount(0), selectedDuplicateSize(0)
{
    setupUI();
    setupTable();
    setupControls();
    setupContextMenu();

    std::cout << "[DuplicateResults] 📊 Widget initialisiert" << std::endl;
}

DuplicateResultsWidget::~DuplicateResultsWidget()
{
    clearResults();
}

void DuplicateResultsWidget::setupUI()
{
    mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(10);

    // Statistics panel
    statsGroup = new QGroupBox("📊 Statistiken");
    QHBoxLayout *statsLayout = new QHBoxLayout(statsGroup);

    totalFilesLabel = new QLabel("Dateien: 0");
    duplicateGroupsLabel = new QLabel("Gruppen: 0");
    duplicateSizeLabel = new QLabel("Duplikat-Größe: 0 MB");
    selectedCountLabel = new QLabel("Ausgewählt: 0");
    selectedSizeLabel = new QLabel("Auswahl-Größe: 0 MB");

    deletionProgress = new QProgressBar();
    deletionProgress->setVisible(false);

    statsLayout->addWidget(totalFilesLabel);
    statsLayout->addWidget(duplicateGroupsLabel);
    statsLayout->addWidget(duplicateSizeLabel);
    statsLayout->addStretch();
    statsLayout->addWidget(selectedCountLabel);
    statsLayout->addWidget(selectedSizeLabel);
    statsLayout->addWidget(deletionProgress);

    mainLayout->addWidget(statsGroup);

    // Configuration panel
    configGroup = new QGroupBox("⚙️ Konfiguration");
    QHBoxLayout *configLayout = new QHBoxLayout(configGroup);

    configLayout->addWidget(new QLabel("Original behalten:"));
    originalRuleCombo = new QComboBox();
    originalRuleCombo->addItems({"Neueste Datei", "Älteste Datei", "Größte Datei", "Kleinste Datei"});
    originalRuleCombo->setCurrentIndex(0); // KEEP_NEWEST

    autoSelectCheck = new QCheckBox("Auto-Auswahl Duplikate");
    autoSelectCheck->setChecked(true);

    colorCodingCheck = new QCheckBox("Farbkodierung");
    colorCodingCheck->setChecked(true);

    refreshBtn = new QPushButton("🔄 Aktualisieren");

    connect(originalRuleCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            [this](int index)
            {
                setOriginalFileRule(static_cast<OriginalFileRule>(index));
                refreshDisplay();
            });
    connect(autoSelectCheck, &QCheckBox::toggled, this, &DuplicateResultsWidget::setAutoSelectDuplicates);
    connect(colorCodingCheck, &QCheckBox::toggled, this, &DuplicateResultsWidget::setColorCoding);
    connect(refreshBtn, &QPushButton::clicked, this, &DuplicateResultsWidget::refreshDisplay);

    configLayout->addWidget(originalRuleCombo);
    configLayout->addWidget(autoSelectCheck);
    configLayout->addWidget(colorCodingCheck);
    configLayout->addStretch();
    configLayout->addWidget(refreshBtn);

    mainLayout->addWidget(configGroup);
}

void DuplicateResultsWidget::setupTable()
{
    // Results table
    resultsGroup = new QGroupBox("🔍 Duplikat-Ergebnisse");
    QVBoxLayout *resultsLayout = new QVBoxLayout(resultsGroup);

    resultsTable = new QTableWidget();
    resultsTable->setColumnCount(6);
    resultsTable->setHorizontalHeaderLabels({"✓", "Datei", "Pfad", "Größe", "Geändert", "Status"});

    // Configure table appearance
    resultsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    resultsTable->setAlternatingRowColors(true);
    resultsTable->setSortingEnabled(true);
    resultsTable->setContextMenuPolicy(Qt::CustomContextMenu);

    // Configure column widths
    QHeaderView *header = resultsTable->horizontalHeader();
    header->setStretchLastSection(true);
    header->resizeSection(0, 50);  // Checkbox column
    header->resizeSection(1, 200); // Filename
    header->resizeSection(2, 300); // Path
    header->resizeSection(3, 80);  // Size
    header->resizeSection(4, 150); // Modified

    connect(resultsTable, &QTableWidget::itemChanged,
            this, &DuplicateResultsWidget::onItemChanged);
    connect(resultsTable, &QTableWidget::itemDoubleClicked,
            this, &DuplicateResultsWidget::onItemDoubleClicked);
    connect(resultsTable, &QTableWidget::customContextMenuRequested,
            this, &DuplicateResultsWidget::showContextMenu);

    resultsLayout->addWidget(resultsTable);
    mainLayout->addWidget(resultsGroup);
}

void DuplicateResultsWidget::setupControls()
{
    // Action buttons
    buttonWidget = new QWidget();
    QHBoxLayout *buttonLayout = new QHBoxLayout(buttonWidget);

    selectAllBtn = new QPushButton("✅ Alle Duplikate");
    deselectAllBtn = new QPushButton("❌ Alle abwählen");
    deleteBtn = new QPushButton("🗑️ Löschen");
    moveToTrashBtn = new QPushButton("📥 In Papierkorb");
    openBtn = new QPushButton("📂 Öffnen");
    exploreBtn = new QPushButton("🔍 Im Explorer");

    // Style the dangerous delete button
    deleteBtn->setStyleSheet("QPushButton { background-color: #D13438; color: white; font-weight: bold; }");
    moveToTrashBtn->setStyleSheet("QPushButton { background-color: #FF8C00; color: white; }");

    connect(selectAllBtn, &QPushButton::clicked, this, &DuplicateResultsWidget::selectAllDuplicates);
    connect(deselectAllBtn, &QPushButton::clicked, this, &DuplicateResultsWidget::deselectAllDuplicates);
    connect(deleteBtn, &QPushButton::clicked, this, &DuplicateResultsWidget::deleteSelectedDuplicates);
    connect(moveToTrashBtn, &QPushButton::clicked, this, &DuplicateResultsWidget::moveSelectedToTrash);
    connect(openBtn, &QPushButton::clicked, this, &DuplicateResultsWidget::openSelectedFiles);
    connect(exploreBtn, &QPushButton::clicked, this, &DuplicateResultsWidget::showSelectedInExplorer);

    buttonLayout->addWidget(selectAllBtn);
    buttonLayout->addWidget(deselectAllBtn);
    buttonLayout->addStretch();
    buttonLayout->addWidget(openBtn);
    buttonLayout->addWidget(exploreBtn);
    buttonLayout->addWidget(moveToTrashBtn);
    buttonLayout->addWidget(deleteBtn);

    mainLayout->addWidget(buttonWidget);
}

void DuplicateResultsWidget::setupContextMenu()
{
    contextMenu = new QMenu(this);

    openAction = contextMenu->addAction("📂 Öffnen");
    exploreAction = contextMenu->addAction("🔍 Im Explorer anzeigen");
    previewAction = contextMenu->addAction("👁️ Vorschau");
    contextMenu->addSeparator();

    selectGroupAction = contextMenu->addAction("✅ Gruppe auswählen");
    deselectGroupAction = contextMenu->addAction("❌ Gruppe abwählen");
    contextMenu->addSeparator();

    trashAction = contextMenu->addAction("📥 In Papierkorb verschieben");
    deleteAction = contextMenu->addAction("🗑️ Permanent löschen");

    connect(openAction, &QAction::triggered, this, &DuplicateResultsWidget::openSelectedFiles);
    connect(exploreAction, &QAction::triggered, this, &DuplicateResultsWidget::showSelectedInExplorer);
    connect(previewAction, &QAction::triggered, this, &DuplicateResultsWidget::previewSelectedFile);
    connect(selectGroupAction, &QAction::triggered, this, &DuplicateResultsWidget::toggleGroupSelection);
    connect(deselectGroupAction, &QAction::triggered, this, &DuplicateResultsWidget::toggleGroupSelection);
    connect(trashAction, &QAction::triggered, this, &DuplicateResultsWidget::moveSelectedToTrash);
    connect(deleteAction, &QAction::triggered, this, &DuplicateResultsWidget::deleteSelectedDuplicates);
}

void DuplicateResultsWidget::displayDuplicateResults(const DuplicateGroups &groups)
{
    currentResults = groups;
    populateTable(groups);
    updateStatistics();

    if (autoSelectDuplicates)
    {
        selectAllDuplicates();
    }

    std::cout << "[DuplicateResults] 📊 " << groups.groups.size()
              << " Duplikat-Gruppen angezeigt" << std::endl;
}

void DuplicateResultsWidget::populateTable(const DuplicateGroups &groups)
{
    resultsTable->setRowCount(0);
    groupLookup.clear();

    int row = 0;
    for (int groupIndex = 0; groupIndex < groups.groups.size(); ++groupIndex)
    {
        const DuplicateGroup &group = groups.groups[groupIndex];

        // Add original file
        resultsTable->insertRow(row);
        QTableWidgetItem *originalItem = createFileItem(group.original, true);
        populateRow(row, group.original, true);
        groupLookup[row] = group;
        row++;

        // Add duplicate files
        for (const FileInfo &duplicate : group.duplicates)
        {
            resultsTable->insertRow(row);
            populateRow(row, duplicate, false);
            groupLookup[row] = group;
            row++;
        }

        // Add separator row for visual grouping
        if (groupIndex < groups.groups.size() - 1)
        {
            resultsTable->insertRow(row);
            for (int col = 0; col < resultsTable->columnCount(); ++col)
            {
                QTableWidgetItem *separatorItem = new QTableWidgetItem("");
                separatorItem->setBackground(QColor(200, 200, 200));
                separatorItem->setFlags(Qt::NoItemFlags);
                resultsTable->setItem(row, col, separatorItem);
            }
            row++;
        }
    }

    if (colorCodingEnabled)
    {
        applyColorCoding();
    }
}

void DuplicateResultsWidget::populateRow(int row, const FileInfo &file, bool isOriginal)
{
    // Checkbox column
    QTableWidgetItem *checkItem = new QTableWidgetItem();
    checkItem->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    checkItem->setCheckState(Qt::Unchecked);
    checkItem->setData(Qt::UserRole, file.filePath);
    checkItem->setData(Qt::UserRole + 1, isOriginal);
    resultsTable->setItem(row, 0, checkItem);

    // Filename with icon
    QFileInfo fileInfo(file.filePath);
    QTableWidgetItem *nameItem = new QTableWidgetItem(file.fileName);
    nameItem->setIcon(getFileTypeIcon(file.filePath));
    nameItem->setToolTip(file.filePath);
    resultsTable->setItem(row, 1, nameItem);

    // Path
    QTableWidgetItem *pathItem = new QTableWidgetItem(fileInfo.absolutePath());
    pathItem->setToolTip(file.filePath);
    resultsTable->setItem(row, 2, pathItem);

    // Size
    QTableWidgetItem *sizeItem = new QTableWidgetItem(formatFileSize(file.size));
    sizeItem->setData(Qt::UserRole, file.size);
    resultsTable->setItem(row, 3, sizeItem);

    // Modified date
    QTableWidgetItem *dateItem = new QTableWidgetItem(formatDateTime(file.lastModified));
    dateItem->setData(Qt::UserRole, file.lastModified);
    resultsTable->setItem(row, 4, dateItem);

    // Status
    QString status = isOriginal ? "📄 Original" : "🔄 Duplikat";
    QTableWidgetItem *statusItem = new QTableWidgetItem(status);
    statusItem->setData(Qt::UserRole, isOriginal);
    resultsTable->setItem(row, 5, statusItem);
}

QTableWidgetItem *DuplicateResultsWidget::createFileItem(const FileInfo &file, bool isOriginal)
{
    QTableWidgetItem *item = new QTableWidgetItem(file.fileName);
    item->setIcon(getFileTypeIcon(file.filePath));
    item->setToolTip(file.filePath);

    if (colorCodingEnabled)
    {
        item->setBackground(isOriginal ? ORIGINAL_COLOR : DUPLICATE_COLOR);
    }

    return item;
}

void DuplicateResultsWidget::applyColorCoding()
{
    for (int row = 0; row < resultsTable->rowCount(); ++row)
    {
        QTableWidgetItem *checkItem = resultsTable->item(row, 0);
        if (!checkItem)
            continue;

        bool isOriginal = checkItem->data(Qt::UserRole + 1).toBool();
        QColor bgColor = isOriginal ? ORIGINAL_COLOR : DUPLICATE_COLOR;

        for (int col = 0; col < resultsTable->columnCount(); ++col)
        {
            QTableWidgetItem *item = resultsTable->item(row, col);
            if (item)
            {
                item->setBackground(bgColor);
            }
        }
    }
}

QString DuplicateResultsWidget::formatFileSize(qint64 bytes) const
{
    const qint64 KB = 1024;
    const qint64 MB = KB * 1024;
    const qint64 GB = MB * 1024;

    if (bytes >= GB)
    {
        return QString("%1 GB").arg(double(bytes) / GB, 0, 'f', 2);
    }
    else if (bytes >= MB)
    {
        return QString("%1 MB").arg(double(bytes) / MB, 0, 'f', 1);
    }
    else if (bytes >= KB)
    {
        return QString("%1 KB").arg(double(bytes) / KB, 0, 'f', 0);
    }
    else
    {
        return QString("%1 B").arg(bytes);
    }
}

QString DuplicateResultsWidget::formatDateTime(qint64 timestamp) const
{
    QDateTime dateTime = QDateTime::fromMSecsSinceEpoch(timestamp);
    return dateTime.toString("dd.MM.yyyy hh:mm");
}

QIcon DuplicateResultsWidget::getFileTypeIcon(const QString &filePath) const
{
    static QFileIconProvider iconProvider;
    return iconProvider.icon(QFileInfo(filePath));
}

void DuplicateResultsWidget::updateStatistics()
{
    totalFilesLabel->setText(QString("Dateien: %1").arg(currentResults.totalFiles));
    duplicateGroupsLabel->setText(QString("Gruppen: %1").arg(currentResults.groups.size()));
    duplicateSizeLabel->setText(QString("Duplikat-Größe: %1").arg(formatFileSize(currentResults.duplicateSize)));

    updateSelection();
}

void DuplicateResultsWidget::updateSelection()
{
    selectedDuplicateCount = 0;
    selectedDuplicateSize = 0;

    for (int row = 0; row < resultsTable->rowCount(); ++row)
    {
        QTableWidgetItem *checkItem = resultsTable->item(row, 0);
        if (checkItem && checkItem->checkState() == Qt::Checked)
        {
            bool isOriginal = checkItem->data(Qt::UserRole + 1).toBool();
            if (!isOriginal)
            { // Only count duplicates
                selectedDuplicateCount++;

                QTableWidgetItem *sizeItem = resultsTable->item(row, 3);
                if (sizeItem)
                {
                    selectedDuplicateSize += sizeItem->data(Qt::UserRole).toLongLong();
                }
            }
        }
    }

    selectedCountLabel->setText(QString("Ausgewählt: %1").arg(selectedDuplicateCount));
    selectedSizeLabel->setText(QString("Auswahl-Größe: %1").arg(formatFileSize(selectedDuplicateSize)));

    emit selectionChanged(selectedDuplicateCount, selectedDuplicateSize);
}

// Stub implementations for remaining methods
void DuplicateResultsWidget::clearResults()
{
    resultsTable->setRowCount(0);
    groupLookup.clear();
    currentResults = DuplicateGroups();
}

void DuplicateResultsWidget::refreshDisplay()
{
    if (!currentResults.groups.isEmpty())
    {
        displayDuplicateResults(currentResults);
    }
}

void DuplicateResultsWidget::selectAllDuplicates()
{
    for (int row = 0; row < resultsTable->rowCount(); ++row)
    {
        QTableWidgetItem *checkItem = resultsTable->item(row, 0);
        if (checkItem)
        {
            bool isOriginal = checkItem->data(Qt::UserRole + 1).toBool();
            if (!isOriginal)
            {
                checkItem->setCheckState(Qt::Checked);
            }
        }
    }
}

void DuplicateResultsWidget::deselectAllDuplicates()
{
    for (int row = 0; row < resultsTable->rowCount(); ++row)
    {
        QTableWidgetItem *checkItem = resultsTable->item(row, 0);
        if (checkItem)
        {
            checkItem->setCheckState(Qt::Unchecked);
        }
    }
}

void DuplicateResultsWidget::setOriginalFileRule(OriginalFileRule rule) { currentRule = rule; }
void DuplicateResultsWidget::setAutoSelectDuplicates(bool enabled) { autoSelectDuplicates = enabled; }
void DuplicateResultsWidget::setColorCoding(bool enabled)
{
    colorCodingEnabled = enabled;
    if (enabled)
        applyColorCoding();
}

// Slot implementations
void DuplicateResultsWidget::onItemChanged(QTableWidgetItem *item) { updateSelection(); }
void DuplicateResultsWidget::onItemDoubleClicked(QTableWidgetItem *item) { openSelectedFiles(); }
void DuplicateResultsWidget::showContextMenu(const QPoint &pos)
{
    QTableWidgetItem *item = resultsTable->itemAt(pos);
    if (!item) return; // Kein Item unter Cursor
    
    // Aktiviere/Deaktiviere Actions basierend auf Selection
    bool hasSelection = !resultsTable->selectedItems().isEmpty();
    openAction->setEnabled(hasSelection);
    exploreAction->setEnabled(hasSelection);
    previewAction->setEnabled(hasSelection);
    trashAction->setEnabled(hasSelection);
    deleteAction->setEnabled(hasSelection);
    
    contextMenu->exec(resultsTable->mapToGlobal(pos));
}

void DuplicateResultsWidget::toggleGroupSelection() 
{
    QTableWidgetItem *item = resultsTable->currentItem();
    if (!item) return;
    
    int row = item->row();
    int groupIndex = resultsTable->item(row, 0)->data(Qt::UserRole).toInt();
    
    // Toggle alle Items in dieser Gruppe
    for (int i = 0; i < resultsTable->rowCount(); ++i) {
        QTableWidgetItem *groupItem = resultsTable->item(i, 0);
        if (groupItem && groupItem->data(Qt::UserRole).toInt() == groupIndex) {
            QTableWidgetItem *checkItem = resultsTable->item(i, 0);
            if (checkItem) {
                bool currentState = (checkItem->checkState() == Qt::Checked);
                checkItem->setCheckState(currentState ? Qt::Unchecked : Qt::Checked);
            }
        }
    }
}

void DuplicateResultsWidget::previewSelectedFile() 
{
    QList<QTableWidgetItem*> selected = resultsTable->selectedItems();
    if (selected.isEmpty()) return;
    
    int row = selected.first()->row();
    QString filePath = resultsTable->item(row, 2)->text(); // Pfad-Spalte
    
    QMessageBox::information(this, "Datei-Info", 
        QString("Pfad: %1\nGröße: %2\nÄnderungsdatum: %3")
            .arg(filePath)
            .arg(resultsTable->item(row, 3)->text())
            .arg(resultsTable->item(row, 4)->text()));
}

void DuplicateResultsWidget::deleteSelectedDuplicates() 
{
    QList<QTableWidgetItem*> selected = resultsTable->selectedItems();
    if (selected.isEmpty()) {
        QMessageBox::information(this, "Keine Auswahl", "Bitte wähle Dateien zum Löschen aus.");
        return;
    }
    
    // Sammle ausgewählte Dateien
    QSet<int> selectedRows;
    for (QTableWidgetItem *item : selected) {
        selectedRows.insert(item->row());
    }
    
    QStringList filesToDelete;
    for (int row : selectedRows) {
        QTableWidgetItem *checkItem = resultsTable->item(row, 0);
        if (checkItem && checkItem->checkState() == Qt::Checked) {
            // Prüfe ob es NICHT das Original ist
            bool isOriginal = checkItem->data(Qt::UserRole + 1).toBool();
            if (!isOriginal) {
                QString filePath = resultsTable->item(row, 2)->text();
                filesToDelete.append(filePath);
            }
        }
    }
    
    if (filesToDelete.isEmpty()) {
        QMessageBox::information(this, "Keine Duplikate", 
            "Keine Duplikate ausgewählt (Originale werden nicht gelöscht).");
        return;
    }
    
    // Bestätigungs-Dialog
    int ret = QMessageBox::warning(this, "Duplikate löschen",
        QString("⚠️ WARNUNG: %1 Dateien permanent löschen?\n\nDieser Vorgang kann NICHT rückgängig gemacht werden!")
            .arg(filesToDelete.size()),
        QMessageBox::Yes | QMessageBox::No,
        QMessageBox::No);
    
    if (ret == QMessageBox::Yes) {
        int deleted = 0;
        int failed = 0;
        
        for (const QString &filePath : filesToDelete) {
            if (QFile::remove(filePath)) {
                deleted++;
                qDebug() << "[DuplicateResults] ✅ Gelöscht:" << filePath;
            } else {
                failed++;
                qDebug() << "[DuplicateResults] ❌ Fehler beim Löschen:" << filePath;
            }
        }
        
        QMessageBox::information(this, "Löschen abgeschlossen",
            QString("✅ Gelöscht: %1\n❌ Fehlgeschlagen: %2").arg(deleted).arg(failed));
        
        // TODO: Tabelle aktualisieren
        emit duplicatesDeleted(deleted);
    }
}

void DuplicateResultsWidget::moveSelectedToTrash() 
{
    QMessageBox::information(this, "Papierkorb",
        "Papierkorb-Funktion noch nicht implementiert.\nVerwende stattdessen 'Löschen'.");
}

void DuplicateResultsWidget::openSelectedFiles() 
{
    QList<QTableWidgetItem*> selected = resultsTable->selectedItems();
    if (selected.isEmpty()) return;
    
    QSet<int> selectedRows;
    for (QTableWidgetItem *item : selected) {
        selectedRows.insert(item->row());
    }
    
    for (int row : selectedRows) {
        QString filePath = resultsTable->item(row, 2)->text();
        
        // Öffne mit Standard-Programm (plattformunabhängig via QDesktopServices)
        QUrl fileUrl = QUrl::fromLocalFile(filePath);
        if (!QDesktopServices::openUrl(fileUrl)) {
            qWarning() << "[DuplicateResults] ❌ Kann Datei nicht öffnen:" << filePath;
        } else {
            qDebug() << "[DuplicateResults] 📂 Geöffnet:" << filePath;
        }
    }
}

void DuplicateResultsWidget::showSelectedInExplorer() 
{
    QList<QTableWidgetItem*> selected = resultsTable->selectedItems();
    if (selected.isEmpty()) return;
    
    int row = selected.first()->row();
    QString filePath = resultsTable->item(row, 2)->text();
    
    // Linux: Öffne Dateimanager und selektiere Datei
    QProcess::startDetached("dolphin", QStringList() << "--select" << filePath);
    
    qDebug() << "[DuplicateResults] 🔍 Im Explorer angezeigt:" << filePath;
}

void DuplicateResultsWidget::selectDuplicatesInGroup(int groupIndex) 
{
    for (int i = 0; i < resultsTable->rowCount(); ++i) {
        QTableWidgetItem *item = resultsTable->item(i, 0);
        if (item && item->data(Qt::UserRole).toInt() == groupIndex) {
            bool isOriginal = item->data(Qt::UserRole + 1).toBool();
            if (!isOriginal) {
                item->setCheckState(Qt::Checked);
            }
        }
    }
}
