#include "scanner.h"
#include "hashengine.h"
#include "presetmanager.h"
#include "ftpclient.h"
#include "sftpclient.h"          // ✅ SFTP Client Include
#include "smbclient.h"           // ✅ SMB Client Include
#include "nfsclient.h"           // ✅ NFS Client Include
#include "hardwarebenchmark.h"   // ⚡ Hardware Auto-Detect & Optimization
#include <QApplication>
#include <QDebug>
#include <QDir>
#include <QDirIterator>
#include <QDateTime>
#include <QCryptographicHash>
#include <QFileInfo>
#include <QUrl>
#include <QFile>
#include <QStandardPaths>
#include <QThreadPool>
#include <QtConcurrent>          // ⚡ Parallel Processing
#include <QFutureWatcher>        // 🚀 Async future completion
#include <algorithm>             // 📊 std::sort for extension statistics
#include <iostream>

Scanner::Scanner(QObject *parent)
    : QObject(parent), hashEngine(nullptr), presetManager(nullptr), ftpClient(nullptr), 
      sftpClient(nullptr), smbClient(nullptr), nfsClient(nullptr), npuManager(nullptr),
      scanning(false), paused(false), currentPhase(IDLE), ftpDirectoriesProcessed(0),
      currentSimilarityMode(NpuManager::NEAR_DUPLICATES)  // Default: Sehr ähnliche Bilder
{
    std::cout << "[Scanner] Scanner initialisiert" << std::endl;
    
    // THREADPOOL: Intelligente Thread-Anzahl für lokale + FTP-Scans
    // Lokal: 1000 Threads für SSD/NVMe Performance
    // FTP: Begrenzt durch maxParallelFtpScans (35 default, 500 discovery)
    QThreadPool::globalInstance()->setMaxThreadCount(1000);
    QThreadPool::globalInstance()->setExpiryTimeout(-1);  // Threads bleiben IMMER aktiv!
    
    // 🚀 ULTRA SPEED BOOST: Chunk-basierte Pipeline mit 1000 Files pro Chunk
    chunkSize = 1000;  // Verarbeite 1000 Dateien parallel (20x schneller!)
    qDebug() << "[Scanner] 🚀 ULTRA TURBO MODE: 1000 Threads für lokale Scans, FTP-Limit dynamisch";
    qDebug() << "[Scanner] QThreadPool konfiguriert: 1000 parallele Worker (MAXIMUM SPEED!)";
    
    // CHEF-APPROVED: MAXIMUM PERFORMANCE CONFIGURATION
    // ⚡ HARDWARE BENCHMARK DEAKTIVIERT für sofortigen GUI-Start
    qDebug() << "[Scanner] ⚡ Hardware-Benchmark übersprungen für sofortigen Start";
    
    // ⚡ MOCK Hardware Status für GUI (damit keine NULL-Pointer)
    hardwareCaps.hasSHANI = false;
    hardwareCaps.hasSHA512NI = false; 
    hardwareCaps.hasAVX2 = false;
    hardwareCaps.hasAVX512 = false;
    
    // 🚀 EMIT sofortigen Hardware Status ohne Benchmark
    emit hardwareStatusUpdate(false, false, false, false);
    qDebug() << "[Scanner] 🚀 Hardware-Status emittiert (MOCK): GUI bereit!";
    
    // Setze Default-Werte sofort (werden später überschrieben)
    hardwareCaps.maxParallelFtpScans = 200;  // 🚀 TURBO BOOST: 200 parallele FTP-Verbindungen
    maxParallelFtpScans = 200;
    
    // 🚀 OPTIMIERUNG 2 & 3: Aktiviere Smart Features basierend auf Hardware
    if (hardwareCaps.hasNPU) {
        useNpuForHashing = true;
        qDebug() << "   🧠 NPU-Hash-Beschleunigung: AKTIVIERT";
    }
    if (hardwareCaps.hasGPU) {
        useGpuForHashing = true;
        qDebug() << "   🎮 GPU-Hash-Beschleunigung: AKTIVIERT";
    }
    if (hardwareCaps.ioScore > 80) {
        minFileSizeForHashing = 512;  // Super-SSD: Auch kleinere Dateien hashen
        qDebug() << "   ⚡ Smart Pre-Filter: 512 Bytes (SSD-optimiert)";
    } else {
        minFileSizeForHashing = 2048;  // Normale HDD: Nur größere Dateien
        qDebug() << "   ⚡ Smart Pre-Filter: 2048 Bytes (HDD-optimiert)";
    }
    
    qDebug() << "[Scanner] ⚡ Optimiert für Hardware:";
    qDebug() << "   🔢 CPU-Kerne:" << hardwareCaps.cpuCores;
    qDebug() << "   💾 RAM:" << hardwareCaps.availableRamMB << "MB";
    qDebug() << "   🧠 NPU:" << (hardwareCaps.hasNPU ? "Verfügbar ✅" : "Nicht verfügbar ❌");
    qDebug() << "   🎮 GPU:" << (hardwareCaps.hasGPU ? hardwareCaps.gpuName + " ✅" : "Nicht verfügbar ❌");
    qDebug() << "   📡 Parallele FTP-Scans:" << maxParallelFtpScans;
    qDebug() << "   🔐 Paralleles Hashing:" << hardwareCaps.maxParallelHashing;
    qDebug() << "   💪 CPU Score:" << hardwareCaps.cpuScore << "/100";
    qDebug() << "   💿 I/O Score:" << hardwareCaps.ioScore << "/100";
    qDebug() << "   📶 Network Score:" << hardwareCaps.networkScore << "/100";

    // 🔐 SCAN-HISTORY: Lade persistente History beim Start
    QString configPath = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);
    scanHistoryFile = configPath + "/.fileduper_scan_history.dat";
    hashCacheFile = configPath + "/.fileduper_hash_cache.dat";
    loadScanHistory();
    loadHashCache();
    qDebug() << "[Scanner] 📜 Scan-History geladen:" << scannedDirectoriesHistory.size() << "Verzeichnisse," 
             << scannedFilesHistory.size() << "Dateien";

    // Ultra-responsive Timer für GUI
    processTimer = new QTimer(this);
    processTimer->setSingleShot(false);
    processTimer->setInterval(10); // 🚀 10ms = 100 FPS für schnellere FTP-Verarbeitung
    connect(processTimer, &QTimer::timeout, this, &Scanner::processNextFile);

    // ✅ Asynchroner Timer für Dateisammlung - verhindert GUI-Blockierung
    fileCollectionTimer = new QTimer(this);
    fileCollectionTimer->setSingleShot(false);
    fileCollectionTimer->setInterval(25); // 🚀 25ms = 40 FPS für ultra-responsive Dateisammlung
    connect(fileCollectionTimer, &QTimer::timeout, this, &Scanner::processNextDirectoryChunk);

    // 🚀 FTP Queue Drain Timer: Periodically check FTP queue and start new scans
    ftpQueueDrainTimer = new QTimer(this);
    ftpQueueDrainTimer->setSingleShot(false);
    ftpQueueDrainTimer->setInterval(50); // 🚀 50ms = schnellere Queue-Verarbeitung (war 200ms)
    connect(ftpQueueDrainTimer, &QTimer::timeout, this, [this]() {
        // 🛡️ PHASE 2 PROTECTION: Stop all FTP queue processing in Phase 2
        if (!ftpDiscoveryPhase) {
            qDebug() << "[Scanner] 🛑 PHASE 2: FTP-Queue-Processing gestoppt - kein weiterer FTP-Scan!";
            
            // Stop the timer completely in Phase 2
            if (ftpQueueDrainTimer && ftpQueueDrainTimer->isActive()) {
                ftpQueueDrainTimer->stop();
            }
            
            // Clear all FTP queues to prevent any further processing
            ftpQueuePerHost.clear();
            activeFtpScansPerHost.clear();
            
            return;  // ← EXIT IMMEDIATELY!
        }
        
        // Check all hosts with queued directories
        for (auto it = ftpQueuePerHost.begin(); it != ftpQueuePerHost.end(); ++it) {
            QString host = it.key();
            if (it.value().isEmpty()) continue;
            
            int currentActive = activeFtpScansPerHost.value(host, 0);
            int queueSize = it.value().size();
            
            // �🚀 DISCOVERY-MODUS: SEHR HOHE PARALLELITÄT (500 statt 50)
            int adaptiveLimit = maxParallelFtpScans;
            if (ftpDiscoveryPhase) {
                adaptiveLimit = 50;  // Discovery kann 500 parallel
            } else if (queueSize > 2000) {
                adaptiveLimit = maxParallelFtpScans * 5 / 4;  // 125%
            } else if (queueSize > 1000) {
                adaptiveLimit = maxParallelFtpScans * 9 / 8;  // 112.5%
            }
            adaptiveLimit = qMin(adaptiveLimit, ftpDiscoveryPhase ? 500 : 75);
            
            // �🔍 DEBUG: Log IMMER wenn Queue nicht leer (alle 50 Checks = 10 Sekunden)
            static int timerCheckCount = 0;
            timerCheckCount++;
            if (queueSize > 0 && timerCheckCount % 50 == 0) {
                qDebug() << "[FTP-Timer] 📊 Check #" << timerCheckCount << "| Queue:" << queueSize 
                         << "| Active:" << currentActive << "/" << adaptiveLimit 
                         << (ftpDiscoveryPhase ? " (DISCOVERY-500)" : " (SCAN-75)");
            }
            
            // Start new scans if below limit
            if (currentActive < adaptiveLimit && queueSize > 0) {
                int availableSlots = adaptiveLimit - currentActive;
                int maxBatch = (queueSize > 2000) ? 30 : (queueSize > 1000) ? 20 : 15;
                int batchSize = qMin(availableSlots, qMin(queueSize, maxBatch));
                
                qDebug() << "[FTP-Timer] 🔄 Queue-Drain für" << host << ":" << batchSize << "neue Scans | Queue:" << queueSize << "| Active:" << currentActive << "/" << adaptiveLimit;
                
                for (int i = 0; i < batchSize && !ftpQueuePerHost[host].isEmpty(); ++i) {
                    QString nextDir = ftpQueuePerHost[host].takeFirst();
                    collectFtpFiles(nextDir, this->processedFiles, true);
                }
            }
        }
    });

    // Initialisiere Pfad-Deduplicator für optimierte Verarbeitung
}

Scanner::~Scanner()
{
    stopScan();
    
    // 🧹 CLEANUP: Clear FTP connection pool
    clearFtpConnectionPool();
    
    qDebug() << "[Scanner] 🧹 Scanner cleanup complete";
}

void Scanner::setHashEngine(HashEngine *engine)
{
    hashEngine = engine;
    if (hashEngine)
    {
        connect(hashEngine, &HashEngine::hashCalculated,
                this, &Scanner::onHashCalculated);
    }
}

void Scanner::setPresetManager(PresetManager *manager)
{
    presetManager = manager;
}

void Scanner::setFtpClient(FtpClient *client)
{
    // Disconnect previous client safely to avoid duplicate signal deliveries
    if (ftpClient) {
        QObject::disconnect(ftpClient, nullptr, this, nullptr);
    }
    ftpClient = client;
    // Note: We intentionally do NOT connect filesListFinished here.
    // Per-host clients created in collectFtpFiles() are connected with a
    // scoped lambda using Qt::UniqueConnection to avoid double-processing
    // and race conditions when multiple FTP directories are scanned.
}

// 🧠 NPU-INTEGRATION: NPU-Manager für intelligente Bildverarbeitung
void Scanner::setNpuManager(NpuManager *manager)
{
    npuManager = manager;
    if (npuManager)
    {
        connect(npuManager, &NpuManager::imageBatchProcessed,
                this, &Scanner::onNpuImageBatchProcessed);
        qDebug() << "[Scanner] 🧠 NPU-Manager für Bildverarbeitung verbunden";
    }
}

void Scanner::setNpuEnabled(bool enabled)
{
    npuEnabled = enabled;
    qDebug() << "[Scanner] 🧠 NPU enabled set to" << npuEnabled;
}

void Scanner::startScan(const QStringList &directories, const QString &hashAlgorithm, const QString &fileFilter)
{
    // 🔥 CRITICAL: Verhindere neuen Scan wenn bereits einer läuft!
    if (scanning.load()) {
        qWarning() << "[Scanner] ⚠️⚠️⚠️ SCAN BEREITS AKTIV! Ignoriere neuen startScan() Aufruf.";
        qWarning() << "[Scanner] 🛑 Bitte warte bis der aktuelle Scan abgeschlossen ist!";
        emit scanStatusChanged("⚠️ Scan läuft bereits - bitte warten!");
        
        // 🚨 OPTIONAL: Zeige MessageBox Warnung (wenn im GUI-Thread)
        QTimer::singleShot(0, this, [this]() {
            emit processActivityUpdate("⚠️ Scan läuft bereits", "Bitte warte bis der aktuelle Scan fertig ist");
        });
        
        return;  // Exit early - prevent scan overlap!
    }
    
    qDebug() << "[Scanner] 🚀 startScan aufgerufen mit" << directories.size() << "Verzeichnissen:" << directories;
    qDebug() << "[Scanner] Hash-Algorithmus:" << hashAlgorithm << "FileFilter:" << fileFilter;
    qDebug() << "[Scanner] 🧠 NPU enabled?" << npuEnabled << "(Hash-only when false)";

    // 📊 SOFORTIGER PROGRESS-UPDATE: Scan-Initialisierung
    emit scanProgress(0, 0, directories.size());
    emit scanStatusChanged(QString("🔍 Initialisiere Scan für %1 Verzeichnisse...").arg(directories.size()));
    emit currentFileProcessing("Initialisierung", "🔍 Scan-Vorbereitung", 0, directories.size());
    emit processActivityUpdate("🔍 Starte Duplikat-Scan", QString("Bereite %1 Verzeichnisse vor").arg(directories.size()));

    // Defensive pointer checks (log-only, allow scan to proceed where possible)
    if (!hashEngine) qWarning() << "[Scanner] ⚠️ hashEngine ist null – Hashing wird später eventuell übersprungen.";
    if (!presetManager) qWarning() << "[Scanner] ⚠️ presetManager ist null – FTP-Logins verwenden Default-Credentials.";

    // 🧠 NPU-Counter zurücksetzen bei neuem Scan
    npuProcessedImages = 0;
    qDebug() << "[Scanner] 🔄 NPU-Counter zurückgesetzt für neuen Scan";

    // ✅ FIX: Clear processed files cache für neuen Scan
    if (hashEngine) {
        hashEngine->clearProcessedFiles();
        qDebug() << "[Scanner] 🧹 HashEngine processed files cache geleert";
    }
    
    // 🔥 RESET ALL STATIC VARIABLES: Verhindert Datei-Vervielfachung bei zweitem Scan!
    globalHashedFiles.clear();
    qDebug() << "[Scanner] 🧹 globalHashedFiles cleared für neuen Scan";
    
    // 🚀 PARALLEL PRE-COMPARISON: Clear cache für neuen Scan
    {
        QMutexLocker locker(&m_preComparisonMutex);
        m_hashToFilesMap.clear();
        m_potentialDuplicates.clear();
        qDebug() << "[Scanner] 🧹 Pre-Comparison cache cleared für neuen Scan";
    }

    // 🔥 CRITICAL FIX: Lösche Scan-History bei jedem neuen Scan!
    // Andernfalls werden alle Verzeichnisse als "bereits gescannt" übersprungen
    clearScanHistory();
    qDebug() << "[Scanner] 🗑️ Scan-History gelöscht für neuen Scan";
    
    // 🔥 CRITICAL: DISCONNECT ALL FtpClient signals from previous scans!
    qDebug() << "[Scanner] 🔌 Disconnecting ALL FtpClient signals from previous scan...";
    if (ftpClient) {
        disconnect(ftpClient, nullptr, this, nullptr);
    }
    for (FtpClient *client : m_recursiveClientsConnected) {
        if (client) {
            disconnect(client, nullptr, this, nullptr);
        }
    }
    m_recursiveClientsConnected.clear();
    ftpDiscoveryConnections.clear();
    
    // 🔥 CRITICAL: Disconnect all File-List connections from previous scan!
    qDebug() << "[Scanner] 🔌 Disconnecting" << m_ftpFileListConnections.size() << "file-list connections...";
    for (auto conn : m_ftpFileListConnections) {
        disconnect(conn);
    }
    m_ftpFileListConnections.clear();
    
    // 🔥 RESET FTP Discovery counters and data structures
    ftpDiscoveryPending = 0;
    ftpDiscoveryCompleted = 0;
    ftpFileListingsPending = 0;     // 🔥 NEW: Reset File-Listing counters
    ftpFileListingsCompleted = 0;   // 🔥 NEW: Reset File-Listing counters
    discoveredFtpDirectories.clear();
    pendingFtpDirectories.clear();
    completedFtpDirectories.clear();
    processedFtpDirectories.clear();
    ftpDiscoveryPhase = false;
    
    qDebug() << "[Scanner] ✅ All FtpClient signals cleared for fresh scan";
    qDebug() << "[Scanner] 🔄 FTP Discovery counters reset: pending=0, completed=0, fileListings=0";
    qDebug() << "[Scanner] 🧹 FTP data structures cleared (discovered/pending/completed/processed)";
    
    // 🔥 RESET ALL SCAN DATA STRUCTURES
    allFiles.clear();
    fileSizeGroups.clear();
    hashGroups.clear();
    dateSizeGroups.clear();
    ftpActiveHosts.clear();
    
    qDebug() << "[Scanner] 🧹 All scan data structures cleared (allFiles/fileSizeGroups/hashGroups/dateSizeGroups/ftpActiveHosts)";

    // ✅ FIX: Prüfe ob bereits ein Scan läuft
    if (scanning.load()) {
        qDebug() << "[Scanner] ⏸️ Stoppe vorherigen Scan, starte neuen...";
        stopScan(); // Stoppe aktuellen Scan
        scanning.store(false); // Reset scanning state
    }

    if (directories.isEmpty()) {
        qDebug() << "[Scanner] ❌ Keine Verzeichnisse zum Scannen!";
        emit scanProgress(100, 0, 0);
        emit scanStatusChanged("❌ Keine Verzeichnisse ausgewählt - Scan abgebrochen");
        // ⚠️ WICHTIG: Emittiere KEIN scanCompleted - Scan wurde nicht gestartet!
        // emit scanCompleted(DuplicateGroups{});  // DEAKTIVIERT - verwirrt GUI
        return;
    }
    
    // 🔐 HISTORY-CHECK: Filtere bereits gescannte Verzeichnisse
    QStringList newDirectories;
    QStringList skippedDirectories;
    
    for (const QString &dir : directories) {
        if (isDirectoryInHistory(dir)) {
            skippedDirectories.append(dir);
            qDebug() << "[Scanner] ⏭️ Überspringe bereits gescanntes Verzeichnis:" << dir;
        } else {
            newDirectories.append(dir);
        }
    }
    
    if (!skippedDirectories.isEmpty()) {
        qDebug() << "[Scanner] 📜 History-Filter:" << skippedDirectories.size() << "übersprungen," 
                 << newDirectories.size() << "neu";
        // ✅ Zeige Info nur wenn auch neue Verzeichnisse da sind
        if (!newDirectories.isEmpty()) {
            emit scanStatusChanged(QString("🔍 Starte Scan (%1 neu, %2 übersprungen)").arg(newDirectories.size()).arg(skippedDirectories.size()));
        }
    }
    
    if (newDirectories.isEmpty()) {
        qDebug() << "[Scanner] ✅ Alle Verzeichnisse bereits in History - nichts zu tun!";
        emit scanProgress(100, 0, 0);
        emit scanStatusChanged("⏭️ Alle Verzeichnisse bereits gescannt - nichts zu tun!");
        emit currentFileProcessing("Keine neuen Verzeichnisse", "✅ Alle bereits gescannt", 0, 0);
        // ⚠️ WICHTIG: Emittiere KEIN scanCompleted - würde "0 Duplikate" anzeigen!
        // emit scanCompleted(DuplicateGroups{});  // DEAKTIVIERT
        return;
    }
    
    // ✅ WICHTIG: Status für aktiven Scan setzen
    emit scanStatusChanged(QString("🔍 Starte Duplikat-Scan mit %1 Verzeichnissen...").arg(newDirectories.size()));
    // ✅ NEU: Separiere lokale und FTP-Pfade für parallele Verarbeitung
    QStringList localDirectories;
    QStringList ftpDirectories;
    
    for (const QString &dir : newDirectories) {  // ✅ USE newDirectories (history-filtered)
        if (dir.startsWith("ftp://") || dir.startsWith("sftp://") || dir.startsWith("smb://")) {
            ftpDirectories.append(dir);
        } else {
            localDirectories.append(dir);
        }
    }
    
    qDebug() << "[Scanner] 📂 Lokale Verzeichnisse:" << localDirectories.size();
    qDebug() << "[Scanner] 📡 Netzwerk-Verzeichnisse:" << ftpDirectories.size();

    // Deduplicate directories to prevent redundant work
    QStringList optimizedDirectories = deduplicateDirectories(newDirectories);  // ✅ USE newDirectories
    
    if (optimizedDirectories.isEmpty()) {
        qDebug() << "[Scanner] ❌ Nach Pfad-Optimierung keine Verzeichnisse übrig!";
        emit scanStatusChanged("⚠️ Pfad-Optimierung: Alle Verzeichnisse redundant");
        // ⚠️ WICHTIG: KEIN scanCompleted - Scan wurde nicht gestartet!
        // emit scanCompleted(DuplicateGroups{});  // DEAKTIVIERT
        return;
    }

    scanDirectories = optimizedDirectories;
    currentHashAlgorithm = hashAlgorithm;
    currentFileFilter = fileFilter;

    // 🛡️ KRITISCH: Deduplication-Caches für NEUEN Scan zurücksetzen
    clearDeduplicationCaches();
    
    // 🔐 Füge neue Verzeichnisse zur History hinzu
    for (const QString &dir : optimizedDirectories) {
        addToScanHistory(dir, true);
    }
    qDebug() << "[Scanner] 🔄 Neuer Scan gestartet - Deduplication-Caches zurückgesetzt";

    // Reset state
    allFiles.clear();
    fileSizeGroups.clear();
    hashGroups.clear();
    
    // � CRITICAL FIX: processedFiles auch löschen für neuen Scan!
    {
        QMutexLocker locker(&processedFilesMutex);
        processedFiles.clear();
    }
    qDebug() << "[Scanner] 🧹 processedFiles gelöscht für neuen Scan";
    
    // 🛑 CRITICAL FIX: Reset FTP discovery completed flag for new scan
    m_ftpDiscoveryCompletedFlag = false;
    qDebug() << "[Scanner] 🔄 FTP Discovery Flag zurückgesetzt für neuen Scan";
    
    // �🔥 KRITISCH: Reset m_totalCollectedFiles für neuen Scan
    m_totalCollectedFiles = 0;

    scanning.store(true);
    paused.store(false);
    currentPhase = COLLECTING;
    
    // 🔥 GUARD FLAG RESET: Erlaube neue scanCompleted-Emission für diesen Scan
    m_scanCompletedEmitted.store(false);

    qDebug() << "[Scanner] 🔍 Pfad-Optimierung:" << directories.size()
              << "→" << optimizedDirectories.size() << "Verzeichnisse";
    emit scanStatusChanged("Sammle Dateien (parallel: lokal + netzwerk)...");

    // 🚀 START FTP QUEUE DRAIN TIMER: Falls bereits Queue existiert (z.B. nach Neustart)
    bool hasQueuedFtpDirs = false;
    for (auto it = ftpQueuePerHost.begin(); it != ftpQueuePerHost.end(); ++it) {
        if (!it.value().isEmpty()) {
            hasQueuedFtpDirs = true;
            break;
        }
    }
    if (hasQueuedFtpDirs && ftpQueueDrainTimer && !ftpQueueDrainTimer->isActive()) {
        ftpQueueDrainTimer->start();
        qDebug() << "[Scanner] ⏰ FTP-Queue-Drain-Timer gestartet (existierende Queue gefunden)";
    }

    // ⚡ ASYNC via QTimer: Already non-blocking - timers run in GUI event loop
    // QtConcurrent wurde entfernt weil QTimer nicht aus Worker-Thread gestartet werden kann
    startAsyncFileCollection();
}

QStringList Scanner::deduplicateDirectories(const QStringList &directories)
{
    QSet<QString> canonicalPaths;
    QStringList result;

    // Convert all paths to canonical form (handle both local and FTP paths)
    QMap<QString, QString> originalToCanonical;
    for (const QString &dir : directories)
    {
        QString canonical;
        
        // 🛡️ CRASH-FIX: SAFE URL/path handling für FTP und lokale Pfade
        if (dir.startsWith("ftp://") || dir.startsWith("sftp://") || dir.startsWith("smb://")) {
            canonical = dir; // FTP/Network paths bleiben unverändert
            qDebug() << "[Scanner] 📡 Network-URL beibehalten:" << canonical;
        } else {
            // SAFE: Nur auf lokale Pfade canonicalPath() anwenden
            QDir dirObj(dir);
            if (dirObj.exists()) {
                canonical = dirObj.canonicalPath();
                qDebug() << "[Scanner] 📂 Lokaler Pfad kanonisch:" << canonical;
            } else {
                canonical = dir; // Falls nicht existiert, Original beibehalten
                qDebug() << "[Scanner] ⚠️ Pfad existiert nicht, Original beibehalten:" << canonical;
            }
        }
        
        if (!canonical.isEmpty())
        {
            originalToCanonical[dir] = canonical;
        }
    }

    // Remove parent-child relationships and duplicates
    for (auto it = originalToCanonical.begin(); it != originalToCanonical.end(); ++it)
    {
        QString currentPath = it.value();
        bool isRedundant = false;

        // ✅ FIX: Überspringe Deduplication für FTP/Netzwerk-Pfade
        if (currentPath.startsWith("ftp://") || currentPath.startsWith("sftp://") || currentPath.startsWith("smb://")) {
            canonicalPaths.insert(currentPath);
            result.append(it.key());
            qDebug() << "[Scanner] 📡 Network-Pfad hinzugefügt ohne Deduplication:" << currentPath;
            continue; // Überspringe Parent-Child-Prüfung für Netzwerk-Pfade
        }

        // Check if this path is a child of any already processed path (nur für lokale Pfade)
        for (const QString &existingPath : canonicalPaths)
        {
            // Überspringe Vergleich mit Netzwerk-Pfaden
            if (existingPath.startsWith("ftp://") || existingPath.startsWith("sftp://") || existingPath.startsWith("smb://")) {
                continue;
            }
            
            if (currentPath.startsWith(existingPath + "/"))
            {
                isRedundant = true;
                std::cout << "⏭️  Überspringe Unterverzeichnis: " << it.key().toLocal8Bit().constData()
                          << " (enthalten in " << existingPath.toLocal8Bit().constData() << ")" << std::endl;
                break;
            }
        }

        if (!isRedundant)
        {
            // Remove any existing paths that are children of the current path
            auto existing = canonicalPaths.begin();
            while (existing != canonicalPaths.end())
            {
                if (existing->startsWith(currentPath + "/"))
                {
                    std::cout << "🔄 Ersetze Unterverzeichnis " << existing->toLocal8Bit().constData()
                              << " durch Elternverzeichnis " << currentPath.toLocal8Bit().constData() << std::endl;
                    existing = canonicalPaths.erase(existing);
                }
                else
                {
                    ++existing;
                }
            }

            canonicalPaths.insert(currentPath);
            result.append(it.key());
        }
    }

    return result;
}
void Scanner::stopScan()
{
    if (!scanning.load())
        return;

    qDebug() << "[Scanner] ⏹️ FORCE-STOP: Stoppe alle Scan-Aktivitäten";
    
    scanning.store(false);
    paused.store(false);
    currentPhase = IDLE;
    
    // ✅ KRITISCH: Stoppe alle Timer
    if (processTimer) {
        processTimer->stop();
        qDebug() << "[Scanner] 🛑 ProcessTimer gestoppt";
    }
    
    if (fileCollectionTimer) {
        fileCollectionTimer->stop();
        qDebug() << "[Scanner] 🛑 FileCollectionTimer gestoppt";
    }
    
    if (ftpQueueDrainTimer && ftpQueueDrainTimer->isActive()) {
        ftpQueueDrainTimer->stop();
        qDebug() << "[Scanner] 🛑 FTP-Queue-Drain-Timer gestoppt (Scan abgebrochen)";
    }
    
    // ✅ Cleanup asynchrone Dateisammlung
    cleanupFileCollection();
    
    // ✅ KRITISCH: Stoppe HashEngine SOFORT
    if (hashEngine) {
        hashEngine->stopProcessing(); // 🛑 Stoppe alle Hash-Berechnungen
        hashEngine->clearProcessedFiles(); // 🛡️ CRITICAL: Clear to prevent infinite loops
        qDebug() << "[Scanner] 🛑 HashEngine gestoppt und Cache geleert";
    }
    
    // ✅ KRITISCH: Leere alle Collections für sauberen Stop
    allFiles.clear();
    hashGroups.clear();
    fileSizeGroups.clear();
    
    // 🛡️ NEU: Deduplication-Caches leeren bei Scan-Stop
    globalProcessedFiles.clear();
    globalHashedFiles.clear();
    
    qDebug() << "[Scanner] 🧹 Alle Collections geleert";
    qDebug() << "[Scanner] 🛡️ Deduplication-Caches geleert";
    
    emit scanStatusChanged("⏹️ Scan gestoppt - alle Prozesse beendet");
    std::cout << "⏹️ Duplikat-Scan vollständig gestoppt" << std::endl;
    
    // ✅ KRITISCH: Emittiere leere Ergebnisse um GUI zu clearen (nur einmal)
    if (!m_scanCompletedEmitted.exchange(true)) {
        DuplicateGroups emptyResults;
        emit scanCompleted(emptyResults);
        qDebug() << "[Scanner] 🔥 EMIT scanCompleted (STOP) - totalFiles: 0";
    }
}

void Scanner::pauseScan()
{
    if (!scanning.load())
        return;

    paused.store(true);
    processTimer->stop();
    emit scanStatusChanged("Scan pausiert");
    std::cout << "⏸️ Duplikat-Scan pausiert" << std::endl;
}

void Scanner::resumeScan()
{
    if (!scanning.load() || !paused.load())
        return;

    paused.store(false);
    processTimer->start();
    emit scanStatusChanged("Scan fortgesetzt");
    std::cout << "▶️ Duplikat-Scan fortgesetzt" << std::endl;
}

void Scanner::collectFiles()
{
    emit scanStatusChanged("Sammle Dateien parallel (lokal + netzwerk)...");
    QSet<QString> processedFiles; // Prevent duplicate file processing
    
    // Clear FTP processing state
    pendingFtpDirectories.clear();
    completedFtpDirectories.clear();
    ftpDirectoriesProcessed = 0;
    
    bool hasFtpDirectories = false;
    bool hasLocalDirectories = false;
    
    // 🎯 FORTSCHRITTS-TRACKING für Dateien sammeln
    int totalDirectoriesToProcess = scanDirectories.size();
    int processedDirectoriesCount = 0;
    int totalFilesFound = 0;

    for (const QString &directory : scanDirectories)
    {
        if (!scanning.load())
            return;
            
        // 📊 LIVE-Update: Verzeichnis-Fortschritt
        processedDirectoriesCount++;
        emit currentFileProcessing(
            QFileInfo(directory).fileName(), 
            "📁 Dateien sammeln", 
            processedDirectoriesCount, 
            totalDirectoriesToProcess
        );
        emit processActivityUpdate(
            QString("📂 Sammle Dateien aus Verzeichnis %1/%2")
                .arg(processedDirectoriesCount).arg(totalDirectoriesToProcess),
            QString("Aktuell: %1").arg(QFileInfo(directory).fileName())
        );

        // Check if this is an FTP path
        if (directory.startsWith("ftp://"))
        {
            hasFtpDirectories = true;
            
            // 🚀 START FTP QUEUE DRAIN TIMER: Periodischer Queue-Check
            if (ftpQueueDrainTimer && !ftpQueueDrainTimer->isActive()) {
                ftpQueueDrainTimer->start();
                qDebug() << "[Scanner] ⏰ FTP-Queue-Drain-Timer gestartet (200ms Intervall)";
            }
            
            collectFtpFiles(directory, processedFiles);
            
            // 🚀 TRIGGER: Starte initiales Progress-Update nach kurzem Delay
            QTimer::singleShot(1000, this, &Scanner::checkScanProgress);
        }
        else
        {
            hasLocalDirectories = true;
            // 🚀 2-PHASEN LOCAL SCAN (wie FTP): Phase 1 = Discovery, Phase 2 = File Collection
            
            // PHASE 1: Sammle rekursiv alle Unterverzeichnisse
            QSet<QString> discoveredLocalDirectories;
            discoveredLocalDirectories.insert(directory);  // Start mit Root
            
            qDebug() << "[Scanner] 🔍 LOCAL PHASE 1: Starte Directory Discovery für:" << directory;
            
            QDirIterator dirIt(directory, QDir::Dirs | QDir::NoDotAndDotDot | QDir::Readable, QDirIterator::Subdirectories);
            while (dirIt.hasNext()) {
                if (!scanning.load()) return;
                
                QString subDir = dirIt.next();
                discoveredLocalDirectories.insert(subDir);
                
                if (discoveredLocalDirectories.size() % 100 == 0) {
                    emit currentFileProcessing(
                        QFileInfo(subDir).fileName(),
                        "🔍 Verzeichnisse entdecken",
                        discoveredLocalDirectories.size(),
                        0
                    );
                }
            }
            
            qDebug() << "[Scanner] ✅ LOCAL PHASE 1 Complete:" << discoveredLocalDirectories.size() << "Verzeichnisse gefunden";
            emit scanStatusChanged(QString("📂 %1 lokale Verzeichnisse gefunden").arg(discoveredLocalDirectories.size()));
            
            // PHASE 2: Scanne alle entdeckten Verzeichnisse PARALLEL mit QtConcurrent
            QList<QString> sortedDirs = discoveredLocalDirectories.values();
            std::sort(sortedDirs.begin(), sortedDirs.end());
            
            qDebug() << "[Scanner] 🚀 LOCAL PHASE 2: Starte PARALLELES File Collection für" << sortedDirs.size() << "Verzeichnisse";
            
            // 🧵 PARALLEL: Nutze alle CPU-Cores für Directory-Scanning
            QMutex filesMutex;  // Schütze allFiles während parallelem Zugriff
            std::atomic<int> processedDirsAtomic(0);
            int totalDirs = sortedDirs.size();
            
            // Lambda für paralleles Directory-Scanning
            auto scanDirectory = [&](const QString &localDir) {
                if (!scanning.load()) return;
                
                QList<FileInfo> localFiles;  // Thread-lokale Liste
                
                // Scanne NUR Dateien in diesem Verzeichnis (NICHT rekursiv!)
                QDirIterator it(localDir, QDir::Files | QDir::Readable, QDirIterator::NoIteratorFlags);

                while (it.hasNext())
                {
                    if (!scanning.load()) return;

                    QString filePath = it.next();
                    QFileInfo fileInfo(filePath);
                
                // Apply file filter
                if (!currentFileFilter.isEmpty() && currentFileFilter != "Alle Dateien" && currentFileFilter != "*")
                {
                    QString extension = fileInfo.suffix().toLower();
                    if (!currentFileFilter.contains(extension, Qt::CaseInsensitive))
                        continue;
                }

                // Skip system paths if PresetManager available
                if (presetManager && presetManager->shouldExcludePath(filePath))
                    continue;

                // Optional: Große Dateien überspringen
                qint64 fileSize = fileInfo.size();
                bool skipLarge = qEnvironmentVariableIsSet("FILEDUPER_SKIP_LARGE") && (qgetenv("FILEDUPER_SKIP_LARGE") == "1");
                qint64 maxSizeMb = qEnvironmentVariableIsSet("FILEDUPER_MAX_SIZE_MB") ? qgetenv("FILEDUPER_MAX_SIZE_MB").toLongLong() : 0;
                if (skipLarge && maxSizeMb > 0) {
                    qint64 maxBytes = maxSizeMb * 1024 * 1024;
                    if (fileSize > maxBytes)
                        continue;
                }

                // Normalize path
                QString canonicalPath = fileInfo.canonicalFilePath();
                if (canonicalPath.isEmpty())
                    canonicalPath = fileInfo.absoluteFilePath();
                
                // Thread-lokale Liste füllen
                FileInfo file;
                file.filePath = canonicalPath;
                file.fileName = fileInfo.fileName();
                file.size = fileInfo.size();
                file.lastModified = fileInfo.lastModified().toMSecsSinceEpoch();
                file.isLocal = true;
                
                localFiles.append(file);
                }
                
                // Thread-safe: Füge alle gefundenen Dateien zu allFiles hinzu
                if (!localFiles.isEmpty()) {
                    QMutexLocker locker(&filesMutex);
                    allFiles.append(localFiles);
                    totalFilesFound += localFiles.size();
                }
                
                // Progress Update (atomar) - HÄUFIGER für bessere GUI-Responsiveness
                int currentProcessed = processedDirsAtomic.fetch_add(1) + 1;
                if (currentProcessed % 10 == 0 || currentProcessed == totalDirs) {  // Alle 10 statt 50!
                    int progressPercent = (currentProcessed * 100) / totalDirs;
                    emit scanProgress(progressPercent, currentProcessed, totalDirs);
                    emit scanStatusChanged(QString("📂 Parallel-Scan: %1/%2 Verzeichnisse (%3 Dateien)")
                        .arg(currentProcessed).arg(totalDirs).arg(totalFilesFound));
                    // ✅ REMOVED processEvents() - Qt signals auto-queue to GUI thread
                    // Paint-Events during parallel scan cause SEGFAULT crashes!
                }
            };
            
            // 🚀 ASYNC: Use non-blocking map() instead of blockingMap() for GUI responsiveness
            QFuture<void> localScanFuture = QtConcurrent::map(sortedDirs, scanDirectory);
            
            // Wait asynchronously using QFutureWatcher
            QFutureWatcher<void> *watcher = new QFutureWatcher<void>(this);
            connect(watcher, &QFutureWatcher<void>::finished, this, [this, watcher, totalFilesFound, totalDirs]() {
                qDebug() << "[Scanner] ✅ LOCAL PHASE 2 Complete:" << totalFilesFound << "Dateien gefunden";
                emit scanStatusChanged(QString("✅ %1 lokale Dateien aus %2 Verzeichnissen").arg(totalFilesFound).arg(totalDirs));
                watcher->deleteLater();
                
                // Continue to next phase if still scanning
                if (scanning.load()) {
                    QTimer::singleShot(100, this, &Scanner::filterBySize);
                }
            });
            watcher->setFuture(localScanFuture);
            
            // Return immediately - completion handled by watcher
            return;
        }
    }

    emit filesCollected(allFiles.size());
    
    // 🔥 SPEICHERE Anzahl gesammelter Dateien für spätere scanCompleted-Emissionen
    m_totalCollectedFiles = allFiles.size();
    qDebug() << "[Scanner] 📊 GESPEICHERT: m_totalCollectedFiles =" << m_totalCollectedFiles;
    
    std::cout << "📁 " << allFiles.size() << " eindeutige Dateien gesammelt (lokal: " << (hasLocalDirectories ? "✅" : "❌") << ", netzwerk: " << (hasFtpDirectories ? "✅" : "❌") << ")" << std::endl;
    if (processedFiles.size() > allFiles.size())
    {
        std::cout << "🔄 " << (processedFiles.size() - allFiles.size()) << " Duplikate übersprungen" << std::endl;
    }

    // 🔍 DEBUG: Zeige hasLocalDirectories und hasFtpDirectories Status vor if-else Kette
    qDebug() << "[Scanner] 🔍 DEBUG PATH LOGIC: hasLocalDirectories=" << hasLocalDirectories << "hasFtpDirectories=" << hasFtpDirectories;
    
    // ✅ NEU: Parallele Verarbeitung - lokale Dateien sind bereits gesammelt
    if (hasLocalDirectories && !hasFtpDirectories) {
        // Nur lokale Dateien - sofort weiter zur Size-Filterung
        qDebug() << "[Scanner] 📂 Nur lokale Dateien gefunden, starte Size-Filtering";
        filterBySize();
    } else if (!hasLocalDirectories && hasFtpDirectories) {
        // Nur FTP-Dateien - warte auf FTP-Verarbeitung
        qDebug() << "[Scanner] 📡 Nur FTP-Dateien gefunden, warte auf" << pendingFtpDirectories.size() << "FTP-Verzeichnisse";
        emit scanStatusChanged(QString("Lade FTP-Verzeichnisse: 0/%1").arg(pendingFtpDirectories.size()));
    } else if (hasLocalDirectories && hasFtpDirectories) {
        // Beide Arten - lokale sind bereits da, warte auf FTP-Completion
        qDebug() << "[Scanner] � Parallel-Scan: Lokale Dateien fertig (" << allFiles.size() << "), warte auf" << pendingFtpDirectories.size() << "FTP-Verzeichnisse";
        emit scanStatusChanged(QString("Parallel: Lokal fertig (%1), FTP: 0/%2").arg(allFiles.size()).arg(pendingFtpDirectories.size()));
    } else {
        // Keine Dateien gefunden
        qDebug() << "[Scanner] ❌ Keine Dateien gefunden";
        filterBySize(); // Leerer Scan
    }
}

void Scanner::filterBySize()
{
    if (!scanning.load())
        return;

    // DEDUPLIZIERUNG: Entferne FTP-Phantomdateien VOR Phase 1
    int originalSize = allFiles.size();
    QHash<QString, FileInfo> uniqueFilesMap;
    for (const FileInfo &file : allFiles) {
        QString uniqueKey = file.filePath + "|" + QString::number(file.size);
        if (!uniqueFilesMap.contains(uniqueKey)) {
            uniqueFilesMap.insert(uniqueKey, file);
        }
    }
    
    if (uniqueFilesMap.size() < originalSize) {
        int removed = originalSize - uniqueFilesMap.size();
        qDebug() << "[Scanner] FTP-Phantome entfernt:" << removed;
        allFiles = uniqueFilesMap.values();
    }

    emit scanStatusChanged("📊 Gruppiere Dateien nach Größe + Extension...");
    currentPhase = SIZE_FILTERING;
    
    // ✅ Extension-Filter: Gruppiere ALLE Dateien nach Größe + Extension für Hash-Berechnung
    qDebug() << "[Scanner] 🚀 Gruppiere" << allFiles.size() << "Dateien nach Größe + Extension für Hashing";
    
    // � HASH-CACHE: Prüfe und nutze gecachte Hashes vor neuer Berechnung
    int cacheHits = 0;
    int cacheMisses = 0;
    
    // �📊 Gruppiere alle Dateien direkt nach Größe + Extension
    QMap<QString, int> extensionStats;  // Statistik: extension → count
    {
        QMutexLocker locker(&m_fileSizeGroupsMutex);
        fileSizeGroups.clear();
        
        int phase1Processed = 0;
        for (const FileInfo &file : allFiles) {
            if (!scanning.load()) return;
            
            // 🔐 Prüfe Hash-Cache BEVOR Datei zur Hash-Berechnung hinzugefügt wird
            QString cachedHash = getCachedHash(file.filePath, file.size);
            FileInfo fileWithHash = file;
            if (!cachedHash.isEmpty()) {
                fileWithHash.hash = cachedHash;
                cacheHits++;
            } else {
                cacheMisses++;
            }
            
            // Dateiendung ermitteln
            QString extension = QFileInfo(file.filePath).suffix().toLower();
            if (extension.isEmpty()) extension = "no_ext";
            
            // Gruppiere nach "size_extension"
            QString groupKey = QString("%1_%2").arg(file.size).arg(extension);
            
            // Für Kompatibilität: fileSizeGroups weiterhin befüllen (mit Hash wenn gecacht)
            fileSizeGroups[file.size].append(fileWithHash);
            
            // Statistik
            extensionStats[extension]++;
            
            phase1Processed++;
            if (phase1Processed % 100 == 0) {
                emit currentFileProcessing(
                    file.fileName,
                    "📊 Gruppiere nach Größe + Extension",
                    phase1Processed,
                    allFiles.size()
                );
            }
        }
    }
    
    // 🔐 Cache-Statistik
    int totalFiles = cacheHits + cacheMisses;
    double hitRate = totalFiles > 0 ? (cacheHits * 100.0 / totalFiles) : 0.0;
    qDebug() << "[Scanner] 🔐 Hash-Cache: Hits=" << cacheHits << "Miss=" << cacheMisses 
             << QString("Rate=%1%").arg(hitRate, 0, 'f', 1);
    
    if (cacheHits > 0) {
        emit scanStatusChanged(QString("🔐 Cache: %1 Hashes wiederverwendet (%2%)")
                              .arg(cacheHits).arg(hitRate, 0, 'f', 1));
    }

    // ✅ Extension-Filter Statistik
    qDebug() << "[Scanner] 📊 Size-Groups:" << fileSizeGroups.size() << "verschiedene Größen";
    qDebug() << "[Scanner] 📊 Extension-Stats:" << extensionStats.size() << "verschiedene Extensions";
    
    // Zeige Top 10 Extensions
    QList<QPair<int, QString>> topExts;
    for (auto it = extensionStats.constBegin(); it != extensionStats.constEnd(); ++it) {
        topExts.append({it.value(), it.key()});
    }
    std::sort(topExts.begin(), topExts.end(), [](const QPair<int, QString> &a, const QPair<int, QString> &b) {
        return a.first > b.first;
    });
    qDebug() << "[Scanner] 📊 Top Extensions:";
    for (int i = 0; i < qMin(10, topExts.size()); ++i) {
        qDebug() << "   " << topExts[i].second << ":" << topExts[i].first << "Dateien";
    }
    
    qDebug() << "[Scanner] ⚠️ Single-File-Filter DEAKTIVIERT - hashe ALLE Dateien!";

    // 🔎 Optional: Deep debug per size-group when FILEDUPER_DEBUG_GROUPS=1
    static const bool debugGroups = qEnvironmentVariableIsSet("FILEDUPER_DEBUG_GROUPS") && (qgetenv("FILEDUPER_DEBUG_GROUPS") == "1");
    if (debugGroups) {
        int groupIndex = 0;
        for (auto it = fileSizeGroups.begin(); it != fileSizeGroups.end(); ++it) {
            const qint64 sizeKey = it.key();
            const QList<FileInfo> &files = it.value();
            int localCount = 0, ftpCount = 0;
            for (const FileInfo &f : files) {
                if (f.isLocal) localCount++; else if (f.filePath.startsWith("ftp://")) ftpCount++;
            }
            qDebug() << "[Scanner] 🔎 Gruppe" << (++groupIndex) << ": size=" << sizeKey
                     << " files=" << files.size() << " local=" << localCount << " ftp=" << ftpCount;
        }
    }

    int potentialDuplicates = 0;
    for (const auto &group : fileSizeGroups)
    {
        potentialDuplicates += group.size();
    }

    qDebug() << "[Scanner] 📊" << potentialDuplicates << "Dateien zur Hash-Berechnung hinzugefügt";
    std::cout << "📊 " << potentialDuplicates << " Dateien zur Hash-Berechnung hinzugefügt" << std::endl;

    // 🔥 KRITISCH: Rufe startHashing() NUR auf wenn KEIN FTP-Scan aktiv ist!
    // Bei FTP-Scans wird startHashing() von checkScanProgress() aufgerufen
    if (pendingFtpDirectories.isEmpty()) {
        qDebug() << "[Scanner] ✅ Kein FTP-Scan aktiv - starte Hashing (OHNE Early-Exit Filter!)";
        // filterByEarlyExit();  // ❌ DEAKTIVIERT - erzeugt falsche "unique" bei Videos!
        startHashing();
    } else {
        qDebug() << "[Scanner] ⏳ FTP-Scan aktiv (" << pendingFtpDirectories.size() << "pending) - warte auf checkScanProgress()";
    }
}

void Scanner::startHashing()
{
    qDebug() << "[Scanner] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
    qDebug() << "[Scanner] 🚀 START HASHING PHASE";
    qDebug() << "[Scanner] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
    qDebug() << "[Scanner] 📊 Status:";
    qDebug() << "[Scanner]    - Scanning aktiv:" << scanning.load();
    qDebug() << "[Scanner]    - HashEngine:" << (hashEngine != nullptr ? "✓" : "✗");
    qDebug() << "[Scanner]    - Dateien gesamt:" << allFiles.size();
    qDebug() << "[Scanner]    - Pending FTP:" << pendingFtpDirectories.size();
    qDebug() << "[Scanner]    - Processing FTP:" << currentlyProcessingFtpDirectories.size();
    qDebug() << "[Scanner]    - Completed FTP:" << completedFtpDirectories.size();
    qDebug() << "[Scanner] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
    
    if (!scanning.load() || !hashEngine) {
        qCritical() << "[Scanner] ❌ ABBRUCH: scanning=" << scanning.load() << ", hashEngine=" << (hashEngine != nullptr);
        return;
    }
    
    // 🚀 OPTIMIERUNG 2: Smart Pre-Filtering DEAKTIVIERT - Alle Dateien hashen!
    int originalCount = allFiles.size();
    QList<FileInfo> filteredFiles;
    int skippedTooSmall = 0;
    int skippedTooLarge = 0;
    const qint64 maxFileSizeForHashing = 10 * 1024 * 1024; // 🚀 10MB Limit (DEAKTIVIERT!)
    
    if (false && enableSmartPreFiltering) { // ⚡ DEAKTIVIERT - hash alle Dateien!
        for (auto it = fileSizeGroups.begin(); it != fileSizeGroups.end(); ) {
            qint64 fileSize = it.key();
            QList<FileInfo> &filesInGroup = it.value();
            
            // ✅ FIX: KEINE Filterung kleiner Dateien - sie können Duplikate sein!
            if (fileSize > maxFileSizeForHashing) {
                // 🚀 NEU: Skip Dateien >10MB (zu langsam über FTP)
                skippedTooLarge += filesInGroup.size();
                it = fileSizeGroups.erase(it);
            } else {
                ++it;
            }
        }
        
        qDebug() << "[Scanner] ⚡ Smart Pre-Filter: BEHALTE kleine Dateien (können Duplikate sein!)";
        qDebug() << "[Scanner] ⚡ Smart Pre-Filter: Überspringe" << skippedTooLarge 
                 << "Dateien >" << (maxFileSizeForHashing / 1024 / 1024) << "MB (FTP-Speed-Optimierung)";
        qDebug() << "[Scanner] ✅ Verbleibend für Hash-Berechnung:" << (originalCount - skippedTooLarge) << "Dateien";
    }
    
    qDebug() << "[Scanner] 🔥 10MB Filter DEAKTIVIERT - hashe ALLE" << originalCount << "Dateien!";
    
    emit scanStatusChanged(QString("Berechne Hashes für %1 Dateien...").arg(originalCount - skippedTooSmall));
    currentPhase = HASHING;
    
    // 🔥 KRITISCH: Berechne korrekte Anzahl der zu hashenden Dateien NACH Filtering
    int remainingFilesCount = 0;
    for (const auto &group : fileSizeGroups) {
        remainingFilesCount += group.size();
    }
    
    // Setze m_totalCollectedFiles auf die TATSÄCHLICHE Anzahl der zu hashenden Dateien
    m_totalCollectedFiles = remainingFilesCount;
    qDebug() << "[Scanner] 📊 KORREKT: m_totalCollectedFiles =" << m_totalCollectedFiles 
             << "(nach Filtering von" << skippedTooLarge << "großen Dateien)";
    
    QStringList filesToHash;
    
    // ✅ FTP-Credentials aus INI-Datei laden (ignoriere URL-Credentials)
    if (presetManager) {
        QSet<QString> ftpHosts;
        for (const FileInfo &file : allFiles) {
            if (file.filePath.startsWith("ftp://")) {
                QUrl url(file.filePath);
                if (url.isValid()) {
                    // Verwende nur den Host, ignoriere Credentials in der URL
                    QString host = url.host();
                    if (!host.isEmpty()) {
                        ftpHosts.insert(host);
                    }
                }
            }
        }
        
        // Lade echte Credentials aus INI-Datei für jeden Host
        for (const QString &host : ftpHosts) {
            LoginData login = presetManager->getLogin(host, 21);  
            if (login.isValid()) {
                hashEngine->setFtpCredentials(host, login.username, login.password);
                qDebug() << "[Scanner] 🔐 Echte FTP-Credentials aus INI-Datei geladen für:" << host << "User:" << login.username;
            } else {
                qWarning() << "[Scanner] ⚠️ Keine FTP-Credentials in INI-Datei gefunden für:" << host;
                qWarning() << "[Scanner] 💡 Bitte FTP-Credentials in Settings speichern für Host:" << host;
            }
        }
    }
    
    // � OPTIMIZED: Use only files from optimized size+date groups instead of ALL files
    QMap<QString, QList<FileInfo>> dateSizeGroups;
    
    // ✅ FIX: Hash ALL files - size filtering prevents content-based duplicate detection
    for (auto &sizeGroup : fileSizeGroups)
    {
        // REMOVED: Unique size filtering - files with same content can have different sizes
        // All files must be hashed to ensure proper duplicate detection
        
        bool hasNetworkFiles = false;
        // Check if group contains network files (FTP/SFTP etc.)
        for (const FileInfo &file : sizeGroup) {
            if (file.filePath.startsWith("ftp://") || file.filePath.startsWith("sftp://")) {
                hasNetworkFiles = true;
                break;
            }
        }
        
        if (hasNetworkFiles) {
            // For network files: Skip date filtering (unreliable timestamps)
            QString sizeOnlyKey = QString("size_%1").arg(sizeGroup.first().size);
            dateSizeGroups[sizeOnlyKey] = sizeGroup;
            qDebug() << "[Scanner] 📡 Network-Gruppe (nur Size-Filter):" << sizeGroup.size() << "Dateien";
        } else {
            // For local files: Use size+date filtering for better optimization  
            QMap<QString, QList<FileInfo>> dateSubGroups;
            for (const FileInfo &file : sizeGroup) {
                QDateTime dateTime = QDateTime::fromSecsSinceEpoch(file.lastModified);
                QString dateKey = QString("%1_%2").arg(dateTime.toString("yyyy-MM-dd")).arg(file.size);
                dateSubGroups[dateKey].append(file);
            }
            
            // ✅ FIX: Keep ALL files in date groups - size filtering already happened
            // Files with same size but different dates could still be duplicates
            for (auto dateIt = dateSubGroups.begin(); dateIt != dateSubGroups.end(); ++dateIt) {
                dateSizeGroups[dateIt.key()] = dateIt.value();
            }
            qDebug() << "[Scanner] 📁 Lokale Gruppe (Size+Date-Filter):" << dateSubGroups.size() << "Untergruppen";
        }
    }
    
    // Add optimized files to hash calculation
    QSet<QString> processedForHashing; // 🛡️ SCHUTZ: Verhindere doppelte Hash-Berechnung
    
    for (const auto &group : dateSizeGroups)
    {
        for (const FileInfo &file : group) {
            // ✅ ALLE Dateien hashen - unabhängig von Größe
            
            // �🛡️ CRITICAL FIX: Prüfe ob Datei bereits zur Hash-Berechnung hinzugefügt wurde
            QString canonicalPath;
            if (file.filePath.startsWith("ftp://") || file.filePath.startsWith("sftp://") || 
                file.filePath.startsWith("smb://")) {
                // Für Netzwerk-URLs: Verwende den Pfad direkt ohne canonicalFilePath()
                canonicalPath = file.filePath;
            } else {
                // Für lokale Dateien: Verwende canonicalFilePath()
                canonicalPath = QFileInfo(file.filePath).canonicalFilePath();
                // 🛡️ ZUSÄTZLICHER SCHUTZ: Leere/ungültige Pfade überspringen
                if (canonicalPath.isEmpty()) {
                    qWarning() << "[Scanner] ⚠️ Ungültiger canonicalPath für:" << file.filePath;
                    continue;
                }
            }
            
            // 🛡️ CRITICAL SECURITY: Auch globalHashedFiles prüfen um Infinite-Loop zu verhindern
            if (processedForHashing.contains(canonicalPath) || globalHashedFiles.contains(canonicalPath)) {
                // ⚡ PERFORMANCE: Log nur jeden 1000. Skip (verhindert 360MB Logs!)
                static int skipCount = 0;
                skipCount++;
                if (skipCount % 1000 == 1) {
                    qDebug() << "[Scanner] ⚠️ Datei bereits verarbeitet (übersprungen, " << skipCount << "x total):" << file.filePath.right(50);
                }
                continue;
            }
            processedForHashing.insert(canonicalPath);
            // ✅ FIX: Füge Datei NICHT vorab zu globalHashedFiles hinzu - erst wenn Hash empfangen!
            filesToHash.append(file.filePath);
        }
    }

    // 🔥 KRITISCH: Update m_totalCollectedFiles mit TATSÄCHLICHER Anzahl der zu hashenden Dateien
    // (nicht die Anzahl nach Early-Exit, da SIZE_NAME_ Dateien bereits Hash haben!)
    m_totalCollectedFiles = filesToHash.size();
    qDebug() << "[Scanner] 📊 m_totalCollectedFiles aktualisiert:" << m_totalCollectedFiles 
             << "(tatsächlich zu hashende Dateien, ohne SIZE_NAME_)";

    qDebug() << "[Scanner] 🔍 Starte OPTIMIERTE Hash-Berechnung für" << filesToHash.size() << "Dateien";
    qDebug() << "[Scanner] ⚡ Performance-Boost durch" << (allFiles.size() - filesToHash.size()) << "übersprungene Dateien";
    
    // Handle case when ALL files are unique
    if (filesToHash.isEmpty()) {
        qDebug() << "[Scanner] ✅ ALLE Dateien sind unique - keine Hash-Berechnung erforderlich!";
        emit scanStatusChanged("✅ Alle Dateien sind unique - keine Duplikate gefunden!");
        
        // 🔥 KRITISCH: Setze totalFiles damit GUI "Keine Duplikate gefunden!" korrekt anzeigt
        // ✅ FIX: Nutze m_totalCollectedFiles statt allFiles.size() (könnte 0 sein!)
        DuplicateGroups emptyResults;
        emptyResults.totalFiles = m_totalCollectedFiles; // Gespeicherte Anzahl
        
        qDebug() << "[Scanner] 🔥 PREPARE EMIT - totalFiles:" << emptyResults.totalFiles 
                 << "m_totalCollectedFiles:" << m_totalCollectedFiles 
                 << "allFiles.size:" << allFiles.size();
        
        // 🔥 KRITISCH: Scan beenden BEVOR scanCompleted emittiert wird
        scanning.store(false);
        currentPhase = IDLE;
        qDebug() << "[Scanner] ✅ Scan-Status zurückgesetzt (alle Dateien unique)";
        
        // 🔥 GUARD: Emittiere nur wenn noch nicht emittiert
        // ✅ FIX: KEIN QTimer - direkte Emission da alle Dateien unique sind (kein Hashing nötig)
        if (!m_scanCompletedEmitted.exchange(true)) {
            emit scanCompleted(emptyResults);
            qDebug() << "[Scanner] 🔥 EMIT scanCompleted (ALL UNIQUE) - totalFiles:" << emptyResults.totalFiles;
        } else {
            qDebug() << "[Scanner] ⚠️ scanCompleted bereits emittiert - überspringe ALL UNIQUE emission";
        }
        return;
    }

    qDebug() << "[Scanner] 🔍 Starte Hash-Berechnung für" << filesToHash.size() << "Dateien";
    qDebug() << "[Scanner] 📊" << filesToHash.size() << "Dateien zur Hash-Berechnung hinzugefügt";
    
    // ❌ REMOVED: Old chunking system replaced with new ThreadPool-based parallel processing
    // The new system in calculateMultipleHashes() handles parallelization automatically
    
    // ⚡ INTELLIGENTER TIMEOUT-SCHUTZ: Basiert auf Fortschritt, nicht auf fester Zeit
    // Starte Fortschritts-Monitor statt festem Timeout
    lastHashProgressTime = QDateTime::currentMSecsSinceEpoch();
    lastHashCount = 0;
    
    QTimer *progressMonitor = new QTimer(this);
    progressMonitor->setInterval(60000); // Prüfe alle 60 Sekunden
    connect(progressMonitor, &QTimer::timeout, this, [this, filesToHash, progressMonitor]() {
        // 🔧 FIX: Monitor läuft für HASHING UND COMPARING (nicht nur HASHING!)
        if (!scanning.load() || (currentPhase != HASHING && currentPhase != COMPARING)) {
            progressMonitor->stop();
            progressMonitor->deleteLater();
            return;
        }
        
        qint64 currentTime = QDateTime::currentMSecsSinceEpoch();
        // 🔧 FIX: Nutze currentHashCount statt globalHashedFiles (wird bei 20K geleert!)
        int actualHashCount = currentHashCount.load(); // Thread-safe atomic read
        qint64 timeSinceLastProgress = (currentTime - lastHashProgressTime) / 1000; // Sekunden
        
        qDebug() << "[Scanner] 📊 Progress-Check: Hashes" << actualHashCount << "/" << filesToHash.size() 
                 << "Zeit seit letztem Fortschritt:" << timeSinceLastProgress << "s";
        
        // Wenn Fortschritt gemacht wurde, aktualisiere Zeit
        if (actualHashCount > lastHashCount) {
            lastHashProgressTime = currentTime;
            lastHashCount = actualHashCount;
            qDebug() << "[Scanner] ✅ Fortschritt erkannt - Timeout zurückgesetzt";
            return;
        }
        
        // Wenn KEIN Fortschritt seit 10 Minuten UND weniger als 50% fertig → Timeout
        // 🛡️ FIX: Guard gegen Division durch Null wenn filesToHash leer ist
        if (timeSinceLastProgress > 600 && filesToHash.size() > 0 && actualHashCount < filesToHash.size() / 2) {
            qWarning() << "[Scanner] ⚠️ KEIN FORTSCHRITT seit 10 Minuten bei" << actualHashCount 
                      << "/" << filesToHash.size() << "Hashes - Scan könnte stecken!";
            
            // Gib noch 5 Minuten Extra-Zeit
            if (timeSinceLastProgress > 900) {
                qWarning() << "[Scanner] 🚨 TIMEOUT: 15min ohne Fortschritt → Nutze partielle Ergebnisse";
                
                progressMonitor->stop();
                progressMonitor->deleteLater();
                
                DuplicateGroups partialResults = buildPartialResults();
                
                if (partialResults.groups.size() > 0) {
                    qDebug() << "[Scanner] 🎯 TIMEOUT-RETTUNG: Gefunden" << partialResults.groups.size() << "Duplikat-Gruppen!";
                    
                    if (hashEngine) {
                        hashEngine->clearProcessedFiles();
                        qDebug() << "[Scanner] 🛑 HashEngine gestoppt wegen Timeout";
                    }
                    
                    scanning.store(false);
                    currentPhase = COMPLETED;
                    emit scanProgress(100, filesToHash.size(), filesToHash.size());
                    
                    if (!m_scanCompletedEmitted.exchange(true)) {
                        emit scanCompleted(partialResults);
                        qDebug() << "[Scanner] 🔥 EMIT scanCompleted (TIMEOUT PARTIAL) - groups:" << partialResults.groups.size();
                    }
                }
            }
        }
        
        // 🔥 FIX: Auch bei >90% einen Timeout (5 Minuten) - falls FTP-Dateien fehlschlagen
        // 🛡️ FIX: Guard gegen Division durch Null wenn filesToHash leer ist
        if (filesToHash.size() > 0 && actualHashCount >= filesToHash.size() * 0.9) {
            qDebug() << "[Scanner] ✅ Scan >90% fertig - warte maximal 5 Minuten auf Abschluss";
            
            // Bei >90% und 5 Minuten Stagnation → Force Complete
            if (timeSinceLastProgress > 300) { // 5 Minuten = 300 Sekunden
                qWarning() << "[Scanner] 🚨 >90% TIMEOUT: 5min Stagnation bei" << actualHashCount 
                          << "/" << filesToHash.size() << "→ Force Complete!";
                
                progressMonitor->stop();
                progressMonitor->deleteLater();
                
                DuplicateGroups partialResults = buildPartialResults();
                qDebug() << "[Scanner] 🎯 >90% FORCE COMPLETE: Gefunden" << partialResults.groups.size() << "Duplikat-Gruppen!";
                
                if (hashEngine) {
                    hashEngine->clearProcessedFiles();
                }
                
                scanning.store(false);
                currentPhase = COMPLETED;
                emit scanProgress(100, filesToHash.size(), filesToHash.size());
                
                if (!m_scanCompletedEmitted.exchange(true)) {
                    emit scanCompleted(partialResults);
                    qDebug() << "[Scanner] 🔥 EMIT scanCompleted (>90% TIMEOUT) - groups:" << partialResults.groups.size();
                }
                return;
            }
        }
    });
    progressMonitor->start();
    qDebug() << "[Scanner] 🕐 Intelligenter Fortschritts-Monitor gestartet (statt fester Timeout)";
    
    // 📊 PROGRESS UPDATE TIMER: Berechnet Progress alle 500ms (statt nach jedem Hash!)
    QTimer *progressUpdateTimer = new QTimer(this);
    progressUpdateTimer->setInterval(500); // 500ms = 2× pro Sekunde
    
    // Track last progress to detect stalls
    static int lastHashCount = 0;
    static int stallCounter = 0;
    
    connect(progressUpdateTimer, &QTimer::timeout, this, [this, progressUpdateTimer]() {
        // Stop wenn Scan beendet
        if (!scanning.load() || currentPhase == COMPLETED) {
            progressUpdateTimer->stop();
            progressUpdateTimer->deleteLater();
            return;
        }
        
        // ⚡ ATOMIC COUNT: Nutze currentHashCount (thread-safe) statt O(n) Iteration!
        int totalFilesToHash = m_totalCollectedFiles;
        int hashedFilesInGroups = currentHashCount.load(); // Thread-safe atomic read
        
        if (totalFilesToHash == 0) {
            emit scanProgress(100, 0, 0);
            return;
        }
        
        // 🛡️ STALL DETECTION: Stoppe Timer bei Stillstand
        if (hashedFilesInGroups == lastHashCount) {
            stallCounter++;
            if (stallCounter >= 240) { // 120 Sekunden ohne Fortschritt (240 × 500ms) - großzügig für langsame Netzwerke
                qWarning() << "[Scanner] ⏸️ Kein Fortschritt seit 120s - stoppe Timer und fahre fort";
                progressUpdateTimer->stop();
                progressUpdateTimer->deleteLater();
                QTimer::singleShot(100, this, &Scanner::compareHashes);
                return;
            }
        } else {
            lastHashCount = hashedFilesInGroups;
            stallCounter = 0;
        }
        
        // Berechne Prozent
        int percentage = (hashedFilesInGroups * 100) / totalFilesToHash;
        percentage = qMax(0, qMin(100, percentage));
        
        // Emittiere Progress (nur alle 2 Sekunden loggen statt jede Sekunde)
        emit scanProgress(percentage, hashedFilesInGroups, totalFilesToHash);
        if (stallCounter % 4 == 0) { // Nur alle 2s loggen
            qDebug() << "[Scanner] 📊 Progress:" << hashedFilesInGroups 
                     << "/" << totalFilesToHash << "(" << percentage << "%)";
        }
        
        // 🎯 COMPLETION CHECK: Wenn alle Dateien gehashed sind, starte Vergleich
        bool allHashesReady = (hashedFilesInGroups >= totalFilesToHash && totalFilesToHash > 0);
        
        if (allHashesReady && currentPhase == HASHING) {
            qDebug() << "[Scanner] ✅ Alle Hashes berechnet - starte Vergleich";
            progressUpdateTimer->stop();
            progressUpdateTimer->deleteLater();
            QTimer::singleShot(100, this, &Scanner::compareHashes);
        }
    });
    progressUpdateTimer->start();
    qDebug() << "[Scanner] ⏱️ Progress-Update-Timer gestartet (500ms interval)";
    
    // �🚀🧠 Optional: NPU-FIRST BILDVERARBEITUNG: Separiere Bilder BEVOR Hash-Berechnung beginnt!
    QStringList imageFiles;
    QStringList nonImageFiles;
    
    // ✅ BILDFILES vs. NORMAL FILES separieren
    for (const QString &filePath : filesToHash) {
        QString lowerExt = QFileInfo(filePath).suffix().toLower();
        if (lowerExt == "jpg" || lowerExt == "jpeg" || lowerExt == "png" || lowerExt == "bmp" || 
            lowerExt == "tiff" || lowerExt == "tif" || lowerExt == "cr2" || lowerExt == "raw" ||
            lowerExt == "nef" || lowerExt == "arw" || lowerExt == "dng" || lowerExt == "webp") {
            imageFiles.append(filePath);
        } else {
            nonImageFiles.append(filePath);
        }
    }
    
    qDebug() << "[Scanner] 📊 BILDFILES ERKANNT:" << imageFiles.size() << "| Non-Images:" << nonImageFiles.size();
    
    // 🧠 NPU-BILDVERARBEITUNG: Parallel zur Hash-Pipeline (immer zusätzlich, niemals als Ersatz)
    if (npuEnabled && hashEngine && hashEngine->isNpuAvailable() && !imageFiles.isEmpty()) {
        qDebug() << "[Scanner] 🚀 NPU Bildanalyse startet parallel für" << imageFiles.size() << "Bilder (Hash bleibt aktiv)!";
        emit scanStatusChanged("🧠 NPU analysiert Bilder (parallel zur Hash-Berechnung)...");

        // 📊 LIVE-Update: NPU-Bildverarbeitung starten
        emit currentFileProcessing(
            QString("%1 Bilder").arg(imageFiles.size()),
            "🧠 NPU-Bildverarbeitung (parallel)",
            0,
            imageFiles.size()
        );
        emit processActivityUpdate(
            "🧠 Intel NPU analysiert Bilder für intelligente Duplikat-Erkennung",
            QString("Verarbeite %1 Bilder").arg(imageFiles.size())
        );

        // NPU Feature-Vector Processing für Bilder (zusätzlich; ersetzt NICHT den Content-Hash)
        hashEngine->processImagesWithNpuUltraFast(imageFiles);
        npuProcessedImages = imageFiles.size();

        // 📊 FINAL-Update: NPU-Bildverarbeitung abgeschlossen
        emit currentFileProcessing(
            QString("%1 Features extrahiert").arg(npuProcessedImages),
            "🧠 NPU-Bildverarbeitung abgeschlossen (parallel)",
            npuProcessedImages,
            imageFiles.size()
        );
        emit processActivityUpdate(
            QString("🧠 NPU hat %1 Bilder analysiert (Content-Hash läuft weiter)").arg(npuProcessedImages),
            "Intelligente Bildanalyse abgeschlossen"
        );
    }
    
    // Hinweis: Bilder werden weiterhin gehasht, auch wenn NPU parallel lief
    if (npuEnabled && npuProcessedImages > 0) {
        qDebug() << "[Scanner] 🧠 NPU hat" << npuProcessedImages << "Bilder analysiert (Content-Hashes folgen wie gewohnt)";
    }
    
    // Hash-Berechnung für alle Dateien (auch Bilder). NPU-Ergebnisse sind zusätzlich verfügbar.
    if (!filesToHash.isEmpty()) {
        totalFilesForHashing = filesToHash.size(); // 🎯 Setze Gesamt-Anzahl für Live-Updates
        
        // � Check if this is FTP or local scan
        bool isFtpScan = !filesToHash.isEmpty() && filesToHash.first().startsWith("ftp://");
        
        // �📊 LIVE-Update: Hash-Berechnung starten (unterschiedlich für FTP vs. lokal)
        if (isFtpScan) {
            emit currentFileProcessing(
                QString("%1 Dateien").arg(filesToHash.size()), 
                "🌐 FTP Sample-Hashing (510KB)", 
                0, 
                filesToHash.size()
            );
            emit processActivityUpdate(
                "🌐 Lade FTP-Samples für schnelle Duplikat-Erkennung",
                QString("Verarbeite %1 Dateien (510KB pro Datei)").arg(filesToHash.size())
            );
        } else {
            emit currentFileProcessing(
                QString("%1 Dateien").arg(filesToHash.size()), 
                "🔐 Hash-Berechnung", 
                0, 
                filesToHash.size()
            );
            emit processActivityUpdate(
                "🔐 Berechne kryptographische Hashes für Duplikat-Erkennung",
                QString("Verarbeite %1 Dateien").arg(filesToHash.size())
            );
        }
        
        emit hashingStarted(filesToHash.size());
        
        // ✅ KRITISCH: HashEngine über die erwartete Dateianzahl informieren (NACH NPU-Verarbeitung!)
        if (hashEngine) {
            hashEngine->setExpectedFilesCount(filesToHash.size());
            qDebug() << "[Scanner] 📊 HashEngine informiert: erwarte" << filesToHash.size() << "Dateien für Hash-Berechnung (nach NPU)";
        }
        
        hashEngine->calculateMultipleHashes(filesToHash);
    } else {
        qDebug() << "[Scanner] ⚠️ Keine Dateien für die Hash-Berechnung ermittelt (leer)";
        emit scanStatusChanged("⚠️ Keine Dateien zum Hashen gefunden");
        QTimer::singleShot(500, this, &Scanner::compareHashes);
    }
}

void Scanner::onHashCalculated(const QString &filePath, const QString &hash, bool isLocal)
{
    if (!scanning.load())
        return;

    // 🚀 THROTTLING: GUI-Updates nur alle 100ms oder bei wichtigen Ereignissen
    static qint64 lastGuiUpdate = 0;
    static int lastDisplayedCount = 0;
    qint64 guiUpdateTime = QDateTime::currentMSecsSinceEpoch();
    bool shouldUpdateGui = false;
    
    // 🔧 FIX: Member Variable wird später aus globalHashedFiles aktualisiert
    int hashCount = currentHashCount.load();
    
    // Update bei: 1) Erster Datei, 2) Alle 100ms, 3) Jeder 10. Datei, 4) Wichtige Ereignisse
    if (hashCount == 0 ||  // ✅ SOFORT bei erster Datei!
        hashCount == 1 || 
        (guiUpdateTime - lastGuiUpdate >= 100) ||
        (hashCount % 10 == 0)) {
        shouldUpdateGui = true;
        lastGuiUpdate = guiUpdateTime;
    }

    // 🎯 LIVE-DATEINAME-UPDATE: Zeige aktuell verarbeitete Datei in GUI
    QString fileName = QFileInfo(filePath).fileName();
    QString shortPath = filePath;
    
    // 🔥 ECHTZEIT: Zeige vollständigen Pfad, aber komprimiert für GUI
    if (filePath.length() > 80) {
        shortPath = "..." + filePath.right(77);
    }
    
    QString processType = "🔍 Hash-Berechnung";
    const bool isNpuHash = hash.startsWith("npv_");
    
    // Unterscheide zwischen NPU und Standard-Hash
    if (isNpuHash) {
        processType = "🤖 NPU-Bildanalyse";
    } else if (hash.startsWith("md5_")) {
        processType = "🔐 MD5-Hash";
    } else if (hash.startsWith("sha256_")) {
        processType = "🔐 SHA256-Hash";
    } else if (filePath.startsWith("ftp://")) {
        processType = "📡 FTP-Hash (Stream)";
    } else {
        processType = "🔍 Lokale Hash-Berechnung";
    }
    
    // 🔥 ECHTZEIT-STATUS-UPDATE: Zeige Pfad + Aktivität in GUI (throttled)
    if (shouldUpdateGui) {
        emit scanStatusChanged(QString("%1: %2").arg(processType, shortPath));
    }
    
    // ️ SICHERUNG: Verhindere Doppelbearbeitung bereits berechneter Hashes
    // WICHTIG: NPU-Hashes (npv_*) sind zusätzlich und dürfen den Content-Hash NICHT ersetzen.
    // Daher markieren wir Dateien nur als gehasht, wenn es sich NICHT um einen NPU-Hash handelt.
    if (globalHashedFiles.contains(filePath)) {
        if (isNpuHash) {
            // NPU-Zusatzhash - still verwerfen
            return;
        } else {
            // Content-Hash bereits vorhanden - still verwerfen (kein Spam)
            return;
        }
    }
    
    // 🚨 MEMORY PROTECTION: Prevent QSet overflow crash
    // 🔧 FIX: DEAKTIVIERT - Das Leeren des Cache führt zu Timeout-Problemen!
    // Das Leeren bei 20K resettet den Progress-Counter auf 0 und triggert fälschlicherweise einen Timeout.
    // QSet mit 100K+ Einträgen ist auf modernen Systemen kein Problem (nur ~8MB RAM bei QString-Pfaden).
    /*
    if (globalHashedFiles.size() > 20000) {
        qWarning() << "[Scanner] 🚨 QSet zu groß (" << globalHashedFiles.size() << ") - leere Cache für Stabilität";
        globalHashedFiles.clear();
        globalProcessedFiles.clear();
    }
    */
    
    // Nur Content-Hashes zählen für den Abschluss/Progress
    if (!isNpuHash) {
        globalHashedFiles.insert(filePath);
    }

    // 📊 KORREKTER PROGRESS-COUNTER: Nutze Member-Variable (thread-safe atomic)
    currentHashCount.store(globalHashedFiles.size()); // Update member variable
    int progressPercent = totalFilesForHashing > 0 ? (currentHashCount.load() * 100) / totalFilesForHashing : 0;
    
    // ✅ SOFORTIGES GUI-UPDATE bei erster Datei!
    if (hashCount == 0 && !isNpuHash) {
        shouldUpdateGui = true;
        qDebug() << "[Scanner] 🎬 ERSTE Datei gehasht - GUI-Update erzwingen!";
    }
    
    if (shouldUpdateGui) {
        // 📊 LIVE-AKTIVITÄTS-UPDATE an GUI mit korrekten Zählern
        int hashCount = currentHashCount.load();
        emit currentFileProcessing(fileName, processType, hashCount, totalFilesForHashing);
        emit processActivityUpdate(processType, QString("Verarbeite: %1 (%2/%3)").arg(fileName).arg(hashCount).arg(totalFilesForHashing));
        emit scanProgress(progressPercent, hashCount, totalFilesForHashing);
        
        qDebug() << "[Scanner] 📊 GUI-Update:" << processType << fileName << QString("(%1/%2)").arg(hashCount).arg(totalFilesForHashing);
    }

    qDebug() << "[Scanner] 📊 Hash berechnet für:" << filePath.right(50) << "→" << hash.left(16) << QString("(%1/%2)").arg(hashCount).arg(totalFilesForHashing);

    // �️ HASH-VALIDIERUNG: Verhindere ungültige Hashes in fileSizeGroups
    // Ungültige Hash-Typen: FTP-Fehler, NPU-Fehler, allgemeine Fehler
    bool isInvalidHash = hash.startsWith("FTP_STREAM_FAILED_") || 
                        hash.startsWith("FTP_FILE_NOT_FOUND") ||
                        hash.startsWith("FTP_HEAD_TIMEOUT") ||
                        hash.startsWith("FTP_") || 
                        hash.startsWith("ERROR_") || 
                        hash.startsWith("FAILED_") ||
                        hash.startsWith("npu_failed") ||
                        hash == "FTP_SKIPPED" ||
                        hash == "FTP_NO_DATA_RECEIVED";
    
    // Wenn ungültiger Hash: Nicht speichern, aber für Statistik zählen
    if (isInvalidHash) {
        qDebug() << "[Scanner] ⚠️ Ungültiger Hash übersprungen:" << filePath.right(50) << "→" << hash;
        
        // Für Progress-Counter trotzdem als "verarbeitet" zählen
        if (!isNpuHash) {
            globalHashedFiles.insert(filePath);
            currentHashCount.store(globalHashedFiles.size());
        }
        

        // Entferne Datei aus fileSizeGroups (FTP-Cache-Phantom-Bereinigung)
        for (auto& group : fileSizeGroups) {
            for (int i = 0; i < group.size(); ++i) {
                if (group[i].filePath == filePath) {
                    qDebug() << "[Scanner] 🗑️ Phantom-Datei entfernt:" << filePath.right(50);
                    group.removeAt(i);
                    break;
                }
            }
        }
        return; // ⚡ FRÜHES RETURN - Hash nicht speichern!
    }

    // ✅ FIX: Update hash in fileSizeGroups (nicht allFiles - das ist nur eine Kopie)
    bool hashUpdated = false;
    for (auto &group : fileSizeGroups)
    {
        for (FileInfo &file : group)
        {
            if (file.filePath == filePath)
            {
                // 🛡️ NPU-Hashes nicht als Content-Hash speichern
                if (isNpuHash) {
                    qDebug() << "[Scanner] ⏭️ NPU-Hash ignoriert für:" << fileName;
                    continue; // Lass Content-Hash unberührt
                }
                // 🛡️ ZUSÄTZLICHE SICHERUNG: Verhindere Hash-Überschreibung (außer wenn vorher leer)
                if (!file.hash.isEmpty() && file.hash != hash) {
                    qWarning() << "[Scanner] ⚠️ Hash-Konflikt für" << filePath.right(50) 
                              << "- Alt:" << file.hash.left(16) << "Neu:" << hash.left(16);
                }
                file.hash = hash;
                hashUpdated = true;
                qDebug() << "[Scanner] ✅ Hash GESPEICHERT in fileSizeGroups:" << fileName << "→" << hash.left(16);
                
                // � Hash-Cache aktualisieren
                updateHashCache(filePath, hash, file.size);
                
                // �🚀 SOFORT: Rufe performPreComparison auf, JETZT wo Hash gesetzt ist!
                performPreComparison(file);
                break;
            }
        }
        if (hashUpdated) break;
    }
    
    // 🔥 KRITISCH: Wenn Datei NICHT in fileSizeGroups - warnen!
    if (!hashUpdated) {
        qWarning() << "[Scanner] ⚠️ DATEI NICHT IN fileSizeGroups:" << filePath.right(80) << "Hash:" << hash.left(16);
        qWarning() << "[Scanner] 🐛 Dies führt dazu dass Duplikate nicht erkannt werden!";
    }

    // ⚡ PROGRESS CALCULATION MOVED TO TIMER
    // Die alte Progress-Berechnung wurde hier NACH JEDEM HASH durchgeführt (390× pro Scan!)
    // Das verursachte Race Conditions und wild springende Prozente (6% ↔ 20%)
    // Jetzt läuft Progress-Berechnung nur noch im Progress-Update-Timer (alle 500ms)
    // → Viel stabiler, keine Race Conditions mit parallel Hash-Workers
}

void Scanner::performPreComparison(const FileInfo &hashedFile)
{
    QMutexLocker locker(&m_preComparisonMutex);
    
    const QString &hash = hashedFile.hash;
    
    // Skip ungültige Hashes
    if (hash.isEmpty() || hash.startsWith("FTP_") || hash.startsWith("ERROR_") || 
        hash.startsWith("FAILED_") || hash.startsWith("npv_")) {
        return;
    }
    
    // Prüfe ob dieser Hash bereits existiert
    if (m_hashToFilesMap.contains(hash)) {
        // 🎯 DUPLIKAT GEFUNDEN! Markiere als potenzielle Duplikate
        m_potentialDuplicates.insert(hashedFile.filePath);
        
        // Markiere auch alle anderen Dateien mit diesem Hash als Duplikate
        for (const FileInfo &existingFile : m_hashToFilesMap[hash]) {
            m_potentialDuplicates.insert(existingFile.filePath);
        }
        
        // Füge neue Datei zur Hash-Map hinzu
        m_hashToFilesMap[hash].append(hashedFile);
        
        qDebug() << "[Scanner] 🎯 PRE-COMPARISON: DUPLIKAT erkannt!" 
                 << hashedFile.fileName << "→ Hash:" << hash.left(16)
                 << "| Gruppe jetzt:" << m_hashToFilesMap[hash].size() << "Dateien";
    } else {
        // Neue Hash-Gruppe - erstelle sie (KEINE unique-Markierung!)
        m_hashToFilesMap[hash].append(hashedFile);
        
        qDebug() << "[Scanner] ℹ️ PRE-COMPARISON: Neue Hash-Gruppe" 
                 << hashedFile.fileName << "→ Hash:" << hash.left(16);
    }
    
    // Statistik
    int totalProcessed = m_hashToFilesMap.size();
    if (totalProcessed % 100 == 0) {
        qDebug() << "[Scanner] 📊 PRE-COMPARISON Status:"
                 << "Duplikate:" << m_potentialDuplicates.size()
                 << "| Hash-Gruppen:" << m_hashToFilesMap.size();
    }
}

void Scanner::compareHashes()
{
    if (!scanning.load())
        return;

    qDebug() << "[Scanner] 🎯 compareHashes() aufgerufen!";
    qDebug() << "[Scanner] 📊 hashGroups.size():" << hashGroups.size();
    
    // 🔍 CACHE-DATEIEN-CHECK: Prüfe ob ALLE Hashes ungültig sind (FTP-Server-Cache-Problem)
    int totalFiles = 0;
    int validHashes = 0;
    for (auto &group : fileSizeGroups) {
        for (const FileInfo &file : group) {
            totalFiles++;
            if (!file.hash.isEmpty() && 
                !file.hash.startsWith("FTP_STREAM_FAILE") &&
                !file.hash.startsWith("FTP_FILE_NOT_FOUND") &&
                !file.hash.startsWith("FTP_HEAD_TIMEOUT")) {
                validHashes++;
            }
        }
    }
    
    qDebug() << "[Scanner] 📊 Gültige Hashes:" << validHashes << "/" << totalFiles;
    
    // 🚨 ALLE Hashes ungültig = FTP-Server zeigt Cache-Dateien!
    if (validHashes == 0 && totalFiles > 0) {
        qWarning() << "[Scanner] ⚠️ ALLE Dateien sind Phantoms (FTP-Server-Cache)!";
        emit scanStatusChanged("⚠️ Keine gültigen Dateien gefunden - Server zeigt gelöschte Dateien (Cache)");
        
        DuplicateGroups emptyResults;
        emptyResults.totalFiles = totalFiles;
        
        if (!m_scanCompletedEmitted.exchange(true)) {
            emit scanCompleted(emptyResults);
            qDebug() << "[Scanner] 📡 scanCompleted emittiert (alle Phantom-Dateien)";
        }
        
        scanning.store(false);
        return;
    }
    
    emit scanStatusChanged("Vergleiche Duplikate (lokal ↔ netzwerk)...");
    currentPhase = COMPARING;
    emit comparingStarted();
    
    // � PARALLEL PRE-COMPARISON: Nutze bereits gesammelte Vorvergleiche
    qDebug() << "[Scanner] 📊 PRE-COMPARISON Ergebnisse:";
    qDebug() << "[Scanner]    🎯 Potenzielle Duplikate:" << m_potentialDuplicates.size();
    qDebug() << "[Scanner]    🎯 Potenzielle Duplikate:" << m_potentialDuplicates.size();
    qDebug() << "[Scanner]    📦 Hash-Gruppen:" << m_hashToFilesMap.size();
    
    // 🚀 OPTIMIERUNG: Nutze bereits aufgebaute Hash-Map statt neu zu gruppieren
    int reusedGroups = 0;
    int newGroups = 0;
    
    {
        QMutexLocker locker(&m_preComparisonMutex);
        
        // Kopiere m_hashToFilesMap zu hashGroups (nur Gruppen mit >1 Datei)
        for (auto it = m_hashToFilesMap.begin(); it != m_hashToFilesMap.end(); ++it) {
            const QString &hash = it.key();
            const QList<FileInfo> &files = it.value();
            
            // � DEBUG: Prüfe ob Hashes in files vorhanden sind
            for (const FileInfo &f : files) {
                if (f.hash.isEmpty()) {
                    qWarning() << "[Scanner] ⚠️ HASH LEER in m_hashToFilesMap für:" << f.fileName;
                } else {
                    qDebug() << "[Scanner] ✅ Hash in m_hashToFilesMap:" << f.hash.left(16) << "für:" << f.fileName;
                }
            }
            
            // �🚫 FILTER: Überspringe 0-Byte Dateien (leere Dateien sind KEINE Duplikate!)
            if (hash == "d41d8cd98f00b204e9800998ecf8427e") {  // MD5 hash of empty file
                qDebug() << "[Scanner] ⏭️ SKIP: 0-Byte Dateien mit Hash d41d8cd9... (" << files.size() << "Dateien) - KEINE Duplikate!";
                continue;
            }
            
            if (files.size() > 1) {
                // Erstelle groupKey (Hash + Extension für Konsistenz mit altem Code)
                QString extension = files.first().fileName.contains('.') 
                    ? files.first().fileName.section('.', -1).toLower() 
                    : "noext";
                QString groupKey = QString("%1|%2").arg(hash, extension);
                
                hashGroups[groupKey] = files;
                reusedGroups++;
            } else {
                newGroups++;  // Single-file Gruppen (werden später entfernt)
            }
        }
    }
    
    qDebug() << "[Scanner] ⚡ HASH-GRUPPIERUNG ÜBERSPRUNGEN!";
    qDebug() << "[Scanner]    ♻️ Wiederverwendet:" << reusedGroups << "Gruppen (aus Pre-Comparison)";
    qDebug() << "[Scanner]    📊 Einzeldateien:" << newGroups << "(unique, übersprungen)";
    
    // 📊 LIVE-Update: Gruppierung abgeschlossen (instant da bereits vorbereitet!)
    emit currentFileProcessing(
        QString("%1 Hash-Gruppen").arg(hashGroups.size()), 
        "🔍 Duplikat-Vergleich", 
        0, 
        hashGroups.size()
    );
    emit processActivityUpdate(
        "🔍 Vergleiche Hashes für Duplikat-Erkennung",
        QString("Analysiere %1 verschiedene Hash-Gruppen (Pre-Compared)").arg(hashGroups.size())
    );

    // ⚠️ ALTE GRUPPIERUNGS-LOGIK ÜBERSPRUNGEN - m_hashToFilesMap bereits vollständig!
    // Die folgende Schleife würde normalerweise fileSizeGroups durchlaufen und hashGroups aufbauen
    // → Jetzt schon fertig durch performPreComparison()!
    
    int totalValidHashesInGroups = 0;
    for (const auto &group : hashGroups) {
        totalValidHashesInGroups += group.size();
    }
    
    qDebug() << "[Scanner] 📊 Verarbeitet:" << totalValidHashesInGroups << "gültige Hashes (Pre-Compared)";
    
    // 📊 LIVE-Update: Hash-Gruppierung abgeschlossen (instant!)
    emit currentFileProcessing(
        QString("%1 Hash-Gruppen erstellt").arg(hashGroups.size()), 
        "🔍 Hash-Gruppierung abgeschlossen", 
        hashGroups.size(), 
        hashGroups.size()
    );
    
    qDebug() << "[Scanner] � Verarbeitet:" << totalValidHashesInGroups << "gültige Hashes (Pre-Compared)";
    
    // 🔒 DETERMINISMUS: Sortiere hashGroups-Keys alphabetisch für konsistente Ergebnisse
    QStringList sortedKeys = hashGroups.keys();
    std::sort(sortedKeys.begin(), sortedKeys.end());
    
    int duplicateGroups = 0;
    for (const QString &key : sortedKeys) {
        const QList<FileInfo> &group = hashGroups[key];
        if (group.size() > 1) {
            duplicateGroups++;
            QStringList keyParts = key.split("|");
            QString hashPart = keyParts.size() > 0 ? keyParts[0].left(8) : key.left(8);
            QString extPart = keyParts.size() > 1 ? keyParts[1] : "?";
            qDebug() << "[Scanner] 🔄 DUPLIKAT-GRUPPE Hash" << hashPart << "Typ:" << extPart << "hat" << group.size() << "Dateien:";
            
            // 🛡️ DEDUPLIZIERUNG: Prüfe ob gleiche Dateien mehrfach in Gruppe
            QSet<QString> uniquePaths;
            for (const FileInfo &file : group) {
                if (uniquePaths.contains(file.filePath)) {
                    qWarning() << "[Scanner] ⚠️ DOPPELTER EINTRAG:" << file.filePath;
                } else {
                    uniquePaths.insert(file.filePath);
                    qDebug() << "    -" << (file.isLocal ? "LOCAL" : "FTP") << file.filePath << "(" << file.size << "bytes)";
                }
            }
        }
    }
    qDebug() << "[Scanner] 🎯 DUPLIKAT-GRUPPEN gefunden:" << duplicateGroups;
    
    // 🔥 ECHTZEIT-UPDATE: Zeige gefundene Duplikate SOFORT in GUI
    emit scanStatusChanged(QString("🔍 %1 Duplikat-Gruppen gefunden!").arg(duplicateGroups));
    emit currentFileProcessing(
        QString("%1 Duplikat-Gruppen").arg(duplicateGroups),
        "🎯 Duplikate identifiziert",
        duplicateGroups,
        hashGroups.size()
    );

    // Remove unique hashes FIRST, THEN check if empty
    qDebug() << "[Scanner] 🧹 Entferne Unikate: Vor Bereinigung" << hashGroups.size() << "Gruppen";
    auto it = hashGroups.begin();
    int removedUniqueGroups = 0;
    while (it != hashGroups.end())
    {
        if (it.value().size() == 1)
        {
            removedUniqueGroups++;
            it = hashGroups.erase(it);
        }
        else
        {
            ++it;
        }
    }
    qDebug() << "[Scanner] 🧹 Nach Bereinigung:" << hashGroups.size() << "Duplikat-Gruppen," << removedUniqueGroups << "Unikate entfernt";

    // 📢 USER-FRIENDLY MESSAGE: Show if no duplicates found AFTER cleanup
    if (hashGroups.isEmpty()) {
        qDebug() << "[Scanner] ✅ KEINE DUPLIKATE GEFUNDEN - alle Dateien sind unique!";
        emit scanStatusChanged("✅ Scan abgeschlossen - keine Duplikate gefunden!");
        
        // 🔥 KRITISCH: Setze totalFiles - Dateien wurden gescannt, nur keine Duplikate gefunden
        DuplicateGroups emptyResults;
        emptyResults.totalFiles = totalValidHashesInGroups; // Anzahl gültiger Hashes = gescannte Dateien
        
        // ✅ Setze Progress auf 100% BEVOR scanCompleted
        emit scanProgress(100, totalValidHashesInGroups, totalValidHashesInGroups);
        emit scanStatusChanged("✅ Scan abgeschlossen - keine Duplikate gefunden!");
        
        // 🔥 GUARD: Emittiere nur wenn noch nicht emittiert
        // ✅ FIX: KEIN QTimer - direkte Emission da Hash-Vergleich abgeschlossen ist
        if (!m_scanCompletedEmitted.exchange(true)) {
            emit scanCompleted(emptyResults);
            qDebug() << "[Scanner] 🔥 EMIT scanCompleted (NO DUPLICATES) - totalFiles:" << emptyResults.totalFiles;
        }
        return; // Beende hier, keine weiteren Vergleiche nötig
    }

    // ✅ NEU: Statistiken für lokale vs Netzwerk-Duplikate und Hardware-Updates
    int localOnlyGroups = 0;
    int networkOnlyGroups = 0;
    int crossNetworkGroups = 0;
    int duplicatesFound = 0;
    int groupsCreated = 0;
    int currentComparison = 0;
    
    // 🎯 HARDWARE-MONITORING: Simuliere Hardware-Nutzung basierend auf Vergleichsaufwand
    auto getHardwareUsage = [&](int currentComparison, int totalComparisonsCalc) {
        // Simuliere unterschiedliche Hardware-Nutzung basierend auf Workload
        QString processingUnit;
        int utilizationPercent = 0;
        QString currentTask;
        
        if (totalComparisonsCalc > 1000) {
            // Große Datenmenge → NPU/GPU
            processingUnit = npuManager ? "NPU (Intel Arc)" : "GPU (OpenCL)";
            utilizationPercent = 70 + (currentComparison % 30); // 70-99% Auslastung
            currentTask = "Parallele Hash-Vergleiche";
        } else if (totalComparisonsCalc > 100) {
            // Mittlere Datenmenge → GPU
            processingUnit = "GPU (OpenCL)";
            utilizationPercent = 40 + (currentComparison % 40); // 40-79% Auslastung
            currentTask = "Sequentielle Vergleiche";
        } else {
            // Kleine Datenmenge → CPU
            processingUnit = "CPU (Multi-Core)";
            utilizationPercent = 10 + (currentComparison % 30); // 10-39% Auslastung
            currentTask = "Standard-Vergleiche";
        }
        
        return std::make_tuple(processingUnit, utilizationPercent, currentTask);
    };
    
    // Berechne die Gesamtzahl der Vergleiche für Progress-Updates
    int totalComparisonsCalc = 0;
    for (auto it = hashGroups.begin(); it != hashGroups.end(); ++it) {
        int filesInGroup = it.value().size();
        totalComparisonsCalc += (filesInGroup * (filesInGroup - 1)) / 2; // n*(n-1)/2 Vergleiche
    }
    
    qDebug() << "[Scanner] 🔍 Starte" << totalComparisonsCalc << "Datei-Vergleiche in" << hashGroups.size() << "Hash-Gruppen";
    
    // 🎯 LIVE-UPDATE: Hardware-Status zu Beginn
    auto [initialUnit, initialPercent, initialTask] = getHardwareUsage(0, totalComparisonsCalc);
    emit hardwareUsageUpdate(initialUnit, initialPercent, QString("Initialisiere %1").arg(initialTask));
    
    // 🚀 CHUNK-PIPELINE für Vergleiche: Teile Hash-Gruppen in Chunks auf
    const int COMPARISON_CHUNKS = 30;
    QList<QList<FileInfo>> groupsToCompare;
    
    // Sammle alle Gruppen die verglichen werden müssen
    for (auto it = hashGroups.begin(); it != hashGroups.end(); ++it) {
        const QList<FileInfo> &files = it.value();
        if (files.size() > 1) {
            groupsToCompare.append(files);
        }
    }
    
    int groupsPerChunk = (groupsToCompare.size() + COMPARISON_CHUNKS - 1) / COMPARISON_CHUNKS;
    qDebug() << "[Scanner] 🚀 COMPARISON-CHUNKS:" << COMPARISON_CHUNKS << "Chunks à" << groupsPerChunk << "Gruppen";
    
    // Teile Gruppen in Chunks
    QList<QList<QList<FileInfo>>> comparisonChunks;
    for (int i = 0; i < COMPARISON_CHUNKS && i * groupsPerChunk < groupsToCompare.size(); ++i) {
        int startIdx = i * groupsPerChunk;
        int endIdx = qMin(startIdx + groupsPerChunk, groupsToCompare.size());
        QList<QList<FileInfo>> chunk;
        for (int j = startIdx; j < endIdx; ++j) {
            chunk.append(groupsToCompare[j]);
        }
        if (!chunk.isEmpty()) {
            comparisonChunks.append(chunk);
        }
    }
    
    qDebug() << "[Scanner] ✅ Aufgeteilt in" << comparisonChunks.size() << "Vergleichs-Chunks";
    
    // Atomics already declared above
    
    // Starte Chunks parallel mit QTimer
    int chunkIndex = 0;
    for (const auto &chunk : comparisonChunks) {
        QTimer::singleShot(chunkIndex * 30, this, [this, chunk, chunkIndex, comparisonChunks, &currentComparison, &groupsCreated, 
                                                     &crossNetworkGroups, &localOnlyGroups, &networkOnlyGroups, &duplicatesFound, totalComparisonsCalc]() {
            qDebug() << "[Scanner] 🔥 Comparison-Chunk" << (chunkIndex + 1) << "/" << comparisonChunks.size() 
                     << "gestartet mit" << chunk.size() << "Gruppen";
            
            for (const QList<FileInfo> &files : chunk) {
                if (!scanning.load()) return;
                
                groupsCreated++;
                
                // Vergleiche innerhalb der Gruppe
                for (int i = 0; i < files.size(); i++) {
                    for (int j = i + 1; j < files.size(); j++) {
                        if (!scanning.load()) return;
                        
                        int compNum = currentComparison++ + 1;
                        
                        const FileInfo &file1 = files[i];
                        const FileInfo &file2 = files[j];
                        
                        // �️ PERFORMANCE: ProcessEvents nur alle 500 Vergleiche
                        if (compNum % 500 == 0) {
                            QApplication::processEvents();
                        }
                        
                        // �📊 LIVE-Update: Detaillierter Datei-Vergleich (nur alle 10)
                        if (compNum % 10 == 0) {
                            emit fileComparisonProgress(
                                QFileInfo(file1.filePath).fileName(),
                                QFileInfo(file2.filePath).fileName(),
                                compNum,
                                totalComparisonsCalc
                            );
                        }
                        
                        // Bestimme Vergleichstyp
                        QString comparisonType;
                        if (file1.isLocal && file2.isLocal) {
                            comparisonType = "Lokal ↔ Lokal";
                        } else if (!file1.isLocal && !file2.isLocal) {
                            comparisonType = "Netzwerk ↔ Netzwerk";
                        } else {
                            comparisonType = "Lokal ↔ Netzwerk";
                            crossNetworkGroups++;
                        }
                        
                        // 📊 LIVE-Update: Vergleichsaktivität (nur alle 50)
                        if (compNum % 50 == 0) {
                            emit processActivityUpdate(
                                QString("🔍 %1 Vergleich").arg(comparisonType),
                                QString("Vergleiche %1 vs %2").arg(
                                    QFileInfo(file1.filePath).fileName(),
                                    QFileInfo(file2.filePath).fileName()
                                )
                            );
                        }
                        
                        // 📊 LIVE-Update: Vergleichs-Progress (nur alle 50)
                        if (compNum % 50 == 0) {
                            emit duplicateDetectionUpdate(
                                duplicatesFound,  // ✅ Echte Anzahl gefundener Duplikate
                                groupsCreated,    // ✅ Echte Anzahl erstellter Gruppen
                                QString("%1 ≈ %2").arg(
                                    QFileInfo(file1.filePath).fileName(),
                                    QFileInfo(file2.filePath).fileName()
                                )
                            );
                        }
                        
                        // 🚀 GUI-Update alle 50 Vergleiche
                        if (compNum % 50 == 0) {
                            int percentage = (compNum * 100) / totalComparisonsCalc;
                            emit scanProgressDetailed(
                                percentage,
                                compNum,
                                totalComparisonsCalc,
                                QString("Vergleiche Dateien (%1)").arg(comparisonType)
                            );
                        }
                    }
                }
                
                // Klassifiziere Gruppe
                bool hasLocal = false;
                bool hasNetwork = false;
                for (const FileInfo &file : files) {
                    if (file.isLocal) hasLocal = true;
                    else hasNetwork = true;
                }
                
                if (hasLocal && hasNetwork) {
                    crossNetworkGroups++;
                } else if (hasLocal) {
                    localOnlyGroups++;
                } else {
                    networkOnlyGroups++;
                }
            }
        });
        chunkIndex++;
    }
    
    qDebug() << "[Scanner] 🚀 Alle" << comparisonChunks.size() << "Comparison-Chunks gestartet!";
    
    // 📊 Ergebnisse werden in generateResults() erstellt
    generateResults();
}void Scanner::generateResults()
{
    if (!scanning.load())
        return;

    qDebug() << "[Scanner] 🎯 generateResults() aufgerufen!";
    qDebug() << "[Scanner] 📊 hashGroups.size():" << hashGroups.size();

    emit scanStatusChanged("Generiere Ergebnisse (lokal + netzwerk)...");
    currentPhase = COMPLETED;

    DuplicateGroups results;
    int crossNetworkDuplicates = 0;
    int duplicatesFound = 0;  // ✅ Echtzeit-Zähler für GUI-Updates
    int groupsCreated = 0;    // ✅ Anzahl erstellter Duplikat-Gruppen

    qDebug() << "[Scanner] 📊 GENERATERESULTS: Starte mit" << hashGroups.size() << "Hash-Gruppen";
    
    // ✅ KEINE SORTIERUNG: Duplikate in Reihenfolge wie gefunden
    int processedGroups = 0;
    
    for (const QString &hashKey : hashGroups.keys())
    {
        const QList<FileInfo> &hashGroup = hashGroups[hashKey];
        processedGroups++;
        qDebug() << "[Scanner] 🔍 Prüfe Gruppe" << processedGroups << "/" << hashGroups.size() << "mit" << hashGroup.size() << "Dateien";
        if (hashGroup.size() < 2) {
            qDebug() << "[Scanner] ⏭️ Überspringe Gruppe (nur" << hashGroup.size() << "Datei)";
            continue;
        }

        // 🔍 NEU: Gruppiere nach Dateiendung - nur gleiche Extensions sind echte Duplikate
        QMap<QString, QList<FileInfo>> extensionGroups;
        for (const FileInfo &f : hashGroup) {
            QFileInfo fileInfo(f.filePath);
            QString extension = fileInfo.suffix().toLower(); // z.B. "mkv", "avi", "nfo"
            extensionGroups[extension].append(f);
        }
        
        // 🔄 WICHTIG: Verarbeite JEDE Extension-Gruppe separat als eigene Duplikatgruppe
        for (const QString &ext : extensionGroups.keys()) {
            QList<FileInfo> extFiles = extensionGroups[ext];
            
            // Überspringe wenn nur 1 Datei mit dieser Extension
            if (extFiles.size() < 2) {
                qDebug() << "[Scanner] ⏭️ Extension ." << ext << ": nur" << extFiles.size() << "Datei (kein Duplikat)";
                continue;
            }
            
            qDebug() << "[Scanner] ✅ Verarbeite Extension-Gruppe ." << ext << "mit" << extFiles.size() << "Duplikaten";
            
            // ✅ FIX: Erstelle NEUE Gruppe für jede Extension (nicht überschreiben!)
            DuplicateGroup group;
            QList<FileInfo> files = extFiles;

        // ✅ VALIDATION: Prüfe ob ALLE Dateien in Gruppe gleichen Hash haben
        QString expectedHash = files.first().hash;
        QSet<QString> uniqueHashes;
        QSet<qint64> uniqueSizes;
        for (const FileInfo &f : files) {
            uniqueHashes.insert(f.hash);
            uniqueSizes.insert(f.size);
        }
        
        if (uniqueHashes.size() > 1) {
            qWarning() << "[Scanner] ❌ FEHLER: Gruppe hat" << uniqueHashes.size() << "verschiedene Hashes!";
            qWarning() << "[Scanner] Hashes:" << uniqueHashes;
            for (const FileInfo &f : files) {
                qWarning() << "  -" << f.filePath << "Hash:" << f.hash << "Size:" << f.size;
            }
            continue; // ❌ Überspringe fehlerhafte Gruppe
        }
        
        if (uniqueSizes.size() > 1) {
            qWarning() << "[Scanner] ⚠️ WARNUNG: Gruppe hat" << uniqueSizes.size() << "verschiedene Größen trotz gleichem Hash!";
            qWarning() << "[Scanner] Größen:" << uniqueSizes;
            for (const FileInfo &f : files) {
                qWarning() << "  -" << f.filePath << "Hash:" << f.hash << "Size:" << f.size;
            }
            // Nicht überspringen - könnte legitim sein (Metadaten-Unterschied)
        }

        // ✅ NEU: Prüfe ob es sich um lokale ↔ Netzwerk Duplikate handelt
        bool hasLocal = false;
        bool hasNetwork = false;
        for (const FileInfo &file : files) {
            if (file.isLocal) {
                hasLocal = true;
            } else {
                hasNetwork = true;
            }
        }
        
        if (hasLocal && hasNetwork) {
            crossNetworkDuplicates++;
        }

        // 🔄 SORTIERUNG: Original bestimmen nach Priorität
        // 1. Lokale Dateien VOR FTP (vertrauenswürdiger)
        // 2. Kürzester relativer Pfad (ohne Mount-Prefix)
        // 3. Ältestes Änderungsdatum (Original ist meist älter)
        // 4. Alphabetisch nach Pfad (Stabilität)
        std::sort(files.begin(), files.end(), [](const FileInfo &a, const FileInfo &b) {
            // Priorität 1: Lokale Dateien zuerst
            if (a.isLocal != b.isLocal) {
                return a.isLocal; // true (local) vor false (FTP)
            }
            
            // Priorität 2: Kürzester RELATIVER Pfad (schneide GVFS/Mount-Prefix ab)
            auto getRelativePath = [](const QString &path) -> QString {
                // Entferne GVFS Mount-Prefix: /run/user/1000/gvfs/smb-share:...share=sdb/
                if (path.contains("/gvfs/smb-share:")) {
                    int sharePos = path.indexOf(",share=");
                    if (sharePos > 0) {
                        int slashAfterShare = path.indexOf('/', sharePos);
                        if (slashAfterShare > 0) {
                            return path.mid(slashAfterShare + 1); // Alles nach /share=sdb/
                        }
                    }
                }
                return path; // Lokale Pfade unverändert
            };
            
            QString relPathA = getRelativePath(a.filePath);
            QString relPathB = getRelativePath(b.filePath);
            
            int depthA = relPathA.count('/');
            int depthB = relPathB.count('/');
            if (depthA != depthB) {
                return depthA < depthB; // Weniger Unterordner = wahrscheinlich Original
            }
            
            // Priorität 3: Kürzerer relativer Pfad
            if (relPathA.length() != relPathB.length()) {
                return relPathA.length() < relPathB.length();
            }
            
            // Priorität 4: Ältestes Änderungsdatum
            if (a.lastModified != b.lastModified) {
                return a.lastModified < b.lastModified; // Ältere zuerst
            }
            
            // Keine weitere Sortierung - Reihenfolge bleibt wie gefunden
            return false;
        });
        
        qDebug() << "[Scanner] 📋 Gruppe mit" << files.size() << "Dateien (sortiert):";
        for (int i = 0; i < files.size(); ++i) {
            const FileInfo &f = files[i];
            qDebug() << "  [" << i << "]" << (f.isLocal ? "📂 LOCAL" : "�� FTP")
                     << f.filePath << "| Size:" << f.size 
                     << "| Hash:" << f.hash.left(12)
                     << "| Modified:" << QDateTime::fromSecsSinceEpoch(f.lastModified).toString("yyyy-MM-dd HH:mm");
        }

        group.original = files.takeFirst();
        group.duplicates.clear();
        
        // ✅ KEINE FILTERUNG: Alle Dateien mit gleichem Hash sind Duplikate
        for (const FileInfo &file : files) {
            group.duplicates.append(file);
        }
        
        qDebug() << "[Scanner] ✅ Original (erste Datei):" << group.original.filePath
                 << "(" << (group.original.isLocal ? "LOCAL" : "FTP") << ")";
        qDebug() << "[Scanner] 📋 Duplikate:" << group.duplicates.size() << "Dateien (nach Filter)";
        group.hash = group.original.hash;
        group.size = group.original.size;
        
        // 📁 ECHTZEIT PARENT/CHILD-ANALYSE: Ermittle Verzeichnis-Hierarchie
        QSet<QString> directories;
        QMap<QString, int> dirFileCounts;
        
        // Extrahiere Parent-Directory für Original
        QFileInfo originalInfo(group.original.filePath);
        group.original.parentDirectory = originalInfo.absolutePath();
        group.original.topLevelDirectory = extractTopLevelDirectory(group.original.filePath);
        directories.insert(group.original.parentDirectory);
        dirFileCounts[group.original.parentDirectory]++;
        
        // Extrahiere Parent-Directories für alle Duplikate
        for (FileInfo &duplicate : group.duplicates) {
            QFileInfo dupInfo(duplicate.filePath);
            duplicate.parentDirectory = dupInfo.absolutePath();
            duplicate.topLevelDirectory = extractTopLevelDirectory(duplicate.filePath);
            directories.insert(duplicate.parentDirectory);
            dirFileCounts[duplicate.parentDirectory]++;
        }
        
        // Speichere Verzeichnis-Informationen in Gruppe
        group.affectedDirectories = directories;
        group.directoryFileCounts = dirFileCounts;
        
        // 🛡️ KONFLIKT-VERMEIDUNG: Automatische Auflösung bei Parent/Child-Duplikaten
        group.hasParentChildConflict = false;
        QStringList dirList = directories.values();
        
        // Finde Parent/Child-Beziehungen
        QMap<QString, QString> childToParent; // Child -> Parent Mapping
        for (int i = 0; i < dirList.size(); ++i) {
            for (int j = 0; j < dirList.size(); ++j) {
                if (i == j) continue;
                QString dir1 = dirList[i];
                QString dir2 = dirList[j];
                
                // Prüfe ob dir1 ein Child von dir2 ist
                if (dir1.startsWith(dir2 + "/")) {
                    childToParent[dir1] = dir2;
                    group.hasParentChildConflict = true;
                }
            }
        }
        
        // 🎯 AUTOMATISCHE KONFLIKT-AUFLÖSUNG: Behalte nur Duplikate in TIEFEREN Verzeichnissen
        if (group.hasParentChildConflict) {
            qDebug() << "[Scanner] ⚠️ Parent/Child-Konflikt erkannt - Starte automatische Auflösung";
            
            QList<FileInfo> resolvedDuplicates;
            QFileInfo originalInfo(group.original.filePath);
            QString originalDir = originalInfo.absolutePath();
            
            for (const FileInfo &duplicate : group.duplicates) {
                QFileInfo dupInfo(duplicate.filePath);
                QString dupDir = dupInfo.absolutePath();
                
                // ✅ REGEL 1: Wenn Original in Parent-Dir ist, behalte nur Child-Duplikate
                bool originalIsParent = dupDir.startsWith(originalDir + "/");
                bool duplicateIsParent = originalDir.startsWith(dupDir + "/");
                
                if (originalIsParent) {
                    // Original ist Parent → Duplikat ist im Child → BEHALTEN (löschbar)
                    resolvedDuplicates.append(duplicate);
                    qDebug() << "[Scanner] ✅ BEHALTEN (Child-Duplikat):" << duplicate.filePath;
                } else if (duplicateIsParent) {
                    // Duplikat ist Parent → SCHÜTZEN (nicht löschbar, mache es zum Original)
                    qDebug() << "[Scanner] 🛡️ GESCHÜTZT (Parent-Duplikat → wird neues Original):" << duplicate.filePath;
                    // Tausche Original und Duplikat
                    FileInfo newOriginal = duplicate;
                    resolvedDuplicates.append(group.original); // Altes Original wird Duplikat
                    group.original = newOriginal;
                } else {
                    // Keine direkte Parent/Child-Beziehung zwischen Original und Duplikat
                    // Prüfe ob beide Siblings (gleiche Hierarchie-Ebene) sind
                    int originalDepth = originalDir.count('/');
                    int dupDepth = dupDir.count('/');
                    
                    if (originalDepth == dupDepth) {
                        // Gleiche Ebene → Beides löschbar
                        resolvedDuplicates.append(duplicate);
                        qDebug() << "[Scanner] ✅ BEHALTEN (Sibling-Duplikat):" << duplicate.filePath;
                    } else if (dupDepth > originalDepth) {
                        // Duplikat ist tiefer → löschbar
                        resolvedDuplicates.append(duplicate);
                        qDebug() << "[Scanner] ✅ BEHALTEN (tiefer als Original):" << duplicate.filePath;
                    } else {
                        // Duplikat ist höher in Hierarchie → SCHÜTZEN
                        qDebug() << "[Scanner] 🛡️ GESCHÜTZT (höher als Original):" << duplicate.filePath;
                        FileInfo newOriginal = duplicate;
                        resolvedDuplicates.append(group.original);
                        group.original = newOriginal;
                    }
                }
            }
            
            // Ersetze Duplikate-Liste mit aufgelöster Version
            group.duplicates = resolvedDuplicates;
            
            qDebug() << "[Scanner] ✅ Konflikt aufgelöst:" << group.duplicates.size() << "sichere Duplikate markiert";
        }
        
        // 📊 ECHTZEIT-LOG: Verzeichnis-Hierarchie-Info (nur alle 10 Gruppen)
        if (processedGroups % 10 == 0) {
            qDebug() << "[Scanner] 📁 Gruppe" << processedGroups << "betrifft" << directories.size() 
                     << "Verzeichnisse, Konflikt:" << (group.hasParentChildConflict ? "AUFGELÖST" : "NEIN");
        }

        // ✅ VALIDATION: Überspringe Gruppen ohne Duplikate (nach Konfliktauflösung)
        if (group.duplicates.isEmpty()) {
            qDebug() << "[Scanner] ⏭️ Überspringe Gruppe ohne Duplikate:" << group.original.filePath;
            continue;
        }

        // --- SAFETY: Ensure that hashes are present on original and duplicates before emitting results
        // In some race conditions a FileInfo may have been copied before its hash was set. Try to fill
        // missing hashes from our pre-computed maps (`m_hashToFilesMap`) or `fileSizeGroups`.
        if (group.original.hash.isEmpty()) {
            // Try lookup in m_hashToFilesMap
            for (auto it = m_hashToFilesMap.begin(); it != m_hashToFilesMap.end() && group.original.hash.isEmpty(); ++it) {
                for (const FileInfo &f : it.value()) {
                    if (f.filePath == group.original.filePath && !f.hash.isEmpty()) {
                        group.original.hash = f.hash;
                        qDebug() << "[Scanner] 🔁 Filled missing original.hash from m_hashToFilesMap for:" << group.original.fileName;
                        break;
                    }
                }
            }
            // Fallback: search fileSizeGroups
            if (group.original.hash.isEmpty()) {
                for (const auto &g : fileSizeGroups) {
                    for (const FileInfo &f : g) {
                        if (f.filePath == group.original.filePath && !f.hash.isEmpty()) {
                            group.original.hash = f.hash;
                            qDebug() << "[Scanner] 🔁 Filled missing original.hash from fileSizeGroups for:" << group.original.fileName;
                            break;
                        }
                    }
                    if (!group.original.hash.isEmpty()) break;
                }
            }
        }

        // Ensure duplicates have hashes too
        for (FileInfo &dup : group.duplicates) {
            if (dup.hash.isEmpty()) {
                for (auto it = m_hashToFilesMap.begin(); it != m_hashToFilesMap.end() && dup.hash.isEmpty(); ++it) {
                    for (const FileInfo &f : it.value()) {
                        if (f.filePath == dup.filePath && !f.hash.isEmpty()) {
                            dup.hash = f.hash;
                            qDebug() << "[Scanner] 🔁 Filled missing duplicate.hash from m_hashToFilesMap for:" << dup.fileName;
                            break;
                        }
                    }
                }

                if (dup.hash.isEmpty()) {
                    for (const auto &g : fileSizeGroups) {
                        for (const FileInfo &f : g) {
                            if (f.filePath == dup.filePath && !f.hash.isEmpty()) {
                                dup.hash = f.hash;
                                qDebug() << "[Scanner] 🔁 Filled missing duplicate.hash from fileSizeGroups for:" << dup.fileName;
                                break;
                            }
                        }
                        if (!dup.hash.isEmpty()) break;
                    }
                }

                if (dup.hash.isEmpty()) {
                    qWarning() << "[Scanner] ⚠️ Hash für Duplikat leer auch nach Lookup:" << dup.filePath;
                }
            }
        }

        // Reinforce group hash/size from (now possibly filled) original
        group.hash = group.original.hash;
        group.size = group.original.size;

        results.groups.append(group);
        results.duplicateFiles += group.duplicates.size();
        results.duplicateSize += group.size * group.duplicates.size();
        
        // ✅ UPDATE: Echtzeit-Zähler für GUI-Updates
        duplicatesFound = results.duplicateFiles;
        groupsCreated = results.groups.size();
        
        // 📊 LIVE-Update: Sende GUI-Update alle 5 Gruppen
        if (groupsCreated % 5 == 0) {
            emit duplicateDetectionUpdate(
                duplicatesFound,
                groupsCreated,
                QString("Gruppe %1: %2 Duplikate").arg(groupsCreated).arg(group.duplicates.size())
            );
        }
        } // Ende Extension-Schleife
    } // Ende Hash-Gruppen-Schleife

    results.totalFiles = allFiles.size();

    scanning.store(false);
    currentPhase = IDLE;

    // ✅ DEBUG: Detaillierte Ergebnis-Analyse
    qDebug() << "[Scanner] 📊 FINALE STATISTIKEN:";
    qDebug() << "    - Verarbeitete Dateien:" << results.totalFiles;
    qDebug() << "    - Duplikat-Gruppen:" << results.groups.size();
    qDebug() << "    - Duplikat-Dateien:" << results.duplicateFiles;
    qDebug() << "    - Gesparte Größe:" << (results.duplicateSize / (1024*1024)) << "MB";

    std::cout << "✅ Parallel-Scan abgeschlossen: " << results.groups.size()
              << " Duplikat-Gruppen mit " << results.duplicateFiles << " Duplikaten" << std::endl;
    std::cout << "   🔄 Lokal ↔ Netzwerk Duplikate: " << crossNetworkDuplicates << " Gruppen" << std::endl;
    
    // ✅ Setze Progress auf 100% BEVOR scanCompleted
    emit scanProgress(100, results.totalFiles, results.totalFiles);
    
    // Benutzerfreundliche Status-Nachricht basierend auf Ergebnis
    if (results.groups.empty()) {
        emit scanStatusChanged("✅ Scan abgeschlossen - keine Duplikate gefunden!");
    } else {
        emit scanStatusChanged(QString("✅ Scan abgeschlossen - %1 Duplikat-Gruppen mit %2 Duplikaten gefunden")
                              .arg(results.groups.size())
                              .arg(results.duplicateFiles));
    }
    
    // 🔥 GUARD: Emittiere nur wenn noch nicht emittiert
    if (!m_scanCompletedEmitted.exchange(true)) {
        emit scanCompleted(results);
        qDebug() << "[Scanner] 🔥 EMIT scanCompleted (NORMAL) - groups:" << results.groups.size() 
                 << "totalFiles:" << results.totalFiles;
        
        // 🔐 SPEICHERE SCAN-HISTORY + HASH-CACHE asynchron NACH scanCompleted (blockiert GUI nicht!)
        QTimer::singleShot(100, this, [this, results]() {
            qDebug() << "[Scanner] 💾 Starte asynchrones Speichern der Scan-History + Hash-Cache...";
            for (const FileInfo &file : allFiles) {
                addToScanHistory(file.filePath, false);
            }
            saveScanHistory();
            
            // 🔥 NUR DUPLIKATE im Hash-Cache speichern (Unikate werden entfernt)
            saveHashCacheOnlyDuplicates(results.groups);
            
            qDebug() << "[Scanner] ✅ Scan-History gespeichert:" << allFiles.size() << "neue Dateien";
        });
    }
}

void Scanner::onFtpFilesReceived(const QString &directory, const QStringList &files, bool success)
{
    qDebug() << "[Scanner] 📄 FTP-Dateien empfangen für:" << directory << "Files:" << files.size() << "Success:" << success;
    
    // 🎯 SOFORTIGE QUEUE-INFO: Emittiere BEVOR frühe returns passieren!
    int totalFtpDirs = pendingFtpDirectories.size() + completedFtpDirectories.size();
    int completedDirs = completedFtpDirectories.size();
    QString ftpProgressWithQueue = QString("FTP %1/%2").arg(completedDirs).arg(totalFtpDirs);
    if (pendingFtpDirectories.size() > 0) {
        ftpProgressWithQueue += QString(" | Verbleibend: %1").arg(pendingFtpDirectories.size());
    }
    
    qDebug() << "[Scanner] 🎯 EMIT currentFileProcessing (SLOT1):" << ftpProgressWithQueue << "(" << completedDirs << "/" << totalFtpDirs << ")";
    
    emit currentFileProcessing(
        ftpProgressWithQueue,  // ✅ Mit Queue-Info für GUI!
        "📡 FTP-Scan läuft",
        completedDirs,
        totalFtpDirs
    );
    
    if (!success) {
        qWarning() << "[Scanner] ⚠️ FTP-Fehler beim Laden von:" << directory;
        return;
    }
    
    // 🛡️ KRITISCHER SICHERHEITSCHECK: Verhindere QHash-Crash bei sehr großen Datensätzen
        if (files.size() > 25000) {
        qDebug() << "[Scanner] 🚨 KRITISCH: Zu viele Dateien (" << files.size() << ") - Chunked Processing aktiviert";
            // Versuche die vollständige FTP-URL für dieses Verzeichnis zu ermitteln
            QString baseUrl = directory;
            if (!baseUrl.startsWith("ftp://")) {
                // Auflösen anhand pendingFtpDirectories
                auto normalizePath = [](QString p) {
                    if (p.isEmpty()) return p;
                    if (!p.startsWith('/')) p.prepend('/');
                    if (p.length() > 1 && p.endsWith('/')) p.chop(1);
                    return p;
                };
                const QString dirNorm = normalizePath(directory);
                for (const QString &pendingUrl : pendingFtpDirectories) {
                    QUrl url(pendingUrl);
                    const QString pendNorm = normalizePath(url.path());
                    if (pendNorm == dirNorm || normalizePath(url.path() + "/") == dirNorm) {
                        baseUrl = pendingUrl;
                        break;
                    }
                }
            }
            processFtpFilesBatch(baseUrl, files, success);
        return;
    }
    
    if (files.size() > 100000) {
        qDebug() << "[Scanner] ⚠️ Zu viele Dateien (" << files.size() << ") - überspringe zur Sicherheit";
        pendingFtpDirectories.remove(directory); // ✅ FIX: QSet verwendet remove()
        checkScanProgress();
        return;
    }
    
    // 🧠 NPU-BILDVERARBEITUNG: Für große Bilddatensätze optimiert
    // 🚀 PRODUCTION NPU: Aktiviert für mittlere bis große Bilddatensätze (>1.000 Dateien)
    if (files.size() > 1000 && npuManager) {  // NPU aktiviert ab 1.000 Dateien
        qDebug() << "[Scanner] 🚀 ULTRA-FAST NPU aktiviert für" << files.size() << "Dateien";
        
        // 🎨 Filtere ALLE Bilddateien für Ultra-Fast NPU-Verarbeitung (inkl. RAW)
        QStringList imageFiles;
        for (const QString &file : files) {
            if (file.endsWith(".jpg", Qt::CaseInsensitive) || 
                file.endsWith(".jpeg", Qt::CaseInsensitive) ||
                file.endsWith(".png", Qt::CaseInsensitive) ||
                file.endsWith(".gif", Qt::CaseInsensitive) ||
                file.endsWith(".cr2", Qt::CaseInsensitive) ||  // Canon RAW
                file.endsWith(".nef", Qt::CaseInsensitive) ||  // Nikon RAW
                file.endsWith(".arw", Qt::CaseInsensitive) ||  // Sony RAW
                file.endsWith(".dng", Qt::CaseInsensitive) ||  // Adobe RAW
                file.endsWith(".tiff", Qt::CaseInsensitive) || // TIFF
                file.endsWith(".bmp", Qt::CaseInsensitive)) {  // Bitmap
                imageFiles.append(file);
            }
        }
        
        qDebug() << "[Scanner] 📊 BILDFILES ERKANNT:" << imageFiles.size() << "Bilder für NPU-Verarbeitung";
        
        if (imageFiles.size() > 50) {  // 🚀 SOFORTIGE NPU-AKTIVIERUNG bei 50+ Bildern
            qDebug() << "[Scanner] 🚀 NPU-ONLY Bildverarbeitung für" << imageFiles.size() << "Bilder (KEINE Hash-Methode)";
            
            // 🧠 NPU FEATURE-VECTOR-BASIERTE DUPLIKATERKENNUNG (ERSETZT Hash-basiert)
            qDebug() << "[Scanner] 🧠 Starte NPU Feature-Vector-Analyse (Hash-frei)...";
            QStringList processedImages = npuManager->processImagesWithNpuUltraFast(imageFiles);
            
            // 🎯 Feature-Vector-Duplikate finden (OHNE Hash-Vergleich!)
            QList<QStringList> featureBasedDuplicates = npuManager->findFeatureBasedDuplicates(processedImages);
            
            qDebug() << "[Scanner] ✅ NPU-Feature-Duplikate gefunden:" << featureBasedDuplicates.size() << "Gruppen";
            qDebug() << "[Scanner] 🚀 NPU-ONLY Verarbeitung abgeschlossen:" 
                     << processedImages.size() << "Bilder ohne Hash-Methode";
                     
            // 📊 NPU-Counter setzen für Hash-Pipeline-Skip
            npuProcessedImages = imageFiles.size();
            qDebug() << "[Scanner] 🎯 NPU-Counter gesetzt:" << npuProcessedImages << "verarbeitete Bilder";
                     
            // 📊 NPU-Aktivitäts-Update für GUI
            emit npuActivityUpdate(imageFiles.size(), featureBasedDuplicates.size());
            
            // 🚀 WICHTIG: Entferne verarbeitete Bilder aus der Hash-Pipeline
            // ⚠️ FIX: Erstelle lokale Kopie da `files` const ist
            QStringList remainingFiles = files;
            for (const QString &img : imageFiles) {
                remainingFiles.removeAll(img);
            }
            qDebug() << "[Scanner] 🎯 BILDER aus Hash-Pipeline entfernt:" << imageFiles.size() << "Dateien";
            qDebug() << "[Scanner] 📊 Verbleibende Dateien für Hash-Verarbeitung:" << remainingFiles.size();
            
        } else {
            qDebug() << "[Scanner] 📊 Zu wenig Bilder für NPU-Batch (" << imageFiles.size() << "/50) - verwende Hash-basierte Einzelverarbeitung";
        }
    }
    
    // 🧠 MEMORY-PROTECTION: Für sehr große Datensätze (>25.000 Dateien) Batch-Verarbeitung
    if (files.size() > 25000) {
        qDebug() << "[Scanner] 🧠 MEMORY-PROTECTION: Aktiviere Batch-Verarbeitung für" << files.size() << "Dateien";
        // directory kann Pfad oder vollständige URL sein; vereinheitlichen
        QString baseUrl = directory;
        if (!baseUrl.startsWith("ftp://")) {
            auto normalizePath = [](QString p) {
                if (p.isEmpty()) return p;
                if (!p.startsWith('/')) p.prepend('/');
                if (p.length() > 1 && p.endsWith('/')) p.chop(1);
                return p;
            };
            const QString dirNorm = normalizePath(directory);
            for (const QString &pendingUrl : pendingFtpDirectories) {
                QUrl url(pendingUrl);
                const QString pendNorm = normalizePath(url.path());
                if (pendNorm == dirNorm || normalizePath(url.path() + "/") == dirNorm) {
                    baseUrl = pendingUrl;
                    break;
                }
            }
        }
        processFtpFilesBatch(baseUrl, files, success);
        return;
    }
    
    // Find the full FTP URL for this directory path (robust against trailing slashes)
    QString fullFtpUrl;
    auto normalizePath = [](QString p) {
        if (p.isEmpty()) return p;
        // Ensure path starts with '/'
        if (!p.startsWith('/')) p.prepend('/');
        // Remove single trailing '/'
        if (p.length() > 1 && p.endsWith('/')) p.chop(1);
        return p;
    };
    const QString dirNorm = normalizePath(directory);
    for (const QString &pendingUrl : pendingFtpDirectories) {
        QUrl url(pendingUrl);
        const QString pendNorm = normalizePath(url.path());
        if (pendNorm == dirNorm) {
            fullFtpUrl = pendingUrl;
            break;
        }
        // Also allow match if directory had an extra '/' when emitted
        if (normalizePath(url.path() + "/") == dirNorm) {
            fullFtpUrl = pendingUrl;
            break;
        }
    }
    
    if (fullFtpUrl.isEmpty()) {
        qWarning() << "[Scanner] ⚠️ Keine entsprechende FTP-URL gefunden für:" << directory;
        return;
    }
    
    // Extract host from full FTP URL for file path construction
    QUrl ftpUrl(fullFtpUrl);
    QString host = ftpUrl.host();
    QString basePath = ftpUrl.path();
    // Normalize basePath to '/path' without trailing '/'
    if (!basePath.startsWith('/')) basePath.prepend('/');
    if (basePath.length() > 1 && basePath.endsWith('/')) basePath.chop(1);
    
    // Add all files to allFiles list
    QSet<QString> processedFileNames; // 🚀 Prevent size-variant duplicates
    
    for (const QString &encodedFile : files) {
        // ✅ FIX: Parse encoded "path/filename|size" format (now with FULL PATH from recursive scan!)
        QStringList parts = encodedFile.split('|');
        QString fullFilePath = parts.size() > 0 ? parts[0] : encodedFile; // JETZT mit vollständigem Pfad!
        qint64 fileSize = parts.size() > 1 ? parts[1].toLongLong() : 0;
        
        // 🔧 CRITICAL FIX: Bereinige kaputte Pfade mit ///
        // Beispiel: /share/Jan/Jana/mix von t.g///share/Jan/naker/Musik/file.mp3
        // Problem: Doppelte Pfade durch rekursiven Scan
        // Lösung: Nimm nur den letzten Teil nach dem letzten ///
        if (fullFilePath.contains("///")) {
            QStringList pathParts = fullFilePath.split("///");
            fullFilePath = pathParts.last(); // Nur der echte Pfad
            
            // ✅ FIX: Ensure path starts with / for valid FTP URL
            if (!fullFilePath.startsWith('/')) {
                fullFilePath = "/" + fullFilePath;
            }
            
            qDebug() << "[Scanner] 🔧 Bereinigter FTP-Pfad:" << fullFilePath;
        }
        
        // Extrahiere nur den Dateinamen für Duplikat-Check
        QString fileName = fullFilePath;
        if (fullFilePath.contains('/')) {
            fileName = fullFilePath.mid(fullFilePath.lastIndexOf('/') + 1);
        }
        
        // 🚀 CRITICAL FIX: Skip if we already processed this filename (prevent size variants)
        if (processedFileNames.contains(fileName)) {
            qDebug() << "[Scanner] ⚠️ Überspringe Größen-Variante:" << fileName;
            continue;
        }
        processedFileNames.insert(fileName);
        
        // ✅ URL-KODIERUNG: Spaces und Sonderzeichen für FTP-URLs kodieren
        QString encodedFullPath = QUrl::toPercentEncoding(fullFilePath);
        
        // ✅ CRITICAL FIX: Ensure encoded path starts with / if not already
        if (!encodedFullPath.startsWith('/')) {
            encodedFullPath = "/" + encodedFullPath;
        }
        
        FileInfo fileInfo;
        // 🔄 NEU: Verwende vollständigen Pfad (rekursiv von FtpClient)
        // ✅ CRITICAL FIX: Add / between port and path in FTP URL
        fileInfo.filePath = QString("ftp://%1:21/%2").arg(host, encodedFullPath.startsWith('/') ? encodedFullPath.mid(1) : encodedFullPath);
        fileInfo.fileName = fileName; // Nur Dateiname für Anzeige
        fileInfo.size = fileSize; // ✅ FIX: Use real file size from FTP LIST
        fileInfo.lastModified = QDateTime::currentSecsSinceEpoch();
        fileInfo.hash = "";
        fileInfo.isLocal = false; // ✅ NEU: Markiere als Netzwerk-Datei
        fileInfo.networkType = "FTP"; // ✅ NEU: Netzwerk-Typ
        
        allFiles.append(fileInfo);
        qDebug() << "[Scanner] ✅ Added FTP file (REKURSIV):" << fileInfo.filePath << "Size:" << fileSize << "bytes";
    }
    
    // ✅ CRITICAL FIX: Remove directory from pending list
    pendingFtpDirectories.remove(directory);
    
    // Mark this directory as completed
    completedFtpDirectories.insert(directory);
    ftpDirectoriesProcessed++;
    
    // ✅ NEU: Zähle lokale und FTP-Dateien separat für bessere Anzeige
    int localFiles = 0;
    int ftpFiles = 0;
    for (const FileInfo &file : allFiles) {
        if (file.isLocal) {
            localFiles++;
        } else {
            ftpFiles++;
        }
    }
    
    emit scanStatusChanged(QString("Parallel: Lokal %1, FTP %2/%3 (%4 Dateien)")
                          .arg(localFiles)
                          .arg(ftpDirectoriesProcessed)
                          .arg(pendingFtpDirectories.size())
                          .arg(ftpFiles));
    
    // ✅ UNIFIED LOGIC: Use checkScanProgress() instead of duplicate check
    qDebug() << "[Scanner] 📊 onFtpFilesReceived abgeschlossen für" << directory << "- prüfe Gesamtfortschritt";
    checkScanProgress();
}

void Scanner::collectFtpFiles(const QString &ftpDirectory, QSet<QString> &processedFiles, bool isFromQueue)
{
    // 🔧 NORMALIZE URL at entry: Always include port for consistent comparison throughout function
    QUrl normalizedEntryUrl(ftpDirectory);
    if (normalizedEntryUrl.port() == -1) {
        normalizedEntryUrl.setPort(21);  // Add default FTP port if missing
    }
    QString normalizedFtpDir = normalizedEntryUrl.toString();  // Use this throughout function
    
    qDebug() << "[Scanner] 📡 FTP-Optimiert: Sammle Dateien für:" << normalizedFtpDir;
    
    // SAFETY CHECK: Skip if already completed or being processed
    if (completedFtpDirectories.contains(normalizedFtpDir)) {
        qDebug() << "[Scanner] ⏭️ Verzeichnis bereits abgeschlossen, überspringe:" << normalizedFtpDir;
        return;
    }
    
    if (currentlyProcessingFtpDirectories.contains(normalizedFtpDir)) {
        qDebug() << "[Scanner] ⏭️ Verzeichnis wird bereits verarbeitet, überspringe:" << normalizedFtpDir 
                 << "| Currently processing count:" << currentlyProcessingFtpDirectories.size()
                 << "| FTP Discovery Phase:" << ftpDiscoveryPhase;
        checkScanProgress();  // Check if we need to progress
        return;
    }
    
    // 🚀 IMPROVED PROGRESS: Track current processing directory
    // Mark this directory as currently being processed
    currentlyProcessingFtpDirectories.insert(normalizedFtpDir);
    
    qDebug() << "[Scanner] 🎯 FTP-Processing started for:" << normalizedFtpDir 
             << "| Currently processing:" << currentlyProcessingFtpDirectories.size()
             << "| Discovery phase:" << ftpDiscoveryPhase;
    
    // Calculate correct progress based on completed + currently processing
    int totalFtpDirs = pendingFtpDirectories.size() + completedFtpDirectories.size() + currentlyProcessingFtpDirectories.size();
    int completedDirs = completedFtpDirectories.size();
    int currentIndex = completedDirs + 1; // 1-based for display
    
    emit currentFileProcessing(
        QString("FTP-Verzeichnis %1/%2").arg(currentIndex).arg(totalFtpDirs),
        QString("📡 Scanne: %1").arg(QFileInfo(normalizedFtpDir).fileName()),
        completedDirs,
        totalFtpDirs
    );
    
    // 🚀 Zusätzliches Process Activity Update
    emit processActivityUpdate(
        QString("📡 FTP-Scan: %1/%2 Verzeichnisse").arg(completedDirs).arg(totalFtpDirs),
        QString("Aktuell: %1").arg(normalizedFtpDir)
    );
    
    // 📊 FTP Progress für GUI-Labels
    emit ftpProgressUpdate(totalFtpDirs, completedDirs, pendingFtpDirectories.size());
    
    // 🚀 Progress für GUI-Balken (40% bis 90% für FTP-Phase)
    if (totalFtpDirs > 0) {
        int progress = 40 + ((completedDirs * 50) / totalFtpDirs); // 40% + bis zu 50% für FTP-Scan
        emit scanProgress(progress, completedDirs, totalFtpDirs);
    }
    
    // ⚡ PERFORMANCE: Cache für große Datensätze 
    static QHash<QString, QStringList> ftpFileCache;
    static QDateTime lastCacheUpdate;
    
    // 🧹 AGGRESSIVE CACHE-INVALIDIERUNG: Bei neuem Scan IMMER Cache leeren!
    static bool cacheClearedForThisScan = false;
    if (!cacheClearedForThisScan) {
        qDebug() << "[Scanner] 🧹 Leere FTP-File-Cache bei Scan-Start (erzwinge frische Server-Daten)";
        ftpFileCache.clear();
        lastCacheUpdate = QDateTime(); // Reset timestamp
        cacheClearedForThisScan = true;
        
        // Reset bei Scan-Ende
        QTimer::singleShot(1000, []() { cacheClearedForThisScan = false; });
    }
    
    // Cache-Check: Verwende gecachte Daten wenn < 5 Min alt (aber nur wenn nicht gerade geleert!)
    if (ftpFileCache.contains(normalizedFtpDir) && 
        lastCacheUpdate.secsTo(QDateTime::currentDateTime()) < 300) {
        qDebug() << "[Scanner] ⚡ FTP-Cache-Hit für:" << normalizedFtpDir;
        processCachedFtpFiles(normalizedFtpDir, ftpFileCache[normalizedFtpDir], processedFiles);
        return;
    }
    
    // Extract IP and path from FTP URL: ftp://192.168.1.224/sdb/Comedy/
    QUrl ftpUrl(normalizedFtpDir);
    if (!ftpUrl.isValid()) {
        qWarning() << "[Scanner] ⚠️ Ungültige FTP-URL:" << normalizedFtpDir;
        return;
    }
    QString host = ftpUrl.host();
    QString path = ftpUrl.path();
    if (host.isEmpty()) {
        qWarning() << "[Scanner] ⚠️ Ungültiger FTP-Pfad (Host leer):" << normalizedFtpDir;
        return;
    }
    if (path.isEmpty()) path = "/"; // ensure non-empty directory path
    
    // ⚡ OPTIMIERT: Wiederverwendung bestehender FTP-Connections
    FtpClient *urlSpecificClient = getOrCreateFtpClient(host);
    if (!urlSpecificClient) {
        qCritical() << "[Scanner] ❌ Konnte keinen FTP-Client erstellen für Host:" << host;
        return;
    }
    
    // ✅ BULLETPROOF: PresetManager Null-Check mit Fallback
    if (!presetManager) {
        qCritical() << "[Scanner] ❌ FATAL: PresetManager null! Verwende Default-Credentials";
        useDefaultFtpCredentials(urlSpecificClient, host);
    } else {
        // Hole Credentials aus PresetManager für gespeicherte Logins
        LoginData login = presetManager->getLogin(host, 21);
        if (!login.isValid()) {
            qWarning() << "[Scanner] ⚠️ Keine Login-Daten für" << host << ":21 → Verwende Default";
            useDefaultFtpCredentials(urlSpecificClient, host);
        } else {
            qDebug() << "[Scanner] 🔐 Verwende Credentials:" << login.username << "für" << host;
            urlSpecificClient->setCredentials(host, 21, login.username, login.password);
        }
    }
    
    // 🎯 REDUNDANCY CHECK: Prüfe ob ein Child-Verzeichnis dieses Parent bereits ersetzt
    QString normalizedFtp = normalizedFtpDir;
    if (normalizedFtp.endsWith('/') && normalizedFtp.length() > 1) {
        normalizedFtp.chop(1);
    }
    
    // Prüfe gegen alle bereits pending FTP-Verzeichnisse
    for (const QString &existingFtp : pendingFtpDirectories) {
        QString normalizedExisting = existingFtp;
        if (normalizedExisting.endsWith('/') && normalizedExisting.length() > 1) {
            normalizedExisting.chop(1);
        }
        
        // Ist das neue Verzeichnis ein PARENT des existierenden? → Skip!
        if (normalizedExisting.startsWith(normalizedFtp + "/")) {
            qDebug() << "[Scanner] 🚫 REDUNDANT: FTP-Parent übersprungen (Child bereits ausgewählt)";
            return;
        }
        
        // Ist das neue Verzeichnis ein CHILD des existierenden? → Entferne Parent!
        if (normalizedFtp.startsWith(normalizedExisting + "/")) {
            // 🔥 CRITICAL MEMORY-FIX: Parent-Removal KOMPLETT DEAKTIVIERT!
            // removeAll() auf großen Listen (10k+) verursacht std::bad_alloc Crash
            // Lieber redundante Scans als Memory-Crash bei 99% Completion!
            qDebug() << "[Scanner] ⏭️ Parent-Child erkannt, aber Skip Removal (Memory-Schutz)";
            // Falls Parent bereits aktiv scannt, werden beide gescannt - kein Problem
        }
    }
    
    // Add to pending directories list for tracking; skip duplicate setup if already pending
    // ⚠️ NUR in Phase 1 zu pending hinzufügen! In Phase 2 scannen wir nur die bereits entdeckten Verzeichnisse
    bool newlyAdded = false;
    if (ftpDiscoveryPhase && !isFromQueue) {
        if (!pendingFtpDirectories.contains(normalizedFtpDir)) {
            pendingFtpDirectories.insert(normalizedFtpDir);
            newlyAdded = true;
            qDebug() << "[Scanner] 📥 PHASE 1: Füge Verzeichnis zu pending hinzu:" << normalizedFtpDir;
        } else {
            qDebug() << "[Scanner] ⏭️ FTP-Verzeichnis bereits pending, überspringe erneute Verbindung:" << normalizedFtpDir;
            return;
        }
    } else if (!ftpDiscoveryPhase) {
        // Phase 2: Sammle Dateien aber füge KEINE neuen Verzeichnisse hinzu
        // � REMOVED: completedFtpDirectories check - wird durch FTP-Phantome falsch befüllt!
        // Stattdessen: GUARD im Callback verhindert Duplikate
        qDebug() << "[Scanner] 📂 PHASE 2: Sammle Dateien (ohne neue Verzeichnisse zu discovern):" << normalizedFtpDir;
    }
    
    ftpActiveHosts.insert(host);
    
    // 🔥 SAFETY: In Phase 2 dürfen KEINE subdirectoriesFound-Connections existieren!
    // Disconnect ALL signals from this client (falls noch Discovery-Signals hängen)
    if (!ftpDiscoveryPhase) {
        qDebug() << "[Scanner] 🔌 DISCONNECT subdirectoriesFound for client (Phase 2 mode)";
        disconnect(urlSpecificClient, &FtpClient::subdirectoriesFound, this, nullptr);
    } else {
        qDebug() << "[Scanner] ⚠️ STILL IN DISCOVERY PHASE - NOT disconnecting!";
    }
    
    // 🔥 CRITICAL: Verwende DirectConnection + store MetaObject::Connection für später disconnect!
    // (Qt::UniqueConnection funktioniert NICHT mit Lambdas!)
    // Stattdessen: Manuelle Verwaltung der Connections
    
    // Verbinde Signal für aktuellen Scan (wird später manuell disconnected)
    QMetaObject::Connection fileListConn = connect(urlSpecificClient, &FtpClient::filesListFinished,
            this, [this, urlSpecificClient, normalizedFtpDir](const QString &dir, const QStringList &files, bool success) {
        
        // 🎯 FILTER: Nur Callbacks für DIESES spezifische Verzeichnis verarbeiten!
        // Verhindert dass Lambda für /sdb/FILME/ auch auf /sdb/FILME/Archive/ reagiert
        // dir = "/sdb/FILME/Archive/" (Pfad), normalizedFtpDir = "ftp://host:21/sdb/FILME/Archive/" (URL)
        QString expectedPath = QUrl(normalizedFtpDir).path();  // Extrahiere Pfad aus URL
        qDebug() << "[Scanner] 🔍 CALLBACK:" << dir << "| Expected:" << expectedPath << "| Match:" << (dir == expectedPath) << "| Files:" << files.size();
        if (dir != expectedPath) {
            qDebug() << "[Scanner] ⏭️ Callback ignoriert (nicht unser Verzeichnis)";
            return;  // Nicht unser Callback - gehört zu anderem Lambda!
        }
        
        // GUARD: Verhindere mehrfache Verarbeitung desselben Verzeichnisses (FTP Phantoms)
        bool alreadyCompleted = completedFtpDirectories.contains(normalizedFtpDir);
        qDebug() << "[Scanner] 🛡️ GUARD Check:" << normalizedFtpDir << "| Already completed:" << alreadyCompleted;
        if (alreadyCompleted) {
            qWarning() << "[Scanner] ⚠️ DUPLICATE CALLBACK ignoriert:" << normalizedFtpDir;
            if (urlSpecificClient) {
                urlSpecificClient->setProperty("busy", false);
            }
            // 🔥 CRITICAL: Increment counter auch bei DUPLICATE!
            int completed = ftpFileListingsCompleted.fetchAndAddRelaxed(1) + 1;
            int pending = ftpFileListingsPending.loadRelaxed();
            qDebug() << "[Scanner] 📊 File-Listing Progress (DUPLICATE):" << completed << "/" << pending;
            
            // CHECK: Sind alle File-Listings fertig?
            if (completed >= pending && pending > 0) {
                qDebug() << "[Scanner] ✅ ALL FILE-LISTINGS COMPLETE (via DUPLICATE)!" << allFiles.size() << "files";
                emit filesCollected(allFiles.size());
            }
            return;
        }
        
        // CONNECTION POOLING: Client SOFORT freigeben fuer naechsten Scan
        if (urlSpecificClient) {
            urlSpecificClient->setProperty("busy", false);
        }
        
        qDebug() << "[Scanner] 📡 FTP-Scan ABGESCHLOSSEN:" << dir << "|" << files.size() << "Dateien | Verbleibend:" << (pendingFtpDirectories.size() - 1);
        
        // 🚀 GUI-Update: FTP-Dateien empfangen
        emit processActivityUpdate(
            QString("📡 FTP: %1 Dateien empfangen").arg(files.size()),
            QString("Von: %1").arg(QFileInfo(dir).fileName())
        );
        
        if (success) {
            for (const QString &file : files) {
                QString baseFileName = file;
                qint64 fileSize = 0;
                
                if (file.contains("|")) {
                    QStringList fileNameParts = file.split("|");
                    baseFileName = fileNameParts[0];
                    fileSize = fileNameParts[1].toLongLong();
                }
                
                // ✅ CRITICAL FIX: Extract only filename if full path returned
                // FTP LIST may return "/share/Jan/Dir///share/Jan/other/file.mp3"
                if (baseFileName.contains("///")) {
                    // Take last segment after ///
                    baseFileName = baseFileName.split("///").last();
                }
                // Extract filename from path
                if (baseFileName.contains('/')) {
                    baseFileName = baseFileName.mid(baseFileName.lastIndexOf('/') + 1);
                }
                
                QUrl ftpUrl;
                ftpUrl.setScheme("ftp");
                ftpUrl.setHost(QUrl(normalizedFtpDir).host());
                ftpUrl.setPort(21);
                
                // ✅ CRITICAL FIX: Construct path correctly with proper slashes
                QString basePath = QUrl(normalizedFtpDir).path();
                if (!basePath.endsWith('/')) basePath += "/";
                if (!basePath.startsWith('/')) basePath = "/" + basePath;
                
                ftpUrl.setPath(basePath + baseFileName);
                QString fullPath = ftpUrl.toString();
                
                QString canonicalPath = QUrl(fullPath).toString();
                
                // 🔒 THREAD-SAFE: Lock für processedFiles Check & Insert
                {
                    QMutexLocker locker(&processedFilesMutex);
                    if (this->processedFiles.contains(canonicalPath)) {
                        continue;
                    }
                    
                    // 🚀 PERFORMANCE: Große Dateien (>10MB) nur nach GRÖSSE+NAME vergleichen (kein Hash!)
                    const qint64 maxFileSizeForHashing = 10 * 1024 * 1024; // 10MB = Skip Music/Video Files!
                    if (fileSize > maxFileSizeForHashing) {
                        qDebug() << "[Scanner] ⚡ FTP-Datei >100MB - nur Size+Name-Vergleich:" << baseFileName << "(" << (fileSize / 1024 / 1024) << "MB)";
                        // ✅ SMART: Große Dateien nach SIZE+NAME vergleichen (sehr zuverlässig!)
                        // Gleicher Name + Gleiche Größe = Duplikat (z.B. "movie.mkv" 4.7GB)
                        this->processedFiles.insert(canonicalPath);
                        
                        FileInfo ftpFile;
                        ftpFile.filePath = fullPath;
                        ftpFile.fileName = baseFileName;
                        ftpFile.size = fileSize;
                        ftpFile.lastModified = QDateTime::currentDateTime().toSecsSinceEpoch();
                        ftpFile.hash = QString("SIZE_NAME_%1_%2").arg(fileSize).arg(baseFileName.toLower()); // 🎯 SIZE+NAME Hash!
                        ftpFile.isLocal = false;
                        ftpFile.networkType = "FTP";
                        
                        allFiles.append(ftpFile);
                        continue; // Nächste Datei
                    }
                    
                    this->processedFiles.insert(canonicalPath);
                }
                
                FileInfo ftpFile;
                ftpFile.filePath = fullPath;
                ftpFile.fileName = baseFileName;
                ftpFile.size = fileSize;
                ftpFile.lastModified = QDateTime::currentDateTime().toSecsSinceEpoch();
                ftpFile.hash = "";
                ftpFile.isLocal = false;
                ftpFile.networkType = "FTP";
                
                allFiles.append(ftpFile);
            }
        }
        
        // 🛡️ ALWAYS clean up processing state (success or failure)
        // ⚠️ Phase 2: pendingFtpDirectories wird NICHT verwendet! (kommt aus discoveredFtpDirectories)
        // pendingFtpDirectories.remove() würde SAFETY CLEANUP fälschlich triggern!
        currentlyProcessingFtpDirectories.remove(normalizedFtpDir);
        
        if (success) {
            completedFtpDirectories.insert(normalizedFtpDir);  // QSet::insert
        } else {
            qWarning() << "[Scanner] ❌ FTP-Scan fehlgeschlagen für:" << normalizedFtpDir;
            // Add to completed anyway to prevent infinite loop
            completedFtpDirectories.insert(normalizedFtpDir);  // QSet::insert
        }
        
        // 🔥 CRITICAL: Increment File-Listing Completed Counter
        int completed = ftpFileListingsCompleted.fetchAndAddRelaxed(1) + 1;  // +1 because fetchAndAdd returns OLD value
        int pending = ftpFileListingsPending.loadRelaxed();
        
        qDebug() << "[Scanner] 📊 File-Listing Progress:" << completed << "/" << pending;
        
        // 🔥 CHECK: Sind alle File-Listings fertig?
        if (completed >= pending && pending > 0) {
            qDebug() << "[Scanner] ✅ ALL FILE-LISTINGS COMPLETE!" << allFiles.size() << "files collected";
            qDebug() << "[Scanner] 🚀 EMIT filesCollected signal NOW";
            emit filesCollected(allFiles.size());
        }
        
        // � REMOVED: filesCollected signal emittiert NUR wenn ALLE File-Listings fertig!
        
        // 🚀 UPDATE PROGRESS after completion
        int totalFtpDirs = pendingFtpDirectories.size() + completedFtpDirectories.size() + currentlyProcessingFtpDirectories.size();
        int completedDirs = completedFtpDirectories.size();
        
        emit processActivityUpdate(
            QString("📡 FTP-Scan: %1/%2 Verzeichnisse").arg(completedDirs).arg(totalFtpDirs),
            QString("Abgeschlossen: %1").arg(dir)  // ✅ FIX: Use 'dir' from callback, not captured 'normalizedFtpDir'
        );
        
        // 📊 FTP Progress für GUI-Labels
        emit ftpProgressUpdate(totalFtpDirs, completedDirs, pendingFtpDirectories.size());
        
        if (totalFtpDirs > 0) {
            int progress = 40 + ((completedDirs * 50) / totalFtpDirs);
            emit scanProgress(progress, completedDirs, totalFtpDirs);
        }
        
        checkScanProgress();
    });
    
    // 🔥 TRACK connection for later cleanup (damit nicht mehrere Lambdas für denselben Client existieren)
    // Key format: "host + directory" for unique tracking
    QString connectionKey = normalizedFtpDir;
    if (m_ftpFileListConnections.contains(connectionKey)) {
        // Disconnect old connection for same directory
        disconnect(m_ftpFileListConnections[connectionKey]);
        qDebug() << "[Scanner] 🔌 Replaced old connection for:" << connectionKey;
    }
    m_ftpFileListConnections[connectionKey] = fileListConn;
    
    // 🕒 ADD TIMEOUT for FTP connection
    QTimer::singleShot(30000, this, [this, normalizedFtpDir]() {
        if (currentlyProcessingFtpDirectories.contains(normalizedFtpDir)) {
            qWarning() << "[Scanner] ⏰ FTP-Timeout für:" << normalizedFtpDir;
            // Force completion to prevent infinite loop
            currentlyProcessingFtpDirectories.remove(normalizedFtpDir);
            completedFtpDirectories.insert(normalizedFtpDir);
            
            int totalFtpDirs = pendingFtpDirectories.size() + completedFtpDirectories.size() + currentlyProcessingFtpDirectories.size();
            int completedDirs = completedFtpDirectories.size();
            
            emit processActivityUpdate(
                QString("📡 FTP-Scan: %1/%2 Verzeichnisse").arg(completedDirs).arg(totalFtpDirs),
                QString("Timeout: %1").arg(normalizedFtpDir)
            );
            
            if (totalFtpDirs > 0) {
                int progress = 40 + ((completedDirs * 50) / totalFtpDirs);
                emit scanProgress(progress, completedDirs, totalFtpDirs);
            }
            
            checkScanProgress();
        }
    });
    
    // Starte die FTP-Verbindung und Dateiliste
    urlSpecificClient->connectToHost();
    if (!path.endsWith('/')) path += '/';
    urlSpecificClient->listFiles(path);
    
    qDebug() << "[Scanner] FTP-Collection gestartet fuer" << normalizedFtpDir;
}


void Scanner::checkScanProgress()
{
    static int recursiveCallCount = 0;
    static auto lastCallTime = std::chrono::steady_clock::now();
    
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - lastCallTime).count();
    
    // Reset counter if more than 5 seconds passed
    if (elapsed > 5) {
        recursiveCallCount = 0;
        lastCallTime = now;
    }
    
    recursiveCallCount++;
    
    // 🛡️ INFINITE LOOP PROTECTION: Stop after 100 calls within 5 seconds
    if (recursiveCallCount > 100) {
        qCritical() << "[Scanner] ❌ EMERGENCY STOP: checkScanProgress() called" << recursiveCallCount << "times in" << elapsed << "seconds!";
        qCritical() << "[Scanner] Pending:" << pendingFtpDirectories.size() << "Processing:" << currentlyProcessingFtpDirectories.size();
        
        // Force cleanup
        currentlyProcessingFtpDirectories.clear();
        pendingFtpDirectories.clear();
        recursiveCallCount = 0;
        
        // Start hashing with whatever we have
        if (!allFiles.isEmpty()) {
            qWarning() << "[Scanner] 🚨 Emergency: Starting hash with" << allFiles.size() << "files";
            emit scanStatusChanged("⚠️ Notfall-Modus: Starte Hashing...");
        }
        return;
    }
    
    qDebug() << "[Scanner] 🔍 Prüfe Scan-Fortschritt - Pending FTP:" << pendingFtpDirectories.size();
    
    // 📊 PROGRESS-UPDATE: FTP-Verarbeitung
    int totalFtpDirs = pendingFtpDirectories.size() + completedFtpDirectories.size();
    if (totalFtpDirs > 0) {
        int progressPercent = (completedFtpDirectories.size() * 100) / totalFtpDirs;
        emit scanProgress(progressPercent, completedFtpDirectories.size(), totalFtpDirs);
        
        // 🎯 QUEUE-INFO: Zeige verbleibende FTP-Verzeichnisse
        QString ftpProgressText = QString("FTP-Verzeichnis %1/%2").arg(completedFtpDirectories.size()).arg(totalFtpDirs);
        if (pendingFtpDirectories.size() > 0) {
            ftpProgressText += QString(" | Verbleibend: %1").arg(pendingFtpDirectories.size());
        }
        
        emit currentFileProcessing(
            ftpProgressText,  // ✅ Mit Queue-Info!
            "📡 Lade Netzwerk-Dateien",
            completedFtpDirectories.size(),
            totalFtpDirs
        );
    }
    
    // 🛡️ SAFETY CLEANUP: If pending is empty but currentlyProcessing has items, clean them up
    // ⚠️ ABER: Nur wenn auch ALLE File-Listings abgeschlossen sind!
    if (pendingFtpDirectories.isEmpty() && !currentlyProcessingFtpDirectories.isEmpty()) {
        int pending = ftpFileListingsPending.loadRelaxed();
        int completed = ftpFileListingsCompleted.loadRelaxed();
        
        // Prüfe ob noch File-Listings ausstehend sind
        if (pending > 0 && completed < pending) {
            qDebug() << "[Scanner] ⏳ SAFETY CLEANUP SKIPPED: Warte noch auf File-Listings:" << completed << "/" << pending;
            return;  // Noch nicht alle Callbacks abgeschlossen!
        }
        
        qWarning() << "[Scanner] 🧹 SAFETY CLEANUP: Found stuck directories in currentlyProcessingFtpDirectories:"
                  << currentlyProcessingFtpDirectories.size();        // Move all stuck directories to completed and clear the processing set
        for (const QString &stuckDir : currentlyProcessingFtpDirectories) {
            if (!completedFtpDirectories.contains(stuckDir)) {
                completedFtpDirectories.insert(stuckDir);
                qDebug() << "[Scanner] 🧹 Moved stuck directory to completed:" << stuckDir;
            }
        }
        currentlyProcessingFtpDirectories.clear();
        
        // Re-check progress after cleanup
        QTimer::singleShot(100, this, &Scanner::checkScanProgress);
        return;
    }
    
    // 🛡️ PHASE 2 SAFETY: In Phase 2, all directories should already be processed
    // ⚠️ ABER: Nur wenn auch ALLE File-Listings abgeschlossen sind!
    // ⚠️ CRITICAL: In Phase 2 ist pendingFtpDirectories IRRELEVANT (nutzt discoveredFtpDirectories)!
    //             Prüfe nur currentlyProcessingFtpDirectories!
    if (!ftpDiscoveryPhase && !currentlyProcessingFtpDirectories.isEmpty()) {
        int pending = ftpFileListingsPending.loadRelaxed();
        int completed = ftpFileListingsCompleted.loadRelaxed();
        
        // Prüfe ob noch File-Listings ausstehend sind
        if (pending > 0 && completed < pending) {
            qDebug() << "[Scanner] ⏳ PHASE 2 EMERGENCY CLEANUP SKIPPED: Warte noch auf File-Listings:" << completed << "/" << pending;
            return;  // Noch nicht alle Callbacks abgeschlossen!
        }
        
        qWarning() << "[Scanner] 🧹 PHASE 2 EMERGENCY CLEANUP: Found stuck directories!" 
                  << "Processing:" << currentlyProcessingFtpDirectories.size() 
                  << "Pending (ignoriert in Phase 2):" << pendingFtpDirectories.size();        // In Phase 2, ALL directories should be completed immediately
        QSet<QString> allStuckDirs = currentlyProcessingFtpDirectories;
        allStuckDirs.unite(pendingFtpDirectories);
        
        for (const QString &stuckDir : allStuckDirs) {
            if (!completedFtpDirectories.contains(stuckDir)) {
                completedFtpDirectories.insert(stuckDir);
                qDebug() << "[Scanner] 🧹 Emergency: Moved stuck directory to completed:" << stuckDir;
            }
        }
        
        // Clear ALL processing and pending directories
        currentlyProcessingFtpDirectories.clear();
        pendingFtpDirectories.clear();
        
        qWarning() << "[Scanner] 🧹 EMERGENCY CLEANUP COMPLETED - All directories moved to completed:" 
                   << completedFtpDirectories.size();
        
        // Re-check progress after cleanup
        QTimer::singleShot(100, this, &Scanner::checkScanProgress);
        return;
    }
    
    // Wenn alle FTP-Operationen abgeschlossen sind, starte die Hash-Berechnung
    if (pendingFtpDirectories.isEmpty() && currentlyProcessingFtpDirectories.isEmpty()) {
        qDebug() << "[Scanner] ✅ Alle FTP-Verzeichnisse geladen - starte Hash-Berechnung";
        
        // 🛑 STOP FTP QUEUE DRAIN TIMER: Alle FTP-Scans abgeschlossen
        if (ftpQueueDrainTimer && ftpQueueDrainTimer->isActive()) {
            ftpQueueDrainTimer->stop();
            qDebug() << "[Scanner] ⏰ FTP-Queue-Drain-Timer gestoppt (alle Scans fertig)";
        }
        
        // ✅ FIX: Group files by size BEFORE starting hash calculation
        emit scanProgress(0, 0, allFiles.size());
        emit scanStatusChanged("📏 Sortiere nach Dateigröße...");
        emit currentFileProcessing("Dateigruppierung", "📏 Größen-Filterung", 0, allFiles.size());
        currentPhase = SIZE_FILTERING;

        // Group files by size (required for progress calculation)
        for (const FileInfo &file : allFiles)
        {
            fileSizeGroups[file.size].append(file);
        }
        
        qDebug() << "[Scanner] 📊 Size-Groups erstellt:" << fileSizeGroups.size() << "verschiedene Größen für" << allFiles.size() << "Dateien";
        
        // � SPEICHERE Anzahl gesammelter Dateien für spätere scanCompleted-Emissionen
        m_totalCollectedFiles = allFiles.size();
        qDebug() << "[Scanner] 📊 GESPEICHERT (FTP-Path): m_totalCollectedFiles =" << m_totalCollectedFiles;
        
        // �📊 SIZE-FILTERING ABGESCHLOSSEN
        emit scanProgress(100, allFiles.size(), allFiles.size());
        emit scanStatusChanged(QString("📁 %1 eindeutige Dateien gesammelt (lokal: ✅, netzwerk: ✅)").arg(allFiles.size()));
        emit currentFileProcessing(
            QString("%1 Dateien gruppiert").arg(allFiles.size()),
            "✅ Größen-Filterung abgeschlossen",
            allFiles.size(),
            allFiles.size()
        );
        
        // 🔥 GUI-UPDATE: Emittiere filesCollected für FTP-Dateien
        emit filesCollected(allFiles.size());
        
        // ❌ REMOVED: startHashing() wird von GUI via startProcessingCollectedFiles() aufgerufen
        // Doppelter Aufruf hier führt zu "X Dateien geprüft" + weiteres Scannen
        if (allFiles.isEmpty()) {
            qDebug() << "[Scanner] ⚠️ Keine Dateien zum Hashen gefunden";
            emit scanProgress(100, 0, 0);
            emit scanStatusChanged("⚠️ Keine Dateien gefunden - Verzeichnis ist leer oder unzugänglich");
            
            // 🔥 GUARD: Emittiere nur wenn noch nicht emittiert
            if (!m_scanCompletedEmitted.exchange(true)) {
                DuplicateGroups emptyGroups;
                emit scanCompleted(emptyGroups);
                qDebug() << "[Scanner] 🔥 EMIT scanCompleted (NO FILES) - totalFiles: 0";
            }
        }
    }
}

// 🧠 NPU-CALLBACK: NPU-Bildverarbeitung abgeschlossen
void Scanner::onNpuImageBatchProcessed(const QStringList &processedImages)
{
    qDebug() << "[Scanner] 🎨 NPU-Bildverarbeitung abgeschlossen:" << processedImages.size() << "Bilder verarbeitet";
    
    // 🎯 LIVE-NPU-UPDATES für jedes verarbeitete Bild
    for (int i = 0; i < processedImages.size(); ++i) {
        QString imagePath = processedImages.at(i);
        QString fileName = QFileInfo(imagePath).fileName();
        
        // 📊 LIVE-AKTIVITÄTS-UPDATE an GUI senden
        emit currentFileProcessing(fileName, "NPU-Bildanalyse", i + 1, processedImages.size());
        emit processActivityUpdate("NPU-Bildverarbeitung", 
                                   QString("Feature-Extraktion: %1").arg(fileName));
    }
    
    // Statistiken für NPU-Verarbeitung
    emit scanStatusChanged(QString("🧠 NPU-Bildverarbeitung: %1 Bilder analysiert").arg(processedImages.size()));
    
    // 🚀 NPU-AKTIVITÄTS-UPDATE für Activity-Indicator
    emit npuActivityUpdate(processedImages.size(), 0); // Noch keine Duplikate gefunden
    
    // Hier könnten wir die NPU-Ergebnisse weiterverarbeiten
    // z.B. für intelligente Duplikatserkennung basierend auf Bildähnlichkeit
}

// 🗑️ FTP-Remove Callback
void Scanner::onFtpRemoveFinished(const QString &remoteFile, bool ok)
{
    deleteAttempted++;
    if (ok) deleteSucceeded++;
    emit deleteProgress(remoteFile, ok, ok ? "FTP gelöscht" : "FTP löschen fehlgeschlagen");
    if (deleteAttempted == 0) return; // shouldn’t happen
}

// 🗑️ Duplikate löschen (Batch)
void Scanner::deleteDuplicateFiles(const QList<FileInfo> &filesToDelete)
{
    deleteAttempted = 0;
    deleteSucceeded = 0;
    for (const auto &fi : filesToDelete) {
        QString msg;
        if (fi.isLocal) {
            bool ok = deleteLocalFile(fi.filePath, msg);
            deleteAttempted++;
            if (ok) deleteSucceeded++;
            emit deleteProgress(fi.filePath, ok, msg);
        } else if (fi.filePath.startsWith("ftp://")) {
            // Sicherheitsnetz: Verzeichnisse nicht löschen
            if (fi.filePath.endsWith('/')) {
                emit deleteProgress(fi.filePath, false, "Verzeichnis-Löschen blockiert");
                continue;
            }
            // FTP: Host + Remote Pfad extrahieren
            QUrl u(fi.filePath);
            QString remote = u.path();
            if (remote.startsWith('/')) remote.remove(0,1);
            if (!ftpClient) {
                emit deleteProgress(fi.filePath, false, "Kein FTP-Client verfügbar");
                continue;
            }
            // Anmeldedaten werden vom FtpClient verwaltet; wir rufen remove() auf
            connect(ftpClient, &FtpClient::removeFinished, this, &Scanner::onFtpRemoveFinished, Qt::UniqueConnection);
            ftpClient->remove(remote);
        } else {
            emit deleteProgress(fi.filePath, false, "Unbekannter Netzwerktyp");
        }
    }
    emit deleteBatchFinished(deleteAttempted, deleteSucceeded);
}

// 🗑️ Lokale Datei löschen → Papierkorb wenn möglich, sonst hart
bool Scanner::deleteLocalFile(const QString &path, QString &msg)
{
    QFileInfo info(path);
    if (!info.exists() || !info.isFile()) {
        msg = "Nicht gefunden oder keine Datei";
        return false;
    }
    // Versuch: direkt löschen (send2trash wäre extern, hier Fallback)
    if (QFile::remove(path)) {
        msg = "Gelöscht";
        return true;
    }
    msg = "Löschen fehlgeschlagen";
    return false;
}

// 🛡️ NEUE FUNKTION: Deduplication-Caches leeren
void Scanner::clearDeduplicationCaches()
{
    globalProcessedFiles.clear();
    globalHashedFiles.clear();
    processedFiles.clear();  // 🛡️ KRITISCH: Member-Variable auch leeren!
    
    // 🧹 ERWEITERTE MEMORY-BEREINIGUNG
    // Nur leeren wenn bereits verarbeitet (nicht während aktiver Scan)
    if (!scanning.load()) {
        allFiles.clear();
        
        fileSizeGroups.clear();
        hashGroups.clear();
        dateSizeGroups.clear();
        
        extractedFeatures.clear();
        
        imageDuplicateGroups.clear();
        
        // Directory iterators cleanup
        currentDirIterators.clear();
        
        qDebug() << "[Scanner] 🧹 ERWEITERTE Memory-Bereinigung durchgeführt";
    }
    
    qDebug() << "[Scanner] 🛡️ Deduplication-Caches geleert (inkl. processedFiles)";
}

// 🛡️ NEUE FUNKTION: Prüfung ob Datei bereits verarbeitet wurde
bool Scanner::isFileAlreadyProcessed(const QString &filePath)
{
    QString canonicalPath = QFileInfo(filePath).canonicalFilePath();
    return globalProcessedFiles.contains(canonicalPath);
}

// 🧠 MEMORY-SAFE: Batch-Verarbeitung für große FTP-Datensätze (>25.000 Dateien)
void Scanner::processFtpFilesBatch(const QString &directoryOrUrl, const QStringList &files, bool success)
{
    qDebug() << "[Scanner] 🧠 BATCH-VERARBEITUNG für" << files.size() << "Dateien gestartet";
    
    const int batchSize = 5000; // 5K Dateien pro Batch
    int totalBatches = (files.size() + batchSize - 1) / batchSize;
    // Ermittele Basis-URL für korrekte Pfadkonstruktion
    QString baseUrl = directoryOrUrl;
    if (!baseUrl.startsWith("ftp://")) {
        auto normalizePath = [](QString p) {
            if (p.isEmpty()) return p;
            if (!p.startsWith('/')) p.prepend('/');
            if (p.length() > 1 && p.endsWith('/')) p.chop(1);
            return p;
        };
        const QString dirNorm = normalizePath(directoryOrUrl);
        for (const QString &pendingUrl : pendingFtpDirectories) {
            QUrl url(pendingUrl);
            const QString pendNorm = normalizePath(url.path());
            if (pendNorm == dirNorm || normalizePath(url.path() + "/") == dirNorm) {
                baseUrl = pendingUrl;
                break;
            }
        }
    }
    
    for (int batch = 0; batch < totalBatches; batch++) {
        int startIdx = batch * batchSize;
        int endIdx = qMin(startIdx + batchSize, files.size());
        
        QStringList batchFiles = files.mid(startIdx, endIdx - startIdx);
        qDebug() << "[Scanner] 🧠 Verarbeite Batch" << (batch + 1) << "/" << totalBatches 
                 << ":" << batchFiles.size() << "Dateien";
        
        // ✅ Direkte Verarbeitung ohne rekursiven Aufruf mit korrekter Basis-URL
        processSingleFtpBatch(baseUrl, batchFiles);
        
        // 🛡️ Memory-Cleanup zwischen Batches
        if (batch % 2 == 0) { // Every 2nd batch
            clearDeduplicationCaches();
            
            // 🧹 AGGRESSIVE Memory-Cleanup für große Datensätze
            if (batch % 10 == 0 && allFiles.size() > 5000) {
                // Periodisches Memory-Defragmentierung bei großen Datensätzen
                qDebug() << "[Scanner] 💾 Aggressive Memory-Defragmentierung bei" << allFiles.size() << "Dateien";
            }
            
            qDebug() << "[Scanner] 🧹 Batch-Memory-Cleanup durchgeführt";
        }
        
        // Kurze Pause zwischen Batches um Memory-Pressure zu reduzieren
        QThread::msleep(50);
    }
    
    // Mark directory as completed after all batches
    pendingFtpDirectories.remove(directoryOrUrl);
    checkScanProgress();
    
    qDebug() << "[Scanner] ✅ BATCH-VERARBEITUNG abgeschlossen:" << totalBatches << "Batches verarbeitet";
}

// 🧠 MEMORY-SAFE: Einzelner Batch ohne Rekursion
void Scanner::processSingleFtpBatch(const QString &baseUrl, const QStringList &files)
{
    // ✅ Einfache Batch-Verarbeitung ohne komplexe NPU-Logik
    // Einheitliche Großdatei-Politik (FTP): env-basiert
    bool skipLarge = qEnvironmentVariableIsSet("FILEDUPER_SKIP_LARGE") && (qgetenv("FILEDUPER_SKIP_LARGE") == "1");
    qint64 maxSizeMb = qEnvironmentVariableIsSet("FILEDUPER_MAX_SIZE_MB") ? qgetenv("FILEDUPER_MAX_SIZE_MB").toLongLong() : 0;
    for (const QString &fileName : files) {
        // ✅ Erstelle FileInfo ohne QSet-Overhead
        QString filePath;
        qint64 fileSize = 0;
        
        // Parse file info (name|size format)
        if (fileName.contains('|')) {
            QStringList parts = fileName.split('|');
            QString name = parts[0];
            if (parts.size() > 1) {
                fileSize = parts[1].toLongLong();
            }
            // Einheitliche Großdatei-Politik anwenden
            if (skipLarge && maxSizeMb > 0) {
                qint64 maxBytes = maxSizeMb * 1024 * 1024;
                if (fileSize > maxBytes) {
                    qDebug() << "[Scanner] 🚫 GROSSE FTP-Datei übersprungen (Batch) (" << maxSizeMb << "MB):" << name;
                    continue;
                }
            }
            filePath = name;
        } else {
            filePath = fileName;
        }
        
        // ✅ Create FTP FileInfo - extract host from directory context
        FileInfo fileInfo;
        fileInfo.fileName = QFileInfo(filePath).fileName();
        
        // ✅ Proper URL construction: baseUrl is a full FTP URL already
        QString url = baseUrl;
        if (!url.endsWith('/')) url += '/';
        fileInfo.filePath = url + QUrl::toPercentEncoding(fileInfo.fileName);
        
        fileInfo.size = fileSize;
        fileInfo.lastModified = QDateTime::currentSecsSinceEpoch();
        fileInfo.hash = "";
        fileInfo.isLocal = false;
        fileInfo.networkType = "FTP";
        
        // ✅ Add to main file list (thread-safe)
        allFiles.append(fileInfo);
    }
    
    qDebug() << "[Scanner] ✅ Batch-Dateien hinzugefügt:" << files.size() << "Total:" << allFiles.size();
}

// 🎯 NPU-BILDVERARBEITUNG: Feature-basierte Ähnlichkeitsanalyse
void Scanner::startNpuImageAnalysis(const QStringList &imagePaths) {
    if (!npuManager) {
        qWarning() << "[Scanner] ❌ NPU-Manager nicht verfügbar - überspringe Bildanalyse";
        return;
    }
    
    qDebug() << "[Scanner] 🎯 NPU-Bildanalyse startet für" << imagePaths.size() << "Bilder";
    emit npuAnalysisProgress("Extrahiere Bildfeatures mit NPU...");
    
    // Extrahiere Features für alle Bilder
    extractedFeatures = npuManager->extractImageFeatures(imagePaths);
    emit imageFeaturesExtracted(extractedFeatures);
    
    // Führe Ähnlichkeitsanalyse durch
    emit npuAnalysisProgress("Analysiere Bildähnlichkeiten...");
    processImageFeatures(extractedFeatures);
}

void Scanner::processImageFeatures(const QList<NpuManager::ImageFeature> &features) {
    if (features.isEmpty()) {
        qDebug() << "[Scanner] ⚠️ Keine gültigen Bildfeatures - überspringe NPU-Analyse";
        return;
    }
    
    qDebug() << "[Scanner] 🔍 Verarbeite" << features.size() << "Bildfeatures";
    
    // Verwende konfigurierbaren Ähnlichkeitsmodus (Standard: NEAR_DUPLICATES)
    QList<NpuManager::NpuDuplicateGroup> npuGroups = npuManager->findSimilarImages(features, currentSimilarityMode);
    
    // Konvertiere NPU-Gruppen zu Scanner-Format
    imageDuplicateGroups.clear();
    for (const auto &npuGroup : npuGroups) {
        ImageDuplicateGroup scannerGroup;
        scannerGroup.originalImage = npuGroup.originalImage;
        scannerGroup.duplicateImages = npuGroup.similarImages;
        scannerGroup.averageSimilarity = npuGroup.avgSimilarity;
        
        // Bestimme Gruppen-Typ basierend auf Ähnlichkeit
        if (npuGroup.avgSimilarity >= 0.95f) scannerGroup.groupType = "STRICT";
        else if (npuGroup.avgSimilarity >= 0.85f) scannerGroup.groupType = "NEAR";
        else if (npuGroup.avgSimilarity >= 0.70f) scannerGroup.groupType = "SIMILAR";
        else scannerGroup.groupType = "LOOSE";
        
        imageDuplicateGroups.append(scannerGroup);
    }
    
    qDebug() << "[Scanner] ✅ NPU-Analyse abgeschlossen:" << imageDuplicateGroups.size() << "Bild-Duplikat-Gruppen";
    emit imageDuplicatesFound(imageDuplicateGroups);
}

// Filtere Bilddateien aus allen gefundenen Dateien
QStringList Scanner::filterImageFiles(const QList<FileInfo> &allFiles) {
    QStringList imagePaths;
    QStringList imageExtensions = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp"};
    
    for (const FileInfo &file : allFiles) {
        if (isImageFile(file.filePath)) {
            imagePaths.append(file.filePath);
        }
    }
    
    qDebug() << "[Scanner] 🖼️ " << imagePaths.size() << "Bilddateien von" << allFiles.size() << "Dateien gefiltert";
    return imagePaths;
}

// Prüfe ob Datei ein Bild ist
bool Scanner::isImageFile(const QString &filePath) const {
    static QStringList imageExtensions = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp", ".svg"};
    
    QString lowerPath = filePath.toLower();
    for (const QString &ext : imageExtensions) {
        if (lowerPath.endsWith(ext)) {
            return true;
        }
    }
    return false;
}

// Kombiniere Hash- und NPU-basierte Ergebnisse
CombinedDuplicateResult Scanner::combineHashAndImageResults() {
    CombinedDuplicateResult combined;
    
    // Hash-basierte Duplikate aus aktuellen Gruppen
    for (const auto &sizeGroup : fileSizeGroups) {
        if (sizeGroup.size() > 1) {
            QHash<QString, QList<FileInfo>> hashMap;
            for (const FileInfo &file : sizeGroup) {
                if (!file.hash.isEmpty()) {
                    hashMap[file.hash].append(file);
                }
            }
            
            for (auto it = hashMap.begin(); it != hashMap.end(); ++it) {
                if (it.value().size() > 1) {
                    DuplicateGroup group;
                    group.hash = it.key();
                    group.size = it.value().first().size;
                    group.original = it.value().first();
                    
                    for (int i = 1; i < it.value().size(); ++i) {
                        group.duplicates.append(it.value()[i]);
                    }
                    
                    combined.hashDuplicates.append(group);
                }
            }
        }
    }
    
    // NPU-basierte Bild-Duplikate hinzufügen
    combined.imageDuplicates = imageDuplicateGroups;
    
    qDebug() << "[Scanner] 🔗 Kombinierte Ergebnisse:" << combined.hashDuplicates.size() << "Hash-Gruppen," << combined.imageDuplicates.size() << "Bild-Gruppen";
    return combined;
}

// Erweiterte Duplikatserkennung: Hash + NPU kombiniert
void Scanner::startAdvancedDuplicateDetection() {
    qDebug() << "[Scanner] 🚀 Erweiterte Duplikatserkennung startet (Hash + NPU)";
    
    // Phase 1: Traditionelle Hash-basierte Duplikaterkennung
    emit scanStatusChanged("Berechne File-Hashes...");
    compareHashes();
    
    // Phase 2: NPU-basierte Bildähnlichkeitsanalyse
    if (npuManager) {
        QStringList imagePaths = filterImageFiles(allFiles);
        if (!imagePaths.isEmpty()) {
            emit scanStatusChanged("NPU analysiert Bildähnlichkeiten...");
            currentSimilarityMode = NpuManager::NEAR_DUPLICATES; // Konfigurierbar
            startNpuImageAnalysis(imagePaths);
        }
    }
    
    // Phase 3: Kombiniere Ergebnisse
    emit scanStatusChanged("Kombiniere Duplikat-Ergebnisse...");
    CombinedDuplicateResult combined = combineHashAndImageResults();
    emit combinedScanCompleted(combined);
}

// Implementierung für CombinedDuplicateResult::totalDuplicates()
int CombinedDuplicateResult::totalDuplicates() const {
    int total = 0;
    for (const DuplicateGroup &group : hashDuplicates) {
        total += group.duplicates.size();
    }
    for (const ImageDuplicateGroup &group : imageDuplicates) {
        total += group.duplicateImages.size();
    }
    return total;
}

void Scanner::processNextFile()
{
    // No longer used - processing is handled by HashEngine callbacks
    // This method is kept for compatibility but should not be called
    qDebug() << "[Scanner] ⚠️ processNextFile() called - should use HashEngine callbacks instead";
}

// ⚡ OPTIMIERUNG: Erstelle partielle Results für Anti-Hang Mechanismus
DuplicateGroups Scanner::buildPartialResults() {
    DuplicateGroups partialResults;
    
    qDebug() << "[Scanner] 🔧 Erstelle partielle Results für Anti-Hang...";
    
    // Sammle alle bereits gehashten Dateien mit identischen Hashes
    QHash<QString, QList<FileInfo>> hashGroups;
    
    for (auto groupIt = fileSizeGroups.begin(); groupIt != fileSizeGroups.end(); ++groupIt) {
        const QList<FileInfo> &filesInGroup = groupIt.value();
        for (const FileInfo &file : filesInGroup) {
            // ✅ KRITISCH: Filtere ALLE Fehler-Hashes (FTP-Phantome, GPU-Fehler, etc.)
            if (!file.hash.isEmpty() && 
                !file.hash.startsWith("FTP_") &&      // Alle FTP-Fehler (FTP_STREAM_FAILED_78, FTP_SKIPPED, etc.)
                !file.hash.startsWith("CURL_") &&     // Alle CURL-Fehler
                !file.hash.startsWith("ERROR_") &&    // Generische Fehler
                !file.hash.startsWith("INVALID_") &&  // Ungültige URLs/Dateien
                !file.hash.startsWith("GPU_") &&      // GPU-Fehler
                !file.hash.startsWith("NPU_")) {      // NPU-Fehler
                hashGroups[file.hash].append(file);
            }
        }
    }
    
    // Erstelle DuplicateGroups aus Hash-Matches
    for (auto hashIt = hashGroups.begin(); hashIt != hashGroups.end(); ++hashIt) {
        const QString &hash = hashIt.key();
        const QList<FileInfo> &files = hashIt.value();
        if (files.size() > 1) {
            DuplicateGroup group;
            group.hash = hash;
            group.size = files.first().size;
            
            // Bestimme Original (älteste Datei)
            FileInfo oldest = files.first();
            for (const FileInfo &file : files) {
                if (file.lastModified < oldest.lastModified) {
                    oldest = file;
                }
            }
            
            group.original = oldest;
            for (const FileInfo &file : files) {
                if (file.filePath != oldest.filePath) {
                    group.duplicates.append(file);
                }
            }
            
            if (!group.duplicates.isEmpty()) {
                partialResults.groups.append(group);
            }
        }
    }
    
    // 🔥 KRITISCH: Berechne Statistiken für korrekte GUI-Anzeige
    partialResults.totalFiles = hashGroups.size();
    partialResults.duplicateFiles = 0;
    partialResults.duplicateSize = 0;
    
    for (const DuplicateGroup &group : partialResults.groups) {
        partialResults.duplicateFiles += group.duplicates.size();
        partialResults.duplicateSize += group.size * group.duplicates.size();
    }
    
    qDebug() << "[Scanner] ✅ Partielle Results:" << partialResults.groups.size() << "Duplikat-Gruppen erstellt"
             << "Duplikat-Dateien:" << partialResults.duplicateFiles
             << "Gesparte Größe:" << (partialResults.duplicateSize / 1024 / 1024) << "MB";
    return partialResults;
}

// ⚡ OPTIMIERUNG: Cache-Processing für FTP-Dateien
void Scanner::processCachedFtpFiles(const QString &ftpDirectory, const QStringList &files, QSet<QString> &processedFiles) {
    qDebug() << "[Scanner] ⚡ Verarbeite" << files.size() << "gecachte FTP-Dateien für:" << ftpDirectory;
    
    for (const QString &file : files) {
        // Skip bereits verarbeitete Dateien
        if (processedFiles.contains(file)) continue;
        
        // ✅ KRITISCH: Filter FTP-|size Variants
        if (file.contains("|")) {
            qDebug() << "[Scanner] 🔧 DUPLIKAT-FIX: Filtere |size variant:" << file;
            continue;
        }
    // FTP cached entries are names, not local paths; build proper URL
    QString fullPath = ftpDirectory;
    if (!fullPath.endsWith('/')) fullPath += '/';
    fullPath += file;

    FileInfo info;
    info.filePath = fullPath;
    info.fileName = file;
    info.size = 0; // unknown from cache (will be set later)
    info.lastModified = QDateTime::currentSecsSinceEpoch();
    info.hash = "";
    info.isLocal = false;
    info.networkType = "FTP";

    // 🔒 THREAD-SAFE: Lock für allFiles & processedFiles
    {
        QMutexLocker locker(&processedFilesMutex);
        allFiles.append(info);
        processedFiles.insert(file);
    }
    }
}

// ⚡ OPTIMIERUNG: FTP-Client Pool für Connection-Reuse
FtpClient* Scanner::getOrCreateFtpClient(const QString &host, int port, const QString &parentFtpUrl) {
    Q_UNUSED(port);
    Q_UNUSED(parentFtpUrl);
    static QHash<QString, QList<FtpClient*>> clientPool;
    static const int MAX_CLIENTS_PER_HOST = 300;  // 🚀 ULTRA: 300 parallele Verbindungen!
    
    // 🚀 CONNECTION POOLING: Wiederverwendung bis zu 300 Clients pro Host
    if (clientPool.contains(host) && !clientPool[host].isEmpty()) {
        // Finde ersten nicht-busy Client
        for (FtpClient *client : clientPool[host]) {
            if (!client->property("busy").toBool()) {
                client->setProperty("busy", true);
                qDebug() << "[Scanner] ♻️ Wiederverwendeter Client #" << clientPool[host].indexOf(client) << "für:" << host;
                return client;
            }
        }
    }
    
    // Erstelle neuen Client wenn Pool noch nicht voll
    if (!clientPool.contains(host) || clientPool[host].size() < MAX_CLIENTS_PER_HOST) {
        FtpClient *client = new FtpClient(this);
        client->setProperty("busy", true);
        client->setProperty("host", host);
        
        // ❌ KEINE automatische Rekursion in Phase 2!
        // Alle Verzeichnisse wurden bereits in Phase 1 (discoverFtpDirectories) gefunden.
        // Phase 2 scannt nur Dateien in den bereits bekannten Verzeichnissen.
        
        if (!clientPool.contains(host)) {
            clientPool[host] = QList<FtpClient*>();
        }
        clientPool[host].append(client);
        
        qDebug() << "[Scanner] 🆕 Neuer Client #" << clientPool[host].size() << "/" << MAX_CLIENTS_PER_HOST << "für:" << host;
        return client;
    }
    
    // Pool voll - warte und verwende ersten verfügbaren (sollte nie passieren mit ThreadPool)
    qWarning() << "[Scanner] ⚠️ Client-Pool voll (" << MAX_CLIENTS_PER_HOST << "), verwende ersten";
    FtpClient *client = clientPool[host].first();
    client->setProperty("busy", true);
    return client;
}

// ⚡ FALLBACK: Default-Credentials wenn PresetManager fehlt
void Scanner::useDefaultFtpCredentials(FtpClient *client, const QString &host) {
    qDebug() << "[Scanner] 🔑 Verwende Default-Credentials für:" << host;
    
    // Standard FTP-Credentials (Anonymous oder häufige Kombinationen)
    QStringList commonUsers = {"ftp", "anonymous", "guest", "user", "admin"};
    QStringList commonPasses = {"", "anonymous", "guest", "password", "admin"};
    
    // Verwende erste Kombination als Default
    client->setCredentials(host, 21, commonUsers.first(), commonPasses.first());
}

// ✅ Asynchrone Dateisammlung - GUI-responsive und crash-sicher
void Scanner::startAsyncFileCollection() {
    qDebug() << "[Scanner] 🚀 Starte asynchrone Dateisammlung für" << scanDirectories.size() << "Verzeichnisse";
    
    // Reset state
    directoriesToProcess.clear();
    cleanupFileCollection();
    allFiles.clear();
    processedFiles.clear();
    currentDirectoryIndex = 0;
    filesFoundInCurrentDir = 0;
    
    // 🎯 SMART REDUNDANCY FILTER: Entferne Parent-Verzeichnisse wenn Child bereits ausgewählt
    QStringList filteredDirectories;
    
    for (const QString &dir : scanDirectories) {
        bool isRedundant = false;
        
        // Normalisiere Pfad (entferne trailing slash für Vergleich)
        QString normalizedDir = dir;
        if (normalizedDir.endsWith('/') && normalizedDir.length() > 1) {
            normalizedDir.chop(1);
        }
        
        // Prüfe ob ein anderes Verzeichnis ein CHILD von diesem ist
        for (const QString &otherDir : scanDirectories) {
            if (dir == otherDir) continue; // Skip sich selbst
            
            QString normalizedOther = otherDir;
            if (normalizedOther.endsWith('/') && normalizedOther.length() > 1) {
                normalizedOther.chop(1);
            }
            
            // Ist otherDir ein Child von dir? (otherDir startet mit dir/)
            if (normalizedOther.startsWith(normalizedDir + "/")) {
                qDebug() << "[Scanner] 🔍 REDUNDANT: Parent" << normalizedDir 
                         << "wird übersprungen weil Child" << normalizedOther << "ausgewählt ist";
                isRedundant = true;
                break;
            }
        }
        
        if (!isRedundant) {
            filteredDirectories.append(dir);
            qDebug() << "[Scanner] ✅ Verzeichnis zur Scan-Queue hinzugefügt:" << dir;
        }
    }
    
    // Fülle Queue mit gefilterten Verzeichnissen
    for (const QString &dir : filteredDirectories) {
        directoriesToProcess.enqueue(dir);
    }
    
    int removedCount = scanDirectories.size() - filteredDirectories.size();
    if (removedCount > 0) {
        qDebug() << "[Scanner] 🎯 Redundanz-Filter: Entfernt" << removedCount 
                 << "Parent-Verzeichnisse (behalten:" << filteredDirectories.size() << ")";
    }
    
    qDebug() << "[Scanner] 📊 Scan-Queue:" << directoriesToProcess.size() 
             << "Verzeichnisse (nach Redundanz-Filterung)";
    
    emit scanStatusChanged(QString("Sammle Dateien aus %1 Verzeichnissen...").arg(directoriesToProcess.size()));
    
    // MASSIVE PARALLELITAET: Starte ALLE FTP-Verzeichnisse SOFORT!
    QStringList ftpDirs;
    QStringList localDirs;
    
    while (!directoriesToProcess.isEmpty()) {
        QString dir = directoriesToProcess.dequeue();
        if (dir.startsWith("ftp://") || dir.startsWith("sftp://") || dir.startsWith("smb://")) {
            ftpDirs.append(dir);
        } else {
            localDirs.append(dir);
        }
    }
    
    qDebug() << "[Scanner] BATCH START:" << ftpDirs.size() << "FTP-Dirs +" << localDirs.size() << "local Dirs";
    
    // 🔍 PHASE 1: FTP Discovery - Entdecke ALLE Unterverzeichnisse rekursiv
    if (!ftpDirs.isEmpty()) {
        qDebug() << "[Scanner] 🔍 PHASE 1: Starte PARALLEL FTP-Discovery für" << ftpDirs.size() << "Root-Verzeichnisse";
        
        // Save local dirs for later (will be scanned after FTP discovery)
        localDirectoriesForLaterScan = localDirs;
        
        // 🚀 Start PARALLEL Phase 1: Discovery
        startParallelFtpDiscovery(ftpDirs);
        
        return; // Exit - Phase 2 wird von onFtpDiscoveryCompleted() gestartet
    }
    
    // Falls KEINE FTP-Dirs: Nur lokaler Scan
    qDebug() << "[Scanner] 📂 Nur lokale Verzeichnisse - kein FTP-Discovery nötig";
    
    // Local: Re-queue für Timer
    for (const QString &localDir : localDirs) {
        directoriesToProcess.enqueue(localDir);
    }
    
    // Starte Timer nur für lokale Verzeichnisse
    if (!directoriesToProcess.isEmpty()) {
        fileCollectionTimer->start();
    } else if (ftpDirs.isEmpty()) {
        // Keine Verzeichnisse -> direkt zur Size-Filtering Phase
        filterBySize();
    }
}

void Scanner::processNextDirectoryChunk() {
    // 🚀 ULTRA-FAST: Verarbeite bis zu 5 Verzeichnisse pro Timer-Event
    const int MAX_DIRS_PER_TICK = 5;
    int processedDirs = 0;
    
    while (processedDirs < MAX_DIRS_PER_TICK) {
        if (!scanning.load() || directoriesToProcess.isEmpty()) {
            // Sammlung abgeschlossen
            cleanupFileCollection();
            
            if (scanning.load()) {
                qDebug() << "[Scanner] ✅ Dateisammlung abgeschlossen:" << allFiles.size() << "Dateien gefunden";
                emit scanStatusChanged(QString("Sammlung abgeschlossen: %1 Dateien gefunden").arg(allFiles.size()));
                
                // 🔥 KRITISCH: Rufe filterBySize() NUR wenn KEIN FTP-Scan aktiv!
                // Bei FTP-Scans wird der Workflow von checkScanProgress() fortgesetzt
                if (pendingFtpDirectories.isEmpty()) {
                    qDebug() << "[Scanner] ✅ Kein FTP-Scan aktiv - starte Size-Filtering direkt";
                    QTimer::singleShot(100, this, &Scanner::filterBySize);
                } else {
                    qDebug() << "[Scanner] ⏳ FTP-Scan aktiv (" << pendingFtpDirectories.size() 
                             << "pending) - warte auf checkScanProgress() für Size-Filtering";
                    emit scanStatusChanged(QString("Warte auf %1 FTP-Verzeichnisse...").arg(pendingFtpDirectories.size()));
                }
            }
            return;
        }
        
        // Verarbeite das nächste Verzeichnis oder chunk
        if (!currentDirIterator) {
            // Starte neues Verzeichnis
            QString currentDir = directoriesToProcess.dequeue();
            currentDirectoryIndex++;
            filesFoundInCurrentDir = 0;
            processedDirs++; // 🚀 Zähle verarbeitete Verzeichnisse
            
            qDebug() << "[Scanner] 📂 Bearbeite Verzeichnis" << currentDirectoryIndex << "/" 
                     << (currentDirectoryIndex + directoriesToProcess.size()) << ":" << currentDir;
            
            emit currentFileProcessing(
                QFileInfo(currentDir).fileName(),
                "📁 Sammle Dateien",
                currentDirectoryIndex,
                currentDirectoryIndex + directoriesToProcess.size()
            );
            
            if (currentDir.startsWith("ftp://")) {
                // FTP-Verzeichnis - verwende bestehende FTP-Logik
                collectFtpFiles(currentDir, processedFiles);
                // FTP ist asynchron - warte auf Completion
                continue; // 🚀 Verarbeite nächstes Verzeichnis sofort
            } else {
                // 🚀 2-PHASEN LOCAL SCAN (wie FTP): Phase 1 = Discovery, Phase 2 = File Collection
                qDebug() << "[Scanner] 🔍 LOCAL 2-PHASE SCAN für:" << currentDir;
                
                // Prüfe ob Verzeichnis existiert
                QDir dir(currentDir);
                if (!dir.exists()) {
                    qWarning() << "[Scanner] ❌ Verzeichnis existiert nicht:" << currentDir;
                    emit scanStatusChanged(QString("❌ Verzeichnis nicht gefunden: %1").arg(currentDir));
                    continue; // Nächstes Verzeichnis
                }
                
                // PHASE 1: Sammle rekursiv alle Unterverzeichnisse
                QSet<QString> discoveredLocalDirectories;
                discoveredLocalDirectories.insert(currentDir);  // Start mit Root
                
                qDebug() << "[Scanner] 🔍 LOCAL PHASE 1: Directory Discovery für:" << currentDir;
                
                QDirIterator dirIt(currentDir, QDir::Dirs | QDir::NoDotAndDotDot | QDir::Readable, QDirIterator::Subdirectories);
                while (dirIt.hasNext()) {
                    if (!scanning.load()) return;
                    QString subDir = dirIt.next();
                    discoveredLocalDirectories.insert(subDir);
                }
                
                qDebug() << "[Scanner] ✅ LOCAL PHASE 1 Complete:" << discoveredLocalDirectories.size() << "Verzeichnisse";
                
                // PHASE 2: Scanne alle entdeckten Verzeichnisse PARALLEL (wie FTP!)
                qDebug() << "[Scanner] 🚀 LOCAL PHASE 2: PARALLEL File Collection in" << discoveredLocalDirectories.size() << "Verzeichnissen";
                QList<QString> sortedDirs = discoveredLocalDirectories.values();
                std::sort(sortedDirs.begin(), sortedDirs.end());
                
                int totalDirs = sortedDirs.size();
                QAtomicInt processedSubDirs(0);
                QAtomicInt totalFilesFound(0);
                
                // 🚀 PARALLEL: Lambda für jedes Verzeichnis (wie bei FTP collectFtpFiles)
                auto scanLocalDirectory = [&](const QString &localDir) {
                    if (!scanning.load()) return;
                    
                    int dirFilesFound = 0;
                    QList<FileInfo> dirFiles;  // Thread-lokale Liste
                    
                    // Scanne NUR Dateien in diesem Verzeichnis (NICHT rekursiv!)
                    QDirIterator fileIt(localDir, QDir::Files | QDir::Readable, QDirIterator::NoIteratorFlags);
                    
                    while (fileIt.hasNext()) {
                        if (!scanning.load()) return;
                        
                        QString filePath = fileIt.next();
                        QFileInfo fileInfo(filePath);
                        
                        QString canonicalPath = fileInfo.canonicalFilePath();
                        if (canonicalPath.isEmpty()) {
                            canonicalPath = fileInfo.absoluteFilePath();
                        }
                        
                        // 🔒 THREAD-SAFE: Lock für processedFiles Check & Insert
                        {
                            QMutexLocker locker(&processedFilesMutex);
                            if (processedFiles.contains(canonicalPath)) {
                                continue;  // Skip duplicate
                            }
                            processedFiles.insert(canonicalPath);
                        }
                        
                        // 🚀 PERFORMANCE: Große Dateien (>10MB) nur nach GRÖSSE+NAME vergleichen
                        const qint64 maxFileSizeForHashing = 10 * 1024 * 1024;
                        qint64 fileSize = fileInfo.size();
                        
                        FileInfo file;
                        file.filePath = canonicalPath;
                        file.fileName = fileInfo.fileName();
                        file.size = fileSize;
                        
                        if (fileSize > maxFileSizeForHashing) {
                            file.hash = "";  // SIZE+NAME only
                        }
                        
                        dirFiles.append(file);
                        dirFilesFound++;
                    }
                    
                    // 🔒 THREAD-SAFE: Füge alle gefundenen Dateien zu allFiles hinzu
                    if (!dirFiles.isEmpty()) {
                        QMutexLocker locker(&allFilesMutex);
                        allFiles.append(dirFiles);
                        totalFilesFound.fetchAndAddRelaxed(dirFilesFound);
                    }
                    
                    // Progress Update
                    int processed = processedSubDirs.fetchAndAddRelaxed(1) + 1;
                    if (processed % 10 == 0 || processed == totalDirs) {
                        emit currentFileProcessing(
                            QFileInfo(localDir).fileName(),
                            QString("📂 Scanne %1/%2 (parallel)").arg(processed).arg(totalDirs),
                            processed,
                            totalDirs
                        );
                    }
                    
                    if (totalFilesFound.loadRelaxed() % 100 == 0) {
                        emit currentFileProcessing(
                            QString("%1 Dateien").arg(totalFilesFound.loadRelaxed()),
                            "🔍 Parallel scan läuft...",
                            totalFilesFound.loadRelaxed(),
                            0
                        );
                    }
                };
                
                // 🚀 STARTE ALLE VERZEICHNISSE PARALLEL (wie FTP!)
                qDebug() << "[Scanner] ⚡ Starte PARALLEL Scan für" << totalDirs << "Verzeichnisse";
                
                // QtConcurrent::map für parallele Verarbeitung
                QFuture<void> future = QtConcurrent::map(sortedDirs, scanLocalDirectory);
                
                // Warte auf Completion
                future.waitForFinished();
                
                qDebug() << "[Scanner] ✅ LOCAL PHASE 2 Complete:" << processedSubDirs.loadRelaxed() << "Verzeichnisse," << totalFilesFound.loadRelaxed() << "Dateien (PARALLEL)";
                
                // Markiere Verzeichnis als vollständig verarbeitet - KEIN Iterator nötig
                currentDirIterator = nullptr;
                continue; // Nächstes Verzeichnis
            }
        }
    
    // Verarbeite Chunk von Dateien (z.B. 20 Dateien pro Timer-Event)
    int filesProcessedInChunk = 0;
    const int MAX_FILES_PER_CHUNK = 20;
    
    // 🚀 DEBUG: Status vor Dateiverarbeitung
    if (currentDirIterator) {
        qDebug() << "[Scanner] 🔄 Verarbeite Datei-Chunk (max" << MAX_FILES_PER_CHUNK << "Dateien)";
    }
    
    while (currentDirIterator && currentDirIterator->hasNext() && filesProcessedInChunk < MAX_FILES_PER_CHUNK) {
        if (!scanning.load()) {
            qDebug() << "[Scanner] 🛑 Scan gestoppt während Dateiverarbeitung";
            return;
        }
        
        // 🚀 DEBUG: Zeige Fortschritt alle 5 Dateien
        if (filesProcessedInChunk % 5 == 0 && filesProcessedInChunk > 0) {
            qDebug() << "[Scanner] 📊 Chunk-Fortschritt:" << filesProcessedInChunk << "/" << MAX_FILES_PER_CHUNK;
        }
        
        QString filePath = currentDirIterator->next();
        QFileInfo fileInfo(filePath);
        
        // 🚀 DEBUG: Zeige Datei nur alle 10 Dateien
        if (allFiles.size() % 10 == 0) {
            qDebug() << "[Scanner] 📄 Verarbeite Datei:" << fileInfo.fileName() << "(" << allFiles.size() << "total)";
        }
        
        // Normale Dateiverarbeitung
        QString canonicalPath = fileInfo.canonicalFilePath();
        if (canonicalPath.isEmpty()) {
            canonicalPath = fileInfo.absoluteFilePath();
        }
        
        // 🔒 THREAD-SAFE: Lock für processedFiles Check & Insert
        {
            QMutexLocker locker(&processedFilesMutex);
            if (processedFiles.contains(canonicalPath)) {
                filesProcessedInChunk++;
                continue;  // Skip duplicate
            }
            // Nach dem Check sofort einfügen (im gleichen Lock)
            processedFiles.insert(canonicalPath);
        }
        
        // 🚀 PERFORMANCE: Große Dateien (>10MB) nur nach GRÖSSE+NAME vergleichen (kein Hash!)
        const qint64 maxFileSizeForHashing = 10 * 1024 * 1024; // 10MB = Skip Music/Video!
        qint64 fileSize = fileInfo.size();
        if (fileSize > maxFileSizeForHashing) {
            // ✅ SMART: Große Dateien nach SIZE+NAME vergleichen (sehr zuverlässig!)
            filesFoundInCurrentDir++;
            
            FileInfo file;
            file.filePath = canonicalPath;
            file.fileName = fileInfo.fileName();
            file.size = fileSize;
            file.lastModified = fileInfo.lastModified().toSecsSinceEpoch();
            file.hash = QString("SIZE_NAME_%1_%2").arg(fileSize).arg(fileInfo.fileName().toLower()); // 🎯 SIZE+NAME Hash!
            file.isLocal = true;
            
            allFiles.append(file);
            filesProcessedInChunk++;
            continue; // Nächste Datei
        }
        
        filesFoundInCurrentDir++;
        
        // Erstelle FileInfo
        FileInfo file;
        file.filePath = canonicalPath;
        file.fileName = fileInfo.fileName();
        file.size = fileSize;
        file.lastModified = fileInfo.lastModified().toSecsSinceEpoch();
        file.isLocal = true;
        
        allFiles.append(file);
        filesProcessedInChunk++;
        
        // 🚀 VERBESSERTE Progress updates - emittiere IMMER für GUI
        if (allFiles.size() % 50 == 0) {
            emit processActivityUpdate(
                QString("📊 %1 Dateien gefunden").arg(allFiles.size()),
                QString("Aktuell: %1").arg(fileInfo.fileName())
            );
            
            // Emittiere auch scanProgress für Fortschrittsbalken
            int progress = qMin(90, (allFiles.size() * 90) / qMax(1, allFiles.size() + 1000)); // Max 90% für Sammlung
            emit scanProgress(progress, allFiles.size(), 0);
            
            qDebug() << "[Scanner] 📊 GUI-Update:" << allFiles.size() << "Dateien, Progress:" << progress << "%";
        }
    }
    
    // Prüfe ob aktuelles Verzeichnis abgeschlossen ist
    if (currentDirIterator && !currentDirIterator->hasNext()) {
        delete currentDirIterator;
        currentDirIterator = nullptr;
        
        qDebug() << "[Scanner] ✅ Verzeichnis abgeschlossen:" << filesFoundInCurrentDir << "Dateien gefunden";
        // 🚀 Verarbeite nächstes Verzeichnis falls noch Budget übrig
        // (Die while-Schleife oben macht das automatisch)
    }
    } // 🚀 Ende der while (processedDirs < MAX_DIRS_PER_TICK) Schleife
}

void Scanner::cleanupFileCollection() {
    if (fileCollectionTimer) {
        fileCollectionTimer->stop();
    }
    
    if (currentDirIterator) {
        delete currentDirIterator;
        currentDirIterator = nullptr;
    }
    
    directoriesToProcess.clear();
}

// 🔐 PERSISTENTE SCAN-HISTORY: Verhindert mehrfaches Scannen
void Scanner::loadScanHistory() {
    QFile file(scanHistoryFile);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "[Scanner] 📜 Keine Scan-History gefunden - erstelle neue";
        return;
    }
    
    QTextStream in(&file);
    QString section;
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        
        if (line.isEmpty()) continue;
        
        if (line == "[DIRECTORIES]") {
            section = "dirs";
            continue;
        } else if (line == "[FILES]") {
            section = "files";
            continue;
        }
        
        if (section == "dirs") {
            scannedDirectoriesHistory.insert(line);
        } else if (section == "files") {
            scannedFilesHistory.insert(line);
        }
    }
    
    file.close();
    qDebug() << "[Scanner] ✅ Scan-History geladen:" << scannedDirectoriesHistory.size() 
             << "Verzeichnisse," << scannedFilesHistory.size() << "Dateien";
}

void Scanner::saveScanHistory() {
    QFile file(scanHistoryFile);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "[Scanner] ❌ Konnte Scan-History nicht speichern:" << scanHistoryFile;
        return;
    }
    
    QTextStream out(&file);
    
    // Schreibe Verzeichnisse
    out << "[DIRECTORIES]\n";
    for (const QString &dir : scannedDirectoriesHistory) {
        out << dir << "\n";
    }
    
    out << "\n[FILES]\n";
    // Schreibe nur die letzten 10000 Dateien (Speicheroptimierung)
    QStringList filesList = scannedFilesHistory.values();
    int startIdx = qMax(0, filesList.size() - 10000);
    for (int i = startIdx; i < filesList.size(); ++i) {
        out << filesList[i] << "\n";
    }
    
    file.close();
    qDebug() << "[Scanner] 💾 Scan-History gespeichert:" << scannedDirectoriesHistory.size() 
             << "Verzeichnisse," << qMin(10000, scannedFilesHistory.size()) << "Dateien";
}

void Scanner::clearScanHistory() {
    scannedDirectoriesHistory.clear();
    scannedFilesHistory.clear();
    
    QFile::remove(scanHistoryFile);
    qDebug() << "[Scanner] 🗑️ Scan-History gelöscht";
}

bool Scanner::isDirectoryInHistory(const QString &dir) const {
    QString canonical = QDir(dir).canonicalPath();
    
    // Prüfe exakte Übereinstimmung
    if (scannedDirectoriesHistory.contains(canonical)) {
        return true;
    }
    
    // Prüfe ob Elternverzeichnis bereits gescannt wurde
    for (const QString &scannedDir : scannedDirectoriesHistory) {
        if (canonical.startsWith(scannedDir + "/")) {
            qDebug() << "[Scanner] 🔍 Verzeichnis bereits in History (als Subdir von:" << scannedDir << ")";
            return true;
        }
    }
    
    return false;
}

bool Scanner::isFileInHistory(const QString &filePath) const {
    QString canonical = QFileInfo(filePath).canonicalFilePath();
    return scannedFilesHistory.contains(canonical);
}

void Scanner::addToScanHistory(const QString &path, bool isDirectory) {
    if (isDirectory) {
        QString canonical = QDir(path).canonicalPath();
        scannedDirectoriesHistory.insert(canonical);
        qDebug() << "[Scanner] 📝 Verzeichnis zur History hinzugefügt:" << canonical;
    } else {
        QString canonical = QFileInfo(path).canonicalFilePath();
        scannedFilesHistory.insert(canonical);
    }
}

// 🔐 HASH-CACHE MANAGEMENT: Persistente Hash-Speicherung für schnellere Re-Scans
void Scanner::loadHashCache() {
    QFile file(hashCacheFile);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "[Scanner] 📜 Kein Hash-Cache gefunden - erstelle neuen";
        return;
    }
    
    QTextStream in(&file);
    int loadedHashes = 0;
    int dualKeys = 0;
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty() || line.startsWith("#")) continue;
        
        // Format: hash|size|filepath
        QStringList parts = line.split("|");
        if (parts.size() >= 3) {
            QString hash = parts[0];
            qint64 size = parts[1].toLongLong();
            QString filePath = parts.mid(2).join("|"); // Falls Pfad | enthält
            
            // 🔑 Speichere mit RAW path (wie in Datei)
            hashCache[filePath] = qMakePair(hash, size);
            loadedHashes++;
            
            // 🔑 ZUSÄTZLICH: Speichere mit CANONICAL path für robuste Lookups
            QString canonical = QFileInfo(filePath).canonicalFilePath();
            if (!canonical.isEmpty() && canonical != filePath) {
                hashCache[canonical] = qMakePair(hash, size);
                dualKeys++;
            }
        }
    }
    
    file.close();
    qDebug() << "[Scanner] ✅ Hash-Cache geladen:" << loadedHashes << "Einträge (" << dualKeys << "dual keys) aus" << hashCacheFile;
}

void Scanner::saveHashCache() {
    QFile file(hashCacheFile);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "[Scanner] ❌ Konnte Hash-Cache nicht speichern:" << hashCacheFile;
        return;
    }
    
    QTextStream out(&file);
    out << "# FileDuper Hash Cache - Format: hash|size|filepath\n";
    out << "# Generated: " << QDateTime::currentDateTime().toString(Qt::ISODate) << "\n";
    
    int savedHashes = 0;
    for (auto it = hashCache.begin(); it != hashCache.end(); ++it) {
        const QString &filePath = it.key();
        const QString &hash = it.value().first;
        qint64 size = it.value().second;
        
        out << hash << "|" << size << "|" << filePath << "\n";
        savedHashes++;
    }
    
    file.close();
    qDebug() << "[Scanner] 💾 Hash-Cache gespeichert:" << savedHashes << "Einträge in" << hashCacheFile;
}

void Scanner::saveHashCacheOnlyDuplicates(const QList<DuplicateGroup> &duplicateGroups) {
    // 🔥 Erstelle Set aller Dateien die Duplikate haben (Original + Duplikate)
    QSet<QString> filesWithDuplicates;
    
    for (const DuplicateGroup &group : duplicateGroups) {
        // Original-Datei hinzufügen
        QString originalCanonical = QFileInfo(group.original.filePath).canonicalFilePath();
        if (!originalCanonical.isEmpty()) {
            filesWithDuplicates.insert(originalCanonical);
        }
        
        // Alle Duplikate hinzufügen
        for (const FileInfo &duplicate : group.duplicates) {
            QString dupCanonical = QFileInfo(duplicate.filePath).canonicalFilePath();
            if (!dupCanonical.isEmpty()) {
                filesWithDuplicates.insert(dupCanonical);
            }
        }
    }
    
    // 🗑️ Entferne alle Unikate aus dem Cache
    QStringList toRemove;
    for (auto it = hashCache.begin(); it != hashCache.end(); ++it) {
        if (!filesWithDuplicates.contains(it.key())) {
            toRemove.append(it.key());
        }
    }
    
    int removedUnikate = 0;
    for (const QString &filePath : toRemove) {
        hashCache.remove(filePath);
        removedUnikate++;
    }
    
    qDebug() << "[Scanner] 🗑️ Unikate aus Hash-Cache entfernt:" << removedUnikate;
    qDebug() << "[Scanner] 💾 Verbleibende Duplikate im Cache:" << hashCache.size();
    
    // 💾 Speichere gefilterten Cache
    saveHashCache();
    qDebug() << "[Scanner] ✅ Hash-Cache gespeichert (nur Duplikate):" << hashCache.size() << "Einträge";
}

void Scanner::updateHashCache(const QString &filePath, const QString &hash, qint64 size) {
    QString canonical = QFileInfo(filePath).canonicalFilePath();
    if (!canonical.isEmpty()) {
        hashCache[canonical] = qMakePair(hash, size);
    }
}

void Scanner::removeFromHashCache(const QString &filePath) {
    QString canonical = QFileInfo(filePath).canonicalFilePath();
    if (hashCache.remove(canonical) > 0) {
        qDebug() << "[Scanner] 🗑️ Hash-Cache-Eintrag entfernt:" << canonical;
    }
}

QString Scanner::getCachedHash(const QString &filePath, qint64 size) {
    QString canonical = QFileInfo(filePath).canonicalFilePath();
    if (hashCache.contains(canonical)) {
        auto cached = hashCache[canonical];
        // Nur verwenden wenn Größe identisch (Datei nicht geändert)
        if (cached.second == size) {
            qDebug() << "[Scanner] 🚀 Cache-HIT:" << QFileInfo(filePath).fileName() << "→" << cached.first.left(16);
            return cached.first;
        } else {
            qDebug() << "[Scanner] ⚠️ Cache-MISS (Größe geändert):" << QFileInfo(filePath).fileName();
            hashCache.remove(canonical); // Veralteter Eintrag
        }
    }
    return QString(); // Kein Cache-Hit
}

bool Scanner::isScanning() const { return scanning.load(); }
bool Scanner::isPaused() const { return paused.load(); }

void Scanner::clearAllHashes()
{
    QMutexLocker locker(&m_fileSizeGroupsMutex);
    qDebug() << "[Scanner] 🗑️ Lösche alle Hash-Indizes...";
    
    // Lösche alle Hash-Maps und Caches
    fileSizeGroups.clear();
    hashGroups.clear();
    dateSizeGroups.clear();
    
    // Lösche HashEngine Cache falls verfügbar
    if (hashEngine) {
        // HashEngine hat eigenen Cache der auch geleert werden sollte
        qDebug() << "[Scanner] 🗑️ HashEngine Cache wird geleert";
    }
    
    qDebug() << "[Scanner] ✅ Alle Hash-Indizes gelöscht";
}

// 🌐 FTP 2-PHASEN-STRATEGIE: Discovery Phase
// 🌐 FTP 2-PHASEN-STRATEGIE: Discovery Phase
void Scanner::startFtpDiscovery(const QStringList &ftpRootDirectories) {
    qDebug() << "[Scanner] 🔍 PHASE 1: Starte FTP-Discovery für" << ftpRootDirectories.size() << "Root-Verzeichnisse";
    
    // Set discovery phase flag
    ftpDiscoveryPhase = true;
    ftpDiscoveryPending = 0;
    ftpDiscoveryCompleted = 0;
    
    // Clear previous discoveries
    discoveredFtpDirectories.clear();
    pendingFtpDirectories.clear();
    processedFtpDirectories.clear();
    
    // Add all root directories to discovered set
    for (const QString &rootDir : ftpRootDirectories) {
        discoveredFtpDirectories.insert(rootDir);
        pendingFtpDirectories.insert(rootDir);
    }
    
    emit scanStatusChanged(QString("🔍 Phase 1/2: Entdecke FTP-Verzeichnisse (%1 roots)...").arg(ftpRootDirectories.size()));
    
    // Start recursive discovery for each root
    for (const QString &rootDir : ftpRootDirectories) {
        qDebug() << "[Scanner] 🌲 Discovery-Root:" << rootDir;
        discoverFtpDirectoriesRecursive(rootDir);
    }
}

void Scanner::discoverFtpDirectoriesRecursive(const QString &directory) {
    // Check if already processed
    if (processedFtpDirectories.contains(directory)) {
        qDebug() << "[Scanner] ⏭️ Discovery Skip (bereits verarbeitet):" << directory;
        checkFtpDiscoveryCompletion();
        return;
    }
    
    qDebug() << "[Scanner] 🔎 Discovery Scan:" << directory;
    processedFtpDirectories.insert(directory);
    
    // Parse FTP URL to extract host, port, and path
    QUrl url(directory);
    QString host = url.host();
    int port = url.port(21);
    QString path = url.path();
    
    // Get FTP client
    FtpClient *client = getOrCreateFtpClient(host);
    if (!client) {
        qWarning() << "[Scanner] ❌ Discovery fehlgeschlagen (kein Client):" << directory;
        checkFtpDiscoveryCompletion();
        return;
    }
    
    // Set credentials - same logic as collectFtpFiles
    if (!presetManager) {
        qWarning() << "[Scanner] ⚠️ PresetManager null - verwende Default-Credentials";
        useDefaultFtpCredentials(client, host);
    } else {
        LoginData login = presetManager->getLogin(host, port);
        if (!login.isValid()) {
            qDebug() << "[Scanner] 🔐 Keine Login-Daten für" << host << "- verwende Default";
            useDefaultFtpCredentials(client, host);
        } else {
            qDebug() << "[Scanner] 🔐 Discovery: Credentials gesetzt für" << host << "User:" << login.username;
            client->setCredentials(host, port, login.username, login.password);
        }
    }
    
    // Connect BOTH signals:
    // 1. subdirectoriesFound - for recursion
    // 2. filesListFinished - for completion tracking (always emitted!)
    
    // 🔥 TRACK client for later disconnect in Phase 2
    m_recursiveClientsConnected.insert(client);
    
    QMetaObject::Connection subdirConn = connect(client, &FtpClient::subdirectoriesFound,
        this, [this, directory, host](const QString &parentDir, const QStringList &subdirs) {
            // ⚠️ SAFETY: Nur während Discovery-Phase neue Verzeichnisse entdecken!
            if (!ftpDiscoveryPhase) {
                qDebug() << "[Scanner] ⏭️ SKIP Discovery (nicht in Discovery-Phase) für" << subdirs.size() << "subdirs";
                return;
            }
            
            qDebug() << "[Scanner] 📁 Discovery found" << subdirs.size() << "subdirs in" << parentDir;
            
            // Convert relative subdirs to full URLs
            for (const QString &subdir : subdirs) {
                QString fullUrl;
                if (subdir.startsWith("ftp://")) {
                    fullUrl = subdir;
                } else {
                    // Build full FTP URL
                    fullUrl = QString("ftp://%1%2").arg(host).arg(subdir);
                }
                
                if (!discoveredFtpDirectories.contains(fullUrl)) {
                    discoveredFtpDirectories.insert(fullUrl);
                    // ⚠️ NUR während Discovery zu pending hinzufügen!
                    // (wird später in Phase 2 aus discoveredFtpDirectories übernommen)
                    
                    qDebug() << "[Scanner] 🌿 Neu entdeckt:" << fullUrl;
                    
                    // 🚀 GUI-Update für Discovery-Fortschritt
                    emit processActivityUpdate(
                        QString("🔍 FTP-Discovery: %1 Verzeichnisse entdeckt").arg(discoveredFtpDirectories.size()),
                        QString("Gefunden: %1").arg(QFileInfo(fullUrl).fileName())
                    );
                    
                    // Recursively discover this subdirectory
                    discoverFtpDirectoriesRecursive(fullUrl);
                }
            }
        });
    
    QMetaObject::Connection finishConn = connect(client, &FtpClient::filesListFinished,
        this, [this, directory](const QString &dir, const QStringList &files, bool success) {
            Q_UNUSED(files);
            Q_UNUSED(dir);
            qDebug() << "[Scanner] ✔️ Discovery finished für:" << directory << "Success:" << success;
            
            // 🚀 GUI-Update für Discovery-Fortschritt
            emit currentFileProcessing(
                QFileInfo(directory).fileName(),
                "🔍 FTP-Discovery abgeschlossen",
                ftpDiscoveryCompleted.loadRelaxed(),
                ftpDiscoveryCompleted.loadRelaxed() + ftpDiscoveryPending
            );
            
            // Increment completed counter
            ftpDiscoveryCompleted.fetchAndAddRelaxed(1);
            
            // Check if discovery is complete
            checkFtpDiscoveryCompletion();
        });
    
    // Store connections for cleanup
    ftpDiscoveryConnections[directory] = subdirConn;
    ftpDiscoveryConnections[directory + "_finish"] = finishConn;
    
    // Increment pending counter BEFORE starting async operation
    ftpDiscoveryPending.fetchAndAddRelaxed(1);
    
    // Start listing with the PATH only (not full URL)
    qDebug() << "[Scanner] 📡 Starte listFiles für path:" << path << "Pending:" << ftpDiscoveryPending.loadRelaxed();
    client->listFiles(path);
}

void Scanner::checkFtpDiscoveryCompletion() {
    int pending = ftpDiscoveryPending.loadRelaxed();
    int completed = ftpDiscoveryCompleted.loadRelaxed();
    
    qDebug() << "[Scanner] 🔄 Discovery Check:" << completed << "/" << pending;
    
    // Check if all pending discovery requests have finished
    if (completed >= pending && pending > 0) {
        qDebug() << "[Scanner] ✅ Discovery Complete:" << discoveredFtpDirectories.size() << "total directories";
        
        // 🚀 Final Discovery GUI-Update
        emit scanProgress(40, discoveredFtpDirectories.size(), discoveredFtpDirectories.size());
        emit scanStatusChanged(QString("✅ FTP-Discovery abgeschlossen: %1 Verzeichnisse gefunden").arg(discoveredFtpDirectories.size()));
        
        // Cleanup connections
        for (auto conn : ftpDiscoveryConnections) {
            disconnect(conn);
        }
        ftpDiscoveryConnections.clear();
        
        onFtpDiscoveryCompleted();
    }
}

void Scanner::onFtpDiscoveryCompleted() {
    qDebug() << "[Scanner] 🚀 onFtpDiscoveryCompleted() called";
    
    // CRITICAL: ONLY execute once per scan - use member variable instead of static
    if (m_ftpDiscoveryCompletedFlag) {
        qDebug() << "[Scanner] ⚡ Discovery already completed - IGNORE duplicate call";
        return;
    }
    
    // CRITICAL: Verify we're still in discovery phase
    if (!ftpDiscoveryPhase) {
        qDebug() << "[Scanner] ⚠️ Discovery phase already finished - IGNORE";
        return;
    }
    
    // MARK completion IMMEDIATELY to prevent race conditions
    m_ftpDiscoveryCompletedFlag = true;
    // ⚠️ DO NOT set ftpDiscoveryPhase = false yet! Keep it true so collectFtpFiles() still works!
    
    // Get consistent counts
    int totalDirectories = discoveredFtpDirectories.size();
    int totalFiles = allFiles.size();
    qDebug() << "[Scanner] ✅ DISCOVERY COMPLETE:" << totalDirectories << "directories," << totalFiles << "files collected";
    
    // 🔥 EMERGENCY STOP: Clear all FTP operations
    if (ftpQueueDrainTimer && ftpQueueDrainTimer->isActive()) {
        ftpQueueDrainTimer->stop();
    }
    ftpQueuePerHost.clear();
    activeFtpScansPerHost.clear();
    
    // DISCONNECT all discovery clients
    for (FtpClient *client : m_recursiveClientsConnected) {
        if (client) {
            disconnect(client, nullptr, this, nullptr);
        }
    }
    m_recursiveClientsConnected.clear();
    
    // GUI Update: Show discovery results
    emit scanProgress(50, totalDirectories, totalDirectories);
    emit scanStatusChanged(QString("✅ Discovery complete: %1 directories found").arg(totalDirectories));
    emit processActivityUpdate(
        QString("📁 %1 directories discovered").arg(totalDirectories),
        QString("Now collecting files from directories...")
    );
    
    // ⚠️ DO NOT emit filesCollected in collectFtpFiles() callback!
    // We emit it HERE after ALL directories are complete
    
    // 🔥 START FILE COLLECTION FROM DISCOVERED DIRECTORIES
    if (totalFiles == 0 && totalDirectories > 0) {
        qDebug() << "[Scanner] 🚀 Discovery found" << totalDirectories << "directories but no files yet";
        qDebug() << "[Scanner] 📂 Starting file collection from discovered directories...";
        
        // 🔤 CONVERT QSet to QList and SORT alphanumerically
        QList<QString> sortedDirectories = discoveredFtpDirectories.values();
        std::sort(sortedDirectories.begin(), sortedDirectories.end(), 
                  [](const QString &a, const QString &b) {
                      return a.compare(b, Qt::CaseInsensitive) < 0;
                  });
        qDebug() << "[Scanner] 🔤 Directories sorted alphabetically";
        
        // 🔥 CRITICAL FIX: Clear completedFtpDirectories before file collection!
        // Discovery phase used this set, but file collection needs a fresh start
        qDebug() << "[Scanner] 🧹 Clearing completedFtpDirectories (" << completedFtpDirectories.size() << "entries from Discovery)";
        completedFtpDirectories.clear();
        
        // 🔥 END DISCOVERY PHASE BEFORE file collection - prevents new directories being added
        ftpDiscoveryPhase = false;
        qDebug() << "[Scanner] 🔄 PHASE 1→2: Discovery ended BEFORE file collection";
        
        // 🔥 Set expected file-listing count for completion tracking
        ftpFileListingsPending = sortedDirectories.size();
        qDebug() << "[Scanner] 📊 Expecting" << ftpFileListingsPending.loadRelaxed() << "file-listing callbacks";
        
        // Start collecting files from all discovered directories (now sorted!)
        // Use this->processedFiles (member variable), not local variable!
        for (const QString &ftpDir : sortedDirectories) {
            qDebug() << "[Scanner] 📡 Collecting files from:" << ftpDir;
            collectFtpFiles(ftpDir, this->processedFiles, false);
        }
        
        // 🔥 REMOVED: filesCollected wird ERST emittiert wenn ALLE File-Listings fertig sind!
        // Das emit erfolgt jetzt im letzten filesListFinished Callback!
        qDebug() << "[Scanner] ✅ File collection started for" << totalDirectories << "directories";
        qDebug() << "[Scanner] ⏳ Waiting for all" << ftpFileListingsPending.loadRelaxed() << "file-listing callbacks...";
    } else {
        // ✅ Files already collected during discovery - proceed to processing
        qDebug() << "[Scanner] ✅ Files already collected during discovery:" << totalFiles << "files";
        
        // 🔥 END DISCOVERY PHASE if not already ended
        if (ftpDiscoveryPhase) {
            ftpDiscoveryPhase = false;
            qDebug() << "[Scanner] 🔄 PHASE 1→2: Discovery ended (files already collected)";
        }
    }
    
    // 🚀 CRITICAL FIX: Start processing if we have files
    if (totalFiles > 0) {
        qDebug() << "[Scanner] 🚀 Starting processing of" << totalFiles << "collected files...";
        QTimer::singleShot(100, this, &Scanner::startProcessingCollectedFiles);
    }
}

void Scanner::startProcessingCollectedFiles() {
    int totalFiles = allFiles.size();
    qDebug() << "[Scanner] 🔍 Processing" << totalFiles << "collected files";
    
    // 🔤 SORT files alphanumerically by path before processing
    std::sort(allFiles.begin(), allFiles.end(), 
              [](const FileInfo &a, const FileInfo &b) {
                  return a.filePath.compare(b.filePath, Qt::CaseInsensitive) < 0;
              });
    qDebug() << "[Scanner] 🔤 Files sorted alphabetically by path";
    
    // Continue with hash calculation phase
    QTimer::singleShot(100, this, [this, totalFiles]() {
        // Start size grouping
        emit scanProgress(0, 0, totalFiles);
        emit scanStatusChanged("📏 Grouping files by size...");
        emit currentFileProcessing("Size analysis", "📏 Processing file sizes", 0, totalFiles);
        currentPhase = SIZE_FILTERING;

        // Group files by size
        fileSizeGroups.clear();
        for (const FileInfo &file : allFiles) {
            fileSizeGroups[file.size].append(file);
        }
        
        qDebug() << "[Scanner] 📊 Size groups created:" << fileSizeGroups.size() << "unique sizes";
        m_totalCollectedFiles = totalFiles;
        
        // Complete size filtering
        emit scanProgress(100, totalFiles, totalFiles);
        emit scanStatusChanged(QString("📁 %1 files analyzed by size").arg(totalFiles));
        
        // Start hash calculation
        qDebug() << "[Scanner] 🔐 Starting hash calculation";
        emit scanProgress(0, 0, totalFiles);
        emit scanStatusChanged("🔐 Calculating file hashes...");
        emit currentFileProcessing("Hash calculation", "🔐 Computing checksums", 0, totalFiles);
        
        startHashing();
    });
}

// 🚀 PARALLEL FTP DISCOVERY mit QtConcurrent - 20x schneller!
void Scanner::startParallelFtpDiscovery(const QStringList &ftpRootDirectories) {
    qDebug() << "[Scanner] 🚀 PARALLEL FTP DISCOVERY gestartet für" << ftpRootDirectories.size() << "Root-Verzeichnisse";
    qDebug() << "[Scanner] ⚡ Nutze" << maxFtpConnections << "parallele FTP-Verbindungen";
    
    // Set discovery phase flag
    ftpDiscoveryPhase = true;
    ftpDiscoveryPending = 0;
    ftpDiscoveryCompleted = 0;
    
    // Clear previous discoveries
    discoveredFtpDirectories.clear();
    pendingFtpDirectories.clear();
    processedFtpDirectories.clear();
    
    // Add all root directories to discovered set
    for (const QString &rootDir : ftpRootDirectories) {
        discoveredFtpDirectories.insert(rootDir);
        pendingFtpDirectories.insert(rootDir);
    }
    
    emit scanStatusChanged(QString("🚀 Phase 1/2: PARALLEL FTP-Discovery (%1 roots, %2 Verbindungen)...").arg(ftpRootDirectories.size()).arg(maxFtpConnections));
    
    // 🚀 BATCH-VERARBEITUNG: Teile Verzeichnisse in Batches auf
    // Jeder Batch nutzt maxFtpConnections parallele Verbindungen
    QList<QStringList> batches;
    QStringList currentBatch;
    
    for (const QString &rootDir : ftpRootDirectories) {
        currentBatch.append(rootDir);
        if (currentBatch.size() >= maxFtpConnections) {
            batches.append(currentBatch);
            currentBatch.clear();
        }
    }
    if (!currentBatch.isEmpty()) {
        batches.append(currentBatch);
    }
    
    qDebug() << "[Scanner] 📦 FTP-Discovery aufgeteilt in" << batches.size() << "Batches";
    
    // 🚀 PARALLEL: Verarbeite jeden Batch mit QtConcurrent
    for (int i = 0; i < batches.size(); ++i) {
        const QStringList &batch = batches[i];
        qDebug() << "[Scanner] 🚀 Batch" << (i+1) << "/" << batches.size() << ":" << batch.size() << "Verzeichnisse";
        
        // Start parallel processing for this batch
        processFtpDiscoveryBatch(batch);
    }
}

void Scanner::processFtpDiscoveryBatch(const QStringList &ftpBatch) {
    qDebug() << "[Scanner] ⚡ Verarbeite FTP-Batch mit" << ftpBatch.size() << "Verzeichnissen PARALLEL";
    
    // � FIX: Pre-create all FtpClients in main thread to avoid Qt parent/child thread warnings
    QMap<QString, FtpClient*> clientMap;
    for (const QString &directory : ftpBatch) {
        QUrl url(directory);
        QString host = url.host();
        int port = url.port(21);
        
        QString key = QString("%1:%2").arg(host).arg(port);
        if (!clientMap.contains(key)) {
            FtpClient *client = getFtpConnectionFromPool(host, port);
            if (client) {
                clientMap[key] = client;
                
                // Set credentials in main thread
                if (presetManager) {
                    LoginData login = presetManager->getLogin(host, port);
                    if (login.isValid()) {
                        client->setCredentials(host, port, login.username, login.password);
                    } else {
                        useDefaultFtpCredentials(client, host);
                    }
                } else {
                    useDefaultFtpCredentials(client, host);
                }
            }
        }
    }
    
    // � THREAD-SAFE: Copy clientMap for capture by value (avoid race condition!)
    QMap<QString, FtpClient*> clientMapCopy = clientMap;
    
    // 🚀 QtConcurrent::map für parallele Verarbeitung (using pre-created clients)
    auto processSingleFtpDirectory = [this, clientMapCopy](const QString &directory) {
        if (!scanning.load()) return;
        
        // Check if already processed
        {
            QMutexLocker locker(&ftpRequestsMutex);
            if (processedFtpDirectories.contains(directory)) {
                qDebug() << "[Scanner] ⏭️ Parallel Discovery Skip:" << directory;
                return;
            }
            processedFtpDirectories.insert(directory);
        }
        
        qDebug() << "[Scanner] 🔎 Parallel Discovery Scan:" << directory;
        
        // Parse FTP URL
        QUrl url(directory);
        QString host = url.host();
        int port = url.port(21);
        QString path = url.path();
        
        // Get pre-created client from map (thread-safe copy)
        QString key = QString("%1:%2").arg(host).arg(port);
        FtpClient *client = clientMapCopy.value(key, nullptr);
        
        if (!client) {
            qWarning() << "[Scanner] ❌ Parallel Discovery failed (no pre-created client):" << directory;
            ftpDiscoveryCompleted.fetchAndAddRelaxed(1);
            checkFtpDiscoveryCompletion();
            return;
        }
        
        // Check FTP cache first
        {
            QMutexLocker locker(&ftpCacheMutex);
            if (ftpListCache.contains(directory)) {
                QPair<QStringList, qint64> cached = ftpListCache[directory];
                qint64 now = QDateTime::currentMSecsSinceEpoch();
                
                if (now - cached.second < ftpCacheExpiryMs) {
                    qDebug() << "[Scanner] 💾 FTP Cache HIT:" << directory << "-" << cached.first.size() << "items";
                    
                    // Process cached subdirectories
                    for (const QString &subdir : cached.first) {
                        QString fullUrl = QString("ftp://%1%2").arg(host).arg(subdir);
                        
                        QMutexLocker reqLocker(&ftpRequestsMutex);
                        if (!discoveredFtpDirectories.contains(fullUrl)) {
                            discoveredFtpDirectories.insert(fullUrl);
                            qDebug() << "[Scanner] 🌿 Cached Subdir:" << fullUrl;
                            
                            // Recursive discovery
                            processFtpDiscoveryBatch(QStringList() << fullUrl);
                        }
                    }
                    
                    // Return connection to pool
                    returnFtpConnectionToPool(client);
                    ftpDiscoveryCompleted.fetchAndAddRelaxed(1);
                    checkFtpDiscoveryCompletion();
                    return;
                }
            }
        }
        
        // ACTUAL FTP LIST call
        ftpDiscoveryPending.fetchAndAddRelaxed(1);
        
        // Connect signals for this request
        connect(client, &FtpClient::subdirectoriesFound,
            this, [this, directory, host, client](const QString &parentDir, const QStringList &subdirs) {
                if (!ftpDiscoveryPhase) return;
                
                qDebug() << "[Scanner] 📁 Parallel Discovery found" << subdirs.size() << "subdirs in" << parentDir;
                
                // Cache result
                {
                    QMutexLocker locker(&ftpCacheMutex);
                    ftpListCache[directory] = qMakePair(subdirs, QDateTime::currentMSecsSinceEpoch());
                }
                
                // Process subdirectories
                QStringList newDirs;
                for (const QString &subdir : subdirs) {
                    QString fullUrl;
                    if (subdir.startsWith("ftp://")) {
                        fullUrl = subdir;
                    } else {
                        fullUrl = QString("ftp://%1%2").arg(host).arg(subdir);
                    }
                    
                    QMutexLocker locker(&ftpRequestsMutex);
                    if (!discoveredFtpDirectories.contains(fullUrl)) {
                        discoveredFtpDirectories.insert(fullUrl);
                        newDirs.append(fullUrl);
                        qDebug() << "[Scanner] 🌿 New parallel subdir:" << fullUrl;
                    }
                }
                
                // Start parallel processing of new subdirectories
                if (!newDirs.isEmpty()) {
                    processFtpDiscoveryBatch(newDirs);
                }
            }, Qt::QueuedConnection);
        
        connect(client, &FtpClient::filesListFinished,
            this, [this, directory, client](const QString &dir, const QStringList &files, bool success) {
                Q_UNUSED(files);
                Q_UNUSED(dir);
                qDebug() << "[Scanner] ✔️ Parallel Discovery finished:" << directory << "Success:" << success;
                
                ftpDiscoveryCompleted.fetchAndAddRelaxed(1);
                
                // Return connection to pool
                returnFtpConnectionToPool(client);
                
                checkFtpDiscoveryCompletion();
            }, Qt::QueuedConnection);
        
        // Start FTP LIST
        client->listFiles(path.isEmpty() ? "/" : path);
        
        emit currentFileProcessing(
            QFileInfo(directory).fileName(),
            "🚀 Parallel FTP-Discovery",
            ftpDiscoveryCompleted.loadRelaxed(),
            ftpDiscoveryPending.loadRelaxed()
        );
    }; // End of processSingleFtpDirectory lambda
    
    // 🚀 ASYNC: Run parallel discovery WITHOUT blocking GUI thread
    // Use mapped() instead of blockingMap() to keep GUI responsive
    QFuture<void> future = QtConcurrent::map(ftpBatch, processSingleFtpDirectory);
    
    // 🎯 Create watcher and store it to prevent premature destruction
    QFutureWatcher<void> *watcher = new QFutureWatcher<void>(this);
    
    // 🔒 CRITICAL: Store watcher to keep future alive
    {
        QMutexLocker lock(&ftpWatchersMutex);
        activeFtpDiscoveryWatchers.append(watcher);
    }
    
    // Connect completion handler
    connect(watcher, &QFutureWatcher<void>::finished, this, [this, watcher]() {
        qDebug() << "🏁 FTP discovery batch completed";
        
        // Remove watcher from active list and delete it
        {
            QMutexLocker lock(&ftpWatchersMutex);
            activeFtpDiscoveryWatchers.removeOne(watcher);
        }
        
        watcher->deleteLater();
    });
    
    watcher->setFuture(future);
    
    // ⚠️ DO NOT call future.waitForFinished() - that would block!
    // Discovery completion is handled via checkFtpDiscoveryCompletion() callbacks
    qDebug() << "[Scanner] 🚀 Async FTP Discovery started for" << ftpBatch.size() << "directories (non-blocking)";
} // End of processFtpDiscoveryBatch function

// 🔄 FTP CONNECTION POOL: Get connection from pool or create new
FtpClient* Scanner::getFtpConnectionFromPool(const QString &host, int port) {
    QMutexLocker locker(&ftpConnectionPoolMutex);
    
    // Check if we can create a new connection
    if (activeFtpConnections >= maxFtpConnections) {
        // 🚀 NON-BLOCKING: Return nullptr immediately instead of waiting
        // Worker threads will retry or use existing connections
        qDebug() << "[Scanner] ⏸️ FTP Connection Pool full (" << activeFtpConnections << "/" << maxFtpConnections << ") - will retry";
        return nullptr;
    }
    
    // 🚀 Simplified: Always create new connection (pool manages reuse via returnToPool)
    FtpClient *newClient = getOrCreateFtpClient(host, port);
    if (newClient) {
        ftpConnectionPool.append(newClient);
        activeFtpConnections++;
        qDebug() << "[Scanner] ➕ Created FTP connection from pool (" << activeFtpConnections << "/" << maxFtpConnections << ")";
    }
    
    return newClient;
}

void Scanner::returnFtpConnectionToPool(FtpClient* client) {
    if (!client) return;
    
    QMutexLocker locker(&ftpConnectionPoolMutex);
    
    // Disconnect all signals
    disconnect(client, nullptr, this, nullptr);
    
    // Mark as available
    if (activeFtpConnections > 0) {
        activeFtpConnections--;
    }
    
    qDebug() << "[Scanner] 🔄 Returned FTP connection to pool (" << activeFtpConnections << "/" << maxFtpConnections << ")";
}

void Scanner::clearFtpConnectionPool() {
    QMutexLocker locker(&ftpConnectionPoolMutex);
    
    qDebug() << "[Scanner] 🧹 Clearing FTP connection pool (" << ftpConnectionPool.size() << "connections)";
    
    for (FtpClient *client : ftpConnectionPool) {
        if (client) {
            disconnect(client, nullptr, this, nullptr);
            // Don't delete - they're managed by Qt parent hierarchy
        }
    }
    
    ftpConnectionPool.clear();
    activeFtpConnections = 0;
    
    // Clear cache
    ftpListCache.clear();
}

void Scanner::scanFtpDirectoryForFiles(const QString &ftpDirectory) {
    qDebug() << "[Scanner] 🔍 Scanning FTP directory for files:" << ftpDirectory;
    
    // Use the existing collectFtpFiles mechanism instead of creating new FtpClient
    // This ensures proper async handling and file collection
    QSet<QString> processedFiles;
    collectFtpFiles(ftpDirectory, processedFiles, false);
}

void Scanner::startFtpScan() {
    qDebug() << "[Scanner] � FTP scan handled by normal scan flow";
}

// 🧠 LEVENSHTEIN-DISTANZ: Berechnet String-Ähnlichkeit für Fuzzy-Matching
int Scanner::calculateLevenshtein(const QString &s1, const QString &s2) const {
    const int len1 = s1.length();
    const int len2 = s2.length();
    
    // Optimierung: Leere Strings
    if (len1 == 0) return len2;
    if (len2 == 0) return len1;
    
    // Optimierung: Identische Strings
    if (s1 == s2) return 0;
    
    // Dynamische Programmierung: 2-Zeilen-Matrix (Speicher-Optimierung)
    QVector<int> prevRow(len2 + 1);
    QVector<int> currRow(len2 + 1);
    
    // Initialisierung
    for (int j = 0; j <= len2; ++j) {
        prevRow[j] = j;
    }
    
    // Berechnung
    for (int i = 1; i <= len1; ++i) {
        currRow[0] = i;
        
        for (int j = 1; j <= len2; ++j) {
            int cost = (s1[i - 1] == s2[j - 1]) ? 0 : 1;
            
            int deletion = prevRow[j] + 1;
            int insertion = currRow[j - 1] + 1;
            int substitution = prevRow[j - 1] + cost;
            
            currRow[j] = qMin(qMin(deletion, insertion), substitution);
        }
        
        // Swap rows
        prevRow = currRow;
    }
    
    return currRow[len2];
}

// ⚡ HARDWARE-OPTIMIERUNG: Intelligente Zuweisung nach Dateityp
Scanner::ProcessingUnit Scanner::selectOptimalHardware(const FileInfo &file) const {
    QString ext = QFileInfo(file.fileName).suffix().toLower();
    
    // 🧠 NPU: Bilder für KI-basierte Ähnlichkeitserkennung
    static QSet<QString> npuTypes = {"jpg", "jpeg", "png", "gif", "bmp", "webp", "tiff", "tif"};
    if (npuEnabled && hardwareCaps.hasNPU && npuTypes.contains(ext)) {
        return USE_NPU;
    }
    
    // 🎮 GPU: Videos und große Bilder (schnelles Hashing)
    static QSet<QString> gpuTypes = {"mp4", "avi", "mkv", "mov", "wmv", "flv", "webm", "m4v", 
                                      "mpg", "mpeg", "3gp", "f4v", "psd", "ai", "raw", "cr2", "nef"};
    if (hardwareCaps.hasGPU && gpuTypes.contains(ext)) {
        return USE_GPU;
    }
    
    // 💻 CPU: Dokumente, Text, Archives, Code
    // (alle anderen Dateien oder wenn keine GPU/NPU verfügbar)
    return USE_CPU;
}

// ❌ REMOVED: filterByEarlyExit() - caused false "unique" for videos
// ❌ REMOVED: selectOptimalHashAlgorithm() - not used, we always use MD5

// 📁 PARENT/CHILD DIRECTORY ANALYSIS: Extrahiert Top-Level-Scan-Verzeichnis

// 📁 PARENT/CHILD DIRECTORY ANALYSIS: Extrahiert Top-Level-Scan-Verzeichnis
QString Scanner::extractTopLevelDirectory(const QString &filePath) const
{
                                             // Für Netzwerk-Pfade (FTP/SFTP/SMB/NFS)
    if (filePath.startsWith("ftp://") || filePath.startsWith("sftp://") || 
        filePath.startsWith("smb://") || filePath.startsWith("nfs://")) {
        QUrl url(filePath);
        QString path = url.path();
        QStringList parts = path.split('/', Qt::SkipEmptyParts);
        if (parts.isEmpty()) return "/";
        return "/" + parts.first(); // Erste Ebene nach Protokoll
    }
    
    // Für lokale Pfade: Finde oberstes Verzeichnis in scanDirectories
    QFileInfo fileInfo(filePath);
    QString absPath = fileInfo.absolutePath();
    
    // Suche in scanDirectories nach dem besten Match
    QString bestMatch;
    int bestMatchLength = 0;
    
    for (const QString &scanDir : scanDirectories) {
        QString normalizedScanDir = QDir(scanDir).absolutePath();
        if (absPath.startsWith(normalizedScanDir)) {
            if (normalizedScanDir.length() > bestMatchLength) {
                bestMatch = normalizedScanDir;
                bestMatchLength = normalizedScanDir.length();
            }
        }
    }
    
    return bestMatch.isEmpty() ? absPath : bestMatch;
}

// 📁 Prüft ob zwei Verzeichnisse in Parent/Child-Beziehung stehen
bool Scanner::isParentChildRelation(const QString &dir1, const QString &dir2) const
{
    QString normalized1 = QDir(dir1).absolutePath();
    QString normalized2 = QDir(dir2).absolutePath();
    
    // Prüfe beide Richtungen
    return normalized1.startsWith(normalized2 + "/") || normalized2.startsWith(normalized1 + "/");
}
