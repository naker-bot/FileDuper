#include <iostream>
#include "sftpclient.h"
#include <QDebug>
#include <QFileInfo>
#include <QDir>
#include <QRegularExpression>

SftpClient::SftpClient(QObject *parent)
    : QObject(parent), port(22), isConnectedFlag(false), currentDirectory("/")
{
    sftpProcess = new QProcess(this);
    connectionTimer = new QTimer(this);
    connectionTimer->setSingleShot(true);
    connectionTimer->setInterval(30000); // 30s timeout

    connect(sftpProcess, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &SftpClient::onSftpProcessFinished);
    connect(sftpProcess, &QProcess::errorOccurred, this, &SftpClient::onSftpProcessError);
    connect(connectionTimer, &QTimer::timeout, [this]()
            { emit errorOccurred("SFTP connection timeout"); });
}

SftpClient::~SftpClient()
{
    disconnectFromHost();
}

void SftpClient::setCredentials(const QString &host, int portNum, const QString &user, const QString &pass)
{
    hostname = host;
    port = portNum;
    username = user;
    password = pass;

    std::cout << "[SftpClient] 🔐 Credentials set for " << host.toUtf8().constData()
              << ":" << port << " user: " << user.toUtf8().constData() << std::endl;
}

void SftpClient::connectToHost()
{
    if (isConnectedFlag)
    {
        std::cout << "[SftpClient] ⚠️ Already connected" << std::endl;
        return;
    }

    std::cout << "[SftpClient] 🔗 Connecting to " << hostname.toUtf8().constData()
              << ":" << port << " via SFTP..." << std::endl;

    // Use sshpass for password authentication if available
    QString program;
    QStringList arguments;

    if (!password.isEmpty())
    {
        program = "sshpass";
        arguments << "-p" << password
                  << "sftp"
                  << "-o" << "StrictHostKeyChecking=no"
                  << "-o" << "UserKnownHostsFile=/dev/null"
                  << "-P" << QString::number(port)
                  << QString("%1@%2").arg(username, hostname);
    }
    else
    {
        program = "sftp";
        arguments << "-o" << "StrictHostKeyChecking=no"
                  << "-o" << "UserKnownHostsFile=/dev/null"
                  << "-P" << QString::number(port)
                  << QString("%1@%2").arg(username, hostname);
    }

    connectionTimer->start();
    sftpProcess->start(program, arguments);

    if (!sftpProcess->waitForStarted(5000))
    {
        emit errorOccurred("Failed to start SFTP process");
        return;
    }

    // Send initial ls command to test connection
    sftpProcess->write("ls -la\n");
    sftpProcess->write("pwd\n");
}

void SftpClient::disconnectFromHost()
{
    if (isConnectedFlag && sftpProcess->state() == QProcess::Running)
    {
        std::cout << "[SftpClient] 📴 Disconnecting from " << hostname.toUtf8().constData() << std::endl;
        sftpProcess->write("quit\n");
        sftpProcess->waitForFinished(3000);
        sftpProcess->kill();
    }
    isConnectedFlag = false;
    connectionTimer->stop();
    emit disconnected();
}

bool SftpClient::isConnected() const
{
    return isConnectedFlag && sftpProcess->state() == QProcess::Running;
}

void SftpClient::listDirectory(const QString &path)
{
    if (!isConnected())
    {
        emit errorOccurred("Not connected to SFTP server");
        return;
    }

    QString targetPath = path.isEmpty() ? currentDirectory : path;
    std::cout << "[SftpClient] 📁 Listing directory: " << targetPath.toUtf8().constData() << std::endl;

    executeSftpCommand(QString("ls -la %1").arg(targetPath));
}

QString SftpClient::getCurrentDirectory() const
{
    return currentDirectory;
}

QList<SftpFileInfo> SftpClient::getCurrentDirectoryListing() const
{
    return currentListing;
}

void SftpClient::downloadFile(const QString &remotePath, const QString &localPath)
{
    if (!isConnected())
    {
        emit errorOccurred("Not connected to SFTP server");
        return;
    }

    std::cout << "[SftpClient] ⬇️ Downloading " << remotePath.toUtf8().constData()
              << " to " << localPath.toUtf8().constData() << std::endl;

    executeSftpCommand(QString("get %1 %2").arg(remotePath, localPath));
}

void SftpClient::uploadFile(const QString &localPath, const QString &remotePath)
{
    if (!isConnected())
    {
        emit errorOccurred("Not connected to SFTP server");
        return;
    }

    std::cout << "[SftpClient] ⬆️ Uploading " << localPath.toUtf8().constData()
              << " to " << remotePath.toUtf8().constData() << std::endl;

    executeSftpCommand(QString("put %1 %2").arg(localPath, remotePath));
}

void SftpClient::deleteFile(const QString &filePath)
{
    if (!isConnected())
    {
        emit errorOccurred("Not connected to SFTP server");
        return;
    }

    std::cout << "[SftpClient] 🗑️ Deleting " << filePath.toUtf8().constData() << std::endl;
    executeSftpCommand(QString("rm %1").arg(filePath));
}

void SftpClient::createDirectory(const QString &path)
{
    if (!isConnected())
    {
        emit errorOccurred("Not connected to SFTP server");
        return;
    }

    std::cout << "[SftpClient] 📁 Creating directory " << path.toUtf8().constData() << std::endl;
    executeSftpCommand(QString("mkdir %1").arg(path));
}

void SftpClient::executeSftpCommand(const QString &command)
{
    if (sftpProcess->state() == QProcess::Running)
    {
        std::cout << "[SftpClient] 💻 Executing: " << command.toUtf8().constData() << std::endl;
        sftpProcess->write((command + "\n").toUtf8());
    }
}

void SftpClient::onSftpProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    std::cout << "[SftpClient] 🏁 Process finished with code " << exitCode << std::endl;

    QString output = sftpProcess->readAllStandardOutput();
    QString errorOutput = sftpProcess->readAllStandardError();

    if (!output.isEmpty())
    {
        std::cout << "[SftpClient] 📄 Output: " << output.toUtf8().constData() << std::endl;

        if (output.contains("sftp>") || output.contains("Connected to"))
        {
            if (!isConnectedFlag)
            {
                isConnectedFlag = true;
                connectionTimer->stop();
                std::cout << "[SftpClient] ✅ SFTP connection established" << std::endl;
                emit connected();
            }
        }

        // Parse directory listing if present
        if (output.contains("-rw") || output.contains("drw"))
        {
            parseDirectoryListing(output);
        }
    }

    if (!errorOutput.isEmpty())
    {
        std::cout << "[SftpClient] ❌ Error: " << errorOutput.toUtf8().constData() << std::endl;
        emit errorOccurred(errorOutput);
    }
}

void SftpClient::onSftpProcessError(QProcess::ProcessError error)
{
    QString errorString;
    switch (error)
    {
    case QProcess::FailedToStart:
        errorString = "SFTP process failed to start (sshpass/sftp not installed?)";
        break;
    case QProcess::Crashed:
        errorString = "SFTP process crashed";
        break;
    case QProcess::Timedout:
        errorString = "SFTP process timeout";
        break;
    default:
        errorString = "Unknown SFTP process error";
    }

    std::cout << "[SftpClient] ❌ Process error: " << errorString.toUtf8().constData() << std::endl;
    isConnectedFlag = false;
    emit errorOccurred(errorString);
}

void SftpClient::parseDirectoryListing(const QString &output)
{
    currentListing.clear();
    QStringList lines = output.split('\n', Qt::SkipEmptyParts);

    for (const QString &line : lines)
    {
        if (line.startsWith("drw") || line.startsWith("-rw") || line.startsWith("lrw"))
        {
            SftpFileInfo info = parseListingLine(line);
            if (!info.name.isEmpty() && info.name != "." && info.name != "..")
            {
                currentListing.append(info);
            }
        }
    }

    std::cout << "[SftpClient] 📊 Parsed " << currentListing.size() << " entries" << std::endl;
    emit directoryListingReceived(currentListing);
}

SftpFileInfo SftpClient::parseListingLine(const QString &line)
{
    SftpFileInfo info;

    // Parse Unix-style ls -la output: drwxr-xr-x 2 user group 4096 Jan 15 10:30 dirname
    QRegularExpression re(R"(^([d\-lrwx]+)\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\w+\s+\d+\s+[\d:]+)\s+(.+)$)");
    QRegularExpressionMatch match = re.match(line);

    if (match.hasMatch())
    {
        info.permissions = match.captured(1);
        info.size = match.captured(2).toLongLong();
        info.name = match.captured(4);
        info.isDirectory = info.permissions.startsWith('d');
        info.path = currentDirectory + "/" + info.name;

        // ✅ ECHTE DATUM-PARSING für SSH ls -la Format
        QString dateStr = match.captured(3);
        
        // Parse verschiedene Datumsformate: "Jul 13 10:30" oder "Jul 13  2024"
        QStringList dateParts = dateStr.split(' ', Qt::SkipEmptyParts);
        if (dateParts.size() >= 3) {
            QString month = dateParts[0];
            int day = dateParts[1].toInt();
            
            QDateTime dateTime;
            if (dateParts[2].contains(':')) {
                // Aktuelles Jahr mit Zeit: "Jul 13 10:30"
                dateTime = QDateTime::currentDateTime();
                dateTime = dateTime.addDays(-(dateTime.date().day() - day));
                
                QTime time = QTime::fromString(dateParts[2], "hh:mm");
                if (time.isValid()) {
                    dateTime.setTime(time);
                }
            } else {
                // Spezifisches Jahr: "Jul 13  2024"
                int year = dateParts[2].toInt();
                
                QMap<QString, int> monthMap = {
                    {"Jan", 1}, {"Feb", 2}, {"Mar", 3}, {"Apr", 4}, {"May", 5}, {"Jun", 6},
                    {"Jul", 7}, {"Aug", 8}, {"Sep", 9}, {"Oct", 10}, {"Nov", 11}, {"Dec", 12}
                };
                
                if (monthMap.contains(month)) {
                    dateTime = QDateTime(QDate(year, monthMap[month], day), QTime(0, 0));
                }
            }
            
            if (dateTime.isValid()) {
                info.lastModified = dateTime;
            } else {
                info.lastModified = QDateTime::currentDateTime();
            }
        } else {
            info.lastModified = QDateTime::currentDateTime();
        }
    }

    return info;
}
