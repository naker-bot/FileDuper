#include "networkdirectorydialog.h"
#include <QMessageBox>
#include <QApplication>
#include <QHeaderView>
#include <QScrollBar>
#include <QSplitter>
#include <QGroupBox>
#include <QDebug>

NetworkDirectoryDialog::NetworkDirectoryDialog(const QString &serverInfo, QWidget *parent)
    : QDialog(parent), m_serverInfo(serverInfo), m_updatingCheckStates(false)
{
    setWindowTitle(QString("📡 Netzwerk-Verzeichnisse: %1").arg(serverInfo));
    setModal(true);
    resize(800, 600);
    setupUI();
}

void NetworkDirectoryDialog::setupUI()
{
    // Main layout
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    
    // Header info
    QLabel *headerLabel = new QLabel(QString("🌐 Server: <b>%1</b><br><small>✅ Unterstützt: FTP, SFTP, SMB/CIFS, NFS</small>").arg(m_serverInfo));
    headerLabel->setStyleSheet("QLabel { font-size: 14px; color: #2563eb; margin: 8px; }");
    mainLayout->addWidget(headerLabel);
    
    // Status label
    m_statusLabel = new QLabel("🔄 Lade Verzeichnisse...");
    m_statusLabel->setStyleSheet("QLabel { color: #059669; margin: 4px 8px; }");
    mainLayout->addWidget(m_statusLabel);
    
    // Loading progress
    m_loadingProgress = new QProgressBar();
    m_loadingProgress->setRange(0, 0); // Indeterminate progress
    m_loadingProgress->setVisible(true);
    mainLayout->addWidget(m_loadingProgress);
    
    // Directory tree with darker background
    QGroupBox *treeGroup = new QGroupBox("📂 Verfügbare Verzeichnisse (Mehrfachauswahl)");
    treeGroup->setStyleSheet(R"(
        QGroupBox {
            font-weight: bold;
            border: 2px solid #d1d5db;
            border-radius: 8px;
            margin-top: 8px;
            padding-top: 8px;
            background-color: #f8fafc;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 12px;
            padding: 0 8px 0 8px;
            color: #374151;
        }
    )");
    
    QVBoxLayout *treeLayout = new QVBoxLayout(treeGroup);
    
    m_directoryTree = new QTreeWidget();
    m_directoryTree->setHeaderLabel("Verzeichnis");
    m_directoryTree->setRootIsDecorated(true);
    m_directoryTree->setAlternatingRowColors(true);
    m_directoryTree->setSelectionMode(QAbstractItemView::ExtendedSelection);
    
    // DARKER BACKGROUND for directory tree
    m_directoryTree->setStyleSheet(R"(
        QTreeWidget {
            background-color: #1f2937;
            color: #f9fafb;
            border: 1px solid #4b5563;
            border-radius: 6px;
            font-family: 'Segoe UI', Arial, sans-serif;
            font-size: 13px;
            alternate-background-color: #374151;
        }
        QTreeWidget::item {
            padding: 6px;
            border-bottom: 1px solid #374151;
        }
        QTreeWidget::item:hover {
            background-color: #4f46e5;
            color: white;
        }
        QTreeWidget::item:selected {
            background-color: #3b82f6;
            color: white;
        }
        QTreeWidget::branch:has-children:!has-siblings:closed,
        QTreeWidget::branch:closed:has-children:has-siblings {
            border-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAABHNCSVQI...) 0;
        }
        QTreeWidget::branch:open:has-children:!has-siblings,
        QTreeWidget::branch:open:has-children:has-siblings {
            border-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAABHNCSVQI...) 0;
        }
        QHeaderView::section {
            background-color: #374151;
            color: #f9fafb;
            border: 1px solid #4b5563;
            padding: 8px;
            font-weight: bold;
        }
    )");
    
    treeLayout->addWidget(m_directoryTree);
    mainLayout->addWidget(treeGroup);
    
    // Tree control buttons
    QHBoxLayout *treeControlLayout = new QHBoxLayout();
    
    m_selectAllBtn = new QPushButton("✅ Alle auswählen");
    m_selectAllBtn->setStyleSheet("QPushButton { background-color: #10b981; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; }");
    
    m_selectNoneBtn = new QPushButton("❌ Auswahl aufheben");
    m_selectNoneBtn->setStyleSheet("QPushButton { background-color: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; }");
    
    m_expandAllBtn = new QPushButton("🌳 Alle erweitern");
    m_expandAllBtn->setStyleSheet("QPushButton { background-color: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; }");
    
    m_collapseAllBtn = new QPushButton("📁 Alle zuklappen");
    m_collapseAllBtn->setStyleSheet("QPushButton { background-color: #6b7280; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; }");
    
    treeControlLayout->addWidget(m_selectAllBtn);
    treeControlLayout->addWidget(m_selectNoneBtn);
    treeControlLayout->addStretch();
    treeControlLayout->addWidget(m_expandAllBtn);
    treeControlLayout->addWidget(m_collapseAllBtn);
    
    mainLayout->addLayout(treeControlLayout);
    
    // Selection count
    m_selectionCountLabel = new QLabel("0 Verzeichnisse ausgewählt");
    m_selectionCountLabel->setStyleSheet("QLabel { font-weight: bold; color: #3b82f6; margin: 8px; }");
    mainLayout->addWidget(m_selectionCountLabel);
    
    // Dialog buttons
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    
    m_okBtn = new QPushButton("✅ Ausgewählte hinzufügen");
    m_okBtn->setStyleSheet("QPushButton { background-color: #059669; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; font-size: 14px; }");
    m_okBtn->setDefault(true);
    m_okBtn->setEnabled(false); // Initially disabled
    
    m_cancelBtn = new QPushButton("❌ Abbrechen");
    m_cancelBtn->setStyleSheet("QPushButton { background-color: #dc2626; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; font-size: 14px; }");
    
    buttonLayout->addStretch();
    buttonLayout->addWidget(m_cancelBtn);
    buttonLayout->addWidget(m_okBtn);
    
    mainLayout->addLayout(buttonLayout);
    
    // Connect signals
    connect(m_directoryTree, &QTreeWidget::itemChanged, this, &NetworkDirectoryDialog::onItemChanged);
    connect(m_directoryTree, &QTreeWidget::itemClicked, this, &NetworkDirectoryDialog::onItemClicked);
    connect(m_selectAllBtn, &QPushButton::clicked, this, &NetworkDirectoryDialog::onSelectAll);
    connect(m_selectNoneBtn, &QPushButton::clicked, this, &NetworkDirectoryDialog::onSelectNone);
    connect(m_expandAllBtn, &QPushButton::clicked, this, &NetworkDirectoryDialog::onExpandAll);
    connect(m_collapseAllBtn, &QPushButton::clicked, this, &NetworkDirectoryDialog::onCollapseAll);
    
    connect(m_okBtn, &QPushButton::clicked, this, &QDialog::accept);
    connect(m_cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
}

void NetworkDirectoryDialog::addDirectories(const QStringList &directories)
{
    qDebug() << "[NetworkDirectoryDialog] 🔄 Füge" << directories.size() << "Verzeichnisse hinzu";
    
    // Hide loading progress
    m_loadingProgress->setVisible(false);
    m_statusLabel->setText(QString("✅ %1 Verzeichnisse geladen").arg(directories.size()));
    
    // Populate tree
    populateDirectoryTree(directories);
    
    // Update selection count
    updateSelectionCount();
}

void NetworkDirectoryDialog::populateDirectoryTree(const QStringList &directories)
{
    m_directoryTree->clear();
    
    // Build hierarchical structure
    buildDirectoryHierarchy(directories);
    
    // Expand first level (Server root) by default
    m_directoryTree->expandToDepth(0);
    
    // SICHTBARKEITS-FIX: Erweitere auch Gruppenelemente
    for (int i = 0; i < m_directoryTree->topLevelItemCount(); ++i) {
        QTreeWidgetItem *serverItem = m_directoryTree->topLevelItem(i);
        if (serverItem) {
            serverItem->setExpanded(true);
            // Erweitere auch die erste Gruppe (z.B. "S-Laufwerke")
            for (int j = 0; j < serverItem->childCount(); ++j) {
                QTreeWidgetItem *groupItem = serverItem->child(j);
                if (groupItem && groupItem->text(0).contains("Laufwerke")) {
                    groupItem->setExpanded(true);
                    qDebug() << "[NetworkDirectoryDialog] 🔄 Auto-Erweiterung:" << groupItem->text(0);
                }
            }
        }
    }
    
    // Connect item expansion signal for lazy loading
    connect(m_directoryTree, &QTreeWidget::itemExpanded, this, [this](QTreeWidgetItem *item) {
        // Lazy Loading für Unterverzeichnisse implementieren
        qDebug() << "[NetworkDirectoryDialog] 🔄 Item erweitert:" << item->text(0);
        
        // Prüfe ob das Item einen Platzhalter hat und echte Unterverzeichnisse laden muss
        bool hasPlaceholder = false;
        for (int i = 0; i < item->childCount(); ++i) {
            QTreeWidgetItem *child = item->child(i);
            if (child->isHidden() || child->data(0, Qt::UserRole).toString() == "PLACEHOLDER") {
                hasPlaceholder = true;
                break;
            }
        }
        
        if (hasPlaceholder) {
            // Das Item hat einen Platzhalter - lade echte Unterverzeichnisse
            QString itemPath = item->data(0, Qt::UserRole).toString();
            if (itemPath.isEmpty()) {
                // Fallback: Extrahiere Pfad aus Text für Gruppenelement
                QString itemText = item->text(0);
                if (itemText.contains("S-Laufwerke")) {
                    qDebug() << "[NetworkDirectoryDialog] 📂 Gruppenexpansion - kein direktes Laden erforderlich";
                    return; // Gruppenelement braucht kein Lazy Loading
                }
            }
            
            if (!itemPath.isEmpty()) {
                qDebug() << "[NetworkDirectoryDialog] 🚀 Starte Lazy Loading für Pfad:" << itemPath;
                loadSubdirectories(item, itemPath);
                
                // Sende Signal für echte FTP-LIST-Anfrage
                emit requestFtpSubdirectories(itemPath);
            } else {
                qDebug() << "[NetworkDirectoryDialog] ⚠️ Kein Pfad für Lazy Loading gefunden in:" << item->text(0);
            }
        } else {
            qDebug() << "[NetworkDirectoryDialog] ✅ Item bereits vollständig geladen:" << item->text(0);
        }
    });
    
    qDebug() << "[NetworkDirectoryDialog] 🌳 Hierarchische Verzeichnisstruktur mit" << directories.size() << "Elementen erstellt";
}

void NetworkDirectoryDialog::buildDirectoryHierarchy(const QStringList &directories)
{
    // ⛔ BLOCKIERE CHECKBOX-EVENTS WÄHREND INITIALISIERUNG
    m_directoryTree->blockSignals(true);
    
    // Erstelle Root-Server-Element
    QTreeWidgetItem *serverRoot = new QTreeWidgetItem();
    serverRoot->setText(0, QString("🌐 %1").arg(m_serverInfo));
    serverRoot->setFlags(serverRoot->flags() | Qt::ItemIsUserCheckable);
    serverRoot->setCheckState(0, Qt::Unchecked); // ✅ EXPLIZIT DEAKTIVIERT
    serverRoot->setIcon(0, QIcon(":/icons/server.png"));
    serverRoot->setExpanded(true);
    m_directoryTree->addTopLevelItem(serverRoot);
    
    // Gruppiere Verzeichnisse nach ersten Buchstaben für bessere Übersicht
    QMap<QString, QStringList> groupedDirs;
    
    for (const QString &dir : directories) {
        if (dir.isEmpty() || dir == "/") continue;
        
        QString cleanPath = dir;
        if (cleanPath.startsWith("/")) cleanPath = cleanPath.mid(1);
        if (cleanPath.endsWith("/")) cleanPath.chop(1);
        
        if (!cleanPath.isEmpty()) {
            QString firstChar = cleanPath.left(1).toUpper();
            groupedDirs[firstChar].append(cleanPath);
        }
    }
    
    // Erstelle hierarchische Struktur mit Gruppierung
    for (auto it = groupedDirs.begin(); it != groupedDirs.end(); ++it) {
        QString group = it.key();
        QStringList groupDirs = it.value();
        
        if (groupDirs.size() == 1) {
            // Einzelnes Verzeichnis direkt unter Server
            QTreeWidgetItem *dirItem = new QTreeWidgetItem(serverRoot);
            dirItem->setText(0, QString("📁 %1").arg(groupDirs.first()));
            dirItem->setFlags(dirItem->flags() | Qt::ItemIsUserCheckable);
            dirItem->setCheckState(0, Qt::Unchecked);
            dirItem->setData(0, Qt::UserRole, QString("/%1/").arg(groupDirs.first()));
            dirItem->setToolTip(0, QString("Pfad: /%1/").arg(groupDirs.first()));
            
            // Füge Platzhalter für echte FTP-Unterverzeichnisse hinzu
            addLazyLoadingPlaceholder(dirItem);
            
        } else {
            // Mehrere Verzeichnisse - erstelle Gruppierung
            QTreeWidgetItem *groupItem = new QTreeWidgetItem(serverRoot);
            groupItem->setText(0, QString("📂 %1-Laufwerke (%2)").arg(group).arg(groupDirs.size()));
            groupItem->setFlags(groupItem->flags() | Qt::ItemIsUserCheckable);
            groupItem->setCheckState(0, Qt::Unchecked);
            groupItem->setExpanded(false); // Nicht automatisch erweitern
            
            for (const QString &dirName : groupDirs) {
                QTreeWidgetItem *dirItem = new QTreeWidgetItem(groupItem);
                dirItem->setText(0, QString("� %1").arg(dirName));
                dirItem->setFlags(dirItem->flags() | Qt::ItemIsUserCheckable);
                dirItem->setCheckState(0, Qt::Unchecked);
                dirItem->setData(0, Qt::UserRole, QString("/%1/").arg(dirName));
                dirItem->setToolTip(0, QString("Pfad: /%1/").arg(dirName));
                
                // Füge Platzhalter für echte FTP-Unterverzeichnisse hinzu
                addLazyLoadingPlaceholder(dirItem);
            }
        }
    }
    
    // ✅ SIGNALE WIEDER AKTIVIEREN nach vollständiger Initialisierung
    m_directoryTree->blockSignals(false);
    
    qDebug() << "[NetworkDirectoryDialog] 🌳 Hierarchische Struktur erstellt mit" << groupedDirs.size() << "Gruppen - ALLE CHECKBOXEN EXPLIZIT DEAKTIVIERT";
}

QTreeWidgetItem* NetworkDirectoryDialog::findOrCreateTreePath(const QString &path)
{
    QStringList pathParts = path.split('/', Qt::SkipEmptyParts);
    if (pathParts.isEmpty()) return nullptr;
    
    QTreeWidgetItem *current = nullptr;
    QTreeWidgetItem *parent = nullptr;
    
    // Traverse or create path hierarchy
    for (int i = 0; i < pathParts.size(); ++i) {
        const QString &part = pathParts[i];
        bool found = false;
        
        // Search in current level
        int childCount = parent ? parent->childCount() : m_directoryTree->topLevelItemCount();
        for (int j = 0; j < childCount; ++j) {
            QTreeWidgetItem *child = parent ? parent->child(j) : m_directoryTree->topLevelItem(j);
            if (child && child->text(0).contains(part)) {
                current = child;
                found = true;
                break;
            }
        }
        
        // Create if not found
        if (!found) {
            current = new QTreeWidgetItem();
            current->setText(0, QString("📁 %1").arg(part));
            
            if (parent) {
                parent->addChild(current);
            } else {
                m_directoryTree->addTopLevelItem(current);
            }
        }
        
        parent = current;
    }
    
    return current;
}

void NetworkDirectoryDialog::onItemChanged(QTreeWidgetItem *item, int column)
{
    if (column != 0 || !item) return;
    
    Qt::CheckState state = item->checkState(0);
    
    // Update all children
    updateChildCheckStates(item, state);
    
    // Update parent state
    updateParentCheckState(item);
    
    // Update selection count
    updateSelectionCount();
}

void NetworkDirectoryDialog::onItemClicked(QTreeWidgetItem *item, int column)
{
    // ✅ Ein-Klick Checkbox Toggle für bessere UX
    if (column == 0 && item && !m_updatingCheckStates) {
        Qt::CheckState currentState = item->checkState(0);
        Qt::CheckState newState = (currentState == Qt::Checked) ? Qt::Unchecked : Qt::Checked;
        
        m_updatingCheckStates = true;
        item->setCheckState(0, newState);
        updateChildCheckStates(item, newState);
        updateParentCheckState(item->parent());
        m_updatingCheckStates = false;
        updateSelectionCount();
    }
}

void NetworkDirectoryDialog::updateChildCheckStates(QTreeWidgetItem *parent, Qt::CheckState state)
{
    if (!parent) return;
    
    for (int i = 0; i < parent->childCount(); ++i) {
        QTreeWidgetItem *child = parent->child(i);
        if (child) {
            child->setCheckState(0, state);
            updateChildCheckStates(child, state); // Recursive
        }
    }
}

void NetworkDirectoryDialog::updateParentCheckState(QTreeWidgetItem *child)
{
    QTreeWidgetItem *parent = child->parent();
    if (!parent) return;
    
    int checkedCount = 0;
    int partialCount = 0;
    int totalChildren = parent->childCount();
    
    for (int i = 0; i < totalChildren; ++i) {
        QTreeWidgetItem *sibling = parent->child(i);
        if (sibling) {
            Qt::CheckState siblingState = sibling->checkState(0);
            if (siblingState == Qt::Checked) {
                checkedCount++;
            } else if (siblingState == Qt::PartiallyChecked) {
                partialCount++;
            }
        }
    }
    
    // Determine parent state
    Qt::CheckState newState;
    if (checkedCount == totalChildren) {
        newState = Qt::Checked;
    } else if (checkedCount > 0 || partialCount > 0) {
        newState = Qt::PartiallyChecked;
    } else {
        newState = Qt::Unchecked;
    }
    
    parent->setCheckState(0, newState);
    
    // Recursively update grandparent
    updateParentCheckState(parent);
}

void NetworkDirectoryDialog::onSelectAll()
{
    qDebug() << "[NetworkDirectoryDialog] 🔄 'Alle auswählen' geklickt";
    
    for (int i = 0; i < m_directoryTree->topLevelItemCount(); ++i) {
        QTreeWidgetItem *item = m_directoryTree->topLevelItem(i);
        if (item) {
            item->setCheckState(0, Qt::Checked);
        }
    }
    
    // 🔥 DIREKTER FIX: Aktiviere OK-Button sofort
    m_okBtn->setEnabled(true);
    m_okBtn->setStyleSheet("QPushButton { background-color: #059669; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; font-size: 14px; }");
    m_selectionCountLabel->setText("Alle Verzeichnisse ausgewählt");
    
    qDebug() << "[NetworkDirectoryDialog] ✅ OK-Button aktiviert - Alle ausgewählt";
    
    updateSelectionCount();
}

void NetworkDirectoryDialog::onSelectNone()
{
    for (int i = 0; i < m_directoryTree->topLevelItemCount(); ++i) {
        QTreeWidgetItem *item = m_directoryTree->topLevelItem(i);
        if (item) {
            item->setCheckState(0, Qt::Unchecked);
        }
    }
    updateSelectionCount();
}

void NetworkDirectoryDialog::onExpandAll()
{
    m_directoryTree->expandAll();
}

void NetworkDirectoryDialog::onCollapseAll()
{
    m_directoryTree->collapseAll();
}

void NetworkDirectoryDialog::updateSelectionCount()
{
    QStringList selected = getSelectedDirectories();
    int count = selected.size();
    
    m_selectionCountLabel->setText(QString("%1 Verzeichnisse ausgewählt").arg(count));
    m_okBtn->setEnabled(count > 0);
    
    // Update button styles based on selection
    if (count > 0) {
        m_okBtn->setStyleSheet("QPushButton { background-color: #059669; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; font-size: 14px; }");
    } else {
        m_okBtn->setStyleSheet("QPushButton { background-color: #9ca3af; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; font-size: 14px; }");
    }
}

QStringList NetworkDirectoryDialog::getSelectedDirectories() const
{
    QStringList selected;
    
    std::function<void(QTreeWidgetItem*)> collectChecked = [&](QTreeWidgetItem *item) {
        if (!item) return;
        
        if (item->checkState(0) == Qt::Checked) {
            QString fullPath = item->data(0, Qt::UserRole).toString();
            qDebug() << "[NetworkDirectoryDialog] 🔍 Debug getSelectedDirectories: item=" << item->text(0) << "fullPath=" << fullPath;
            
            // Überspringe Placeholders und leere Pfade
            if (!fullPath.isEmpty() && fullPath != "PLACEHOLDER") {
                selected.append(fullPath);
                qDebug() << "[NetworkDirectoryDialog] 🔍 Debug: ADDED to selected:" << fullPath;
            }
        }
        
        // Check children
        for (int i = 0; i < item->childCount(); ++i) {
            collectChecked(item->child(i));
        }
    };
    
    // Collect from all top-level items
    for (int i = 0; i < m_directoryTree->topLevelItemCount(); ++i) {
        collectChecked(m_directoryTree->topLevelItem(i));
    }
    
    return selected;
}

void NetworkDirectoryDialog::setConnectionStatus(const QString &status)
{
    m_statusLabel->setText(status);
}

void NetworkDirectoryDialog::addLazyLoadingPlaceholder(QTreeWidgetItem *parent)
{
    if (!parent) return;
    
    // Füge unsichtbaren Platzhalter-Child hinzu um expandierbar zu erscheinen
    QTreeWidgetItem *placeholder = new QTreeWidgetItem(parent);
    placeholder->setText(0, ""); // Leerer Text - unsichtbar
    placeholder->setFlags(placeholder->flags() & ~Qt::ItemIsUserCheckable); // Nicht checkbar
    placeholder->setData(0, Qt::UserRole, "PLACEHOLDER");
    placeholder->setHidden(true); // Verstecke den Platzhalter
    
    // Setze Tooltip nur für Debugging
    placeholder->setToolTip(0, "Platzhalter für Lazy Loading");
}

void NetworkDirectoryDialog::loadSubdirectories(QTreeWidgetItem *parentItem, const QString &path)
{
    if (!parentItem) return;
    
    qDebug() << "[NetworkDirectoryDialog] � Starte ECHTE FTP-LIST für Unterverzeichnisse:" << path;
    
    // Entferne den unsichtbaren Platzhalter
    while (parentItem->childCount() > 0) {
        QTreeWidgetItem *child = parentItem->child(0);
        if (child->data(0, Qt::UserRole).toString() == "PLACEHOLDER" || child->isHidden()) {
            delete parentItem->takeChild(0);
        } else {
            break; // Echte Kinder behalten
        }
    }
    
    // Signal an MainWindow senden, um echte FTP-LIST für diesen Pfad zu starten
    // TODO: Hier sollte eine echte FTP-LIST-Abfrage gestartet werden
    // Beispiel: emit requestFtpSubdirectories(path);
    
    // Temporärer Platzhalter während des Ladens
    QTreeWidgetItem *loadingItem = new QTreeWidgetItem(parentItem);
    loadingItem->setText(0, "🔄 Lade Unterverzeichnisse...");
    loadingItem->setFlags(loadingItem->flags() & ~Qt::ItemIsUserCheckable);
    loadingItem->setData(0, Qt::UserRole, "LOADING");
    
    qDebug() << "[NetworkDirectoryDialog] ⏳ Loading-Platzhalter für" << path << "hinzugefügt - warte auf echte FTP-LIST";
}

void NetworkDirectoryDialog::addSubdirectories(const QString &parentPath, const QStringList &subdirs)
{
    qDebug() << "[NetworkDirectoryDialog] 📋 Füge" << subdirs.size() << "echte Unterverzeichnisse für" << parentPath << "hinzu";
    
    // Finde das Parent-Item basierend auf dem Pfad
    QTreeWidgetItem *parentItem = nullptr;
    
    std::function<QTreeWidgetItem*(QTreeWidgetItem*, const QString&)> findItemByPath = 
        [&](QTreeWidgetItem *item, const QString &searchPath) -> QTreeWidgetItem* {
        if (!item) return nullptr;
        
        QString itemPath = item->data(0, Qt::UserRole).toString();
        if (itemPath == searchPath) {
            return item;
        }
        
        // Rekursiv in Kindern suchen
        for (int i = 0; i < item->childCount(); ++i) {
            QTreeWidgetItem *found = findItemByPath(item->child(i), searchPath);
            if (found) return found;
        }
        return nullptr;
    };
    
    // Suche in allen Top-Level-Items
    for (int i = 0; i < m_directoryTree->topLevelItemCount(); ++i) {
        parentItem = findItemByPath(m_directoryTree->topLevelItem(i), parentPath);
        if (parentItem) break;
    }
    
    if (!parentItem) {
        qDebug() << "[NetworkDirectoryDialog] ⚠️ Parent-Item für Pfad" << parentPath << "nicht gefunden";
        return;
    }
    
    // Entferne Loading-Platzhalter
    while (parentItem->childCount() > 0) {
        QTreeWidgetItem *child = parentItem->child(0);
        if (child->data(0, Qt::UserRole).toString() == "LOADING") {
            delete parentItem->takeChild(0);
        } else {
            break;
        }
    }
    
    // Füge echte Unterverzeichnisse hinzu
    for (const QString &subdir : subdirs) {
        if (subdir.isEmpty()) continue;
        
        // Verhindere Rekursion - wenn das Unterverzeichnis dem Parent-Namen entspricht, überspringe es
        QString parentDirName = parentPath;
        if (parentDirName.endsWith("/")) parentDirName.chop(1);
        if (parentDirName.startsWith("/")) parentDirName = parentDirName.mid(1);
        
        QString cleanSubdir = subdir;
        if (cleanSubdir.startsWith("/")) cleanSubdir = cleanSubdir.mid(1);
        if (cleanSubdir.endsWith("/")) cleanSubdir.chop(1);
        
        // KORREKTUR: Extrahiere nur den letzten Teil des Pfades (Verzeichnisname)
        // Falls der Pfad bereits den Parent-Pfad enthält, entferne ihn
        QStringList pathParts = cleanSubdir.split('/', Qt::SkipEmptyParts);
        if (!pathParts.isEmpty()) {
            cleanSubdir = pathParts.last(); // Nur der letzte Teil (Verzeichnisname)
        }
        
        // Überspringe wenn das Unterverzeichnis den gleichen Namen wie das Parent hat
        if (cleanSubdir == parentDirName) {
            qDebug() << "[NetworkDirectoryDialog] ⚠️ Überspringe rekursives Verzeichnis:" << cleanSubdir << "in" << parentPath;
            continue;
        }
        
        QTreeWidgetItem *subdirItem = new QTreeWidgetItem(parentItem);
        subdirItem->setText(0, QString("📁 %1").arg(cleanSubdir));
        subdirItem->setFlags(subdirItem->flags() | Qt::ItemIsUserCheckable);
        subdirItem->setCheckState(0, Qt::Unchecked);
        
        // KORREKTUR: Baue den vollständigen Pfad korrekt auf
        // Der parentPath enthält bereits den korrekten Basis-Pfad (z.B. "/sdb/")
        QString fullPath = parentPath;
        if (!fullPath.endsWith("/")) fullPath += "/";
        fullPath += cleanSubdir;
        if (!fullPath.endsWith("/")) fullPath += "/";
        
        // Bereinige doppelte Slashes
        fullPath = fullPath.replace("//", "/");
        
        qDebug() << "[NetworkDirectoryDialog] 🔍 Debug addSubdirectories: parentPath=" << parentPath << "cleanSubdir=" << cleanSubdir << "finalPath=" << fullPath;
        
        subdirItem->setData(0, Qt::UserRole, fullPath);
        subdirItem->setToolTip(0, QString("Echter FTP-Pfad: %1").arg(fullPath));
        
        // Füge weitere Platzhalter für tiefere Ebenen hinzu
        addLazyLoadingPlaceholder(subdirItem);
    }
    
    qDebug() << "[NetworkDirectoryDialog] ✅" << subdirs.size() << "ECHTE Unterverzeichnisse für" << parentPath << "hinzugefügt";
}
