#include "directoryselectiondialog.h"
#include "networkscanner.h"
#include "presetmanager.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QMenu>
#include <QHeaderView>
#include <QStandardPaths>
#include <QStorageInfo>
#include <QDir>
#include <iostream>

DirectorySelectionDialog::DirectorySelectionDialog(QWidget *parent)
    : QDialog(parent), networkScanner(nullptr), presetManager(nullptr), multiSelectionEnabled(true), editDeleteEnabled(true), currentIpRange("192.168.1.0/24")
{
    setWindowTitle("Verzeichnisse für Duplikat-Scan auswählen");
    setWindowIcon(QIcon(":/icons/folder.svg"));
    resize(900, 600);

    setupUI();
    setupLocalPanel();
    setupNetworkPanel();
    setupButtons();

    // Initialize components
    networkScanner = new NetworkScanner(this);
    connect(networkScanner, &NetworkScanner::serviceFound,
            this, &DirectorySelectionDialog::networkServiceFound);

    std::cout << "📁 Directory Selection Dialog initialisiert" << std::endl;
}

DirectorySelectionDialog::~DirectorySelectionDialog()
{
    if (portScanTimer && portScanTimer->isActive())
    {
        portScanTimer->stop();
    }
}

void DirectorySelectionDialog::setupUI()
{
    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    // Main splitter
    mainSplitter = new QSplitter(Qt::Horizontal, this);
    mainLayout->addWidget(mainSplitter);

    // Button area
    buttonWidget = new QWidget(this);
    mainLayout->addWidget(buttonWidget);
}

void DirectorySelectionDialog::setupLocalPanel()
{
    localWidget = new QWidget();
    localGroup = new QGroupBox("📁 Lokale Verzeichnisse");

    QVBoxLayout *localLayout = new QVBoxLayout(localWidget);
    localLayout->addWidget(localGroup);

    QVBoxLayout *groupLayout = new QVBoxLayout(localGroup);

    // Local directory tree
    localTree = new QTreeWidget();
    localTree->setHeaderLabels({"Pfad", "Größe", "Dateien"});
    localTree->setSelectionMode(QAbstractItemView::ExtendedSelection);
    localTree->setContextMenuPolicy(Qt::CustomContextMenu);
    localTree->setRootIsDecorated(true);
    localTree->setAnimated(true);
    localTree->setIndentation(20);

    connect(localTree, &QTreeWidget::itemDoubleClicked,
            this, &DirectorySelectionDialog::onLocalDirectoryDoubleClicked);
    connect(localTree, &QTreeWidget::customContextMenuRequested,
            this, &DirectorySelectionDialog::showLocalContextMenu);

    groupLayout->addWidget(localTree);

    // Local controls
    QHBoxLayout *localControls = new QHBoxLayout();
    addLocalBtn = new QPushButton("➕ Hinzufügen");
    refreshLocalBtn = new QPushButton("🔄 Aktualisieren");
    expandAllBtn = new QPushButton("🌳 Alle erweitern");
    localCountLabel = new QLabel("0 Verzeichnisse ausgewählt");

    connect(addLocalBtn, &QPushButton::clicked, this, &DirectorySelectionDialog::addLocalDirectory);
    connect(refreshLocalBtn, &QPushButton::clicked, this, &DirectorySelectionDialog::populateLocalDirectories);
    connect(expandAllBtn, &QPushButton::clicked, this, &DirectorySelectionDialog::expandAllTrees);

    localControls->addWidget(addLocalBtn);
    localControls->addWidget(refreshLocalBtn);
    localControls->addWidget(expandAllBtn);
    localControls->addStretch();
    localControls->addWidget(localCountLabel);

    groupLayout->addLayout(localControls);

    mainSplitter->addWidget(localWidget);

    // Populate with system directories
    populateLocalDirectories();
}

void DirectorySelectionDialog::setupNetworkPanel()
{
    networkWidget = new QWidget();
    networkGroup = new QGroupBox("📡 Netzwerk-Dienste");

    QVBoxLayout *networkLayout = new QVBoxLayout(networkWidget);
    networkLayout->addWidget(networkGroup);

    QVBoxLayout *groupLayout = new QVBoxLayout(networkGroup);

    // IP range input
    QHBoxLayout *ipLayout = new QHBoxLayout();
    ipLayout->addWidget(new QLabel("IP-Bereich:"));
    ipRangeEdit = new QLineEdit(currentIpRange);
    ipRangeEdit->setPlaceholderText("192.168.1.0/24 oder 192.168.1.1-192.168.1.254");
    scanNetworkBtn = new QPushButton("🔍 Netzwerk scannen");
    autoScanEnabled = new QCheckBox("Auto-Scan (30s)");

    connect(scanNetworkBtn, &QPushButton::clicked, this, &DirectorySelectionDialog::startAutomaticPortScan);

    ipLayout->addWidget(ipRangeEdit);
    ipLayout->addWidget(scanNetworkBtn);
    ipLayout->addWidget(autoScanEnabled);

    groupLayout->addLayout(ipLayout);

    // Network services tree
    networkTree = new QTreeWidget();
    networkTree->setHeaderLabels({"Host:Port", "Dienst", "Status"});
    networkTree->setSelectionMode(QAbstractItemView::ExtendedSelection);
    networkTree->setContextMenuPolicy(Qt::CustomContextMenu);
    networkTree->setRootIsDecorated(true);
    networkTree->setAnimated(true);

    connect(networkTree, &QTreeWidget::itemDoubleClicked,
            this, &DirectorySelectionDialog::onNetworkServiceDoubleClicked);
    connect(networkTree, &QTreeWidget::customContextMenuRequested,
            this, &DirectorySelectionDialog::showNetworkContextMenu);

    groupLayout->addWidget(networkTree);

    // Network scan progress
    QHBoxLayout *progressLayout = new QHBoxLayout();
    scanProgress = new QProgressBar();
    scanProgress->setVisible(false);
    scanStatusLabel = new QLabel("Bereit für Netzwerk-Scan");
    networkCountLabel = new QLabel("0 Dienste gefunden");

    progressLayout->addWidget(scanProgress);
    progressLayout->addWidget(scanStatusLabel);
    progressLayout->addStretch();
    progressLayout->addWidget(networkCountLabel);

    groupLayout->addLayout(progressLayout);

    mainSplitter->addWidget(networkWidget);
}

void DirectorySelectionDialog::setupButtons()
{
    QHBoxLayout *buttonLayout = new QHBoxLayout(buttonWidget);

    selectAllBtn = new QPushButton("✅ Alle auswählen");
    deselectAllBtn = new QPushButton("❌ Alle abwählen");
    okBtn = new QPushButton("🚀 Duplikat-Scan starten");
    cancelBtn = new QPushButton("Abbrechen");

    connect(selectAllBtn, &QPushButton::clicked, this, &DirectorySelectionDialog::selectAllDirectories);
    connect(deselectAllBtn, &QPushButton::clicked, this, &DirectorySelectionDialog::deselectAllDirectories);
    connect(okBtn, &QPushButton::clicked, this, &QDialog::accept);
    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);

    // Style the main action button
    okBtn->setStyleSheet("QPushButton { background-color: #007ACC; color: white; font-weight: bold; padding: 8px 16px; }");

    buttonLayout->addWidget(selectAllBtn);
    buttonLayout->addWidget(deselectAllBtn);
    buttonLayout->addStretch();
    buttonLayout->addWidget(cancelBtn);
    buttonLayout->addWidget(okBtn);
}

void DirectorySelectionDialog::populateLocalDirectories()
{
    localTree->clear();

    std::cout << "📁 Lade lokale Verzeichnisse..." << std::endl;

    loadSystemDirectories();
    loadUserDirectories();
    loadMountPoints();

    localTree->expandToDepth(1);
    std::cout << "✅ Lokale Verzeichnisse geladen" << std::endl;
}

void DirectorySelectionDialog::loadSystemDirectories()
{
    QTreeWidgetItem *systemRoot = new QTreeWidgetItem(localTree);
    systemRoot->setText(0, "🖥️ System");
    systemRoot->setIcon(0, QIcon(":/icons/computer.svg"));

    QStringList systemPaths = {"/home", "/media", "/mnt", "/opt", "/usr/local"};

    for (const QString &path : systemPaths)
    {
        QDir dir(path);
        if (dir.exists())
        {
            QTreeWidgetItem *item = new QTreeWidgetItem(systemRoot);
            item->setText(0, path);
            item->setData(0, Qt::UserRole, path);
            item->setIcon(0, QIcon(":/icons/folder.svg"));

            // Add size info if available
            QStorageInfo storage(path);
            if (storage.isValid())
            {
                item->setText(1, QString("%1 GB").arg(storage.bytesTotal() / (1024 * 1024 * 1024)));
            }
        }
    }
}

void DirectorySelectionDialog::loadUserDirectories()
{
    QTreeWidgetItem *userRoot = new QTreeWidgetItem(localTree);
    userRoot->setText(0, "👤 Benutzer");
    userRoot->setIcon(0, QIcon(":/icons/user.svg"));

    QStringList userPaths = {
        QStandardPaths::writableLocation(QStandardPaths::HomeLocation),
        QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation),
        QStandardPaths::writableLocation(QStandardPaths::PicturesLocation),
        QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
        QStandardPaths::writableLocation(QStandardPaths::MoviesLocation),
        QStandardPaths::writableLocation(QStandardPaths::DownloadLocation)};

    for (const QString &path : userPaths)
    {
        if (!path.isEmpty() && QDir(path).exists())
        {
            QTreeWidgetItem *item = new QTreeWidgetItem(userRoot);
            QFileInfo info(path);
            item->setText(0, info.fileName().isEmpty() ? path : info.fileName());
            item->setData(0, Qt::UserRole, path);
            item->setIcon(0, QIcon(":/icons/folder.svg"));
            item->setToolTip(0, path);
        }
    }
}

void DirectorySelectionDialog::loadMountPoints()
{
    QTreeWidgetItem *mountRoot = new QTreeWidgetItem(localTree);
    mountRoot->setText(0, "💾 Laufwerke");
    mountRoot->setIcon(0, QIcon(":/icons/drive.svg"));

    for (const QStorageInfo &storage : QStorageInfo::mountedVolumes())
    {
        if (storage.isValid() && storage.isReady())
        {
            QString mountPoint = storage.rootPath();

            // Skip system mounts
            if (mountPoint == "/" || mountPoint.startsWith("/sys") ||
                mountPoint.startsWith("/proc") || mountPoint.startsWith("/dev"))
            {
                continue;
            }

            QTreeWidgetItem *item = new QTreeWidgetItem(mountRoot);
            item->setText(0, storage.displayName().isEmpty() ? mountPoint : storage.displayName());
            item->setText(1, QString("%1 GB").arg(storage.bytesTotal() / (1024 * 1024 * 1024)));
            item->setData(0, Qt::UserRole, mountPoint);
            item->setIcon(0, QIcon(":/icons/drive.svg"));
            item->setToolTip(0, QString("%1 (%2)").arg(mountPoint, storage.fileSystemType().data()));
        }
    }
}

void DirectorySelectionDialog::addLocalDirectory()
{
    QString dir = QFileDialog::getExistingDirectory(this, "Verzeichnis hinzufügen");
    if (!dir.isEmpty())
    {
        QTreeWidgetItem *item = new QTreeWidgetItem(localTree);
        item->setText(0, dir);
        item->setData(0, Qt::UserRole, dir);
        item->setIcon(0, QIcon(":/icons/folder-add.svg"));
        item->setCheckState(0, Qt::Checked);

        std::cout << "📁 Verzeichnis hinzugefügt: " << dir.toUtf8().constData() << std::endl;
    }
}

void DirectorySelectionDialog::startAutomaticPortScan()
{
    if (!networkScanner)
        return;

    scanProgress->setVisible(true);
    scanProgress->setRange(0, 0); // Indeterminate progress
    scanStatusLabel->setText("Scanne Netzwerk...");
    scanNetworkBtn->setEnabled(false);

    // Set IP range from input
    currentIpRange = ipRangeEdit->text();
    networkScanner->setIpRange(currentIpRange);

    // Start scan
    networkScanner->startScan();

    std::cout << "📡 Starte Netzwerk-Scan für " << currentIpRange.toUtf8().constData() << std::endl;
}

QStringList DirectorySelectionDialog::getSelectedDirectories() const
{
    QStringList result;
    result.append(getSelectedLocalDirectories());
    result.append(getSelectedNetworkDirectories());
    return result;
}

QStringList DirectorySelectionDialog::getSelectedLocalDirectories() const
{
    QStringList result;

    for (int i = 0; i < localTree->topLevelItemCount(); ++i)
    {
        QTreeWidgetItem *topItem = localTree->topLevelItem(i);
        for (int j = 0; j < topItem->childCount(); ++j)
        {
            QTreeWidgetItem *item = topItem->child(j);
            if (item->checkState(0) == Qt::Checked)
            {
                result.append(item->data(0, Qt::UserRole).toString());
            }
        }
    }

    return result;
}

QStringList DirectorySelectionDialog::getSelectedNetworkDirectories() const
{
    QStringList result;

    // Collect checked network services from network tree
    if (networkTree)
    {
        QTreeWidgetItemIterator it(networkTree);
        while (*it)
        {
            QTreeWidgetItem *item = *it;
            if (item->checkState(0) == Qt::Checked)
            {
                QString service = item->text(0);
                if (service.contains(":"))
                {
                    // Format: IP:Port (Service) -> convert to network path
                    QStringList parts = service.split(" ");
                    if (parts.size() >= 1)
                    {
                        QString ipPort = parts[0];
                        QString serviceName = parts.size() > 1 ? parts[1].remove("(").remove(")") : "Unknown";

                        // Convert to network path format
                        QString networkPath = QString("network://%1/%2").arg(ipPort, serviceName);
                        result.append(networkPath);

                        std::cout << "[DirectorySelection] 📡 Netzwerk-Verzeichnis ausgewählt: "
                                  << networkPath.toUtf8().constData() << std::endl;
                    }
                }
            }
            ++it;
        }
    }

    std::cout << "[DirectorySelection] 📊 " << result.size()
              << " Netzwerk-Verzeichnisse ausgewählt" << std::endl;

    return result;
}

// Complete implementations for all slots
void DirectorySelectionDialog::removeSelectedDirectories()
{
    std::cout << "[DirectorySelection] 🗑️ Entferne ausgewählte Verzeichnisse..." << std::endl;

    // Remove selected local directories
    if (localTree)
    {
        QList<QTreeWidgetItem *> itemsToRemove;
        QTreeWidgetItemIterator it(localTree);

        while (*it)
        {
            QTreeWidgetItem *item = *it;
            if (item->isSelected())
            {
                itemsToRemove.append(item);
            }
            ++it;
        }

        for (QTreeWidgetItem *item : itemsToRemove)
        {
            delete item;
        }

        std::cout << "[DirectorySelection] ✅ " << itemsToRemove.size()
                  << " lokale Verzeichnisse entfernt" << std::endl;
    }
}

void DirectorySelectionDialog::onLocalDirectoryDoubleClicked(QTreeWidgetItem *item)
{
    if (item)
    {
        // Toggle check state on double-click
        Qt::CheckState newState = (item->checkState(0) == Qt::Checked) ? Qt::Unchecked : Qt::Checked;
        item->setCheckState(0, newState);

        QString path = item->data(0, Qt::UserRole).toString();
        std::cout << "[DirectorySelection] 🖱️ Lokales Verzeichnis "
                  << (newState == Qt::Checked ? "ausgewählt" : "abgewählt")
                  << ": " << path.toUtf8().constData() << std::endl;
    }
}

void DirectorySelectionDialog::onNetworkServiceDoubleClicked(QTreeWidgetItem *item)
{
    if (item)
    {
        // Toggle check state for network services
        Qt::CheckState newState = (item->checkState(0) == Qt::Checked) ? Qt::Unchecked : Qt::Checked;
        item->setCheckState(0, newState);

        QString service = item->text(0);
        std::cout << "[DirectorySelection] 🌐 Netzwerk-Service "
                  << (newState == Qt::Checked ? "ausgewählt" : "abgewählt")
                  << ": " << service.toUtf8().constData() << std::endl;

        // If service is being selected, try to establish connection for directory listing
        if (newState == Qt::Checked && service.contains(":"))
        {
            QStringList parts = service.split(":");
            if (parts.size() >= 2)
            {
                QString ip = parts[0];
                QString portService = parts[1];

                emit networkServiceSelected(ip, portService);
                std::cout << "[DirectorySelection] 📡 Verbindungsversuch zu "
                          << ip.toUtf8().constData() << ":" << portService.toUtf8().constData() << std::endl;
            }
        }
    }
}

void DirectorySelectionDialog::showLocalContextMenu(const QPoint &pos)
{
    if (!localTree)
        return;

    QTreeWidgetItem *item = localTree->itemAt(pos);
    QMenu contextMenu(this);

    if (item)
    {
        // Item-specific actions
        QAction *selectAction = contextMenu.addAction("✅ Auswählen");
        QAction *deselectAction = contextMenu.addAction("❌ Abwählen");
        QAction *removeAction = contextMenu.addAction("🗑️ Entfernen");

        contextMenu.addSeparator();

        connect(selectAction, &QAction::triggered, [item]()
                { item->setCheckState(0, Qt::Checked); });
        connect(deselectAction, &QAction::triggered, [item]()
                { item->setCheckState(0, Qt::Unchecked); });
        connect(removeAction, &QAction::triggered, [this, item]()
                { delete item; });
    }

    // Global actions
    QAction *selectAllAction = contextMenu.addAction("✅ Alle auswählen");
    QAction *deselectAllAction = contextMenu.addAction("❌ Alle abwählen");
    QAction *expandAllAction = contextMenu.addAction("🌳 Alle erweitern");
    QAction *collapseAllAction = contextMenu.addAction("📁 Alle reduzieren");

    connect(selectAllAction, &QAction::triggered, [this]()
            {
        QTreeWidgetItemIterator it(localTree);
        while (*it) {
            (*it)->setCheckState(0, Qt::Checked);
            ++it;
        } });

    connect(deselectAllAction, &QAction::triggered, [this]()
            {
        QTreeWidgetItemIterator it(localTree);
        while (*it) {
            (*it)->setCheckState(0, Qt::Unchecked);
            ++it;
        } });

    connect(expandAllAction, &QAction::triggered, [this]()
            { localTree->expandAll(); });

    connect(collapseAllAction, &QAction::triggered, [this]()
            { localTree->collapseAll(); });

    contextMenu.exec(localTree->mapToGlobal(pos));

    std::cout << "[DirectorySelection] 📋 Kontext-Menü für lokale Verzeichnisse angezeigt" << std::endl;
}
void DirectorySelectionDialog::showNetworkContextMenu(const QPoint &pos) {}
void DirectorySelectionDialog::updatePortScanProgress() {}
void DirectorySelectionDialog::expandAllTrees()
{
    localTree->expandAll();
    networkTree->expandAll();
}
void DirectorySelectionDialog::collapseAllTrees()
{
    localTree->collapseAll();
    networkTree->collapseAll();
}
void DirectorySelectionDialog::selectAllDirectories() {}
void DirectorySelectionDialog::deselectAllDirectories() {}

// Configuration methods
void DirectorySelectionDialog::setupLocalDirectoryTree() {}
void DirectorySelectionDialog::setupNetworkServicesPanel() {}
void DirectorySelectionDialog::enableMultiSelection(bool enabled) { multiSelectionEnabled = enabled; }
void DirectorySelectionDialog::enableEditAndDelete(bool enabled) { editDeleteEnabled = enabled; }
void DirectorySelectionDialog::setCustomIpRange(const QString &range) { currentIpRange = range; }
void DirectorySelectionDialog::ensureParentChildVisibility(QTreeWidgetItem *item) {}
void DirectorySelectionDialog::connectToNetworkService(const NetworkService &service) {}
