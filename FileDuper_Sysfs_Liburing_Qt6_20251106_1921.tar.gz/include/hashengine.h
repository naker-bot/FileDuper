#ifndef HASHENGINE_H
#define HASHENGINE_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <QCryptographicHash>
#include <QFile>
#include <QFileInfo>
#include <QProcess>
#include <QMap>
#include <QSet>
#include <QDateTime>
#include <QThread>
#include <QMutex>
#include <QSemaphore>
#include <QQueue>
#include <QImage>
#include <QVector>
#include <atomic>

#ifdef ENABLE_OPENCL
#include <CL/cl.h>
#endif

class HashEngine : public QObject
{
    Q_OBJECT
    friend class ParallelHashWorker; // 🧵 Allow parallel workers to access private members

public:
    explicit HashEngine(QObject *parent = nullptr);
    ~HashEngine();

    enum Algorithm
    {
        MD5,        // Fast, good for duplicates
        SHA1,       // Balanced speed/security
        SHA256,     // Secure, slower
        SHA512,     // Most secure, slowest
        XXHASH,     // Fastest, less collision-resistant
        SHA3,       // Modern, secure
        BLAKE2,     // Very fast, modern, secure
        BLAKE3,     // Ultra fast, parallel, modern
        MURMUR3,    // Ultra fast, hash tables
        CITYHASH,   // Google, very fast
        FARMHASH,   // Google successor to CityHash
        HIGHWAY,    // Google, SIMD-optimized
        METROHASH,  // Extremely fast
        SPOOKY      // Fast, well distributed
    };

    enum HashMode
    {
        QUICK_HASH, // First 1KB + Last 1KB (fast, less accurate)
        FULL_HASH   // Complete file content (slower, 100% accurate)
    };

    enum ProcessingUnit
    {
        AUTO_SELECT = 0,      // Automatic best available
        CPU_ALL_CORES = 1,    // Always available fallback
        GPU_OPENCL = 2,       // Generic OpenCL acceleration
        INTEL_GPU_OPENCL = 3, // Intel GPU optimized (Arc, Xe, UHD)
        NPU_LEVEL_ZERO = 4    // Intel NPU via Level Zero API
    };
    Q_ENUM(ProcessingUnit)

    enum ProcessingCategory
    {
        IMAGES = 0,      // .jpg, .png, .bmp, .tiff → NPU processing
        VIDEOS = 1,      // .mp4, .avi, .mkv, .mov → NPU processing  
        AUDIO = 2,       // .mp3, .wav, .flac, .ogg → GPU-Hash processing
        DOCUMENTS = 3,   // .pdf, .doc, .txt, .rtf → GPU-Hash processing
        ARCHIVES = 4,    // .zip, .rar, .7z, .tar → GPU-Hash processing
        DATA = 5,        // .dat, .db, .json, .xml → GPU-Hash processing
        UNKNOWN = 6      // Other file types → Auto-select processing
    };
    Q_ENUM(ProcessingCategory)

    // Configuration
    void setAlgorithm(Algorithm algo);
    void setHashMode(HashMode mode);
    void setProcessingUnit(ProcessingUnit unit);
    void setPresetManager(QObject *presetManager);
    void setExpectedFilesCount(int count); // 📊 Set total expected file count for progress calculation

    // Hash calculation
    QString calculateFileHash(const QString &filePath);
    void calculateFileHashAsync(const QString &filePath, const QString &algorithm = QString());  // 🧠 Optional algorithm override
    void calculateMultipleHashes(const QStringList &filePaths);

    // 🔥 RAPID PRE-HASH: Nur erste 512 Bytes - 100x schneller!
    QString calculateRapidPreHash(const QString &filePath);

    // 🚀 MEMORY-MAPPED HASHING: Ultra-fast für große Dateien (> 64KB)
    QString calculateHashMapped(const QString &filePath, Algorithm algo);
    QString calculateHashAsync(const QString &filePath, Algorithm algo);  // 🚀 io_uring async
    QString calculateTripleHash(const QString &filePath);  // 🔒 MD5+SHA256+SHA512 triple verification
    bool verifyFileDuplicates(const QString &file1, const QString &file2);  // 🔒 Safe duplicate verification

    // 🧵 PARALLEL HASH CALCULATION: Multiple files in parallel via ThreadPool (+2-3x speedup)
    void calculateHashesParallel(const QStringList &filePaths);  // Parallel hash computation with GPU cache safety

    // 🚀 GPU/NPU-QUEUE DISPATCH: Route files to hardware-accelerated queues
    void enqueueForGpuHash(const QString &filePath);   // Add to GPU hash queue
    void enqueueForNpuFeatures(const QString &imagePath); // Add to NPU feature queue

    // 🧠 NPU-FIRST: Feature-Vector-based Image Processing (KEIN Hash!)
    void processImagesWithNpuUltraFast(const QStringList &imageFiles);

    // ✅ FTP-Credentials setzen (PUBLIC!)
    void setFtpCredentials(const QString &host, const QString &username, const QString &password);

    // 🧠 Intelligent File Categorization & Processing Unit Switching
    ProcessingCategory categorizeFile(const QString &filePath);
    ProcessingUnit getOptimalUnitForCategory(ProcessingCategory category);
    void processFileWithOptimalUnit(const QString &filePath);
    void processCategorizedFiles(const QStringList &filePaths); // Auto-categorize and process

    // Hardware detection
    bool isGpuAvailable() const;
    bool isIntelGpuAvailable() const;
    bool isNpuAvailable() const;

    // Performance monitoring
    int getHashRate() const; // Hashes per second
    QString getCurrentUnit() const;
    
    // 🎯 DUPLIKAT-DATEN ACCESS
    const QHash<QString, QString>& getFileHashes() const { return fileHashes; }
    
    // 🖼️ NPU-BILDVERARBEITUNG (Public für Tests)
    QVector<float> extractNpuImageFeatures(const QString &imagePath);  // 🚀 NPU-spezifische Bildanalyse
    QVector<float> extractNpuImageFeaturesFromFtp(const QString &ftpUrl);  // 🌐 FTP-Download + NPU-Analyse
    QStringList scanFtpDirectoryForFiles(const QString &ftpDirUrl);  // 🔍 FTP Directory Scanner
    QString calculateNpuImageSimilarityHash(const QString &imagePath);
    bool areImagesSimilarByNpu(const QString &imagePath1, const QString &imagePath2, float threshold = 0.85f);

    // 📈 Workflow-Phasen (PUBLIC für Tests!)
    void startSortingPhase();
    void startDuplicateComparison();
    void displayResults(int duplicateGroups);
    
    // ✅ NO-LAMBDA Processing Steps (prevents capture bugs)
    void processSortingStep();
    void processComparisonStep();
    
    // 🛡️ CRITICAL: Clear processed files cache to prevent infinite loops
    void clearProcessedFiles();
    
    // 🧹 MEMORY MANAGEMENT: Periodic cleanup during long scans
    void periodicMemoryCleanup();
    
    // 🛑 STOP: Stop all processing immediately
    void stopProcessing();
    
    // Test-Helper für Workflow
    void setProcessedFilesCount(int count) { processedFiles.store(count); }

signals:
    void hashCalculated(const QString &filePath, const QString &hash, bool isLocal);
    void progressChanged(int percentage);
    void errorOccurred(const QString &error);
    void error(const QString &message);  // Zusätzliches error Signal
    void gpuActivitySignal(int percentage);  // GPU-Aktivität für GUI
    void npuActivitySignal(int percentage);  // NPU-Aktivität für GUI
    
    // Status und Debug Signale
    void statusUpdate(const QString &phase, const QString &message);
    void criticalError(const QString &title, const QString &message);
    void processingUnitChanged(ProcessingUnit unit);
    void hashProgress(int processed, int total);
    void hashRateChanged(double hashesPerSecond);
    void ftpCredentialsRequiredForHost(const QString &host, int port, const QString &service);
    
    // NPU-spezifische Signale
    void npuProcessingStarted(const QString &task);
    void npuProcessingFinished();
    void processingUnitAutoSwitched(ProcessingUnit from, ProcessingUnit to, const QString &reason);
    void processingCategoryChanged(const QString &filePath, int category);
    void categorizedProcessingStarted(int totalFiles, int category);
    void categorizedProcessingProgress(int processed, int total, int category);
    void downloadProgressChanged(int downloaded, int total, bool success);
    
    // Sortierung und Analyse
    void sortingStarted(int totalFiles);
    void sortingProgress(int processed, int total);
    void sortingFinished();
    void duplicateComparisonStarted(int totalGroups);
    void duplicateComparisonProgress(int processed, int total);
    void duplicatesFound(const QHash<QString, QStringList> &groups, int totalFiles);
    void hashGroupsFound(const QHash<QString, QStringList> &groups);
    void allPhasesCompleted();

private slots:
    void processNextHash();
    void updateHashRate();
    void processCachedFile(const QString &ftpUrl, const QString &localPath, const QString &fileName); // 🚀 Async NPU-Processing
    void storeCalculatedHash(const QString &filePath, const QString &hash); // 🗂️ Hash Storage
    
    // 🚀 GPU/NPU-BESCHLEUNIGTE QUEUES
    void processGpuHashQueue();   // GPU-beschleunigte Hash-Berechnung
    void processNpuFeatureQueue(); // NPU-Feature-Extraktion für Bilder

private:
    void detectHardware();
    void detectHardwareCapabilities(); // Intel-optimierte Hardware-Erkennung
    void detectHardwareAsync(); // 🚀 Async Hardware-Erkennung ohne GUI-Block
    void checkHardwareDetectionComplete(); // Check wenn alle Async-Checks fertig
    void saveHardwareCache(); // Speichere Hardware-Cache in QSettings
    void configureIntelGpu();
    void initializeOpenCL();
    void cleanup();
    void cleanupCache(); // 🧹 Cache-Management
    void downloadFtpFileAsync(const QString &ftpUrl, const QString &localPath, const QString &fileName); // 🚀 Async FTP-Download

    private:
    // Hilfsfunktionen
    QString calculateMD5(const QString &filePath);
    QString calculateSHA1(const QString &filePath);
    QString calculateSHA256(const QString &filePath);
    QString calculateSHA512(const QString &filePath);
    QString calculateXXHash(const QString &filePath);
    QString calculateSHA3(const QString &filePath);
    
    // Vereinfachte hashCalculated Hilfsfunktion
    void emitHashCalculated(const QString &filePath, const QString &hash) {
        bool isLocal = !filePath.startsWith("ftp://");
        emit hashCalculated(filePath, hash, isLocal);
    }

    QString calculateQuickHash(const QString &filePath, Algorithm algo);
    QString calculateFullHash(const QString &filePath, Algorithm algo);
    
    // 🚀 SIMD SHA256-NI: CPU Hardware-accelerated SHA256 (Intel SHA Extensions)
    QString calculateSha256WithNI(const QString &filePath);
    
    // ✅ FTP-Hash-Berechnung mit Credentials-Support
    QString calculateFtpFileHash(const QString &ftpUrl, Algorithm algo);
    QString calculateFtpFileHashWithCredentials(const QString &ftpUrl, const QString &username, const QString &password, Algorithm algo);
    QString calculateFtpStreamHash(const QString &ftpUrl, const QString &username, const QString &password, Algorithm algo);
    QString calculateFileHash(const QString &filePath, Algorithm algo);

    
    ProcessingUnit selectOptimalUnit();
    
    // 🚀 GPU-BESCHLEUNIGTE HASH-BERECHNUNG
    QString calculateGpuAcceleratedHash(const QString &filePath, Algorithm algo);
    QString calculateIntelGpuHash(const QString &filePath, Algorithm algo);
    QString calculateGenericGpuHash(const QString &filePath, Algorithm algo);
    QString calculateOptimizedCpuHash(const QString &filePath, Algorithm algo);
    
    // 🚀 Multi-Stage Hashing: 4KB Pre-Hash für schnelle Filterung
    QString calculate4KBPreHash(const QString &filePath, Algorithm algo);
    
#ifdef ENABLE_OPENCL
    QString calculateOpenCLHash(const QString &filePath, Algorithm algo);
#endif
    
    // ✅ MEMORY MANAGEMENT: Thread-safe temp file handling
    QString createTempFile(const QString &filename);
    void cleanupTempFile(const QString &tempPath);
    
    // 🧠 NPU Helper-Methoden für Feature-Vector-based Processing
    QVector<float> extractImageFeatures(const QString &imagePath);
    QString calculateFeatureVectorHash(const QVector<float> &features);

private:
    Algorithm currentAlgorithm;
    HashMode currentHashMode;
    ProcessingUnit currentUnit;

    // Hardware availability
    bool gpuAvailable;
    bool intelGpuAvailable;
    bool npuAvailable;
    
    // ✅ FTP-Credentials-Speicher
    QString ftpUsername;
    QString ftpPassword;
    QString ftpHost;
    
    // 🚀 FTP-DOWNLOAD-CACHE für Speed-Optimization
    QMap<QString, QString> ftpDownloadCache; // URL → lokaler Pfad
    QMutex cacheMutex;
    QString cacheDirectory; // /tmp/fileduper_cache/
    
    // 🎮 GPU HASH RESULT CACHE: LRU-Cache für wiederholte große Dateien
    // Expected: 3-5x speedup bei Duplicate Scanning von großen Dateien
    QMap<QString, QString> gpuHashCache; // filePath → SHA256 Hash Result
    QList<QString> gpuHashCacheOrder; // LRU order tracking (FIFO)
    static const int GPU_HASH_CACHE_SIZE = 100; // Cache letzte 100 Hashes
    QMutex gpuHashCacheMutex; // Thread-safe cache access
    
    // ⚡ ULTRA-PERFORMANCE: CURL Connection Pool für FTP-Reuse
    void* ftpCurlHandle; // CURL* handle for persistent FTP connection
    QMutex curlMutex; // Thread-safety for CURL handle reuse
    QString currentFtpHost; // Track current FTP connection
    
    // ✅ PresetManager für FTP-Credential-Abfrage
    QObject *presetManager;

    // Async processing
    QTimer *processTimer;
    QTimer *rateTimer;
    QQueue<QString> hashQueue;
    QMutex queueMutex;

    // Performance tracking
    std::atomic<int> hashCount;
    std::atomic<int> hashRate;
    std::atomic<int> processedFiles; // ✅ NEW: Track processed files for progress
    qint64 lastRateUpdate;
    
    // ✅ WORKFLOW STATE: Simple member variables (no Lambda-Capture bugs)
    int currentSortedFiles = 0;
    int currentComparedGroups = 0;
    int totalDuplicateGroups = 0;
    int foundDuplicateGroups = 0;
    int totalFilesToSort = 0;  // 🚀 CRITICAL FIX: Store total files for sorting
    int expectedFilesCount = 0; // 🔢 TOTAL files expected (lokal + FTP)
    QTimer *sortingTimer = nullptr;
    QTimer *compareTimer = nullptr;
    QStringList realDuplicateHashes; // 🔍 ECHTE Duplikat-Hashes für Vergleich
    QHash<QString, QString> fileHashes; // 🗂️ Datei → Hash Mapping für Duplikat-Erkennung
    
    // 🚨 ULTRA-PERFORMANCE: GPU/NPU-basiertes Parallel-Download-System
    int maxConcurrentDownloads = 100;  // 🚀 100 parallele FTP-Downloads mit GPU-Hashing!
    int activeDownloads = 0;           // Aktuell laufende Downloads
    int gpuQueueSize = 0;              // Dateien in GPU-Hash-Queue
    int npuQueueSize = 0;              // Bilder in NPU-Feature-Queue
    QQueue<QString> downloadQueue;     // Warteschlange für FTP-Downloads
    QQueue<QString> gpuHashQueue;      // GPU-beschleunigte Hash-Berechnung
    QQueue<QString> npuFeatureQueue;   // NPU-Feature-Extraktion für Bilder
    QMutex downloadMutex;              // Thread-Safety für Downloads
    QMutex gpuMutex;                   // Thread-Safety für GPU-Queue
    QMutex npuMutex;                   // Thread-Safety für NPU-Queue
    
    // 🎬 FTP CONNECTION LIMITER: Verhindert Server-Überlastung
    QSemaphore *ftpConnectionSemaphore; // Max 3 gleichzeitige FTP-Connections
    
    // ✅ MEMORY OPTIMIZATION: Thread-safe temporary file management
    QMutex tempFileMutex;
    QSet<QString> activeTempFiles; // Track active temp files for cleanup
    QSet<QString> processedFilePaths; // 🛡️ CRITICAL: Track processed files to prevent infinite loops
    
    // 🛑 STOP FLAG: Atomic flag to stop parallel hash workers
    std::atomic<bool> m_stopRequested{false};
    
    // 🧠 NPU LOAD BALANCING: Track active NPU threads (75% reserve for stability)
    std::atomic<int> npuActiveThreads{0};
    static constexpr int NPU_MAX_THREADS = 6;  // 75% of 8 NPU Compute Units
    
    // 🧠 SMART HASH AUTO-DETECT: Per-file algorithm override map (thread-safe)
    QMap<QString, Algorithm> fileAlgorithmOverrides; // filePath → Algorithm (e.g., video.mp4 → XXHASH)
    QMutex algorithmOverrideMutex; // Thread-safety for per-file algorithm selection

#ifdef ENABLE_OPENCL
    // OpenCL context
    cl_context context;
    cl_command_queue queue;
    cl_program program;
    cl_kernel kernel;        // SHA256 Kernel
    cl_kernel md5Kernel;     // MD5 Kernel für schnelle Duplicate Detection
    cl_device_id device;
    bool openclInitialized;
#endif
};

#endif // HASHENGINE_H
