#ifndef SFTPCLIENT_H
#define SFTPCLIENT_H

#include <QObject>
#include <QProcess>
#include <QTimer>
#include <QStringList>
#include <QNetworkAccessManager>
#include <QNetworkReply>

struct SftpFileInfo
{
    QString name;
    QString path;
    qint64 size;
    QDateTime lastModified;
    bool isDirectory;
    QString permissions;
};

class SftpClient : public QObject
{
    Q_OBJECT

public:
    explicit SftpClient(QObject *parent = nullptr);
    ~SftpClient();

    // Connection management
    void setCredentials(const QString &host, int port, const QString &username, const QString &password);
    void connectToHost();
    void disconnectFromHost();
    bool isConnected() const;

    // Directory operations
    void listDirectory(const QString &path = QString());
    QString getCurrentDirectory() const;
    QList<SftpFileInfo> getCurrentDirectoryListing() const;

    // File operations
    void downloadFile(const QString &remotePath, const QString &localPath);
    void uploadFile(const QString &localPath, const QString &remotePath);
    void deleteFile(const QString &filePath);
    void createDirectory(const QString &path);

signals:
    void connected();
    void disconnected();
    void errorOccurred(const QString &message);
    void directoryListingReceived(const QList<SftpFileInfo> &files);
    void fileDownloaded(const QString &localPath);
    void fileUploaded(const QString &remotePath);

private slots:
    void onSftpProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);
    void onSftpProcessError(QProcess::ProcessError error);

private:
    void executeSftpCommand(const QString &command);
    void parseDirectoryListing(const QString &output);
    SftpFileInfo parseListingLine(const QString &line);

    QString hostname;
    int port;
    QString username;
    QString password;
    QString currentDirectory;
    QList<SftpFileInfo> currentListing;

    QProcess *sftpProcess;
    bool isConnectedFlag;
    QTimer *connectionTimer;
};

#endif // SFTPCLIENT_H
