#ifndef FTPDELETEWORKER_H
#define FTPDELETEWORKER_H

#include <QRunnable>
#include <QString>
#include <functional>

class FtpDeleteWorker : public QRunnable
{
public:
    using CompletionCallback = std::function<void(const QString&, bool)>;
    
    FtpDeleteWorker(const QString &host, int port, const QString &user, const QString &pass, 
                    const QString &remotePath, CompletionCallback callback);
    ~FtpDeleteWorker();

    void run() override;

private:
    QString m_host;
    int m_port;
    QString m_user;
    QString m_pass;
    QString m_remotePath;
    CompletionCallback m_callback;
};

#endif // FTPDELETEWORKER_H
