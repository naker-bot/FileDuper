#ifndef FTPDIRECTORYDIALOG_H
#define FTPDIRECTORYDIALOG_H

#include <QDialog>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QDialogButtonBox>
#include <QCheckBox>
#include <QGroupBox>
#include <QStringList>

class FtpDirectoryDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FtpDirectoryDialog(const QString &serverInfo, const QStringList &directories, QWidget *parent = nullptr);
    ~FtpDirectoryDialog();

    QStringList getSelectedDirectories() const;
    bool shouldAddToScanner() const;
    bool shouldStartScanImmediately() const;

private slots:
    void onSelectAll();
    void onSelectNone();
    void onExpandAll();
    void onCollapseAll();
    void onItemChanged(QTreeWidgetItem *item, int column);
    void onItemClicked(QTreeWidgetItem *item, int column);
    void updateSelectionCount();

private:
    void setupUI();
    void populateTree(const QStringList &directories);
    void setItemCheckState(QTreeWidgetItem *item, Qt::CheckState state, bool recursive = true);
    int countCheckedItems(QTreeWidgetItem *parentItem = nullptr) const;

    // UI Components
    QTreeWidget *directoryTree;
    QLabel *serverLabel;
    QLabel *selectionCountLabel;
    QPushButton *selectAllBtn;
    QPushButton *selectNoneBtn;
    QPushButton *expandAllBtn;
    QPushButton *collapseAllBtn;
    QCheckBox *addToScannerCheck;
    QCheckBox *startScanCheck;
    QDialogButtonBox *buttonBox;

    // Data
    QString m_serverInfo;
    QStringList m_directories;
    QMap<QString, QTreeWidgetItem*> pathToItemMap;
};

#endif // FTPDIRECTORYDIALOG_H
