#ifndef DIRECTORYSELECTIONDIALOG_H
#define DIRECTORYSELECTIONDIALOG_H

#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QGroupBox>
#include <QTreeWidget>
#include <QListWidget>
#include <QPushButton>
#include <QCheckBox>
#include <QLineEdit>
#include <QLabel>
#include <QProgressBar>
#include <QTimer>
#include <QStringList>
#include <QSet>

class NetworkScanner;
class PresetManager;
struct NetworkService; // Forward declaration

class DirectorySelectionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DirectorySelectionDialog(QWidget *parent = nullptr);
    ~DirectorySelectionDialog();

    // Configuration
    void setupLocalDirectoryTree();
    void setupNetworkServicesPanel();
    void enableMultiSelection(bool enabled);
    void enableEditAndDelete(bool enabled);

    // Network operations
    void startAutomaticPortScan();
    void setCustomIpRange(const QString &range);

    // Results
    QStringList getSelectedDirectories() const;
    QStringList getSelectedLocalDirectories() const;
    QStringList getSelectedNetworkDirectories() const;

signals:
signals:
    void directoriesSelected(const QStringList &local, const QStringList &network);
    void networkServiceSelected(const QString &ip, const QString &port);
    void networkServiceFound(const NetworkService &service);

private slots:
    void addLocalDirectory();
    void removeSelectedDirectories();
    void onLocalDirectoryDoubleClicked(QTreeWidgetItem *item);
    void onNetworkServiceDoubleClicked(QTreeWidgetItem *item);
    void showLocalContextMenu(const QPoint &pos);
    void showNetworkContextMenu(const QPoint &pos);
    void updatePortScanProgress();
    void expandAllTrees();
    void collapseAllTrees();
    void selectAllDirectories();
    void deselectAllDirectories();

private:
    void setupUI();
    void setupLocalPanel();
    void setupNetworkPanel();
    void setupButtons();
    void populateLocalDirectories();
    void loadSystemDirectories();
    void loadUserDirectories();
    void loadMountPoints();
    void ensureParentChildVisibility(QTreeWidgetItem *item);
    void connectToNetworkService(const NetworkService &service);

private:
    // UI Components
    QSplitter *mainSplitter;

    // Left panel - Local directories
    QWidget *localWidget;
    QGroupBox *localGroup;
    QTreeWidget *localTree;
    QPushButton *addLocalBtn;
    QPushButton *refreshLocalBtn;
    QPushButton *expandAllBtn;
    QLabel *localCountLabel;

    // Right panel - Network services
    QWidget *networkWidget;
    QGroupBox *networkGroup;
    QLineEdit *ipRangeEdit;
    QPushButton *scanNetworkBtn;
    QCheckBox *autoScanEnabled;
    QTreeWidget *networkTree;
    QProgressBar *scanProgress;
    QLabel *scanStatusLabel;
    QLabel *networkCountLabel;

    // Bottom buttons
    QWidget *buttonWidget;
    QPushButton *selectAllBtn;
    QPushButton *deselectAllBtn;
    QPushButton *okBtn;
    QPushButton *cancelBtn;

    // Data
    NetworkScanner *networkScanner;
    PresetManager *presetManager;
    QTimer *portScanTimer;
    QStringList selectedLocalDirs;
    QStringList selectedNetworkDirs;
    QSet<QString> excludedPaths;

    // Settings
    bool multiSelectionEnabled;
    bool editDeleteEnabled;
    QString currentIpRange;
};

#endif // DIRECTORYSELECTIONDIALOG_H
