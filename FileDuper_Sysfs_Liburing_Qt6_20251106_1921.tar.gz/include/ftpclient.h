#ifndef FTPCLIENT_H
#define FTPCLIENT_H

#include <QObject>
#include <QStringList>
#include <QQueue>
#include <QDateTime>
#include <QThread>
#include <QTimer>
#include <QTextStream>
#include <QRegularExpression>
#include <QFile>
#include <QDir>
#include <QFileInfo>
#include <QDebug>

class FtpClient : public QObject
{
    Q_OBJECT

public:
    explicit FtpClient(QObject *parent = nullptr);
    ~FtpClient();

    // Connection management
    void setCredentials(const QString &host, int port, const QString &username, const QString &password);
    void connectToHost();
    void disconnectFromHost();
    bool isConnected() const;

    // libcurl FTP operations - main interface
    void list(const QString& dir);  // Asynchronous FTP LIST for hierarchical tree
    void listFiles(const QString& dir);  // List files in directory for scanner
    void remove(const QString& remoteFile);

    // Legacy compatibility (for old GUI code)
    void listDirectory(const QString &path = QString());
    QString getCurrentDirectory() const;
    QStringList getCurrentDirectoryListing() const;
    
    // 🔥 NEW: Getter für Host/Port (für rekursives FTP-Scanning)
    QString getHost() const { return m_host; }
    int getPort() const { return m_port; }

signals:
    void connected();
    void disconnected();
    void error(const QString &message);
    void directoryListingReceived(const QStringList &files);
    
    // libcurl-specific signals
    void listFinished(const QStringList &allDirs, bool success);
    void filesListFinished(const QString &directory, const QStringList &files, bool success);
    void subdirectoriesFound(const QString &directory, const QStringList &subdirs);  // 🆕 Neue Signal für Subdirectories
    void removeFinished(const QString &file, bool success);
    void scanProgress(const QString &directory, int iteration, int totalFiles);  // Progress during recursive scan

private:
    // libcurl FTP implementation
    QStringList performFtpList(const QString& dir);
    QStringList parseProftpdList(const QStringList& lines);
    QStringList parseProftpdFiles(const QStringList& lines);  // Parse files from FTP LIST
    QStringList listAllDirsRecursive(const QString& rootDir);

    // Connection details
    QString m_host;      // Changed to m_host for libcurl consistency
    int m_port;          // Changed to m_port for libcurl consistency
    QString m_user;      // Changed to m_user for libcurl consistency
    QString m_pass;      // Changed to m_pass for libcurl consistency
    bool isConnectedToHost;
    
    // 🚀 OPTIMIERUNG 1: Connection Pooling für Wiederverwendung
    void* m_curlHandle;  // Persistent CURL handle
    QDateTime m_lastUsed;
    bool m_keepAlive;

    // Current state
    QString currentDirectory;
    QStringList currentListing;
};

#endif // FTPCLIENT_H
