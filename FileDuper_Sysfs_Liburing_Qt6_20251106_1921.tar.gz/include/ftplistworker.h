#ifndef FTPLISTWORKER_H
#define FTPLISTWORKER_H

#include <QRunnable>
#include <QObject>
#include <QString>
#include <QStringList>
#include <curl/curl.h>

// Async FTP LIST Worker for QThreadPool
class FtpListWorker : public QObject, public QRunnable
{
    Q_OBJECT

public:
    FtpListWorker(const QString &host, int port, const QString &user, const QString &pass, const QString &dir);
    ~FtpListWorker();

    void run() override;

signals:
    void listCompleted(const QString &directory, const QStringList &lines, bool success);

private:
    static size_t writeToString(void *ptr, size_t size, size_t nmemb, void *stream);

    QString m_host;
    int m_port;
    QString m_user;
    QString m_pass;
    QString m_dir;
};

#endif // FTPLISTWORKER_H
