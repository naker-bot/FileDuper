#include <cmath>
#ifndef NPUMANAGER_H
#define NPUMANAGER_H

#include <QObject>
#include <QProcess>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <QDebug>
#include <algorithm>
#include <QSize>
#include <QVector>
#include <QHash>
#include <cmath>

#ifdef OPENCL_AVAILABLE
#include <CL/cl.h>
#endif

class NpuManager : public QObject
{
    Q_OBJECT

public:
    enum ProcessingUnit
    {
        AUTO_SELECT,      // Automatic best available
        CPU_ALL_CORES,    // Always available fallback
        GPU_OPENCL,       // Generic OpenCL acceleration
        INTEL_GPU_OPENCL, // Intel GPU optimized (Arc, Xe, UHD)
        NPU_LEVEL_ZERO    // Intel NPU via Level Zero API
    };

    enum NpuCapability
    {
        NPU_INFERENCE,  // AI inference acceleration
        NPU_HASH_ACCEL, // Hash computation acceleration
        NPU_SIMILARITY, // Content similarity detection
        NPU_IMAGE_PROC  // Image processing
    };

    // 🎯 FEATURE-VEKTOR: Struktur für NPU-basierte Bildvergleiche
    struct ImageFeature {
        QString filePath;
        QVector<float> featureVector;  // 512-dimensional feature vector from NPU
        QString perceptualHash;        // Perceptual hash for quick pre-filtering  
        QSize imageSize;              // Image dimensions for additional filtering
        qint64 timestamp;             // Processing timestamp
        float confidence;             // NPU confidence score
        
        // Ähnlichkeitsberechnung zwischen zwei Feature-Vektoren
        float similarity(const ImageFeature &other) const {
            if (featureVector.size() != other.featureVector.size()) return 0.0f;
            
            float dotProduct = 0.0f, normA = 0.0f, normB = 0.0f;
            for (int i = 0; i < featureVector.size(); ++i) {
                dotProduct += featureVector[i] * other.featureVector[i];
                normA += featureVector[i] * featureVector[i];
                normB += other.featureVector[i] * other.featureVector[i];
            }
            
            if (normA == 0.0f || normB == 0.0f) return 0.0f;
            return dotProduct / (sqrt(normA) * sqrt(normB)); // Cosine similarity
        }
        
        bool operator==(const ImageFeature &other) const {
            return filePath == other.filePath;
        }
    };

    // 🎯 DUPLIKAT-GRUPPE: NPU-erkannte ähnliche Bilder
    struct NpuDuplicateGroup {
        ImageFeature originalImage;           // Referenzbild (höchste Qualität/Auflösung)
        QList<ImageFeature> similarImages;   // Ähnliche/duplizierte Bilder
        float avgSimilarity;                  // Durchschnittliche Ähnlichkeit in der Gruppe
        int groupSize() const { return similarImages.size() + 1; }
    };

    explicit NpuManager(QObject *parent = nullptr);
    ~NpuManager();

    // Hardware detection
    bool isNpuAvailable() const { return npuAvailable; }
    bool isIntelGpuAvailable() const { return intelGpuAvailable; }
    bool isGpuAvailable() const { return gpuAvailable; }

    // Processing unit selection
    void setProcessingUnit(ProcessingUnit unit);
    ProcessingUnit getCurrentUnit() const { return currentUnit; }
    ProcessingUnit selectOptimalUnit();

    // NPU capabilities
    bool hasCapability(NpuCapability capability) const;
    QStringList getSupportedCapabilities() const;

    // Performance monitoring
    int getNpuUtilization() const;
    int getGpuUtilization() const;
    QString getHardwareInfo() const;

    // OpenCL interface
    bool initializeOpenCL();
    void cleanupOpenCL();
    
    // 🧠 NPU-BILDVERARBEITUNG: Intelligente Verarbeitung großer Bilddatensätze
    QStringList processImageBatch(const QStringList &imagePaths);
    
    // 🚀 ULTRA-FAST NPU-Bildverarbeitung Methoden (Optimiert) - PUBLIC für Scanner-Zugriff
    QStringList processImagesWithNpuUltraFast(const QStringList &imagePaths);
    QStringList processImagesWithIntelGpuUltraFast(const QStringList &imagePaths);
    QStringList processImagesWithCpuUltraFast(const QStringList &imagePaths);
    
    // 🧠 FEATURE-VECTOR-BASIERTE DUPLIKATERKENNUNG (ohne Hash-Vergleich)
    QList<QStringList> findFeatureBasedDuplicates(const QStringList &processedImages);
    
    // 🎯 INSTANT Bildtyp-Erkennung (Nur Dateierweiterung) - PUBLIC
    QStringList filterImageFilesByExtension(const QStringList &filePaths);
    bool isImageFile(const QString &filePath);
    
    // 🎯 NEUE NPU-FEATURE-VERGLEICHSMETHODEN: Ähnlich wie Hash-Engine
    QList<ImageFeature> extractImageFeatures(const QStringList &imagePaths);
    QList<NpuDuplicateGroup> findSimilarImages(const QList<ImageFeature> &features, float similarityThreshold = 0.85f);
    ImageFeature extractSingleImageFeature(const QString &imagePath);
    
    // 🔍 VERGLEICHSMODI: Verschiedene Ähnlichkeitsstufen
    enum SimilarityMode {
        STRICT_DUPLICATES,    // >0.95 similarity (nahezu identisch)
        NEAR_DUPLICATES,      // >0.85 similarity (sehr ähnlich) 
        SIMILAR_IMAGES,       // >0.70 similarity (ähnliche Motive)
        LOOSE_SIMILARITY      // >0.50 similarity (grobe Ähnlichkeit)
    };
    
    // Ähnlichkeitssuche mit konfigurierbaren Modi
    QList<NpuDuplicateGroup> findSimilarImages(const QList<ImageFeature> &features, SimilarityMode mode);
    float getSimilarityThreshold(SimilarityMode mode) const;

public slots:
    void detectHardware();
    void updateUtilization();

signals:
    void hardwareDetected();
    void utilizationChanged(int npuLoad, int gpuLoad);
    void capabilityChanged(NpuCapability capability, bool available);
    void error(const QString &message);
    // 🎨 Neue Signale für Bildverarbeitung
    void npuLoadChanged(int load);
    void gpuLoadChanged(int load);
    void imageBatchProcessed(const QStringList &processedImages);
    
    // 🎯 NEUE SIGNALE für Feature-basierte Bildvergleiche
    void imageFeatureExtracted(const ImageFeature &feature);
    void duplicateGroupFound(const NpuDuplicateGroup &group);
    void featureExtractionProgress(int processed, int total);
    void featureExtractionMessage(const QString &message);
    void similarityAnalysisCompleted(const QList<NpuDuplicateGroup> &groups);

private slots:
    void onHardwareCheckFinished();

private:
    // Hardware detection
    void detectIntelNpu();
    void detectIntelGpu();
    void detectGenericGpu();

    // OpenCL management
    void configureIntelGpu();
    void configureIntelNpu();
    int calculateGpuLoadPercentage(const QByteArray &output) const;
    int queryNpuUtilization() const;
    
    // 🎨 NPU-Bildverarbeitung Methoden (Standard)
    QStringList processImagesWithNpu(const QStringList &imagePaths);
    QStringList processImagesWithIntelGpu(const QStringList &imagePaths);
    QStringList processImagesWithCpu(const QStringList &imagePaths);
    
    // 🎯 FEATURE-EXTRAKTION: NPU-basierte Bildanalyse
    ImageFeature extractFeatureWithNpu(const QString &imagePath);
    ImageFeature extractFeatureWithIntelGpu(const QString &imagePath); 
    ImageFeature extractFeatureWithCpu(const QString &imagePath);
    
    // 🧮 ÄHNLICHKEITSANALYSE: Vergleich von Feature-Vektoren
    bool areImagesSimilar(const ImageFeature &img1, const ImageFeature &img2, float threshold) const;
    QVector<float> generateMockFeatureVector(const QString &imagePath); // Für Entwicklung/Tests
    QString calculatePerceptualHash(const QString &imagePath);
    
    // 🧠 ERWEITERTE FEATURE-VECTOR-METHODEN für echte NPU-Funktionalität
    QVector<float> generateAdvancedFeatureVector(const QString &imagePath);
    float calculateCosineSimilarity(const QVector<float> &vec1, const QVector<float> &vec2);
    
    // 🔍 GRUPPENBILDUNG: Clustering ähnlicher Bilder
    QList<NpuDuplicateGroup> clusterSimilarImages(const QList<ImageFeature> &features, float threshold);
    ImageFeature selectBestQualityImage(const QList<ImageFeature> &candidates);

    // Hardware state
    bool npuAvailable;
    bool intelGpuAvailable;
    bool gpuAvailable;
    ProcessingUnit currentUnit;

    // OpenCL context
#ifdef OPENCL_AVAILABLE
    cl_context context;
    cl_command_queue queue;
    cl_program program;
    cl_kernel kernel;
    cl_device_id device;
    bool openclInitialized;
#endif

    // Monitoring
    QTimer *utilizationTimer;
    int currentNpuLoad;
    int currentGpuLoad;

    // Hardware info
    QString npuDeviceInfo;
    QString gpuDeviceInfo;
    QStringList capabilities;
};

#endif // NPUMANAGER_H
