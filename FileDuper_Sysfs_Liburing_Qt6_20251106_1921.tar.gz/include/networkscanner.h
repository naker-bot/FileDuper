#ifndef NETWORKSCANNER_H
#define NETWORKSCANNER_H

#include <QObject>
#include <QString>
#include <QTimer>
#include <QTcpSocket>
#include <QHostAddress>
#include <QNetworkInterface>

struct NetworkService
{
    QString ip;
    int port;
    QString service;
    QString status;
    qint64 responseTime;
};

struct NetworkRange
{
    QString name;
    QString cidr;
    QString description;
    bool isAutoDetected;
    QString interfaceName;
};

class NetworkScanner : public QObject
{
    Q_OBJECT

public:
    explicit NetworkScanner(QObject *parent = nullptr);
    ~NetworkScanner();

    // Network Range Management
    QStringList autoDetectNetworkRanges();  // 🌐 Changed to return QStringList
    QList<NetworkRange> getAvailableNetworkRanges() const;
    void addCustomNetworkRange(const QString &name, const QString &cidr, const QString &description = "");
    void removeNetworkRange(const QString &name);
    void setActiveNetworkRange(const QString &name);
    QString getActiveNetworkRange() const;
    
    // IP Range Presets
    void loadNetworkPresets();
    void saveNetworkPresets();
    QStringList getNetworkPresetNames() const;
    
    // Configuration
    void setIpRange(const QString &range);
    void setPorts(const QList<int> &ports);
    void setTimeout(int msec);
    
    // Port presets for file transfer services
    void setPortPreset(const QString &presetName);
    QStringList getAvailablePresets() const;
    QList<int> getPortsForPreset(const QString &presetName) const;
    QString getCurrentPresetName() const;

    // Scanning
    void startScan();
    void scanAllAvailableRanges();  // Scan all auto-detected + custom ranges
    void stopScan();
    bool isScanning() const;

    // Results
    QList<NetworkService> getFoundServices() const;
    int getProgress() const;

signals:
    void serviceFound(const NetworkService &service);
    void scanProgress(int current, int total);
    void scanFinished();
    void networkRangeDetected(const NetworkRange &range);
    void networkRangeChanged(const QString &rangeName);
    void error(const QString &message);

private slots:
    // Chunk scanning (replaces old single-socket methods)
    // Slots are handled via lambda functions in chunk methods

private:
    // Network range management
    QList<NetworkRange> m_networkRanges;
    QString m_activeNetworkRange;
    QString m_presetConfigFile;
    
    // Auto-detection helpers
    QString detectNetworkFromInterface(const QNetworkInterface &interface);
    QHostAddress getNetworkAddress(const QHostAddress &ip, const QHostAddress &netmask);
    QString cidrFromNetmask(const QHostAddress &netmask);
    
    // IP range parsing and generation
    QStringList generateIpRange(const QString &cidr);
    bool isValidCidr(const QString &cidr);
    
    void parseIpRange(const QString &range);
    void generateTargets();
    void resetScan();
    // Service detection and analysis
    QString detectService(const QString &ip, int port);
    QString getServiceDescription(int port);
    bool isFileTransferService(int port);
    QStringList getSupportedFileTransferProtocols();

    // Enhanced scanning (stable lightning methods)
    void performServiceBanner(const QString &ip, int port);
    void performEnhancedServiceDetection(const QString &ip, int port);
    void performSafeServiceDetection(const QString &ip, int port);
    void analyzeServiceBanner(const QString &ip, int port, const QString &banner);
    void analyzeEnterpriseServiceBanner(const QString &ip, int port, const QString &banner);
    void analyzeSafeServiceBanner(const QString &ip, int port, const QString &banner);

private:
    // Core data (no more single socket/timer)
    QString ipRange;
    QStringList baseIps;
    QList<int> scanPorts;
    QList<QPair<QString, int>> scanTargets;
    QList<NetworkService> foundServices;
    QMap<QString, QList<int>> portPresets; // File-Transfer-Port-Presets

    // Parallel chunk scanning (30 chunks)
    QList<QList<QPair<QString, int>>> scanChunks;
    QList<QTimer*> chunkTimers;
    QList<QTcpSocket*> chunkSockets;
    int completedChunks;
    int totalChunks;
    bool scanFinishedReported;  // 🔒 Verhindere mehrfache "SCAN FINISHED" Messages
    static const int MAX_CHUNKS = 1000;

    int currentTargetIndex;
    int socketTimeout;
    bool scanning;
    
    // Initialization
    void initializePortPresets();
    
    // Parallel chunk scanning methods
    void createScanChunks();
    void startChunkScan(int chunkIndex);
    void processChunkTarget(int chunkIndex, int targetIndex);
    void onChunkCompleted(int chunkIndex);
    void cleanupChunkResources();

    // Default ports for file transfer services (Lightning-stable)
    static const QList<int> DEFAULT_PORTS;
};

#endif // NETWORKSCANNER_H
