#ifndef PRESETMANAGER_H
#define PRESETMANAGER_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QSettings>
#include <QTimer>
#include <QFileInfo>
#include <QDir>
#include <QMutex>
#include <QHash>
#include <QMultiMap>
#include <QVariantMap>

struct FileTypeMapping
{
    QString extension; // .mp4, .iso, .blend, .csv
    QString category;  // "Media", "Backups", "3D Design", "Office"
    bool autoAdd;      // Learned behavior from user interactions
    int frequency;     // How often this type was encountered
};

struct LoginData
{
    QString username;
    QString password;
    QString service; // "FTP", "SSH", "SMB"
    qint64 lastUsed;
    bool saveCredentials;
    bool autoLogin; // NEW: Auto-login functionality

    bool isValid() const { return !username.isEmpty(); }
};

struct DirectoryPreset
{
    QString name; // "Media Files", "Project Backups"
    QString description;
    QStringList paths; // Vereinfacht: Ein Pfad-Array statt getrennt local/network
    QStringList fileTypes;
    qint64 lastUsed;
    int usageCount;
    QString category; // "Media", "Backups", etc.
};

class PresetManager : public QObject
{
    Q_OBJECT

public:
    explicit PresetManager(QObject *parent = nullptr);
    ~PresetManager();

    // Settings management
    void saveSettings();
    void loadSettings();

    // Directory presets
    void addDirectoryPreset(const DirectoryPreset &preset);
    void removeDirectoryPreset(const QString &name);
    QList<DirectoryPreset> getDirectoryPresets() const;
    DirectoryPreset getPreset(const QString &name) const;

    // Smart file type detection with hardware optimization
    void analyzeNewFileTypes(const QStringList &filePaths);
    void addFileTypeMapping(const QString &extension, const QString &category, bool permanent = false);
    void removeFileTypeMapping(const QString &extension);
    QStringList getFileTypesForCategory(const QString &category) const;
    QStringList getAllCategories() const;
    
    // Hardware-optimized processing
    QString getOptimalHashAlgorithm(const QString &fileExtension) const;
    QString getOptimalHashAlgorithm(const QString &category, const QString &fileExtension) const;
    bool shouldUseNpuProcessing(const QString &fileExtension) const;
    bool shouldUseCpuProcessing(const QString &fileExtension) const;

    // Login management
    void saveLogin(const QString &host, int port, const LoginData &login);
    void removeLogin(const QString &host, int port);
    Q_INVOKABLE LoginData getLogin(const QString &host, int port) const;
    QList<QPair<QString, LoginData>> getAllLogins() const;

    // Auto-categorization
    QString suggestCategoryForExtension(const QString &extension) const;
    bool shouldShowAutoAddDialog(const QString &extension) const;
    void markExtensionAsIgnored(const QString &extension);
    void markExtensionAsUninteresting(const QString &extension);

    // Usage statistics
    void recordPresetUsage(const QString &presetName);
    void recordFileTypeUsage(const QString &extension);
    QStringList getMostUsedPresets(int count = 5) const;
    QStringList getMostUsedFileTypes(int count = 10) const;

    // Path filtering
    QStringList getSystemExcludePaths() const;
    bool shouldExcludePath(const QString &path) const;

signals:
    void newFileTypesDetected(const QStringList &extensions);
    void autoAddDialogRequested(const QString &extension, const QString &suggestedCategory);
    void settingsSaved();
    void presetsChanged();

private slots:
    void autoSaveSettings();
    void analyzeFileTypes();

private:
    void initializeDefaultSettings();
    void initializeDefaultFileTypes();
    void initializeSystemExcludes();
    void detectNewFileTypes(const QStringList &extensions);
    QString getFileExtension(const QString &filePath) const;
    QString getCategoryForExtension(const QString &extension) const;

    // File paths
    QString getSettingsFilePath() const;
    QString getLoginFilePath() const;

private:
    // Settings storage
    QSettings *mainSettings;  // ~/.fileduper_settings.ini
    QSettings *loginSettings; // ~/.fileduper_login.ini

    // Data storage
    QHash<QString, FileTypeMapping> fileTypeMappings;
    QHash<QString, DirectoryPreset> directoryPresets;
    QHash<QString, LoginData> loginData; // Key: "host:port"
    QStringList systemExcludePaths;
    QStringList ignoredExtensions;
    QStringList uninterestingExtensions;
    
    // Hardware optimization maps
    QHash<QString, QStringList> defaultCategories;
    QHash<QString, QString> hashPreferences;      // Category -> Hash Algorithm
    QHash<QString, QStringList> npuCategories;    // NPU-optimized categories

    // Auto-save timer
    QTimer *autoSaveTimer;
    QMutex settingsMutex;
    
    // Private methods
    void loadLoginData(); // ✅ Login-Daten beim Start laden

    // Default categories and mappings
    void setupDefaultMappings();
};

#endif // PRESETMANAGER_H
