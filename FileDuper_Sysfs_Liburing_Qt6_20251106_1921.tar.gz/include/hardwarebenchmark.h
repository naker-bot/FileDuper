#ifndef HARDWAREBENCHMARK_H
#define HARDWAREBENCHMARK_H

#include <QObject>
#include <QString>
#include <QThread>

struct HardwareCapabilities {
    int cpuCores;
    int recommendedThreads;
    int maxParallelFtpScans;
    int maxParallelHashing;
    qint64 availableRamMB;
    bool hasNPU;
    bool hasGPU;
    QString gpuName;
    
    // 🚀 CPU Instruction Set Extensions
    bool hasSHANI;      // SHA-1/SHA-256 Hardware Acceleration
    bool hasSHA512NI;   // SHA-512 Hardware Acceleration  
    bool hasAVX2;       // Advanced Vector Extensions 2
    bool hasAVX512;     // Advanced Vector Extensions 512
    
    // Performance scores (0-100)
    int cpuScore;
    int ioScore;
    int networkScore;
};

class HardwareBenchmark : public QObject
{
    Q_OBJECT

public:
    explicit HardwareBenchmark(QObject *parent = nullptr);
    
    // Führt automatischen Hardware-Test durch
    HardwareCapabilities detectAndBenchmark();
    
    // 💾 INI-Speicherung: Lade/Speichere Benchmark-Ergebnisse
    static bool loadBenchmarkFromINI(HardwareCapabilities &caps);
    static void saveBenchmarkToINI(const HardwareCapabilities &caps);
    static bool hasSavedBenchmark();  // Prüft ob Benchmark-Daten in INI existieren
    
    // Einzelne Tests
    int detectCpuCores();
    qint64 detectAvailableRAM();
    bool detectNPU();
    bool detectGPU(QString &gpuName);
    
    // Performance-Tests
    int benchmarkCpuSpeed();      // CPU Multi-Threading Test
    int benchmarkDiskIO();        // Disk I/O Geschwindigkeit
    int benchmarkNetworkSpeed();  // Netzwerk-Durchsatz Test
    
    // Empfohlene Einstellungen basierend auf Hardware
    static int recommendThreadCount(int cpuCores, int cpuScore);
    static int recommendFtpParallel(int cpuCores, int networkScore);
    static int recommendHashParallel(int cpuCores, int ioScore);

signals:
    void benchmarkProgress(const QString &message, int progress);
    void benchmarkComplete(const HardwareCapabilities &caps);

private:
    void detectCpuFeatures(HardwareCapabilities &caps);  // 🚀 CPUID Instruction Set Detection
    HardwareCapabilities m_capabilities;
};

#endif // HARDWAREBENCHMARK_H
