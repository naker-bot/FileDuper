# FileDuper Qt6 (Modern Systems)

## 🎯 Zielplattform
- Arch Linux (current)
- Debian 12+ (Bookworm)
- Ubuntu 24.04+ (Noble)
- Fedora 38+
- Andere moderne Linux-Distributionen mit Qt6

## 📦 Installation

```bash
sudo ./install.sh
```

## 🔧 Manuelle Installation

**Arch Linux:**
```bash
sudo pacman -S qt6-base libcurl-gnutls
sudo install -m 755 FileDuper /usr/local/bin/FileDuper
```

**Debian/Ubuntu:**
```bash
sudo apt install qt6-base-dev libqt6widgets6 libqt6network6 libqt6concurrent6 libcurl4
sudo install -m 755 FileDuper /usr/local/bin/FileDuper
```

## ✨ Features

### Parallele FTP-Operations
- ✅ 20 simultane FTP-Verbindungen
- ✅ Thread-safe async Operations
- ✅ QFutureWatcher lifecycle management
- ✅ Connection Pool mit Wiederverwendung
- ✅ 5-Minuten FTP-Cache

### Duplicate Scanner
- ✅ Multi-threaded Hashing (MD5/SHA256/SHA512/xxHash)
- ✅ Hardware-beschleunigte Hashing (OpenCL/NPU)
- ✅ Batch-Deletion (20x schneller)
- ✅ Safe deletion mit send2trash

### GUI Features
- ✅ Non-blocking responsive GUI
- ✅ Real-time progress updates
- ✅ Network discovery scanner
- ✅ Auto-login für FTP/SFTP

## 🐛 Bugfixes in dieser Version
- ✅ QFuture lifecycle management (kein vorzeitiges destroy)
- ✅ Thread-safe clientMap (copy by value statt reference)
- ✅ Watcher-based async completion
- ✅ Kein GUI-Freeze mehr bei FTP-Scans

## 📊 System-Anforderungen
- **OS**: Linux mit Qt6-Support
- **RAM**: Mindestens 512 MB
- **Display**: X11 oder Wayland
- **Network**: FTP/SFTP/SMB-Zugriff (optional)

## 🚀 Start
```bash
FileDuper
```

## 📝 Build-Info
- **Qt-Version**: 6.x
- **C++ Standard**: 17
- **Compiler**: GCC/Clang
- **Features**: QtConcurrent, FTP, Network Discovery
