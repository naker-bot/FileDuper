#!/bin/bash
# FileDuper Qt6 Installation Script

echo "🚀 FileDuper Qt6 Installation..."
echo "================================="

# Detect system
if command -v pacman &>/dev/null; then
    echo "📦 Arch Linux detected - installing Qt6 dependencies..."
    sudo pacman -S --needed --noconfirm qt6-base libcurl-gnutls
elif command -v apt-get &>/dev/null; then
    echo "📦 Debian/Ubuntu detected - installing Qt6 dependencies..."
    sudo apt-get update
    sudo apt-get install -y qt6-base-dev libqt6widgets6 libqt6network6 libqt6concurrent6 libcurl4
else
    echo "⚠️  Unknown system - please install Qt6 manually"
fi

# Install binary
echo ""
echo "📥 Installing FileDuper to /usr/local/bin..."
sudo install -m 755 FileDuper /usr/local/bin/FileDuper

echo ""
echo "✅ Installation complete!"
echo "Start FileDuper with: FileDuper"
